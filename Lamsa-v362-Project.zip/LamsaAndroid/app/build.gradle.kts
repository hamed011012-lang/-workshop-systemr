plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.lamsa.workshop"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.lamsa.workshop"
        minSdk = 23
        targetSdk = 35
        versionCode = 36001
        versionName = "360.1"
    }
    signingConfigs { getByName("debug") { storeFile = file("signing/debug.keystore"); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android" } }
    buildTypes { getByName("release") { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.core:core-ktx:1.15.0")
}
