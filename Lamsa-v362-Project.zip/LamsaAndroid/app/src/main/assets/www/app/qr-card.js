// QR generation stays local. Library: Project Nayuki, MIT, app/vendor/qrcodegen.js.
(function(g){'use strict';
function svg(text){if(typeof text!=='string'||text.length>1000)throw Error('نص رمز البطاقة غير صالح');const qr=g.qrcodegen.QrCode.encodeText(text,g.qrcodegen.QrCode.Ecc.MEDIUM),border=4,size=qr.size+border*2;let path='';for(let y=0;y<qr.size;y++)for(let x=0;x<qr.size;x++)if(qr.getModule(x,y))path+='M'+(x+border)+','+(y+border)+'h1v1h-1z ';return '<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="رمز بطاقة التنفيذ" viewBox="0 0 '+size+' '+size+'" width="130" height="130" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="white"/><path d="'+path+'" fill="black"/></svg>';}
g.WSQR=Object.freeze({svg});
})(window);
