(function(g){'use strict';
const clone=x=>JSON.parse(JSON.stringify(x)),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),norm=x=>String(x||'').trim().toLowerCase().replace(/\s+/g,' ');
let options,draft=null,saving=false,loadedKey='';
function key(){return 'ws_price_grid_v359_'+(options.uid||'local');}
function status(t){const e=document.getElementById('ws-price-status');if(e)e.textContent=t;}
function persist(){try{localStorage.setItem(key(),JSON.stringify(draft));}catch(e){status('تعذر حفظ المسودة على الجهاز؛ أبق الصفحة مفتوحة.');}}
function keyed(){return options.items.map((r,i)=>({...clone(r),_key:r.id||'local-'+i}));}
function begin(){if(!draft){draft={base:keyed(),rows:keyed()};persist();}return draft;}
function dirty(){return !!draft;}
function render(opts){options=opts;const host=document.getElementById('priceTags');if(!host)return;
 if(loadedKey!==key()){loadedKey=key();draft=null;try{const d=JSON.parse(localStorage.getItem(key())||'null');if(d&&Array.isArray(d.rows)&&Array.isArray(d.base))draft=d;}catch(_){};}
 const focused=host.contains(document.activeElement)?document.activeElement:null,focusKey=focused?.closest('tr')?.dataset.key,focusClass=focused?.className,caret=focused?.selectionStart;
 const rows=draft?draft.rows:keyed();host.style.display='block';
 host.innerHTML=`<p>عدّل الأسماء والأسعار وأضف الأصناف، ثم احفظها مرة واحدة. كميات المخزن لا تتغير هنا.</p><div class="ws-price-toolbar"><button type="button" id="ws-price-add">＋ إضافة صف</button><button type="button" id="ws-price-save">حفظ جميع التغييرات</button><button type="button" id="ws-price-cancel">إلغاء التعديلات</button></div><p id="ws-price-status" role="status">${saving?'جارٍ الحفظ؛ المسودة محفوظة على هذا الجهاز.':draft?'لديك تعديلات غير محفوظة.':'الأسعار الحالية'}</p><div class="ws-price-scroll"><table class="ws-price-table"><thead><tr><th>اسم الصنف</th><th>السعر</th><th>حذف / استعادة</th></tr></thead><tbody>${rows.map(r=>`<tr data-key="${esc(r._key)}" class="${r._deleted?'ws-price-deleted':''}"><td><input class="ws-price-name" aria-label="اسم الصنف" value="${esc(r.name)}" ${r._deleted||saving?'disabled':''}></td><td><input class="ws-price-value" aria-label="سعر الصنف" inputmode="decimal" value="${esc(r.price)}" ${r._deleted||saving?'disabled':''}></td><td><button type="button" class="ws-price-remove" ${saving?'disabled':''}>${r._deleted?'استعادة':'حذف'}</button></td></tr>`).join('')}</tbody></table></div>`;
 host.querySelectorAll('tr[data-key]').forEach(tr=>{
  for(const [selector,field] of [['.ws-price-name','name'],['.ws-price-value','price']])tr.querySelector(selector).oninput=e=>{if(saving)return;const r=begin().rows.find(x=>x._key===tr.dataset.key);r[field]=e.target.value;persist();status('تعديلات غير محفوظة — اضغط «حفظ جميع التغييرات».');};
  tr.querySelector('button').onclick=()=>{if(saving)return;const r=begin().rows.find(x=>x._key===tr.dataset.key);if(r.id&&!r._new&&!options.canDelete){status('حذف صنف محفوظ متاح للمدير فقط.');return;}r._deleted=!r._deleted;persist();render(options);};
 });
 host.querySelector('#ws-price-add').onclick=add;host.querySelector('#ws-price-save').onclick=save;host.querySelector('#ws-price-cancel').onclick=()=>{if(saving)return;if(draft&&!confirm('إلغاء تعديلات جدول الأسعار غير المحفوظة؟'))return;draft=null;localStorage.removeItem(key());render(options);};
 host.querySelectorAll('.ws-price-toolbar button').forEach(b=>b.disabled=saving);
 if(focusKey&&!saving){const tr=[...host.querySelectorAll('tr[data-key]')].find(r=>r.dataset.key===focusKey),input=tr&&[...tr.querySelectorAll('input')].find(i=>i.className===focusClass);if(input&&!input.disabled){input.focus();if(caret!=null)input.setSelectionRange(caret,caret);}}
}
function add(){if(saving)return;begin().rows.push({_key:'new-'+Date.now()+'-'+Math.random().toString(36).slice(2),id:options.uidFactory(),_new:true,name:'',price:'',qty:0,recipe:null});persist();render(options);document.querySelector('.ws-price-table tbody tr:last-child input')?.focus();}
function edit(index){render(options);document.querySelectorAll('.ws-price-name')[index]?.focus();}
async function save(){if(saving||!draft)return;const d=clone(draft),live=options.items,ops=[],changed=[];try{
 const seen=new Set();for(const r of d.rows){if(r._deleted)continue;const name=String(r.name||'').trim(),raw=String(r.price??'').trim(),price=options.number(raw,NaN);if(!name||!raw||!Number.isFinite(price)||price<0)throw Error('راجع الاسم والسعر في جميع الصفوف؛ السعر صفر مسموح.');if(seen.has(norm(name)))throw Error('اسم صنف مكرر: '+name);seen.add(norm(name));r.name=name;r.price=price;}
 for(const r of d.rows){const base=d.base.find(b=>b._key===r._key||(r.id&&b.id===r.id)),current=live.find(b=>r.id?b.id===r.id:base&&b.name===base.name);const modified=r._deleted||!base||r.name!==base.name||Number(r.price)!==Number(base.price);if(!modified)continue;
  if(base&&(!current||current.name!==base.name||Number(current.price)!==Number(base.price)))throw Error('تغيّر الصنف «'+base.name+'» من جهاز آخر. احتفظ بنسخة من تعديلاتك ثم ألغِ المسودة لتحديث الجدول.');
  if(!r._deleted&&live.some(b=>b!==current&&norm(b.name)===norm(r.name)&&!d.rows.some(x=>x.id===b.id&&x._deleted)))throw Error('يوجد صنف آخر بالاسم نفسه: '+r.name);
  if(r._deleted){if(!base)continue;if(!options.canDelete)throw Error('حذف الأصناف متاح للمدير فقط.');if(!r.id)throw Error('انتظر اكتمال مزامنة الأصناف القديمة أولاً.');ops.push({kind:'trash',id:r.id,data:{type:'صنف مخزن',id:r.id,deletedAt:Date.now(),dateStr:new Date().toLocaleString('ar-EG'),payload:clone(current)}});ops.push({kind:'delete',id:r.id});changed.push(r);}
  else if(base){if(!r.id)throw Error('انتظر اكتمال مزامنة الأصناف القديمة أولاً.');ops.push({kind:'update',id:r.id,data:{name:r.name,price:r.price}});changed.push(r);}
  else if(current){if(current.name!==r.name||Number(current.price)!==r.price)throw Error('تعارض في الصنف الجديد: '+r.name);changed.push(r);}
  else{ops.push({kind:'create',id:r.id,data:{id:r.id,name:r.name,price:r.price,qty:0,recipe:null}});changed.push(r);}
 }
 if(!ops.length){draft=null;localStorage.removeItem(key());render(options);return;}
 if(ops.length>500)throw Error('عدد عمليات الحفظ يتجاوز 500؛ قلّل عدد الصفوف المعدلة في هذه الدفعة.');
 saving=true;render(options);status('جارٍ حفظ جميع التغييرات؛ إن انقطع الاتصال ستبقى المسودة حتى اكتمال المزامنة.');await options.commit(ops);
 const deleted=new Set(changed.filter(r=>r._deleted).map(r=>r.id));const result=options.items.filter(r=>!deleted.has(r.id)).map(r=>{const c=changed.find(c=>c.id===r.id&&!c._deleted);return c?{...r,name:c.name,price:c.price}:r;});for(const r of changed)if(!r._deleted&&!result.some(x=>x.id===r.id))result.push({id:r.id,name:r.name,price:r.price,qty:0,recipe:null});
 options.onSaved(result);draft=null;localStorage.removeItem(key());saving=false;render({...options,items:result});status('تم حفظ جميع التغييرات.');
 }catch(e){saving=false;render(options);status('لم تُحفظ التغييرات: '+e.message+' — مسودتك ما زالت موجودة.');}
}
g.WSPriceGrid=Object.freeze({render,add,edit,save,dirty});
})(window);
