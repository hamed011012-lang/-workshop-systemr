(function(g){'use strict';
const clone=x=>JSON.parse(JSON.stringify(x));
function el(t,text){const e=document.createElement(t);if(text!=null)e.textContent=text;return e;}
function button(p,text,fn){const b=el('button',text);b.type='button';b.style.cssText='padding:12px;margin:5px;border-radius:9px;border:1px solid #b7c8c0;font:inherit;cursor:pointer';b.onclick=fn;p.append(b);return b;}
function input(p,label,value,type='number'){const l=el('label',label),i=el('input');i.type=type;i.value=value;if(type==='number')i.step='any';i.style.cssText='display:block;padding:10px;width:100%;box-sizing:border-box;font:inherit';l.style.cssText='display:block;margin:8px 0';l.append(i);p.append(l);return i;}
function select(p,label,values){const l=el('label',label),s=el('select');s.style.cssText='display:block;padding:10px;width:100%;font:inherit';for(const [value,name] of values)s.add(new Option(name,value));l.append(s);p.append(l);return s;}
function number(i){const text=String(i.value).trim().replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/٫/g,'.');if(!text||!Number.isFinite(Number(text)))throw Error('أكمل جميع الخانات الرقمية بأرقام صحيحة');return Number(text);}
function show({panel,status,getDraft,attempt}){
 panel.replaceChildren();const file=getDraft();file.workshopOptions.engineering=g.WSEngine.validate(file.workshopOptions.engineering);
 panel.append(el('h2','المواد والخام — تعديل سهل'),el('p','١ اختر النظام والعملية. ٢ اختر المادة وعدّل الأرقام. ٣ راجع المثال ثم أضف التعديل للمسودة واضغط «اعتماد التعديلات». بقية المواد تبقى كما هي.'));
 const pick=el('div');pick.style.cssText='display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px';panel.append(pick);
 const system=select(pick,'النظام',file.systems.map(s=>[s.id,s.name])),operation=select(pick,'الباب أو النافذة / العملية',[]);
 const w=input(pick,'عرض المثال بالسم',120),h=input(pick,'ارتفاع المثال بالسم',150),manual=input(pick,'عرض الضلفة / ارتفاع القلاب اليدوي عند الحاجة',50);
 const editor=el('div'),report=el('div');report.setAttribute('aria-live','polite');panel.append(editor,report);
 const scope=el('p');panel.insertBefore(scope,editor);let baseRows=[],chosen=-1;
 const systemRow=()=>file.systems.find(s=>s.id===system.value);
 const key=()=>systemRow().cutProfile+'::'+operation.value;
 const rules=()=>g.WSEngine.mapped(file,'rawEdits',systemRow().cutProfile,operation.value)||[];
 const args=()=>[system.value,operation.value,number(w),number(h),number(manual)];
 function table(before,after,warnings=[]){report.replaceChildren();report.append(el('h3','معاينة '+w.value+' × '+h.value+' سم'));
  warnings.forEach(t=>report.append(el('p',t)));
  const t=el('table');t.style.cssText='width:100%;border-collapse:collapse;text-align:right';const head=el('tr');['المادة','الحساب الأساسي','بعد التعديل','طول العود بعد التعديل'].forEach(s=>head.append(el('th',s)));t.append(head);
  const format=r=>{if(!r)return '—';const n=Math.round(r.amount*100)/100;return r.unit==='عود'?n+' سم = '+(r.amount/r.rodLength).toFixed(3)+' عود (شراء '+Math.ceil(r.amount/r.rodLength)+')':n+' '+r.unit;};
  after.forEach((r,i)=>{const tr=el('tr');[r.name,format(before[i]),format(r),r.unit==='عود'?r.rodLength+' سم':'—'].forEach(s=>{const td=el('td',s);td.style.cssText='padding:9px;border-bottom:1px solid #dce4df';tr.append(td);});t.append(tr);});report.append(t,el('p','العدد المقرب في هذا المثال للمراجعة فقط؛ صفحة القص تجمع أطوال المقاسات المتوافقة أولًا ثم تقرّب عدد الأعواد. تغيير طول العود هنا يغيّر حساب الخام، ولا يغيّر أطوال قطع القص. أطوال الأعواد في تخطيط القص تُراجع من القسم الموجود أسفل المحرر؛ طول خام المادة لا يغيّرها تلقائيًا لأن المادة قد تضم قطاعات مختلفة.'));
 }
 function preview(candidate=file){const result=g.WSMaterials.preview(candidate,...args());table(result.original,result.rows,result.warnings);return result;}
 function refresh(){attempt(()=>{scope.textContent='بروفايل القص: '+systemRow().cutProfile+' — التعديلات تخص هذه العملية في الأنظمة التي تستخدم هذا البروفايل. للمستقل استخدم نسخة نظام مستقلة.';const result=preview();baseRows=result.original;chosen=-1;editor.replaceChildren();const materials=select(editor,'المادة المراد تعديلها',result.rows.map((r,i)=>[String(i),r.name+' — '+r.unit+(r.unit==='عود'?' / عود '+r.rodLength+' سم':'')]));const fields=el('div');editor.append(fields);
  function form(add=false){fields.replaceChildren();chosen=add?-1:Number(materials.value);const row=add?{name:'مادة جديدة',unit:'عود',rodLength:580}:result.rows[chosen];if(!row)return;
   const old=rules().find(r=>r.name===row.name&&r.unit===row.unit),draft=old||{name:row.name,unit:row.unit,base:add?'fixed':'original',factor:1,offset:0,waste:0,rod:row.unit==='عود'?row.rodLength:0,add};
   const name=input(fields,'اسم المادة',draft.name,'text');name.disabled=!add;
   const unit=select(fields,'الوحدة',[['عود','عود — الأطوال بالسنتيمتر'],['قطعة','قطعة'],['م²','متر مربع'],['متر','متر طولي'],['كمية','كمية']]);unit.value=draft.unit;unit.disabled=!add;
   const presets=select(fields,'طول العود الشائع بالسم',[['','طول مخصص'],['560','560 سم'],['580','580 سم'],['600','600 سم'],['640','640 سم']]),rod=input(fields,'طول العود بالسم',draft.rod||580);presets.value=['560','580','600','640'].includes(String(rod.value))?String(rod.value):'';presets.onchange=()=>{if(presets.value)rod.value=presets.value;};rod.oninput=()=>presets.value='';
   const calcBox=el('details');calcBox.open=add||draft.base!=='original'||draft.factor!==1||draft.offset!==0||draft.waste!==0;calcBox.append(el('summary','تغيير طريقة الحساب والكمية والهدر (اختياري)'));fields.append(calcBox);
   const base=select(calcBox,'طريقة الحساب',[(add?null:['original','الحساب الحالي — تعديل بسيط عليه']),['w','العرض'],['h','الارتفاع'],['perimeter','المحيط: عرضان + ارتفاعان'],['area','المساحة بالمتر المربع'],['fixed','عدد / كمية ثابتة'],['result','ناتج من جدول القص']].filter(Boolean));base.value=draft.base;
   const resultField=select(calcBox,'ناتج القص (يستخدم فقط عند اختيار ناتج من جدول القص)',Object.keys(result.cut).map(k=>[k,k]));resultField.value=draft.result||Object.keys(result.cut)[0]||'';
   const factor=input(calcBox,'المضاعف / العدد (1 يبقي الكمية كما هي)',draft.factor),offset=input(calcBox,'زيادة أو خصم من الأساس قبل الضرب (0 دون تغيير)',draft.offset),waste=input(calcBox,'هدر إضافي % (0 دون هدر)',draft.waste);
   function visibility(){rod.disabled=presets.disabled=unit.value!=='عود';resultField.disabled=base.value!=='result';}unit.onchange=base.onchange=visibility;visibility();
   calcBox.append(el('p','الحساب = (الأساس + الزيادة أو الخصم) × المضاعف، ثم تضاف نسبة الهدر. عند اختيار «كمية ثابتة» اكتب الكمية في المضاعف واترك الزيادة صفرًا. العرض والارتفاع ونواتج الأطوال بالسم؛ تُحوّل إلى متر عند اختيار وحدة متر.'));
   function candidate(){const rule={name:name.value.trim(),unit:unit.value,base:base.value,result:resultField.value,factor:number(factor),offset:number(offset),waste:number(waste),rod:unit.value==='عود'?number(rod):0,add:old?.add||add};if(rule.unit==='عود'&&rule.rod<=0)throw Error('طول العود يجب أن يكون أكبر من صفر');if(add&&baseRows.some(r=>r.name===rule.name&&r.unit===rule.unit))throw Error('المادة موجودة؛ اخترها من القائمة لتعديلها');const copy=clone(file);copy.workshopOptions.engineering.rawEdits[key()]=rules().filter(r=>r.name!==rule.name||r.unit!==rule.unit).concat(rule);g.WSFullSystemFile.validate(copy);return copy;}
   button(fields,'معاينة التعديل قبل الحفظ',()=>attempt(()=>preview(candidate())));
   button(fields,'إضافة التعديل إلى المسودة',()=>attempt(()=>{const copy=candidate(),tested=preview(copy);if(tested.warnings.length)throw Error(tested.warnings.join('؛ '));file.workshopOptions.engineering.rawEdits[key()]=copy.workshopOptions.engineering.rawEdits[key()];status.textContent='أُضيف تعديل '+name.value+' إلى المسودة. اضغط «اعتماد التعديلات» لحفظه؛ الطلبات المحفوظة تبقى بحساباتها القديمة.';refresh();}));
   if(old)button(fields,old.add?'حذف المادة المضافة من المسودة':'إلغاء تعديل هذه المادة فقط',()=>attempt(()=>{file.workshopOptions.engineering.rawEdits[key()]=rules().filter(r=>r.name!==row.name||r.unit!==row.unit);refresh();}));
  }
  const stockMaps=g.WSEngine.mapped(file,'cutItems',systemRow().cutProfile,operation.value)||[];
  if(stockMaps.length){const stockBox=el('details');stockBox.append(el('summary','أطوال أعواد تخطيط القص — '+stockMaps.length+' قطاع'));const stockInputs=stockMaps.map(m=>input(stockBox,m.label+' / '+m.code+' / '+(m.color||'بدون لون')+' — طول العود بالسم',m.stock));button(stockBox,'تحديث أطوال أعواد التخطيط في المسودة',()=>attempt(()=>{const maps=stockMaps.map((m,i)=>({...m,stock:number(stockInputs[i])}));const copy=clone(file);copy.workshopOptions.engineering.cutItems[key()]=maps;g.WSFullSystemFile.validate(copy);file.workshopOptions.engineering.cutItems[key()]=maps;status.textContent='أُضيفت أطوال أعواد التخطيط للمسودة؛ اعتمد التعديلات للحفظ.';refresh();}));editor.append(stockBox);}
  materials.onchange=()=>form();button(editor,'إضافة مادة جديدة',()=>form(true));form();
 });}
 function operations(){operation.replaceChildren();const sys=systemRow();if(!sys)return;const names=file.customTypeNames||{},keys=Object.keys(g.WSEngine.resolveProfile(file,sys.cutProfile));const fits=k=>k.startsWith('custom_')||(!g.WSCuttingDefaults.names[k])||(sys.baseMaterial==='xtype_alum'?k.startsWith('aluminum_'):sys.baseMaterial==='xtype_pvc_slide'?k.startsWith('sliding_'):sys.baseMaterial==='xtype_ser_normal'?k==='sranti_normal':sys.baseMaterial==='xtype_ser_out'?k.startsWith('sranti_external'):sys.baseMaterial==='pvc'?!/^(aluminum_|sranti_|sliding_)/.test(k):true);keys.filter(fits).forEach(k=>operation.add(new Option(names[k]||g.WSCuttingDefaults.names[k]||k,k)));file.symbolFormulas.filter(b=>b.material===sys.id).forEach(b=>operation.add(new Option(b.name,b.key)));refresh();}
 system.onchange=operations;operation.onchange=refresh;button(pick,'تحديث المثال',refresh);operations();
}
function mount(context){button(context.nav,'المواد والخام — تعديل سهل',()=>show(context));}
g.WSMaterialsUI=Object.freeze({show,mount});
})(window);
