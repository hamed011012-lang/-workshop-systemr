/* v147 — lightweight sync health surface; no UI dependency. */
(function(g){'use strict'; if(g.AppSyncHealth)return;
  async function snapshot(){
    const s=g.AppSync&&g.AppSync.state?g.AppSync.state():{online:navigator.onLine};
    let db=null; try{db=g.AppDB&&g.AppDB.health?await g.AppDB.health():null;}catch(_){ }
    return {at:Date.now(),online:!!s.online,running:!!s.running,pending:Number(s.pending||0),durablePending:Number(s.durablePending||0),lastSyncAt:Number(s.lastSyncAt||0),db};
  }
  g.AppSyncHealth=Object.freeze({snapshot});
})(window);
