/* Workshop Core v152 — unified sync coordinator.
 * Additive and backwards-compatible: Firestore native offline queue remains intact.
 * Adds durable IndexedDB outbox support, retry/backoff, operation deduplication,
 * per-operation versions, and conflict events without changing existing business rules.
 */
(function (g) {
  'use strict';
  if (g.AppSync && g.AppSync.version >= 146) return;
  let running = false;
  let lastSyncAt = 0;
  let lastError = null;
  let retryTimer = null;
  const RETRIES = new Map();
  const MAX_RETRY = 8;

  function state() {
    return {
      version: 151,
      online: navigator.onLine,
      pending: Number(g.wsPendingWrites || 0),
      durablePending: Number(g.wsDurablePending || 0),
      resuming: !!g.wsResumingFromPreviousSession,
      running,
      lastSyncAt,
      lastError: lastError ? String(lastError.message || lastError) : null
    };
  }

  function emit(name, payload) {
    try { if (g.AppEvents) g.AppEvents.emit(name, payload); } catch (_) {}
  }

  function delayFor(attempt) {
    const n = Math.min(MAX_RETRY, Math.max(0, Number(attempt) || 0));
    return Math.min(60000, 500 * Math.pow(2, n)) + Math.floor(Math.random() * 250);
  }

  async function durablePending() {
    try {
      if (!g.AppDB || !g.AppDB.list) return [];
      const rows = await g.AppDB.list('outbox', 500);
      return rows.filter(x => x && x.status !== 'done');
    } catch (_) { return []; }
  }

  async function refreshPending() {
    const rows = await durablePending();
    g.wsDurablePending = rows.length;
    emit('sync:state', state());
    return rows;
  }

  async function enqueue(operation) {
    if (!operation || !operation.type) throw new Error('عملية مزامنة غير صالحة');
    const id = String(operation.id || (g.AppIdempotency && g.AppIdempotency.make
      ? g.AppIdempotency.make([operation.type, operation.entityId || '', operation.version || '', JSON.stringify(operation.payload || {})])
      : Date.now() + ':' + Math.random()));
    const row = {
      id,
      type: String(operation.type),
      entity: String(operation.entity || 'unknown'),
      entityId: String(operation.entityId || ''),
      version: Number(operation.version || 1),
      payload: operation.payload == null ? null : operation.payload,
      status: 'pending',
      tries: 0,
      createdAt: Number(operation.createdAt || Date.now()),
      updatedAt: Date.now()
    };
    if (g.AppDB && g.AppDB.get && g.AppDB.put) {
      const old = await g.AppDB.get('outbox', id);
      if (old) return { id, duplicate: true, row: old };
      await g.AppDB.put('outbox', row);
      await refreshPending();
      emit('sync:queued', row);
      return { id, duplicate: false, row };
    }
    if (g.AppOutbox && g.AppOutbox.enqueue) return { id: g.AppOutbox.enqueue(row.type, row.payload, id), duplicate: false, row };
    throw new Error('طبقة التخزين المحلي غير متاحة');
  }

  async function markDone(row) {
    if (g.AppDB && g.AppDB.put) {
      await g.AppDB.put('outbox', Object.assign({}, row, { status: 'done', updatedAt: Date.now(), doneAt: Date.now() }));
    }
    RETRIES.delete(row.id);
    emit('sync:item-complete', row);
  }

  async function markRetry(row, error) {
    const attempt = (RETRIES.get(row.id) || Number(row.tries) || 0) + 1;
    RETRIES.set(row.id, attempt);
    const next = Date.now() + delayFor(attempt);
    if (g.AppDB && g.AppDB.put) {
      await g.AppDB.put('outbox', Object.assign({}, row, { status: 'pending', tries: attempt, nextAttemptAt: next, lastError: String(error && error.message || error || 'sync error'), updatedAt: Date.now() }));
    }
    emit('sync:item-retry', { row, attempt, nextAttemptAt: next, error });
    if (!retryTimer) retryTimer = setTimeout(() => { retryTimer = null; flush(); }, Math.min(delayFor(attempt), 30000));
  }

  async function sendRow(row) {
    /* Only process operations that have an explicit handler. This keeps the
       coordinator safe: it never guesses how a business operation should
       be written to Firebase. Existing Firebase listeners remain authoritative. */
    const handlers = g.AppSyncHandlers || {};
    const handler = handlers[row.type];
    if (typeof handler !== 'function') return false;
    try {
      await handler(row);
      await markDone(row);
      return true;
    } catch (error) {
      if (error && (error.code === 'conflict' || error.code === 'version-conflict')) {
        emit('sync:conflict', { row, error }); try { if (g.AppConflictCenter && g.AppConflictCenter.capture) g.AppConflictCenter.capture({ row, error }); } catch (_) {}
        if (g.AppDB && g.AppDB.put) await g.AppDB.put('outbox', Object.assign({}, row, { status: 'conflict', conflictAt: Date.now(), lastError: String(error.message || error), updatedAt: Date.now() }));
        return false;
      }
      await markRetry(row, error);
      return false;
    }
  }

  async function flush() {
    if (running) return false;
    running = true;
    lastError = null;
    try {
      if (!navigator.onLine) return false;
      const rows = await durablePending();
      g.wsDurablePending = rows.length;
      for (const row of rows) {
        if (!row || row.status === 'done' || row.status === 'conflict') continue;
        if (row.nextAttemptAt && Number(row.nextAttemptAt) > Date.now()) continue;
        await sendRow(row);
      }
      if (g.db && typeof g.db.waitForPendingWrites === 'function') await g.db.waitForPendingWrites();
      lastSyncAt = Date.now();
      await refreshPending();
      emit('sync:complete', state());
      return true;
    } catch (e) {
      lastError = e;
      emit('sync:error', { error: e, state: state() });
      return false;
    } finally { running = false; }
  }

  function schedule() { clearTimeout(retryTimer); retryTimer = setTimeout(() => { retryTimer = null; flush(); }, 250); }
  addEventListener('online', schedule);
  addEventListener('offline', () => emit('sync:state', state()));
  if (g.AppEvents && g.AppEvents.on) g.AppEvents.on('sync:requested', schedule);
  refreshPending().catch(() => {});

  g.AppSync = Object.freeze({ version: 151, state, enqueue, flush, refreshPending });
})(window);
