(function(g){'use strict';
const copy=x=>JSON.parse(JSON.stringify(x));let timer=null,running=false;
function key(uid){return 'ws_archive_outbox_v360:'+uid;}
function read(uid){try{return JSON.parse(localStorage.getItem(key(uid))||'{}');}catch(e){return {};}}
function write(uid,data){localStorage.setItem(key(uid),JSON.stringify(data));}
function status(message){let p=document.getElementById('ws-archive-save-status');if(p)p.textContent=message;}
function enqueue(uid,id,payload,create=false){if(!uid)throw Error('يلزم تسجيل الدخول للمزامنة؛ بياناتك محفوظة محلياً.');const all=read(uid),old=all[id];all[id]={id,create:!!(create||old?.create),revision:Date.now()+'-'+Math.random(),payload:copy({...old?.payload,...payload})};write(uid,all);status('حُفظ على الجهاز — بانتظار المزامنة');clearTimeout(timer);timer=setTimeout(flush,800);}
function pending(uid){return Object.values(read(uid));}
async function flush(){if(running||!g.WSArchiveContext)return;const ctx=g.WSArchiveContext(),uid=ctx?.uid;if(!uid||!ctx.db||navigator.onLine===false)return;running=true;try{
 for(const item of pending(uid)){
  if(g.WSArchiveContext()?.uid!==uid)break;
  try{
   const operation=ctx.db.runTransaction(async tx=>{const ref=ctx.db.collection('measurementJobs').doc(item.id),snap=await tx.get(ref),server=snap.exists?snap.data():null;
    if(server?.deleted)throw Error('نُقلت الكراسة للسلة؛ نسختك المحلية محفوظة للمراجعة.');
    if(!server&&!item.create)throw Error('الكراسة غير موجودة بالسحابة؛ نسختك المحلية محفوظة للمراجعة.');
    if(server&&Number(server.updatedAt)>Number(item.payload.updatedAt))throw Error('تغيّرت الكراسة من جهاز آخر؛ نسختك المحلية محفوظة للمراجعة.');
    if(server){const patch={...item.payload};delete patch.createdAt;delete patch.createdByUid;delete patch.creationOperationId;tx.update(ref,patch);}else tx.set(ref,item.payload);
   });
   await (ctx.track?ctx.track(operation):operation);
   const latest=read(uid);if(latest[item.id]?.revision===item.revision)delete latest[item.id];else if(latest[item.id])latest[item.id].create=false;write(uid,latest);status(Object.keys(latest).length?'حُفظ على الجهاز — توجد تعديلات بانتظار المزامنة':'تم حفظ الزبون والمقاسات ومزامنتهما');
  }catch(e){status('حُفظ على الجهاز ولم تكتمل المزامنة: '+(e.message||'تعذر الاتصال')+' — ستُعاد المحاولة.');console.warn('Archive sync pending',e);}
 }
}finally{running=false;}}
g.WSArchiveOutbox=Object.freeze({enqueue,pending,flush});
window.addEventListener('online',flush);window.addEventListener('pageshow',flush);setInterval(flush,15000);
})(window);
