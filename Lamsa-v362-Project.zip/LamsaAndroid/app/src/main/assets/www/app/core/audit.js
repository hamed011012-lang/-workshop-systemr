/* Workshop Core v239 — bounded tamper-evident local audit trail. */
(function (g) {
  'use strict';
  if (g.AppAudit) return;
  const MAX = 1500;
  const GENESIS = 'WORKSHOP-AUDIT-v239-GENESIS';
  function makeId() { return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 9); }
  function stable(v) {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
    return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  }
  async function digest(v) {
    const s = stable(v);
    if (g.crypto && g.crypto.subtle && g.TextEncoder) {
      const b = await g.crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
      return Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join('');
    }
    let h = 2166136261; for (let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); }
    return 'fnv1a-' + (h>>>0).toString(16).padStart(8,'0');
  }
  async function record(type, data) {
    try {
      const rows = await g.AppDB.list('audit', 1);
      const prev = rows[0] && rows[0].hash ? rows[0].hash : GENESIS;
      const body = { id: makeId(), at: Date.now(), type: String(type || 'event'), data: data || {}, prevHash: prev };
      body.hash = await digest(body);
      await g.AppDB.put('audit', body);
      const all = await g.AppDB.list('audit', MAX + 100);
      if (all.length > MAX) await Promise.all(all.slice(MAX).map(x => g.AppDB.del('audit', x.id)));
      return true;
    } catch (e) { try { console.warn('[AppAudit]', e); } catch (_) {} return false; }
  }
  async function verify(limit) {
    try {
      const rows = await g.AppDB.list('audit', Math.max(1, Number(limit) || MAX));
      const ordered = rows.slice().reverse();
      let prev = null, checked = 0, broken = 0;
      for (const row of ordered) {
        if (!row || !row.hash) { broken++; continue; }
        if (prev && row.prevHash !== prev) broken++;
        const expected = await digest({ id:row.id, at:row.at, type:row.type, data:row.data||{}, prevHash:row.prevHash||GENESIS });
        if (expected !== row.hash) broken++;
        prev = row.hash; checked++;
      }
      return {ok:broken===0, checked, broken, genesis:GENESIS};
    } catch (_) { return {ok:false, checked:0, broken:1, genesis:GENESIS}; }
  }
  async function recent(limit) { try { return await g.AppDB.list('audit', Math.max(1, Number(limit) || 100)); } catch (_) { return []; } }
  g.AppAudit = Object.freeze({ record, recent, verify, digest });
})(window);
