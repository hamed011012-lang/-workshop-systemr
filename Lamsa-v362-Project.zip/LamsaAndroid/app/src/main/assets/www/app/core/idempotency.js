/* Persistent idempotency ledger. It prevents accidental duplicate user actions. */
(function (g) {
  'use strict'; if (g.AppIdempotency) return;
  const PREFIX = 'ws:v141:op:';
  function normalize(v) { return String(v == null ? '' : v).trim().slice(0, 240); }
  function hash(s) { let h = 2166136261; for (let i=0;i<s.length;i++) { h ^= s.charCodeAt(i); h = Math.imul(h,16777619); } return (h>>>0).toString(36); }
  function make(parts) { return PREFIX + hash((Array.isArray(parts) ? parts : [parts]).map(normalize).join('|')); }
  function has(key) { try { return localStorage.getItem(key) === '1'; } catch (_) { return false; } }
  function mark(key) { try { localStorage.setItem(key, '1'); return true; } catch (_) { return false; } }
  function clear(key) { try { localStorage.removeItem(key); } catch (_) {} }
  function claim(key, ttl) { const k = normalize(key); if (!k) return true; const lock = k + ':busy'; const t = Date.now(); try { const until = Number(localStorage.getItem(lock)||0); if (until > t) return false; localStorage.setItem(lock, String(t + Math.max(500, ttl || 5000))); return true; } catch (_) { return true; } }
  function release(key) { try { localStorage.removeItem(normalize(key) + ':busy'); } catch (_) {} }
  g.AppIdempotency = Object.freeze({ make, has, mark, clear, claim, release });
})(window);
