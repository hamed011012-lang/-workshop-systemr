/* Workshop Inventory v147 — stock command gateway.
 * Provides one safe entry point for future stock mutations without replacing
 * the legacy inventory engine yet.
 */
(function(g){'use strict'; if(g.StockCommand)return;
  async function mirror(items){
    if(!g.InventoryRepository)return {saved:0};
    return g.InventoryRepository.mirrorAll(Array.isArray(items)?items:[]);
  }
  async function movement(input){
    if(!input||!input.itemId||!input.operationId) throw new Error('هوية حركة المخزون مطلوبة');
    return g.InventoryRepository.recordMovement(input);
  }
  g.StockCommand=Object.freeze({mirror,movement});
})(window);
