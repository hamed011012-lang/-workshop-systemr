/* Workshop Inventory v147 — stock invariants. */
(function(g){'use strict'; if(g.StockPolicy)return;
  function normalizeName(v){
    return String(v==null?'':v).trim().replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[\s\u0640]+/g,' ').toLowerCase();
  }
  function duplicateGroups(items){
    const map=new Map();
    for(const x of (Array.isArray(items)?items:[])){const k=normalizeName(x&&x.name);if(!k)continue;(map.get(k)||map.set(k,[]).get(k)).push(x);}
    return Array.from(map.entries()).filter(([,v])=>v.length>1).map(([name,items])=>({name,items}));
  }
  function validate(item){
    const errors=[]; if(!item||!item.id)errors.push('معرّف الصنف مفقود'); if(item&&(!Number.isFinite(Number(item.qty))))errors.push('كمية غير صالحة'); return {ok:!errors.length,errors};
  }
  g.StockPolicy=Object.freeze({normalizeName,duplicateGroups,validate});
})(window);
