/* Workshop Invoices v143 — durable local invoice repository.
 * Phase 3: invoices gain a single local IndexedDB contract while Firebase remains
 * the existing remote source. The repository is intentionally additive so old
 * invoices and the legacy UI continue to work during migration.
 */
(function(g){'use strict';
  const VERSION_ENTITY='invoices';
  async function versioned(data,id,source){ if(g.AppVersioning&&g.AppVersioning.stamp) return g.AppVersioning.stamp(VERSION_ENTITY,String(id),data,source); return data; }
 if(g.InvoiceRepository)return;
  const COLLECTION='invoices';
  const key=id=>COLLECTION+':'+String(id);
  const clean=id=>{const x=String(id==null?'':id).trim(); if(!x) throw new Error('معرّف الفاتورة مطلوب'); return x;};
  let scheduled=false, lastSignature='';
  function signature(inv){
    try { return JSON.stringify([inv.id,inv.updatedAt,inv.editedAtMs,inv.timestamp,inv.subtotal,inv.paid,inv.netDebt,inv.customerName,inv.items&&inv.items.length]); }
    catch(_){ return String(inv.id); }
  }
  async function get(id){if(!g.AppDB)return null; const r=await g.AppDB.get('records',key(clean(id))); return r?r.data:null;}
  async function put(inv){
    if(!g.AppDB||!inv) return false; const id=clean(inv.id), now=Date.now();
    const existing=await g.AppDB.get('records',key(id));
    let data=Object.assign({},inv,{_repositoryVersion:144,_localUpdatedAt:now});
    
    data=await versioned(data, inv.id, 'repository');await g.AppDB.put('records',{key:key(id),collection:COLLECTION,id,data,createdAt:existing&&existing.createdAt||now,updatedAt:now});
    return true;
  }
  async function remove(id){if(g.AppDB) await g.AppDB.del('records',key(clean(id)));}
  async function list(limit){
    if(!g.AppDB)return [];
    const rows=await g.AppDB.list('records',Math.max(1,Number(limit)||5000));
    return rows.filter(x=>x&&x.collection===COLLECTION).map(x=>x.data);
  }
  async function mirrorAll(invoices){
    if(!g.AppDB||!Array.isArray(invoices)) return {saved:0};
    let saved=0;
    for(const inv of invoices){
      if(!inv||!inv.id) continue;
      const sig=signature(inv);
      const existing=await get(inv.id);
      const oldSig=existing?signature(existing):'';
      if(!existing||sig!==oldSig){ await put(inv); saved++; }
    }
    return {saved};
  }
  function scheduleMirror(invoices){
    if(scheduled)return;
    scheduled=true;
    Promise.resolve().then(async()=>{
      scheduled=false;
      try{
        const arr=Array.isArray(invoices)?invoices.slice():[];
        const sig=String(arr.length)+'|'+arr.slice(-3).map(signature).join('~');
        if(sig===lastSignature)return;
        lastSignature=sig;
        await mirrorAll(arr);
      }catch(e){ if(g.wsSilent)g.wsSilent('invoice-repository:mirror',e); else console.warn('[InvoiceRepository]',e); }
    });
  }
  async function migrateLegacy(invoices){
    if(!Array.isArray(invoices)||!invoices.length)return {saved:0};
    return mirrorAll(invoices);
  }
  g.InvoiceRepository=Object.freeze({collection:COLLECTION,get,put,upsert:put,remove,list,mirrorAll,scheduleMirror,migrateLegacy});
})(window);
