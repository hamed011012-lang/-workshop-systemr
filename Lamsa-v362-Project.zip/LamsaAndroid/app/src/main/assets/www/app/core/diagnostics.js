(function (g) {
  'use strict'; if (g.AppDiagnostics) return;
  const marks = new Map();
  function start(name) { marks.set(name, performance.now()); }
  function end(name) { const t=marks.get(name); if (t==null) return 0; const d=performance.now()-t; marks.delete(name); return Math.round(d); }
  function report(name, extra) { try { console.debug('[WS]', name, extra || ''); } catch (_) {} }
  function page() { return document.body && document.body.dataset ? document.body.dataset.page || location.pathname : location.pathname; }
  g.AppDiagnostics = Object.freeze({ start, end, report, page });
})(window);
