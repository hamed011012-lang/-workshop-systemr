const {JSDOM}=require('jsdom');const fs=require('fs'),assert=require('assert');const base='app/src/main/assets/www/';
const html=fs.readFileSync(base+'cutting.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
const dom=new JSDOM(html,{url:'https://test.local/cutting.html',runScripts:'outside-only'}),w=dom.window;
w.guardPage=()=>{};w.auth={onAuthStateChanged(){}};w.alert=console.log;w.confirm=()=>true;w.escHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));w.wsNum=(v,f=0)=>{let n=parseFloat(v);return Number.isFinite(n)?n:f;};w.safeSetItem=(k,v)=>w.localStorage.setItem(k,v);w.showToast=()=>{};w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};
for(const f of ['app/opening-symbols.js','app/default-cutting-data.js','app/symbol-formulas.js','app/calculation-systems.js','app/full-system-file.js','app/system-studio.js','app/engineering.js','app/cut-optimizer.js','app/materials-easy.js','app/pages/cutting.js'])w.eval(fs.readFileSync(base+f,'utf8'));
w.eval(`initProfiles();document.getElementById('measurements-container').innerHTML=[1,2].map(i=>'<div class="measurement-item">'+createMeasurementHTML(i,300,90,'window_double','','','الافتراضي')+'</div>').join('');calculateAll();`);
let text=w.document.getElementById('results').textContent;assert(text.includes('4 عود كامل'),text);assert(text.includes('تقرير ترتيب القص'));assert.equal(w.document.querySelectorAll('.total-row').length>0,true);
assert.equal(w.getComputedStyle(w.document.querySelector('.sh-pair')).direction,'rtl');assert.equal(w.getComputedStyle(w.document.querySelector('.dimensions-row')).direction,'rtl');
w.eval('resultsAsTable=true;renderResultsTable();');assert(w.document.getElementById('results').textContent.includes('تقرير ترتيب القص'));
w.eval(`resultsAsTable=false;localStorage.setItem('ws_pvc_stock_cm','700');calculateAll();`);text=w.document.getElementById('results').textContent;assert(text.includes('طول العود: 700 سم'));
// Five distinct measurements: verify actual execution order, piece coverage and collapsed details.
w.eval(`resultsAsTable=false;localStorage.setItem('ws_pvc_stock_cm','580');document.getElementById('measurements-container').innerHTML=[100,300,110,240,130].map((width,i)=>'<div class="measurement-item">'+createMeasurementHTML(i+1,width,90,'window_double','','','الافتراضي')+'</div>').join('');calculateAll();`);
const first=w.document.querySelector('.total-row');assert(first.querySelector('.ws-material-name').textContent.startsWith('شمبرلي'));
const details=first.querySelector('details');assert(details&&!details.open);assert.equal(details.querySelector('summary').textContent,'التفاصيل');assert(details.querySelector('.raw-exact'));assert(!first.querySelector(':scope > .raw-amounts .raw-exact'));
const steps=[...details.querySelectorAll('.ws-cut-steps tbody tr')];
const codes=steps.map(r=>{const match=r.cells[0].textContent.match(/^([LH])(\d+)$/),dim=r.cells[2].querySelector('bdi').textContent.match(/^([\d.]+) × (\d+)$/);assert(match,r.cells[0].textContent);assert(dim,r.cells[2].textContent);return {axis:match[1],source:Number(match[2]),qty:Number(dim[2])};});
assert.equal(codes.reduce((n,c)=>n+c.qty,0),20);assert.equal(codes[0].source,2);
for(let n=1;n<=5;n++){assert.equal(codes.filter(c=>c.source===n&&c.axis==='L').reduce((sum,c)=>sum+c.qty,0),2);assert.equal(codes.filter(c=>c.source===n&&c.axis==='H').reduce((sum,c)=>sum+c.qty,0),2);}
assert(!details.textContent.includes('خطوة القص'));
const report=w.wsExecutionCutReport({name:'شمبرلي',family:'اختبار',stock:580,kerf:0,optimal:true,rods:[{used:500,pieces:[{source:1,axis:'ارتفاع',length:150},{source:1,axis:'عرض',length:100},{source:1,axis:'ارتفاع',length:150},{source:1,axis:'عرض',length:100}]},{used:250,pieces:[{source:1,axis:'ارتفاع',length:100},{source:1,axis:'ارتفاع',length:150}]}]});
const test=w.document.createElement('div');test.innerHTML=report;
const rods=test.querySelectorAll('.ws-rod-card');assert.equal(rods[0].querySelectorAll('tbody tr').length,2);assert.equal(rods[0].querySelector('tbody tr td').textContent,'H1');assert.equal(rods[0].querySelector('tbody tr .ws-length bdi').textContent,'150 × 2');assert.equal(rods[1].querySelectorAll('tbody tr').length,2);assert.equal(rods[1].querySelector('tbody tr .ws-length bdi').textContent,'100 × 1');assert.equal(rods[0].querySelector('tbody tr bdi').dir,'ltr');assert(rods[0].querySelector('.ws-cut-bar').textContent.includes('H1'));
const ranks=[...w.document.querySelectorAll('.total-row .ws-material-name')].map(e=>w.wsMaterialOrder(e.childNodes[0].textContent));assert(ranks.every((n,i)=>!i||n>=ranks[i-1]));
assert.deepEqual(['شمبرلي','حلق المونيوم','ضلفة الباب','تي T','مسطح الباب','الباكيتة'].map(w.wsMaterialOrder),[0,0,1,2,3,4]);
assert(details.querySelectorAll('.ws-rod-card').length>1);assert(details.textContent.includes('انتهى قص هذا القطاع.'));
console.log('PASS five measurements: all 20 frame pieces once, longest starts from measurement 2, L/H references, length × quantity per rod, collapsed details, material category order.');
console.log('PASS integrated DOM: calculateAll with WSMaterials, width/right CSS, 4 bars, raw report in table, changed stock length.');dom.window.close();
