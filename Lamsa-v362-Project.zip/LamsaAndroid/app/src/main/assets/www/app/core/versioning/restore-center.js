/* Workshop Restore Center v156 — safe, version-aware historical restore.
 * Restores are NEW operations: history is never edited or deleted.
 * Current-version checks prevent a stale restore from overwriting a newer edit.
 * Phase 1 adapter: invoices. Other entities remain review-only until their
 * business adapter is explicitly registered.
 */
(function(g){'use strict'; if(g.AppRestoreCenter)return;
  const PREFIX='restore:';
  const clone=v=>{try{return JSON.parse(JSON.stringify(v));}catch(_){return v;}};
  const opKey=(entity,id,version)=>g.AppIdempotency&&g.AppIdempotency.make?g.AppIdempotency.make([PREFIX,entity,id,version]):PREFIX+entity+':'+id+':'+version;
  const adapters={};
  function register(entity,adapter){if(!entity||!adapter||typeof adapter.apply!=='function')throw new Error('محول الاستعادة غير صالح'); adapters[String(entity)]=adapter;}
  async function findSnapshot(entity,id,version){
    const rows=await (g.AppVersioning&&g.AppVersioning.list?g.AppVersioning.list(entity,id,1000):[]);
    return rows.find(r=>Number(r.version)===Number(version))||null;
  }
  async function preview(ref){
    const entity=String(ref&&ref.entity||''), id=String(ref&&ref.entityId||''), version=Number(ref&&ref.version||0);
    if(!entity||!id||!version) throw new Error('بيانات النسخة المطلوب استعادتها غير مكتملة');
    const snapshot=await findSnapshot(entity,id,version);
    if(!snapshot||!snapshot.data) throw new Error('لا توجد نسخة كاملة قابلة للاستعادة لهذا الإصدار');
    const current=g.AppVersioning?await g.AppVersioning.read(entity,id):{version:0};
    return {entity,id,version,snapshot,current,adapter:!!adapters[entity],data:clone(snapshot.data)};
  }
  async function apply(ref,options){
    const p=await preview(ref), adapter=adapters[p.entity];
    if(!adapter) throw new Error('الاستعادة الآمنة غير مفعلة بعد لهذا النوع: '+p.entity);
    const expected=Number(options&&options.expectedCurrentVersion!=null?options.expectedCurrentVersion:p.current.version||0);
    const check=g.AppVersioning?await g.AppVersioning.check(p.entity,p.id,expected):{ok:true,current:{version:0}};
    if(!check.ok) throw new Error('تم تعديل السجل منذ فتح نافذة الاستعادة. أعد المعاينة قبل الاستعادة.');
    const operationId=opKey(p.entity,p.id,p.version);
    if(g.AppIdempotency&&g.AppIdempotency.has&&g.AppIdempotency.has(operationId)) return {status:'already-restored',operationId,version:p.version};
    if(g.AppIdempotency&&g.AppIdempotency.claim&&!g.AppIdempotency.claim(operationId,10000)) throw new Error('عملية استعادة أخرى جارية بالفعل.');
    try{
      const restored=clone(p.data);
      const result=await adapter.apply(restored,{operationId,fromVersion:p.version,currentVersion:expected});
      if(g.AppVersioning){await g.AppVersioning.next(p.entity,p.id,'restore');await g.AppVersioning.record(p.entity,p.id,restored,operationId);}
      if(g.AppAudit) await g.AppAudit.record('history:restore',{entity:p.entity,entityId:p.id,fromVersion:p.version,operationId});
      if(g.AppIdempotency&&g.AppIdempotency.mark) g.AppIdempotency.mark(operationId);
      return {status:'restored',operationId,fromVersion:p.version,result};
    }finally{if(g.AppIdempotency&&g.AppIdempotency.release)g.AppIdempotency.release(operationId);}
  }
  register('invoices',{async apply(invoice,ctx){
    const id=String(invoice.id||'').trim(); if(!id) throw new Error('معرّف الفاتورة مفقود');
    /* Update the durable repository first. The legacy Firebase/local path is
       then updated through the existing fsSet/saveDB compatibility layer. */
    if(g.InvoiceRepository&&g.InvoiceRepository.put) await g.InvoiceRepository.put(invoice);
    let localApplied=false;
    if(g.DB&&Array.isArray(g.DB.sales)){
      const idx=g.DB.sales.findIndex(x=>x&&String(x.id)===id);
      if(idx>=0) g.DB.sales[idx]=clone(invoice); else g.DB.sales.push(clone(invoice));
      localApplied=true;
    }
    if(typeof g.fsSet==='function') await g.fsSet('sales',id,invoice);
    if(typeof g.saveDB==='function') g.saveDB();
    if(g.AppEvents&&g.AppEvents.emit) g.AppEvents.emit('invoice:restored',{id,operationId:ctx.operationId});
    return {localApplied,queuedToFirebase:typeof g.fsSet==='function'};
  }});
  g.AppRestoreCenter=Object.freeze({register,preview,apply,supported:()=>Object.keys(adapters)});
})(window);
