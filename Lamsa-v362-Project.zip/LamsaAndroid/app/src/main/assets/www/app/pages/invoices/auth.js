
// ============================================================
// نظام تسجيل الدخول عبر Firebase Authentication (بريد إلكتروني + كلمة مرور)
// ============================================================
let _currentUser = null;  // { uid, email, name, role:'manager'|'employee', color }
let _firestoreUnsubscribers = []; // لإيقاف كل مستمعات المزامنة الحيّة عند الخروج

function setLoginError(msg) {
  const el = document.getElementById('login-error');
  if (!el) return;
  el.textContent = msg || '';
  el.classList.remove('shake');
  void el.offsetWidth;
  if (msg) el.classList.add('shake');
}

async function firebaseLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  if (!email || !password) { setLoginError('أدخل البريد الإلكتروني وكلمة المرور.'); return; }
  const btn = document.getElementById('login-submit-btn');
  btn.disabled = true; btn.textContent = 'جارٍ الدخول...';
  setLoginError('');
  try {
    await auth.signInWithEmailAndPassword(email, password);
    // الباقي تتولاه onAuthStateChanged
  } catch (e) {
    let msg = 'تعذّر تسجيل الدخول.';
    if (['auth/wrong-password','auth/user-not-found','auth/invalid-credential','auth/invalid-email'].includes(e.code)) msg = '❌ البريد الإلكتروني أو كلمة المرور غير صحيحة';
    else if (e.code === 'auth/too-many-requests') msg = 'محاولات كثيرة جداً، حاول لاحقاً.';
    else if (e.code === 'auth/network-request-failed') msg = '📶 تحقق من اتصال الإنترنت.';
    setLoginError(msg);
    btn.disabled = false; btn.textContent = 'دخول';
  }
}

async function logoutUser() {
  return sharedLogout();
}

function getCurrentUserName() {
  return _currentUser ? _currentUser.name : 'غير معروف';
}

function getCurrentUserRole() {
  return _currentUser ? _currentUser.role : '';
}

function isAdmin() {
  const currentEmail = auth.currentUser && auth.currentUser.email;
  return !!(currentEmail && ADMIN_EMAIL && String(currentEmail).trim().toLowerCase() === String(ADMIN_EMAIL).trim().toLowerCase());
}

function updateUserBadge() {
  if (!_currentUser) return;
  const dot = document.getElementById('user-role-dot');
  const name = document.getElementById('user-display-name');
  if (dot) dot.style.background = wsSafeColor(_currentUser.color);   // 8.8.5
  // الاسم وحده فقط — بلا أي كلمة صفة أو أيقونة صفة بجانبه
  if (name) name.textContent = _currentUser.name;
}

function showAppForUser() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('app-screen').style.display = '';
  document.getElementById('login-email').value = '';
  document.getElementById('login-password').value = '';
  setLoginError('');
  updateUserBadge();
  const isMgr = _currentUser.role === 'manager';
  const managerBtn = document.getElementById('btn-manager-collect');
  if (managerBtn) managerBtn.classList.toggle('hidden', !isMgr);
  ADMIN_ONLY_SECTIONS.forEach(secId => {
    const secBtn = document.getElementById('btn-' + secId);
    if (secBtn) secBtn.classList.toggle('hidden', !isMgr);
  });
  const membersTabBtn = document.getElementById('stab-members');
  if (membersTabBtn) membersTabBtn.classList.toggle('hidden', !isAdmin());
  refreshIcons();
  // فتح نافذة إدارة الأعضاء مباشرةً عند وصول المدير من بطاقة الصفحة الرئيسية.
  if (new URLSearchParams(window.location.search).get('openMembers') === '1' && isAdmin()) {
    setTimeout(() => { if (typeof openSettings === 'function') openSettings(); }, 180);
  }
  try {
    const nv = document.getElementById('app-nav');
    if (nv) nv.style.display = 'flex';
    const nb = document.getElementById('nav-user-badge');
    if (nb) nb.textContent = shopUser.name || '';
  } catch (e) {}

  // v301: لا نفترض أن app.js اكتمل تحميله في اللحظة التي يرد فيها Firebase Auth.
  // في بعض الهواتف/الشبكات يصل رد المصادقة قبل تعريف الدوال التابعة للواجهة.
  const startInvoiceListeners = (attempt = 0) => {
    if (typeof window.attachAllFirestoreListeners === 'function') {
      window.attachAllFirestoreListeners();
      return;
    }
    if (attempt < 40) {
      setTimeout(() => startInvoiceListeners(attempt + 1), 50);
      return;
    }
    console.error('Invoice boot: attachAllFirestoreListeners was not defined after app scripts loaded.');
    showFsErrorToast('⚠️ تعذّر تجهيز مزامنة الفواتير. حدّث الصفحة، وإذا تكرر الخطأ أرسل صورة الرسالة للمشرف.');
  };
  startInvoiceListeners();
  applyPendingInvoiceHandoffIfAny();
  // فحص صامت بعد وصول البيانات — ينبّه المدير وحده إن وُجدت سجلات مشوّهة قديمة
  if (isMgr) setTimeout(() => {
    try {
      const found = wsAuditFinances(true);
      // نوجّهه للزر، لا لأمر في نافذة المطوّر — لا أحد يدير ورشة من هناك
      if (found.length) showFsErrorToast('⚠️ فحص الحسابات وجد ' + found.length +
        ' سجلاً يحتاج مراجعة — افتح «النسخ الاحتياطي» ← «فحص الحسابات».');
    } catch (e) {}
  }, 6000);
}

// يتحقق إن جاء المستخدم للتو من صفحة القياسات بزر "تحويل إلى فاتورة"، ويملأ بيانات
// العميل والبنود المالية في فاتورة جديدة تلقائياً (بدون جدول القياسات نفسه، فقط الاسم/الهاتف/البنود)
/* ينتقل مباشرة إلى خانة المبلغ المدفوع ويحيطها بإطار أخضر واضح.
   يُستخدم بعد استيراد البنود من صفحة القياسات، حيث يكون كل شيء
   جاهزاً ولم يبقَ إلا إدخال المبلغ. */
function focusPaidField() {
  const wrap = document.getElementById('pos-paid-wrap');
  const input = document.getElementById('pos-amount-paid');
  if (!wrap || !input) return;

  wrap.classList.add('paid-highlight');
  setTimeout(() => {
    wrap.scrollIntoView({ behavior: 'smooth', block: 'center' });
    input.focus();
    input.select && input.select();
  }, 320);

  // يبقى التمييز حتى يبدأ المستخدم الكتابة فعلاً
  const clear = () => {
    wrap.classList.remove('paid-highlight');
    input.removeEventListener('input', clear);
    input.removeEventListener('blur', clear);
  };
  input.addEventListener('input', clear);
  input.addEventListener('blur', clear);
  setTimeout(clear, 20000);
}

function applyPendingInvoiceHandoffIfAny() {
  const raw = localStorage.getItem('handoff_to_invoice');
  if (!raw) return;

  let h;
  try { h = JSON.parse(raw); }
  catch (e) {
    // ملف تسليم تالف: نحذفه حتى لا يتكرر الخطأ مع كل فتح
    localStorage.removeItem('handoff_to_invoice');
    console.error('handoff parse:', e);
    return;
  }

  /* ══ حارسان قبل حقن البنود ══
     1) شاشة البيع قد تكون في وضع «تعديل فاتورة محفوظة». حقن بنود زبون
        القياسات فيها كان يضيفها إلى فاتورة زبون آخر مُصدَرة أصلاً، فيتغيّر
        إجماليها ومخزونها ودينها — بلا أن يلاحظ أحد.
     2) وقد تكون فيها بنود فاتورة قيد التحضير لزبون آخر. الدفع كان يُلحق
        البنود بها ويستبدل الاسم، فتُخلط بضاعة زبونين في فاتورة واحدة. */
  const editId = (document.getElementById('pos-edit-id') || {}).value || '';
  if (editId) {
    if (!confirm('📥 وصلت بنود من كراسة القياسات باسم «' + (h.customerName || 'بدون اسم') + '».\n\n' +
                 'لكنك تعدّل الآن الفاتورة ' + editId + '.\n\n' +
                 'موافق = إنهاء التعديل واستيراد البنود في فاتورة جديدة\n' +
                 'إلغاء = تجاهل البنود الواردة (تبقى محفوظة لفتحة قادمة)')) return;
    try { exitEditMode(); } catch (e) {}
  } else if (currentInvoiceItems.length) {
    const ans = confirm('📥 وصلت بنود من كراسة القياسات باسم «' + (h.customerName || 'بدون اسم') + '».\n\n' +
                        'وشاشة البيع فيها ' + currentInvoiceItems.length + ' بنداً بالفعل.\n\n' +
                        'موافق = استبدال البنود الحالية بالواردة\n' +
                        'إلغاء = إضافة الواردة إلى الموجودة');
    if (ans) currentInvoiceItems = [];
  }

  // لا نحذف بيانات التسليم إلا بعد نجاح الحقن فعلاً
  localStorage.removeItem('handoff_to_invoice');
  openSectionModal('pos');
  try {
    setTimeout(() => {
      const nameEl = document.getElementById('pos-customer-name');
      const phoneEl = document.getElementById('pos-customer-phone');
      if (nameEl) nameEl.value = h.customerName || '';
      if (phoneEl) phoneEl.value = h.customerPhone || '';
      (h.items || []).forEach(it => {
        const qty = r2(it.qty) > 0 ? r2(it.qty) : 1;
        const price = r2(it.price) > 0 ? r2(it.price) : 0;
        // دمج المكرر بنفس السعر بدل تكرار السطر
        const ex = currentInvoiceItems.find(x => x.name === it.name && r2(x.price) === price);
        if (ex) { ex.qty = r2(ex.qty + qty); ex.total = r2(ex.qty * ex.price); }
        else currentInvoiceItems.push({ name: it.name, qty, price, total: r2(qty * price) });
      });
      renderPOSTable();
      calculateInvoiceTotals();
      showSuccessToast('📥 تم استيراد البنود — أدخل المبلغ المدفوع لإتمام الفاتورة');
      focusPaidField();
    }, 200);
  } catch (e) { console.error('applyPendingInvoiceHandoffIfAny:', e); }
}

function showLoginScreen(message) {
  _firestoreUnsubscribers.forEach(u => { try { u(); } catch(e) {} });
  _firestoreUnsubscribers = [];
  _currentUser = null;
  // بدل عرض نموذج دخول محلي منفصل، نوجّه لصفحة الدخول الموحّدة التي تفتح الوحدات الثلاث
  window.location.href = 'index.html' + (message ? ('?msg=' + encodeURIComponent(message)) : '');
}

/* ⚠️⚠️ إصلاح جذري 8.9.4 — تصفية صنف كامل من الأعطال، لا عطلاً واحداً.

   كُشف بمدقّق جديد يبحث عن «المنطقة الميتة الزمنية» عبر كتل السكربت:
   دالة معرَّفة في كتلة متأخرة (فالنداء يجدها لأنها مرفوعة) لكنها تقرأ
   let/const من تلك الكتلة نفسها (وهي **لا تُرفع**). فإن جرى النداء قبل
   تنفيذ تلك الكتلة، رمت ReferenceError.

   وجد المدقّق **ثلاثة عشر موضعاً** من هذا الصنف في هذا الملف وحده،
   بينها attachAllFirestoreListeners و openSectionModal و calculateInvoiceTotals.
   وكلها تُنادى من showAppForUser في كتلة سابقة. أي أن إصلاح refreshIcons
   وحده كان يؤجّل العطل سطراً واحداً لا يمنعه.

   والسبب الجذري ليس أياً منها: بل أن معالج المصادقة كان يُسجَّل في الكتلة
   الثالثة. وحين تكون الجلسة محفوظة يعود النداء بسرعة كمهمّة مُجدوَلة،
   فينفّذها المتصفح **قبل أن يُنفِّذ الكتلة الرابعة** — فتُبنى الواجهة كلها
   على متغيّرات لم تُهيّأ بعد.

   الحلّ يقطع الجذر: لا يبدأ الحارس إلا بعد DOMContentLoaded — وهي تقع
   بعد تنفيذ **كل** سكربتات الصفحة بلا استثناء. فلا منطقة ميتة تبقى ممكنة،
   لا في المواضع الثلاثة عشر ولا في أي موضع يُضاف مستقبلاً.

   والتأخير الذي يضيفه صفر عملياً: الصفحة تُحلَّل في أجزاء من الثانية،
   والتحقق من الهوية يحتاج الشبكة على أي حال. */
let _invoiceAuthRun = 0;
let _invoiceBootUid = '';
function _startAuthWatch() {
auth.onAuthStateChanged(async function(user) {
  const run = ++_invoiceAuthRun;
  if (!user) { _invoiceBootUid = ''; showLoginScreen(); return; }
  // v247: يمنع سباق onAuthStateChanged من بناء صفحة الفواتير مرتين،
  // وبالتالي منع تكرار مستمعات Firestore وإعادة الرسم على الهاتف.
  if (_invoiceBootUid === user.uid && _currentUser) return;
  /* ⚠️ إصلاح بنيوي 8.9.3 — خطأٌ في الرسم كان يطرد المستخدم ويتّهم الشبكة.

     كان showAppForUser() داخل نفس try الذي يلفّ التحقق من الهوية. فأي
     استثناء في بناء الواجهة — عنصر ناقص، دالة أخطأت، متغيّر في منطقة ميتة —
     يسقط في catch الذي لا يعرف إلا سبباً واحداً: «الشبكة». فيُنفَّذ signOut
     ويُعاد التوجيه، ويعود المستخدم فيدخل فيقع الخطأ نفسه… حلقة لا تنتهي،
     وتشخيصها مستحيل لأن الرسالة تشير إلى مكان بريء.

     وهذا ما وقع فعلاً في 8.9.1: سطرٌ واحد في المنطقة الميتة أقفل النظام
     كلياً على كل مستخدم.

     الآن مفصولان: التحقق من الهوية وحده هو ما يبرّر الخروج. وخطأ الرسم
     يُعرض كخطأ رسم — ويبقى المستخدم داخلاً، فيستطيع على الأقل أن يخبرنا
     بما يرى بدل أن يجد نفسه خارجاً. */
  let shopUser = null;
  try {
    shopUser = await resolveShopUser(user);
  } catch (e) {
    // دون اتصال: لا نطرد المستخدم إطلاقاً — الخروج هنا يعني عجزه عن العودة،
    // لأن تسجيل الدخول نفسه يحتاج شبكة. نكتفي بتنبيه ونعيد المحاولة تلقائياً.
    if (!navigator.onLine) {
      showFsErrorToast('🔴 تعذّر التحقق من الحساب لانقطاع الشبكة — سيُعاد التحقق تلقائياً فور عودتها.');
      return;
    }
    console.error('resolveShopUser:', e);
    await auth.signOut().catch(() => {});
    showLoginScreen(typeof wsAuthFailureMessage === 'function'
      ? wsAuthFailureMessage()
      : 'تعذّر التحقق من الحساب، تحقق من الاتصال وحاول مجدداً.');
    return;
  }

  if (run !== _invoiceAuthRun || !auth.currentUser || auth.currentUser.uid !== user.uid) return;

  if (!shopUser) {
    // 9.2.0 — فشل مؤقت لا يُخرج أحداً (انظر wsAuthFailureIsDefinitive)
    if (typeof wsAuthFailureIsDefinitive === 'function' && !wsAuthFailureIsDefinitive()) {
      showFsErrorToast('📡 تعذّر التحقق من حسابك مؤقتاً — تبقى داخل النظام، وسيُعاد التحقق تلقائياً.');
      if (typeof wsRetryAuthSoon === 'function') wsRetryAuthSoon(function () {
        try {
          if (auth.currentUser && auth.currentUser.uid === user.uid) {
            _invoiceBootUid = '';
            _startAuthWatch();
          }
        } catch (e) { console.warn('auth retry without reload:', e); }
      });
      return;
    }
    await auth.signOut().catch(() => {});
    showLoginScreen(typeof wsAuthFailureMessage === 'function'
      ? wsAuthFailureMessage()
      : '❌ هذا الحساب غير مصرّح له بالدخول. تواصل مع المشرف.');
    return;
  }

  // بعد اكتمال المصادقة نُفرغ أي واصل حُفظ أثناء الانقطاع أو قبل جاهزية Auth.
  try { wsFlushPendingReceipts(); } catch (e) {}

  /* ⚠️⚠️ 9.5.0 — الحارس الحقيقي، لا الإخفاء.

     إخفاء البطاقة والرابط يمنع الوصول **بالخطأ** لا بالقصد: من يعرف
     العنوان يكتبه، ومن حفظ الصفحة في المفضّلة يفتحها. فلو اكتُفي
     بالإخفاء لكان القسم مقفولاً في الظاهر مفتوحاً في الحقيقة.

     وهذا حارس واجهة كذلك — لا يغني عن قواعد السيرفر. لكنه يمنع العضو
     من رؤية أرقام لا تخصّه: الأرشيف والديون والأرباح والمصروفات، وهي
     تُقرأ من Firestore بصلاحية `read: if isMember()`.

     (الإقفال الكامل للقراءة يحتاج تعديل قواعد read على sales/payments/
      expenses ليصير isManager — وهو قرارٌ يخصّك: بعض المحلات تريد
      الموظف أن يرى دَين العميل الذي يقف أمامه.) */
  /* ⚠️⚠️ إصلاح 9.5.3 — كان المدير نفسه يُطرد من قسمه.

     كان هنا حارسان لا واحد. والأول يفحص `isManager()`، وهي:
         getCurrentUserRole() → _currentUser ? _currentUser.role : ''
     و`_currentUser` **لا يُسنَد إلا بعده بسبعة أسطر**. فترجع فارغة دائماً،
     ويفشل الفحص **لكل مستخدم** — المدير والمشرف والموظف سواء. ثم ينفّذ
     signOut ويعيد التوجيه، فيخرج المدير من حسابه كلما فتح قسم الفواتير.

     وهو نفس صنف الخطأ الذي عطّل الدخول في 8.9.4: قيمةٌ تُقرأ قبل أن
     تُهيّأ. والفرق أن ذاك كان `let` في منطقة ميتة، وهذا متغيّرٌ يُسنَد
     لاحقاً في نفس الدالة.

     الآن حارس واحد يقرأ `shopUser` مباشرةً — وهو الوسيط المُمرَّر
     والمحقَّق منه للتوّ، فلا يعتمد على حالة لم تُبنَ بعد.

     ولماذا هنا لا في قواعد السيرفر؟ لأن الموظف **يحتاج** بيانات الفواتير
     فعلاً: اعتماد الخدمة من صفحة القياسات يكتب في sales وpayments ويقرأ
     creditBalances. فمنعُ القراءة على السيرفر يكسر اعتماد الخدمات كله.
     فالمنع هنا منع **قسم** لا منع بيانات. */
  const _mgrOnly = (shopUser.role === 'manager') || isAdmin();
  if (!_mgrOnly) {
    /* بلا رسالة: القسم مخفيّ أصلاً عن العضو (البطاقة والرابط)، فرسالةٌ
       تقول «متاح للمدير فقط» تُعلن وجود ما أخفيناه وتُغري بالمحاولة.
       نُعيده إلى الرئيسية بصمت كأن العنوان لم يكن. */
    window.location.replace('index.html');
    return;
  }

  if (run !== _invoiceAuthRun || !auth.currentUser || auth.currentUser.uid !== user.uid) return;
  _currentUser = shopUser;
  _invoiceBootUid = user.uid;
  /* بناء الواجهة خارج حارس الهوية: خطؤه يُعرَض ولا يُخرج أحداً */
  try {
    showAppForUser();
  } catch (e) {
    console.error('showAppForUser:', e);
    showFsErrorToast('⚠️ حدث خطأ في عرض الواجهة — أعد تحميل الصفحة. (' +
                     ((e && e.message) || e) + ')');
  }
});
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', _startAuthWatch);
} else {
  _startAuthWatch();
}

// ============================================================
// المبالغ المستلمة من الأعضاء
// كل مبلغ يتسلمه أي عضو (غير المدير) — من فاتورة أو سداد دين — يظهر هنا
// تلقائياً بمجرد تسجيله، دون أي إدخال يدوي. المدير يؤكد استلامه فعلياً
// من العضو بعلامة صح: السطر أحمر ما لم يُستلَم بعد، ويتحول أخضر فور التأكيد.
// ============================================================
let _collectShowConfirmed = false; // إظهار/إخفاء سجل العمليات المؤكدة سابقاً داخل النافذة

function openManagerCollect() {
  if (getCurrentUserRole() !== 'manager') {
    alert('هذه الخاصية متاحة للمشرف فقط.');
    return;
  }
  _collectShowConfirmed = false;
  document.getElementById('manager-collect-modal').classList.remove('hidden');
  renderReceivedAmountsList();
}

function closeManagerCollect() {
  document.getElementById('manager-collect-modal').classList.add('hidden');
}

// كل مبلغ سجّله أي عضو (غير المدير) من مدفوعات العملاء — وهذا ما يجب على
// المدير استلامه فعلياً منه وتأكيده. تُستبعد عمليات الاسترداد النقدي (خارجة)
// وأي سجلات قديمة من نظام التحصيل اليدوي السابق.
function getEmployeeReceivedPayments() {
  return (DB.payments || []).filter(p => p.receiverRole === 'employee' && !p.isRefund && !p.isManagerCollect);
}

function toggleConfirmedHistory() {
  _collectShowConfirmed = !_collectShowConfirmed;
  renderReceivedAmountsList();
}

function renderReceivedAmountsList() {
  const modal = document.getElementById('manager-collect-modal');
  if (!modal || modal.classList.contains('hidden')) return; // النافذة مغلقة — لا داعي للرسم الآن
  const statsBox    = document.getElementById('collect-stats');
  const body        = document.getElementById('collect-list-body');
  const toggleBtn   = document.getElementById('collect-toggle-confirmed');
  const confirmedBox = document.getElementById('collect-confirmed-body');
  if (!body) return;

  const all = getEmployeeReceivedPayments();
  if (!all.length) {
    if (statsBox) statsBox.innerHTML = '';
    if (toggleBtn) toggleBtn.classList.add('hidden');
    if (confirmedBox) confirmedBox.classList.add('hidden');
    body.innerHTML = '<p class="text-xs text-slate-400 text-center py-8">لا توجد مبالغ مسجَّلة من الأعضاء بعد.</p>';
    return;
  }

  const pending   = all.filter(p => !p.handoverConfirmed).sort((a,b) => (b.timestamp||0)-(a.timestamp||0));
  const confirmed = all.filter(p =>  p.handoverConfirmed).sort((a,b) => (b.timestamp||0)-(a.timestamp||0));
  const pendingTotal   = r2(pending.reduce((a,p)=>a+(p.amount||0),0));
  const confirmedTotal = r2(confirmed.reduce((a,p)=>a+(p.amount||0),0));

  if (statsBox) {
    statsBox.innerHTML = `
      <div class="flex-1 p-3 rounded-xl bg-rose-50 border-2 border-rose-200 text-center">
        <div class="text-[11px] font-black text-rose-600">🔴 بانتظار الاستلام</div>
        <div class="text-sm font-black text-rose-700 mt-0.5">${pending.length} عملية — ${fmt(pendingTotal)}</div>
      </div>
      <div class="flex-1 p-3 rounded-xl bg-emerald-50 border-2 border-emerald-200 text-center">
        <div class="text-[11px] font-black text-emerald-600">🟢 تم تأكيدها</div>
        <div class="text-sm font-black text-emerald-700 mt-0.5">${confirmed.length} عملية — ${fmt(confirmedTotal)}</div>
      </div>`;
  }

  body.innerHTML = pending.length
    ? pending.map(_receivedAmountRowHtml).join('')
    : '<p class="text-xs text-emerald-600 font-bold text-center py-3">✅ لا توجد مبالغ بانتظار الاستلام حالياً.</p>';

  if (toggleBtn) {
    toggleBtn.classList.toggle('hidden', !confirmed.length);
    toggleBtn.textContent = _collectShowConfirmed ? `▲ إخفاء العمليات المؤكدة (${confirmed.length})` : `▼ عرض العمليات المؤكدة سابقاً (${confirmed.length})`;
  }
  if (confirmedBox) {
    confirmedBox.classList.toggle('hidden', !_collectShowConfirmed);
    if (_collectShowConfirmed) confirmedBox.innerHTML = confirmed.map(_receivedAmountRowHtml).join('');
  }
}

function _receivedAmountRowHtml(p) {
  const ok = !!p.handoverConfirmed;
  const id = p.id || '';
  const actionHtml = ok
    ? `<div class="text-left shrink-0">
         <span class="inline-flex items-center gap-1 text-emerald-700 font-black text-xs">✅ تم الاستلام</span>
         <div class="text-[10px] text-emerald-600 mt-0.5">${escapeHtml(p.handoverConfirmedBy || '')}</div>
         <button onclick="unconfirmReceivedAmount('${escapeAttr(id)}')" class="text-[10px] text-slate-400 hover:text-rose-500 font-bold mt-1 underline">تراجع</button>
       </div>`
    : `<button ${id ? '' : 'disabled'} onclick="confirmReceivedAmount('${escapeAttr(id)}')" class="shrink-0 px-4 py-2.5 rounded-xl text-white font-black text-xs shadow-sm transition-all ${id ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-95' : 'bg-slate-300 cursor-not-allowed'}">✔️ تأكيد الاستلام</button>`;
  return `
    <div class="flex items-center justify-between gap-3 p-3 rounded-xl border-2 mb-2" style="background:${ok?'#effcfd':'#fef2f0'};border-color:${ok?'#b3eef4':'#fecbc4'};">
      <div class="min-w-0 flex-1">
        <div class="flex items-center gap-2 flex-wrap">
          <span class="font-black text-slate-800 text-sm">${escapeHtml(p.signedBy || 'غير معروف')}</span>
          <span class="font-black text-base" style="color:${ok?'#047480':'#b92512'}">${fmt(p.amount)}</span>
          ${p.type ? `<span class="text-[10px] font-bold text-slate-400">${escapeHtml(p.type)}</span>` : ''}
        </div>
        <div class="text-[11px] text-slate-500 mt-0.5">${escapeHtml(p.reason || '')}</div>
        <div class="text-[10px] text-slate-400 mt-0.5">${escapeHtml(p.date || '')}</div>
      </div>
      ${actionHtml}
    </div>`;
}

async function confirmReceivedAmount(id) {
  /* تسليم المبالغ يكتب سجلات مالية على السيرفر. بلا حارس اتصال يظن
     الموظف أنه سلّم والمدير لم يستلم شيئاً — ولا يظهر الفرق إلا عند
     الجرد. وبلا مؤشّر يضغط مرتين فيُسجَّل التسليم مرتين. */
  if (!navigator.onLine) {
    alert('🔴 تسليم المبالغ يحتاج اتصالاً بالإنترنت.\n\nأعد المحاولة بعد عودة الشبكة.');
    return;
  }
  if (getCurrentUserRole() !== 'manager') return;
  if (!id) { alert('⏳ هذه العملية ما زالت قيد المزامنة مع السيرفر، أعد المحاولة خلال لحظات.'); return; }
  const p = DB.payments.find(x => x.id === id);
  if (!p) return;

  /* قفل لكل سجل على حدة لا قفل عام: المدير قد يُسلّم عدة مبالغ متتابعة،
     وقفلٌ واحد يمنعه من الثاني حتى ينتهي الأول. والمقصود منع الضغط
     مرتين على **نفس** السجل — وهو ما يُسجّل التسليم مرتين. */
  window._collectBusy = window._collectBusy || {};
  if (window._collectBusy[id]) return;
  window._collectBusy[id] = true;
  setTimeout(() => { try { delete window._collectBusy[id]; } catch (e) {} }, 4000);
  const patch = { handoverConfirmed: true, handoverConfirmedBy: getCurrentUserName(), handoverConfirmedAt: new Date().toLocaleString('ar-EG') };
  Object.assign(p, patch);
  renderReceivedAmountsList();
  showSuccessToast(`✅ تم تأكيد استلام ${fmt(p.amount)} من ${p.signedBy || ''}`);
  try { await fsUpdate('payments', id, patch); } catch (e) { /* fsUpdate تعرض تنبيهاً بالخطأ بنفسها */ }
}

async function unconfirmReceivedAmount(id) {
  if (getCurrentUserRole() !== 'manager') return;
  if (!id) return;
  if (!confirm('التراجع عن تأكيد استلام هذا المبلغ؟ سيعود للقائمة كمبلغ لم يُستلَم بعد.')) return;
  const p = DB.payments.find(x => x.id === id);
  if (!p) return;
  const patch = { handoverConfirmed: false, handoverConfirmedBy: null, handoverConfirmedAt: null };
  Object.assign(p, patch);
  renderReceivedAmountsList();
  try { await fsUpdate('payments', id, patch); } catch (e) { /* fsUpdate تعرض تنبيهاً بالخطأ بنفسها */ }
}

