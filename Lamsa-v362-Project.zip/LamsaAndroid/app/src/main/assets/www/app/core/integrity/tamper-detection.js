/* v239 — financial tamper/orphan detection. Read-only; never writes Firebase. */
(function(g){'use strict'; if(g.FinancialTamper)return;
  function arr(db,k){return Array.isArray(db&&db[k])?db[k]:[];}
  function ids(rows){const s=new Set(),dup=[];for(const r of rows){const id=String(r&&r.id||'').trim();if(!id)continue;if(s.has(id))dup.push(id);s.add(id);}return dup;}
  function scan(db){
    db=db||{}; const issues=[]; const sales=arr(db,'sales'), payments=arr(db,'payments'), returns=arr(db,'returns');
    for(const k of ['sales','payments','returns','expenses','store','trash']) for(const id of ids(arr(db,k))) issues.push({type:'duplicate-id',collection:k,id});
    const saleIds=new Set(sales.map(x=>String(x&&x.id||'')));
    payments.forEach(p=>{ if(p&&p.originalInvId&&!saleIds.has(String(p.originalInvId))) issues.push({type:'orphan-payment',id:p.id,originalInvId:p.originalInvId}); if(Array.isArray(p&&p.debtDistribution)) p.debtDistribution.forEach(d=>{if(d&&d.saleId&&!saleIds.has(String(d.saleId)))issues.push({type:'orphan-debt-distribution',id:p.id,saleId:d.saleId});}); });
    returns.forEach(r=>{if(r&&r.originalInvId&&!saleIds.has(String(r.originalInvId)))issues.push({type:'orphan-return',id:r.id,originalInvId:r.originalInvId});});
    if(g.FinancialIntegrity){const v=g.FinancialIntegrity.scan(db);for(const x of v.issues)issues.push({type:'financial-integrity',...x});}
    return {ok:issues.length===0,count:issues.length,issues};
  }
  g.FinancialTamper=Object.freeze({scan});
})(window);
