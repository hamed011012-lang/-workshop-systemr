/* Workshop Invoices v140 — receipt command boundary.
 * UI -> Command Bus -> existing receipt transaction.
 * The existing transaction remains the compatibility engine; this layer adds
 * one authoritative command identity so future migrations can replace the
 * legacy implementation without changing the UI.
 */
(function (g) {
  'use strict';
  if (g.AppReceiptCommand) return;

  function operationIdentity(mode) {
    const modal = document.getElementById('receipt-modal');
    const op = modal && modal.dataset ? modal.dataset.receiptOpKey : '';
    return String(op || '') + '|' + String(mode || 'save');
  }

  async function run(mode) {
    const identity = operationIdentity(mode);
    const execute = function () {
      if (mode === 'print') {
        if (typeof g.savePaymentReceiptAndPrint !== 'function') throw new Error('وظيفة حفظ وطباعة الواصل غير جاهزة.');
        return g.savePaymentReceiptAndPrint();
      }
      if (typeof g.savePaymentReceipt !== 'function') throw new Error('وظيفة حفظ الواصل غير جاهزة.');
      return g.savePaymentReceipt();
    };

    if (g.AppCommands && typeof g.AppCommands.run === 'function') {
      const result = await g.AppCommands.run('receipt.save', identity, execute, { mode });
      if (result && result.skipped) {
        if (typeof g.showSuccessToast === 'function') g.showSuccessToast('ℹ️ هذه العملية قيد التنفيذ أو تم تنفيذها بالفعل.');
        return false;
      }
      return result ? result.value !== false : false;
    }
    return await execute();
  }

  g.AppReceiptCommand = Object.freeze({ run });
})(window);
