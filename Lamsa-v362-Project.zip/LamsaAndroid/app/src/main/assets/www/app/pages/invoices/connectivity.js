
    // رصد الاتصال يعمل بالكامل، لكن بلا شريط أحمر ظاهر (بناءً على الطلب).
    // الحالة تُنشر عبر الفئة is-offline على <html> وعبر حدث connectivity-change،
    // ويتكفّل shared.js بالمؤشر الصغير. تُترك الدالة معرَّفة للتوافق مع أي استدعاء قديم.
    function _updateConnectivityBanner() {
      const banner = document.getElementById('connectivity-banner');
      if (banner) { banner.classList.add('hidden'); banner.style.display = 'none'; }
      document.documentElement.classList.toggle('is-offline', !navigator.onLine);
    }
    window.addEventListener('online', _updateConnectivityBanner);
    window.addEventListener('offline', _updateConnectivityBanner);
    _updateConnectivityBanner();
  