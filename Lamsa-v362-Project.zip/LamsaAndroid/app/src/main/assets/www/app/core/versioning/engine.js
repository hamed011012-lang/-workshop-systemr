/* Workshop Version Engine v152 — optimistic local versioning.
 * Additive: does not replace Firebase conflict handling. Tracks per-entity version
 * and revision history locally so concurrent edits can be detected safely.
 */
(function(g){'use strict'; if(g.AppVersioning)return;
  const META='meta'; const HISTORY='records'; const now=()=>Date.now();
  // Serialize local version increments per entity so two concurrent saves in the
  // same tab/context cannot both observe the same version. Remote Firestore
  // conflict detection remains authoritative across devices/users.
  const nextQueues=new Map();
  const key=(entity,id)=>`version:${String(entity)}:${String(id)}`;
  async function read(entity,id){
    if(!g.AppDB)return {version:0,updatedAt:0};
    const r=await g.AppDB.get(META,key(entity,id));
    return r||{key:key(entity,id),entity:String(entity),entityId:String(id),version:0,updatedAt:0};
  }
  async function next(entity,id,source){
    if(!g.AppDB)return {version:1,updatedAt:now()};
    const qkey=key(entity,id), previous=nextQueues.get(qkey)||Promise.resolve();
    const run=previous.catch(()=>{}).then(async()=>{
      const current=await read(entity,id);
      const n={key:qkey,entity:String(entity),entityId:String(id),version:Number(current.version||0)+1,updatedAt:now(),source:String(source||'local')};
      await g.AppDB.put(META,n); return n;
    });
    nextQueues.set(qkey,run);
    try{return await run;}finally{if(nextQueues.get(qkey)===run)nextQueues.delete(qkey);}
  }
  async function check(entity,id,expected){
    const current=await read(entity,id); const e=Number(expected||0);
    return {ok:current.version===e,current,expected:e,conflict:current.version!==e};
  }
  async function stamp(entity,id,payload,source){
    const v=await next(entity,id,source);
    return Object.assign({},payload,{_version:v.version,_versionUpdatedAt:v.updatedAt,_versionSource:v.source});
  }
  function entityIdSafe(entity,id){return String(id);}
  async function record(entity,id,payload,operationId){
    if(!g.AppDB)return;
    const v=await read(entity,id);
    const rid=`revision:${entity}:${id}:${v.version}:${operationId||now()}`;
    await g.AppDB.put(HISTORY,{key:rid,collection:'revisions',id:rid,entity:String(entity),entityId:String(id),version:Number(v.version||0),operationId:String(operationId||''),data:payload||null,createdAt:now(),updatedAt:now()}); if(g.AppFieldRevisions){try{const prev=await list(entity,id,2); const before=prev.length>1?prev[1].data:(prev.length?prev[0].data:null); await g.AppFieldRevisions.record({entity,entityId:String(id),version:Number(v.version||0),operationId:String(operationId||''),before,after:payload});}catch(_){}}
  }
  async function list(entity,id,limit){
    if(!g.AppDB)return [];
    const rows=await g.AppDB.list(HISTORY,Math.max(1,Number(limit)||1000));
    return rows.filter(x=>x&&x.collection==='revisions'&&(!entity||x.entity===String(entity))&&(!id||x.entityId===String(id)));
  }
  async function compare(entity,id,expectedVersion){ const current=await read(entity,id); const expected=Number(expectedVersion||0); return {entity:String(entity),entityId:String(id),expected,currentVersion:Number(current.version||0),same:Number(current.version||0)===expected,stale:Number(current.version||0)>expected,ahead:Number(current.version||0)<expected}; }
  async function health(){
    try{await g.AppDB.open();return {available:true};}catch(error){return {available:false,error:String(error&&error.message||error)};}
  }
  g.AppVersioning=Object.freeze({read,next,check,compare,stamp,record,list,health,key});
})(window);
