/* Workshop Invoices v144 — Invoice Command Gateway
 * Phase 5: one guarded entry point for create/update/delete/restore.
 * The legacy invoice engine remains the source of business rules; this layer
 * adds operation locking, repository persistence, and audit without rewriting it.
 */
(function (g) {
  'use strict';
  if (g.InvoiceCommands) return;

  const busy = new Map();
  const HOLD_MS = 1400;

  function idOf(value) {
    return String(value == null ? '' : value).trim();
  }

  function run(kind, identity, work, after) {
    const key = kind + ':' + idOf(identity || 'screen');
    if (busy.has(key)) return { skipped: true, reason: 'busy' };
    busy.set(key, Date.now());
    try {
      const result = work();
      Promise.resolve().then(() => after && after(result)).catch(e => {
        if (g.wsSilent) g.wsSilent('invoice-command:after', e);
      });
      if (g.AppAudit) Promise.resolve(g.AppAudit.record('invoice-command', { kind, identity: idOf(identity), actorUid: (typeof g.getCurrentUserUid === 'function' ? g.getCurrentUserUid() : ''), financialScan: (g.FinancialTamper && g.FinancialTamper.scan ? g.FinancialTamper.scan(g.DB || {}) : null) })).catch(() => {});
      return { skipped: false, value: result };
    } finally {
      setTimeout(() => busy.delete(key), HOLD_MS);
    }
  }

  async function put(id) {
    if (!g.InvoiceRepository || !id) return;
    const sales = Array.isArray(g.DB && g.DB.sales) ? g.DB.sales : [];
    const inv = sales.find(x => x && String(x.id) === String(id));
    if (inv) await g.InvoiceRepository.put(inv);
  }

  async function remove(id) {
    if (g.InvoiceRepository && id) await g.InvoiceRepository.remove(id);
  }

  function install(name, kind, identityFn, afterFn) {
    const original = g[name];
    if (typeof original !== 'function' || original.__wsInvoiceCommandWrapped) return false;
    function wrapped() {
      const args = arguments;
      let identity = '';
      try { identity = identityFn ? identityFn.apply(this, args) : ''; } catch (_) {}
      const result = run(kind, identity, () => original.apply(this, args), () => afterFn && afterFn(identity, args));
      return result.skipped ? undefined : result.value;
    }
    wrapped.__wsInvoiceCommandWrapped = true;
    wrapped.__wsInvoiceCommandOriginal = original;
    g[name] = wrapped;
    return true;
  }

  function installAll() {
    install('saveCurrentInvoice', 'create', () => {
      const el = document.getElementById('pos-edit-id');
      return (el && el.value) || 'new';
    }, async identity => {
      const sales = Array.isArray(g.DB && g.DB.sales) ? g.DB.sales : [];
      const inv = identity !== 'new' ? sales.find(x => x.id === identity) : sales[sales.length - 1];
      if (inv) await put(inv.id);
    });

    install('confirmDraftInvoice', 'draft-create', () => {
      const d = g.draftData;
      return d && d.id ? d.id : 'draft';
    }, async () => {
      const sales = Array.isArray(g.DB && g.DB.sales) ? g.DB.sales : [];
      const inv = sales[sales.length - 1];
      if (inv) await put(inv.id);
    });

    install('saveEditedInvoice', 'update', () => {
      const el = document.getElementById('modal-inv-id');
      return el && el.value;
    }, async identity => { if (identity) await put(identity); });

    install('deleteInvoiceToTrash', 'delete', argsId => argsId, async identity => {
      if (!identity) return;
      const sales = Array.isArray(g.DB && g.DB.sales) ? g.DB.sales : [];
      if (!sales.some(x => x && String(x.id) === String(identity))) await remove(identity);
    });

    install('restoreTrashItem', 'restore', idx => {
      const t = g.DB && Array.isArray(g.DB.trash) ? g.DB.trash[idx] : null;
      return t && t.payload ? t.payload.id : String(idx);
    }, async identity => {
      if (identity) await put(identity);
    });
    g.__wsInvoiceCommandsInstalled = true;
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', installAll, { once: true });
  else installAll();

  g.InvoiceCommands = Object.freeze({ install: installAll });
})(window);
