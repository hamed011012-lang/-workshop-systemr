
    /* بديل صامت إن تعذّر تحميل lucide (أول فتح دون اتصال مثلاً).
       بدونه كان أول استدعاء lucide.createIcons() يرمي خطأً يوقف بقية
       السكربت كلياً، فتفتح الصفحة فارغة تماماً بلا أي رسالة. */
    if (typeof lucide === 'undefined') window.lucide = { createIcons: function(){} };
  