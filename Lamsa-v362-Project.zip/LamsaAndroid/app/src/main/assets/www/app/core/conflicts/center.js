/* Workshop Conflict Center v152.
 * Conservative conflict handling: never overwrites remote/local data automatically.
 * Persists conflict records in IndexedDB and exposes explicit inspect/resolve APIs.
 */
(function(g){'use strict'; if(g.AppConflictCenter)return;
  const STORE='conflicts';
  const now=()=>Date.now();
  const safe=s=>{try{return JSON.stringify(s)}catch(_){return String(s)}};
  const idOf=(row,error)=>String((row&&row.id)||('conflict:'+now()+':'+Math.random().toString(36).slice(2)));
  async function save(conflict){
    if(!g.AppDB||!g.AppDB.put) return conflict;
    const existing=await g.AppDB.get(STORE,conflict.id);
    if(existing && existing.status==='resolved') return existing;
    await g.AppDB.put(STORE,Object.assign({},existing||{},conflict,{updatedAt:now()}));
    return conflict;
  }
  async function capture(payload){
    const row=payload&&payload.row||{}; const error=payload&&payload.error||{};
    const id=idOf(row,error);
    const c={id, status:'open', entity:String(row.entity||'unknown'), entityId:String(row.entityId||''), operationId:String(row.id||''), type:String(row.type||'unknown'), version:Number(row.version||0), payload:row.payload==null?null:row.payload, error:{code:String(error.code||'conflict'),message:String(error.message||error)}, createdAt:now(), updatedAt:now(), attempts:Number(row.tries||0)};
    await save(c);
    try{g.AppEvents&&g.AppEvents.emit&&g.AppEvents.emit('conflict:created',c);}catch(_){}
    return c;
  }
  async function list(limit){
    if(!g.AppDB||!g.AppDB.list)return [];
    const rows=await g.AppDB.list(STORE,Math.max(1,Number(limit)||500));
    return rows.filter(x=>x&&x.status!=='resolved');
  }
  async function all(limit){return g.AppDB&&g.AppDB.list?g.AppDB.list(STORE,Math.max(1,Number(limit)||1000)):[];}
  async function resolve(id,decision,meta){
    if(!g.AppDB)throw new Error('التخزين المحلي غير متاح');
    const c=await g.AppDB.get(STORE,String(id)); if(!c)throw new Error('التعارض غير موجود');
    const next=Object.assign({},c,{status:'resolved',decision:String(decision||'reviewed'),resolution:meta||null,resolvedAt:now(),updatedAt:now()});
    await g.AppDB.put(STORE,next);
    try{g.AppEvents&&g.AppEvents.emit&&g.AppEvents.emit('conflict:resolved',next);}catch(_){}
    return next;
  }
  async function reopen(id){
    if(!g.AppDB)throw new Error('التخزين المحلي غير متاح');
    const c=await g.AppDB.get(STORE,String(id)); if(!c)throw new Error('التعارض غير موجود');
    c.status='open';c.updatedAt=now();await g.AppDB.put(STORE,c);return c;
  }
  async function count(){return (await list(5000)).length;}
  function label(c){return c?`${c.entity||'unknown'} ${c.entityId||''} — ${c.error&&c.error.message||'تعارض'}`:'تعارض';}
  async function inspect(id){const c=await g.AppDB.get(STORE,String(id));if(!c)throw new Error('التعارض غير موجود');return g.AppConflictResolver&&g.AppConflictResolver.inspect?g.AppConflictResolver.inspect(c):c;}
  async function refreshBadge(){
    const b=document.getElementById('conflict-center-badge'); if(!b)return;
    const n=await count();
    b.textContent=n?`⚠️ ${n} تعارضات`:'لا توجد تعارضات';
    b.classList.toggle('hidden',!n);
  }
  async function show(){
    const rows=await list(20);
    if(!rows.length){alert('✅ لا توجد تعارضات مفتوحة.');return;}
    let msg=`⚠️ تعارضات تحتاج مراجعة (${rows.length})\n\n`;
    rows.forEach((c,i)=>{msg+=`${i+1}) ${label(c)}\nالعملية: ${c.operationId||'-'}\nالنوع: ${c.type}\n\n`;});
    msg+='لم يتم الكتابة فوق أي بيانات تلقائيًا.';
    alert(msg);
  }
  g.AppConflictCenter=Object.freeze({capture,list,all,resolve,reopen,count,label,refreshBadge,show,inspect});
  if(g.AppEvents&&g.AppEvents.on) g.AppEvents.on('sync:conflict',p=>capture(p).then(refreshBadge).catch(()=>{}));
  const init=()=>setTimeout(()=>refreshBadge().catch(()=>{}),1000);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(window);
