from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote
import json,hashlib,xml.etree.ElementTree as ET
root=Path('app/src/main/assets');manifest=json.loads((root/'vendor-map.json').read_text())
for u,e in manifest.items():assert hashlib.sha256((root/e['path']).read_bytes()).hexdigest()==e['sha256']
class P(HTMLParser):
 def handle_starttag(self,t,a):
  a=dict(a);u=a.get('src') if t=='script' else a.get('href') if t=='link' and a.get('rel') in ['stylesheet','manifest','icon'] else None
  if not u:return
  if u.startswith('https://'):
   if t=='script' or a.get('rel')=='stylesheet':assert u in manifest,u
  elif not u.startswith(('data:','//','#')):assert (root/'www'/unquote(urlparse(u).path)).exists(),u
for p in (root/'www').glob('*.html'):P().feed(p.read_text())
ET.parse('app/src/main/AndroidManifest.xml')
print('PASS: 33 bundled dependencies and hashes; external/local boot assets; manifest XML')
