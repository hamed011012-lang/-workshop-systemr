/* v142 — Invoice/Receipt local repository.
 * Single local contract for receipt durability. Remote Firebase remains a sync sink.
 */
(function(g){'use strict';
  const VERSION_ENTITY='receipts';
  async function versioned(data,id,source){ if(g.AppVersioning&&g.AppVersioning.stamp) return g.AppVersioning.stamp(VERSION_ENTITY,String(id),data,source); return data; }
 if(g.ReceiptRepository)return;
  const COLLECTION='receipts';
  const key=id=>COLLECTION+':'+String(id);
  function valid(id){const x=String(id||'').trim();if(!x)throw new Error('معرّف الواصل مطلوب');return x;}
  async function get(id){if(!g.AppDB)return null;const r=await g.AppDB.get('records',key(valid(id)));return r?r.data:null;}
  async function put(item){
    if(!g.AppDB) return false;
    const id=valid(item&&item.id), now=Date.now(), existing=await g.AppDB.get('records',key(id));
    if(existing && existing.data && existing.data.clientOperationId && item.clientOperationId && existing.data.clientOperationId!==item.clientOperationId)
      throw new Error('تعارض في هوية عملية الواصل المحلية');
    
    item=await versioned(item, item.id, 'repository');await g.AppDB.put('records',{key:key(id),collection:COLLECTION,id,data:item,createdAt:existing&&existing.createdAt||now,updatedAt:now});
    return true;
  }
  async function list(limit){
    if(!g.AppDB)return [];
    const rows=await g.AppDB.list('records',Math.max(1,Number(limit)||1000));
    return rows.filter(x=>x&&x.collection===COLLECTION).map(x=>x.data);
  }
  async function remove(id){if(g.AppDB)await g.AppDB.del('records',key(valid(id)));}
  async function markSynced(id){const x=await get(id);if(!x)return;await put(Object.assign({},x,{syncedAt:Date.now()}));}
  async function pending(limit){const rows=await list(limit);return rows.filter(x=>x&&!x.syncedAt);}
  g.ReceiptRepository=Object.freeze({collection:COLLECTION,get,put,list,remove,markSynced,pending});
})(window);
