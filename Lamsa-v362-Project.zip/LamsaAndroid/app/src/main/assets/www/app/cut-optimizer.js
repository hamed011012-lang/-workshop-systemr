(function(g){'use strict';
function solve(pieces,stock,kerf=0){
 const scale=10000,capacity=Math.round(stock*scale),K=Math.round(kerf*scale);
 if(!(capacity>0)||K<0||!Number.isFinite(K))throw Error('طول عود أو سماكة سلاح غير صالحة');
 const sorted=pieces.map(p=>({...p,cost:Math.round(p.length*scale)+K})).sort((a,b)=>b.cost-a.cost||a.source-b.source);
 const invalid=sorted.some(p=>!(p.cost>0)||p.cost>capacity);
 if(invalid)return {rods:[],invalid:true,optimal:false,kerf};
 let bins=[];
 for(const p of sorted){let best=null;for(const b of bins)if(b.used+p.cost<=capacity&&(!best||b.used>best.used))best=b;if(!best){best={used:0,pieces:[]};bins.push(best);}best.used+=p.cost;best.pieces.push(p);}
 const lower=Math.max(Math.ceil(sorted.reduce((n,p)=>n+p.cost,0)/capacity),sorted.filter(p=>p.cost>capacity/2).length);
 let optimal=bins.length===lower,nodes=0,aborted=false;
 if(!optimal&&sorted.length<=80){
  for(let target=lower;target<bins.length;target++){
   const trial=Array.from({length:target},()=>({used:0,pieces:[]}));
   function visit(i){if(++nodes>200000){aborted=true;return false;}if(i===sorted.length)return true;
    const p=sorted[i],seen=new Set();
    const order=trial.slice().sort((a,b)=>b.used-a.used);
    for(const b of order){if(seen.has(b.used)||b.used+p.cost>capacity)continue;seen.add(b.used);b.used+=p.cost;b.pieces.push(p);if(visit(i+1))return true;b.pieces.pop();b.used-=p.cost;if(aborted)return false;if(b.used===0)break;}return false;
   }
   if(visit(0)){bins=trial;optimal=true;break;}if(aborted)break;
   if(target===bins.length-1)optimal=true;
  }
 }
 return {rods:bins.filter(b=>b.pieces.length).map(b=>({used:b.used/scale,pieces:b.pieces.map(({cost,...p})=>p)})),invalid:false,optimal,kerf};
}
g.WSCutOptimizer=Object.freeze({solve});if(typeof module!=='undefined')module.exports=g.WSCutOptimizer;
})(typeof window==='undefined'?globalThis:window);
