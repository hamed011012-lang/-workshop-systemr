/* Workshop Core v139 — one safe path for user commands.
 * Claim -> execute -> audit -> release. Duplicate clicks are stopped here.
 */
(function (g) {
  'use strict';
  if (g.AppCommands) return;

  async function run(name, identity, work, meta) {
    const key = g.AppIdempotency.make(['command', name, identity]);
    if (!g.AppIdempotency.claim(key, 7000)) return { skipped: true, reason: 'busy', key };
    try {
      if (g.AppIdempotency.has(key)) return { skipped: true, reason: 'duplicate', key };
      const value = await work();
      g.AppIdempotency.mark(key);
      if (g.AppAudit) await g.AppAudit.record('command', { name, identity, meta: meta || {} });
      return { skipped: false, key, value };
    } finally {
      g.AppIdempotency.release(key);
    }
  }

  g.AppCommands = Object.freeze({ run });
})(window);
