/* Generic local outbox. It is deliberately independent of Firebase so the UI remains usable offline. */
(function (g) {
  'use strict'; if (g.AppOutbox) return;
  const KEY='ws:v141:outbox:v1';
  const read=()=>{try{const x=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(x)?x:[]}catch(_){return[]}};
  const write=a=>{try{localStorage.setItem(KEY,JSON.stringify(a.slice(-300)));return true}catch(_){return false}};
  function enqueue(type,payload,id){const a=read(), key=String(id||((g.AppIdempotency&&g.AppIdempotency.make)?g.AppIdempotency.make([type,JSON.stringify(payload)]):Date.now())); if(a.some(x=>x&&x.id===key)) return key; a.push({id:key,type,payload,createdAt:Date.now(),tries:0}); write(a); return key;}
  function pending(){return read();}
  function remove(id){write(read().filter(x=>x&&x.id!==id));}
  function update(id,patch){const a=read(),i=a.findIndex(x=>x&&x.id===id);if(i<0)return false;a[i]=Object.assign({},a[i],patch);return write(a);}
  g.AppOutbox=Object.freeze({enqueue,pending,remove,update});
})(window);
