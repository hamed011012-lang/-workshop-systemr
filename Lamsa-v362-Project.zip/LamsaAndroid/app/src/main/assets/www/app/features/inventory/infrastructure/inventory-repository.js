/* Workshop Inventory v147 — local inventory repository.
 * Additive migration layer: DB.store remains authoritative during rollout.
 * Mirrors stock items and keeps a durable movement ledger for reconciliation.
 */
(function(g){'use strict';
  const VERSION_ENTITY='inventory';
  async function versioned(data,id,source){ if(g.AppVersioning&&g.AppVersioning.stamp) return g.AppVersioning.stamp(VERSION_ENTITY,String(id),data,source); return data; }
 if(g.InventoryRepository)return;
  const COLLECTION='inventory';
  const LEDGER='inventory-movements';
  const key=id=>COLLECTION+':'+String(id);
  const clean=id=>{const x=String(id==null?'':id).trim(); if(!x) throw new Error('معرّف الصنف مطلوب'); return x;};
  function normalize(item){
    if(!item||!item.id)return null;
    return Object.assign({},item,{id:String(item.id),_inventoryVersion:149,_localUpdatedAt:Date.now()});
  }
  async function get(id){if(!g.AppDB)return null; const r=await g.AppDB.get('records',key(clean(id))); return r?r.data:null;}
  async function put(item){
    const x=normalize(item); if(!x||!g.AppDB)return false;
    const old=await get(x.id), now=Date.now();
    
    const data=await versioned(x, x.id, 'repository');await g.AppDB.put('records',{key:key(x.id),collection:COLLECTION,id:x.id,data,createdAt:old&&old._createdAt||now,updatedAt:now});
    return true;
  }
  async function remove(id){if(g.AppDB)await g.AppDB.del('records',key(clean(id)));}
  async function list(limit){
    if(!g.AppDB)return [];
    const rows=await g.AppDB.list('records',Math.max(1,Number(limit)||5000));
    return rows.filter(x=>x&&x.collection===COLLECTION).map(x=>x.data);
  }
  function sig(item){try{return JSON.stringify([item.id,item.name,item.qty,item.price,JSON.stringify(item.recipe||[])]);}catch(_){return String(item.id);}}
  async function mirrorAll(items){
    if(!Array.isArray(items)||!g.AppDB)return {saved:0}; let saved=0;
    for(const item of items){
      if(!item||!item.id)continue;
      const old=await get(item.id);
      if(!old||sig(old)!==sig(item)){await put(item);saved++;}
    }
    return {saved};
  }
  async function recordMovement(m){
    if(!g.AppDB||!m||!m.itemId||!m.delta)return false;
    const op=String(m.operationId||'').trim();
    if(!op)return false; // no durable ledger entry without a stable operation identity
    const id=op+':'+String(m.itemId);
    const row={id,itemId:String(m.itemId),delta:Number(m.delta)||0,reason:String(m.reason||'stock-movement'),invoiceId:String(m.invoiceId||''),operationId:op,at:Number(m.at||Date.now())};
    const record={key:LEDGER+':'+id,collection:LEDGER,id,data:row,createdAt:row.at,updatedAt:row.at};
    // Use IndexedDB add when available: unlike get()+put(), add is atomic and
    // therefore prevents the same operation from being recorded twice across tabs.
    if(typeof g.AppDB.add==='function'){
      try{await g.AppDB.add('records',record);return {duplicate:false,id};}
      catch(error){
        const code=String(error&&error.name||'');
        if(code==='ConstraintError')return {duplicate:true,id};
        throw error;
      }
    }
    const old=await g.AppDB.get('records',LEDGER+':'+id);
    if(old)return {duplicate:true,id};
    await g.AppDB.put('records',record);
    return {duplicate:false,id};
  }
  async function movementList(limit){
    if(!g.AppDB)return [];
    const rows=await g.AppDB.list('records',Math.max(1,Number(limit)||5000));
    return rows.filter(x=>x&&x.collection===LEDGER).map(x=>x.data);
  }
  async function reconcile(items){return mirrorAll(items);}
  g.InventoryRepository=Object.freeze({collection:COLLECTION,get,put,upsert:put,remove,list,mirrorAll,reconcile,recordMovement,movementList});
})(window);
