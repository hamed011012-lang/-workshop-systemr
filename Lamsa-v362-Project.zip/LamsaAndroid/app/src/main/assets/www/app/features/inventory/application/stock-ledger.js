/* Workshop Inventory v149 — authoritative movement ledger / reconciliation.
 * The legacy stock quantity remains executable authority during migration.
 * This module makes every post-v149 quantity change auditable and verifies
 * current quantities against a durable baseline + movement ledger.
 */
(function(g){'use strict'; if(g.StockLedger)return;
  const META='stock-ledger:baseline:';
  const n=v=>Number.isFinite(Number(v))?Number(v):0;
  const key=id=>META+String(id);
  async function movements(){ return g.InventoryRepository&&g.InventoryRepository.movementList ? g.InventoryRepository.movementList(20000) : []; }
  async function aggregate(){
    const rows=await movements(), map=new Map(), ops=new Set(), duplicateOps=new Set();
    for(const r of rows){
      const item=String(r.itemId||''); if(!item)continue;
      map.set(item,n(map.get(item))+n(r.delta));
      const op=String(r.operationId||''); if(op){ if(ops.has(op)) duplicateOps.add(op); else ops.add(op); }
    }
    return {rows,map,duplicateOps};
  }
  async function ensureBaseline(items){
    if(!g.AppDB)return {created:0};
    const current=Array.isArray(items)?items:[]; const a=await aggregate(); let created=0;
    for(const item of current){ if(!item||!item.id)continue; const id=String(item.id); const existing=await g.AppDB.get('meta',key(id)); if(existing)continue;
      const baseline=n(item.qty)-n(a.map.get(id));
      await g.AppDB.put('meta',{key:key(id),itemId:id,baseline,createdAt:Date.now(),version:149}); created++;
    }
    return {created};
  }
  async function reconcile(items){
    if(!g.AppDB)return {ok:true,available:false,mismatches:[],duplicates:[]};
    const list=Array.isArray(items)?items:[]; await ensureBaseline(list); const a=await aggregate();
    const mismatches=[];
    for(const item of list){ if(!item||!item.id)continue; const id=String(item.id); const base=await g.AppDB.get('meta',key(id)); if(!base)continue;
      const expected=n(base.baseline)+n(a.map.get(id)); const actual=n(item.qty); const delta=actual-expected;
      if(Math.abs(delta)>1e-9)mismatches.push({itemId:id,name:String(item.name||''),actual,expected,delta});
    }
    return {ok:mismatches.length===0&&a.duplicateOps.size===0,available:true,checked:list.length,movementCount:a.rows.length,mismatches,duplicates:Array.from(a.duplicateOps)};
  }
  async function report(){
    const items=Array.isArray(g.DB&&g.DB.store)?g.DB.store:[]; return reconcile(items);
  }
  g.StockLedger=Object.freeze({version:149,ensureBaseline,reconcile,report,aggregate});
})(window);
