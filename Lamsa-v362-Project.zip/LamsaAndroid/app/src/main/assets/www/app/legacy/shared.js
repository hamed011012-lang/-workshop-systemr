/* ============================================================
   shared.js — النواة الموحّدة لكل تطبيقات الورشة   (نسخة 2.0)
   (القياسات / الفواتير / القص وحساب المواد الخام)
   ------------------------------------------------------------
   يُحمَّل قبل كود كل صفحة، ويوفّر:
   • اتصال Firebase واحد (Auth + Firestore) مع تخزين محلي مضمون
   • طبقة كتابة لا تنتظر السيرفر إطلاقاً (تعمل دون اتصال)
   • صندوق صادر (Outbox) يتابع ما لم يُرفع بعد ويستأنفه تلقائياً
   • حارس دخول موحّد + هوية محفوظة محلياً للعمل الميداني
   • أدوات تهريب نصوص (escHtml/escAttr) لمنع كسر الواجهة والحقن
   • تنقّل سلس بين الأقسام: انتقال بصري + سحب بالإصبع + تحميل مسبق
   ============================================================ */
'use strict';

/* بصمة النسخة — تُطبع في console وتظهر أسفل الصفحة الرئيسية.
   فائدتها عملية: عند ظهور أي خلل تعرف فوراً أي نسخة تعمل على الجهاز فعلاً،
   بدل تخمين ما إذا كان الجهاز ما زال يفتح نسخة قديمة مخزَّنة. */
const WS_BUILD = 'v360.1';
const WS_BUILD_DATE = '2026-10-28';
window.WS_BUILD = WS_BUILD;
console.log('%c نظام الورشة ' + WS_BUILD + ' (' + WS_BUILD_DATE + ') ', 'background:#0f172a;color:#fff;padding:3px 8px;border-radius:4px');

/* ============================================================
   تحديث إجباري — يمسح النسخة المخزَّنة ويُعيد التحميل من الخادم
   ------------------------------------------------------------
   يُستدعى عند الشك في أن الجهاز ما زال يفتح نسخة قديمة رغم رفع
   ملفات جديدة. لا يمس بيانات Firestore إطلاقاً — يمسح ملفات
   الواجهة المخزَّنة فقط.
   ============================================================ */
async function wsForceUpdate() {
  if ((window.wsPendingWrites || 0) > 0) {
    if (!confirm('⏳ ما زال هناك عمل لم يُرفع للسيرفر. التحديث الآن قد يؤخّر رفعه.\n\nهل تريد المتابعة؟')) return;
  }
  try {
    if (!window.WS_ANDROID && 'serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
    if (window.caches) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
  } catch (e) { console.warn('wsForceUpdate:', e); }
  // معامل عشوائي يتجاوز ذاكرة المتصفح نفسها لا ذاكرة Service Worker فقط
  window.location.replace(location.pathname + '?fresh=' + Date.now());
}
window.wsForceUpdate = wsForceUpdate;

const firebaseConfig = {
  apiKey: "AIzaSyBg-Fa9AXpc9obFnluZzRJL2eBa7TnyxNg",
  authDomain: "smart-center-7b530.firebaseapp.com",
  databaseURL: "https://smart-center-7b530-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "smart-center-7b530",
  storageBucket: "smart-center-7b530.firebasestorage.app",
  messagingSenderId: "225888431424",
  appId: "1:225888431424:web:b45dad4b0c2023d7e61ea5",
  measurementId: "G-L4TKN4Q9ZB"
};

// حساب المدير الأساسي (صلاحية كاملة تلقائياً بلا حاجة لسجلّ عضوية)
const ADMIN_EMAIL = 'hamed011012@gmail.com';

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

/* ============================================================
   1) أدوات تهريب النصوص — تُستخدم في كل الصفحات
   ------------------------------------------------------------
   المشكلة التي تعالجها: اسم عميل أو صنف يحتوي على علامة اقتباس
   ( مثل  O'Brien  أو  مقاس 5" ) كان يكسر زر «واصل سداد» أو «صرف كاش»
   فلا يعمل إطلاقاً بلا أي رسالة، ويفتح ثغرة حقن HTML.
   escHtml : للنص الظاهر داخل العنصر.
   escAttr : لأي قيمة توضع داخل خاصية (onclick="fn('...')").
   ============================================================ */
/* ============================================================
   الأرقام والنصوص العربية — مصدر واحد لكل الصفحات   (جديد في 8.8)
   ------------------------------------------------------------
   كان لكل صفحة معالجتها الخاصة: toLatinDigits في الفواتير،
   toLatinDigitsM في القياسات، و**لا شيء إطلاقاً** في القص. والنتيجة
   أخطاء حسابية صامتة لا رسالة خطأ فيها ولا أثر:

   • في القص: من يكتب «١٢٠ × ٢١٠» بلوحة مفاتيح عربية (وهي الافتراضية
     على أغلب الهواتف هنا) يحصل على NaN ثم صفر — فتُحسب أطوال قصّ
     خاطئة ويُقصّ الألمنيوم عليها. خسارة مادة لا رجعة فيها.
   • في الفواتير: أربعة مواضع تستدعي parseFloat على النص الخام **قبل**
     r2، فتتجاوز التحويل: مبلغ السداد في نافذة الدفع، وكمية وسعر الصنف
     الجديد. يُقرأ المبلغ صفراً فيُسجَّل دين على عميل دفع فعلاً.

   ملاحظة دقيقة: \d في تعابير جافاسكربت النمطية لا تطابق إلا 0-9
   اللاتينية. فأي تنظيف بـ [^\d.] يمسح الأرقام العربية مسحاً بدل
   تحويلها — وهذا ما كان يقع في cutting.html: numOf ترجع null دائماً.
   لذلك التحويل يسبق التنظيف دائماً في wsNum أدناه.
   ============================================================ */
function wsToLatinDigits(v) {
  if (v == null) return '';
  if (typeof v === 'number') return String(v);
  return String(v)
    .replace(/[\u0660-\u0669]/g, d => String(d.charCodeAt(0) - 0x0660))  // ٠-٩ عربية
    .replace(/[\u06F0-\u06F9]/g, d => String(d.charCodeAt(0) - 0x06F0))  // ۰-۹ فارسية
    .replace(/\u066B/g, '.')                                             // الفاصلة العشرية العربية
    .replace(/\u066C/g, '')                                              // فاصلة الآلاف العربية
    .replace(/\u060C/g, '')                                              // الفاصلة العربية
    .replace(/[\u200E\u200F\u061C\u202A-\u202E\u2066-\u2069\uFEFF]/g, '') // محارف الاتجاه غير المرئية
    .replace(/\u00A0/g, ' ');                                            // مسافة غير قابلة للكسر
}

/* قراءة JSON من التخزين المحلي بلا أن تُسقط الصفحة   (جديد في 8.8)
   ------------------------------------------------------------
   كان في measurements.html سطران في **النطاق الأعلى** للكتلة:

       let priceDB     = JSON.parse(safeGetItem('workshop_prices') || '[]');
       let noteHistory = JSON.parse(safeGetItem('note_history')    || '[...]');

   و safeGetItem تحمي من فشل القراءة، لكنها لا تحمي من **قيمة مقروءة
   تالفة**. وقيمة واحدة نصفها مكتوب (كتابة انقطعت عند امتلاء الحصة، أو
   إغلاق مفاجئ أثناء الحفظ) تجعل JSON.parse ترمي SyntaxError — والرمي
   في النطاق الأعلى يوقف **تنفيذ كتلة السكربت كلها**.

   النتيجة: صفحة القياسات تفتح بيضاء لا يعمل فيها زر واحد، بلا رسالة
   ولا سبب ظاهر، وتبقى كذلك في كل فتحة إلى أن تُمسح بيانات المتصفح —
   أي أن مفتاحاً تالفاً واحداً كان يُعطّل الصفحة تعطيلاً دائماً.

   wsParse تُعيد البديل عند أي تلف، وتُسجّل ما جرى في الـ console
   ليبقى الأثر لمن يبحث. */
function wsParse(raw, fallback) {
  if (raw == null || raw === '') return fallback;
  try {
    const v = JSON.parse(raw);
    return (v === null || v === undefined) ? fallback : v;
  } catch (e) {
    console.error('wsParse: قيمة مخزَّنة تالفة، أُهملت واستُعمل البديل:', e);
    return fallback;
  }
}
window.wsParse = wsParse;

/* wsNum: قراءة رقم من أي إدخال بشري. يُعيد fallback (صفر افتراضاً)
   بدل NaN، فلا يتسرّب NaN إلى حساب مالي فيلوّث كل مجموع بعده. */
function wsNum(v, fallback) {
  const fb = (fallback === undefined) ? 0 : fallback;
  if (typeof v === 'number') return isFinite(v) ? v : fb;
  const s = wsToLatinDigits(v).trim().replace(/,/g, '');
  if (!s) return fb;
  const n = parseFloat(s);
  return isFinite(n) ? n : fb;
}

/* توحيد اسم العميل للمطابقة والتجميع — لا للعرض.

   الديون تُجمَّع بمساواة نصية تامة (s.customerName === name). وفي
   العربية هذا يعني أن «أحمد» و«احمد» و«أحمد » (بمسافة زائدة) ثلاثة
   عملاء منفصلين: الدين ينقسم على ثلاثة سجلات، ورصيد أحدهم لا يسدّد
   دين الآخر، ويظهر العميل مرات في قائمة المديونين. وهذا يقع يومياً
   لأن الهمزة والمسافة الزائدة أشيع أخطاء الكتابة عندنا.

   نُوحّد: المسافات، وأشكال الألف (أإآ→ا)، والياء (ى→ي)، والتاء
   المربوطة (ة→ه)، والتشكيل. والاسم الأصلي يبقى كما كتبه المستخدم
   للعرض والطباعة — هذا للمقارنة فقط. */
function wsNormName(v) {
  if (v == null) return '';
  return String(v)
    .replace(/[\u200E\u200F\u061C\u202A-\u202E\u2066-\u2069\uFEFF]/g, '')
    .replace(/[\u064B-\u0652\u0670\u0640]/g, '')   // التشكيل والتطويل
    .replace(/[\u0623\u0625\u0622\u0671]/g, '\u0627')  // أ إ آ ٱ ← ا
    .replace(/\u0649/g, '\u064A')                       // ى ← ي
    .replace(/\u0629/g, '\u0647')                       // ة ← ه
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

window.wsToLatinDigits = wsToLatinDigits;
window.wsNum           = wsNum;
window.wsNormName      = wsNormName;

function escHtml(v) {
  return String(v == null ? '' : v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
/* حارس ألوان موحّد — 8.8.5.
   لون العضو يأتي من مستند members أو من نسخة الهوية المخزّنة محلياً،
   ويُسنَد مباشرةً إلى style. وإسنادُ خاصية واحدة لا يقبل تصريحاً ثانياً،
   لكنه يقبل `url(...)` داخل القيمة — وذلك وحده يكفي لإطلاق طلب خارجي.
   (وقد أُغلق هذا الباب أيضاً بتضييق img-src في 8.8.5، وهذا سدّ ثانٍ:
   الدفاع لا ينبغي أن يعتمد على طبقة واحدة.) */
function wsSafeColor(v) {
  const s = String(v == null ? '' : v).trim();
  return /^(#[0-9a-fA-F]{3,8}|rgba?\([\d\s.,%]+\)|hsla?\([\d\s.,%]+\)|[a-zA-Z]{3,20})$/.test(s)
    ? s : '#3b82f6';
}
window.wsSafeColor = wsSafeColor;

function escAttr(v) {
  // يُهرَّب كنص جافاسكريبت ثم كـ HTML، ليصلح داخل onclick="fn('...')"
  return escHtml(String(v == null ? '' : v).replace(/\\/g, '\\\\').replace(/'/g, "\\'"));
}
/* 8.9.2 — اسمان ثانيان لنفس السلوك.
   كان escapeHtml/escapeAttr معرَّفين حرفياً في invoices.html وmeasurements.html
   بجسم مطابق لما هنا — ثلاثة تعريفات لدالة واحدة. وخطر التكرار في دوال
   التهريب ليس طول الملف، بل أن يُصلَح أحدها يوماً ويُنسى الآخران فتصير
   صفحة محميّة وأخرى لا. المرجع الآن واحد. */
const escapeHtml = escHtml;
const escapeAttr = escAttr;

window.escHtml = escHtml;
window.escAttr = escAttr;
window.escapeHtml = escapeHtml;
window.escapeAttr = escapeAttr;

/* ============================================================
   2) التخزين المحلي دون اتصال — مع بدائل مضمونة
   ------------------------------------------------------------
   الخلل السابق: عند فتح تبويب ثانٍ كان enablePersistence يفشل بـ
   failed-precondition، فيُكتفى بتحذير في الـ console ويبقى ذلك التبويب
   بلا أي عمل دون اتصال إطلاقاً — والمستخدم لا يعلم.
   الآن: نجرّب المزامنة بين التبويبات، وإن فشلت نجرّب الوضع المفرد،
   وإن فشل الاثنان نُعلم المستخدم بوضوح بدل الصمت.

   الأهم: كل شيء يبدأ الآن بعد wsReady، لأن enablePersistence يجب أن
   يُستدعى قبل أول عملية Firestore. كانت قراءة members أحياناً تسبقه
   فيفشل التخزين المحلي بالكامل دون أن يلاحظ أحد.
   ============================================================ */
window.wsOfflineMode = 'pending';   // 'multi-tab' | 'single-tab' | 'none'

/* اطلب من المتصفح إبقاء مساحة التطبيق محمية من التنظيف التلقائي قدر الإمكان.
   هذا لا يعتمد عليه التطبيق وحده، لكنه طبقة أمان مهمة على هواتف الورشة
   عندما تمتلئ الذاكرة أو يعمل Chrome بتنظيف التخزين الأقل استعمالاً. */
try {
  if (navigator.storage && navigator.storage.persist) {
    navigator.storage.persist().then(ok => { window.wsPersistentStorage = !!ok; }).catch(() => { window.wsPersistentStorage = false; });
  }
} catch (e) { window.wsPersistentStorage = false; }

window.wsReady = (function enableOfflineStorage() {
  return db.enablePersistence({ synchronizeTabs: true })
    .then(() => { window.wsOfflineMode = 'multi-tab'; return true; })
    .catch((err) => {
      const code = err && err.code;
      if (code === 'failed-precondition') {
        // تبويب آخر يمسك التخزين — نعمل بوضع التبويب المفرد بدل التخلي عن العمل دون اتصال
        return db.enablePersistence()
          .then(() => { window.wsOfflineMode = 'single-tab'; return true; })
          .catch(() => { window.wsOfflineMode = 'none'; return false; });
      }
      window.wsOfflineMode = 'none';
      if (code === 'unimplemented') {
        console.warn('المتصفح لا يدعم التخزين المحلي (تصفح خفي غالباً) — التعديلات تحتاج إنترنت.');
      } else {
        console.warn('تعذّر تفعيل العمل دون اتصال:', code);
      }
      return false;
    });
})();

// تنبيه واضح إن تعذّر العمل دون اتصال، بدل اكتشاف ذلك بعد ضياع عمل يوم كامل
window.wsReady.then((ok) => {
  if (ok) return;
  const warn = () => showFsErrorToast('⚠️ هذا المتصفح لا يحفظ العمل دون إنترنت (تصفح خفي؟). افتح النظام في نافذة عادية.');
  if (document.body) warn(); else document.addEventListener('DOMContentLoaded', warn);
});

/* بقاء تسجيل الدخول محفوظاً محلياً — ضروري للعمل دون اتصال،
   فبدونه يخرج المستخدم من حسابه عند إعادة الفتح بلا إنترنت
   ولا يستطيع الدخول مجدداً (تسجيل الدخول نفسه يحتاج شبكة). */
/* ⚠️ إصلاح 8.9.2 — وعدٌ لم يكن ينتظره أحد.

   setPersistence تُعيد Promise، وكان الناتج يُسنَد إلى ثابت **لا يُقرأ في
   أي موضع من النظام كله** (كشفه فحص المتغيّرات غير المستعملة). أي أن
   تسجيل الدخول كان يجري دون ضمان أن نمط الحفظ قد ضُبط بعد.

   وأثره ليس نظرياً: النمط هو ما يُبقي الجلسة بعد إغلاق المتصفح. فإن سبق
   signInWithEmailAndPassword ضبطَ النمط، احتُمل أن تُحفظ الجلسة بالنمط
   السابق — فيجد المستخدم نفسه مطالَباً بالدخول من جديد، ودخولُه يحتاج
   شبكة. وهذا بالضبط ما جاء التعليق أعلاه ليمنعه.

   الآن يُصدَّر الوعد، وينتظره doLogin قبل الدخول. */
window.wsAuthReady = (function () {
  try {
    return auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch((e) => {
      if (typeof wsSilent === 'function') wsSilent('setPersistence', e);
    });
  } catch (e) { return Promise.resolve(); }
})();

/* ============================================================
   3) هوية المستخدم — مع نسخة محلية للعمل الميداني
   ------------------------------------------------------------
   حساب Auth وحده لا يكفي: لا بد من سجلّ في members أو أن يكون المدير.
   ونحتفظ بنسخة محلية صالحة 7 أيام، وإلا كان انقطاع الإنترنت يعني
   فشل قراءة members ثم تسجيل خروج فوري — أي طرد العضو من التطبيق
   وهو في الميدان بلا شبكة، فلا يستطيع الدخول مجدداً إطلاقاً.
   ============================================================ */
const PROFILE_CACHE_KEY = 'ws_user_profile';
const PROFILE_MAX_OFFLINE_DAYS = 7;

function normalizeShopAccess(raw) {
  const a = (raw && typeof raw === 'object') ? raw : {};
  // الأعضاء القدامى الذين لا يحملون حقل access يبقون بصلاحية الوحدتين،
  // حتى لا نفقد وصولهم بعد التحديث.
  const hasM = Object.prototype.hasOwnProperty.call(a, 'measurements');
  const hasC = Object.prototype.hasOwnProperty.call(a, 'cutting');
  return {
    measurements: hasM ? a.measurements === true : true,
    cutting: hasC ? a.cutting === true : true
  };
}
function wsCanAccess(section, user) {
  const u = user || window.currentShopUser || {};
  if (u.role === 'manager' || u.email === ADMIN_EMAIL) return true;
  const a = normalizeShopAccess(u.access);
  return section === 'measurements' ? a.measurements : section === 'cutting' ? a.cutting : true;
}
window.normalizeShopAccess = normalizeShopAccess;
window.wsCanAccess = wsCanAccess;
function applyModuleAccessUI(user) {
  const u = user || window.currentShopUser || {};
  const m = wsCanAccess('measurements', u), c = wsCanAccess('cutting', u);
  document.querySelectorAll('a[href="measurements.html"]').forEach(el => { el.hidden = !m; });
  document.querySelectorAll('a[href="cutting.html"]').forEach(el => { el.hidden = !c; });
  const mm = document.getElementById('module-measurements');
  const cm = document.getElementById('module-cutting');
  if (mm) mm.hidden = !m;
  if (cm) cm.hidden = !c;
  // حجم البيانات يكشف معلومات تشغيلية عن قاعدة البيانات؛ للمشرف فقط.
  const isManager = u.role === 'manager' || (u.email && u.email === ADMIN_EMAIL);
  const dataSize = document.getElementById('module-data-size');
  if (dataSize) dataSize.hidden = !isManager;
}
window.applyModuleAccessUI = applyModuleAccessUI;

function cacheShopUser(u) {
  /* ⚠️ إصلاح 8.8.3 — الفشل الصامت الوحيد الذي ثمنه الطرد من التطبيق.

     هذه الكتابة كانت داخل `catch (e) {}` فارغة تماماً. وهي ليست تفضيلاً
     في الواجهة كبقية الـ catch الفارغة، بل **النسخة المحلية من الهوية**
     التي يقوم عليها العمل دون اتصال كله:

       resolveShopUser → لا تقرأ members دون شبكة → readCachedShopUser
       → لا نسخة محفوظة → تُعيد null → guardPage يُنفّذ signOut()
       → وتسجيل الدخول نفسه يحتاج إنترنت.

     أي أن فشل هذا السطر يعني: العضو في الميدان بلا تغطية، يفتح التطبيق،
     فيُطرد ولا يستطيع العودة إطلاقاً — ومعه عمل لم يُرفع. وهو بالضبط
     ما بُني هذا التخزين لمنعه.

     وفشلُه ليس نادراً: امتلاء حصة التخزين (مسودّات الكراسات وأنظمة القص
     تتراكم)، أو تصفّح خفي، أو منع مواقع الطرف الثالث للتخزين. وفي كل
     هذه الحالات كان لا يظهر شيء إطلاقاً — لا في الشاشة ولا في السجل —
     إلى أن ينقطع الإنترنت فيُكتشف الأمر متأخراً.

     الآن: يُسجَّل الفشل في سجل التشخيص، ويُنبَّه المستخدم مرة واحدة
     بصياغة عملية — فالمشكلة قابلة للحل قبل الخروج للميدان لا بعده. */
  try {
    localStorage.setItem(PROFILE_CACHE_KEY, JSON.stringify({ user: u, at: Date.now() }));
  } catch (e) {
    wsSilent('cacheShopUser', e);
    showFsErrorToast('⚠️ تعذّر حفظ هويتك على هذا الجهاز — قد يُطلب منك تسجيل الدخول عند فتح التطبيق دون إنترنت. أفرغ بعض مساحة المتصفح، ولا تستخدم التصفّح الخفي.');
  }
}
function readCachedShopUser(uid) {
  try {
    const raw = JSON.parse(localStorage.getItem(PROFILE_CACHE_KEY) || 'null');
    if (!raw || !raw.user || raw.user.uid !== uid) return null;
    const days = (Date.now() - (raw.at || 0)) / 86400000;
    if (days > PROFILE_MAX_OFFLINE_DAYS) return null;
    return raw.user;
  } catch (e) { return null; }
}
function clearCachedShopUser() {
  try { localStorage.removeItem(PROFILE_CACHE_KEY); } catch (e) {}
}

async function resolveShopUser(user) {
  if (!user) return null;
  await window.wsReady;            // لا نقرأ Firestore قبل تجهيز التخزين المحلي
  if (user.email === ADMIN_EMAIL) {
    const admin = { uid: user.uid, email: user.email, name: 'المدير', role: 'manager', color: '#f59e0b', access: { measurements:true, cutting:true } };
    cacheShopUser(admin);
    return admin;
  }
  try {
    // مع التخزين المحلي المفعّل، هذه القراءة تنجح من ذاكرة الجهاز أيضاً دون اتصال
    const doc = await db.collection('members').doc(user.uid).get();
    if (doc.exists) {
      const m = doc.data();
      const u = {
        uid: user.uid,
        email: user.email,
        name: m.name || user.email,
        role: (m.role === 'manager') ? 'manager' : 'employee',
        color: m.color || '#3b82f6',
        access: normalizeShopAccess(m.access)
      };
      cacheShopUser(u);
      return u;
    }
    /* السجل غير موجود على السيرفر ونحن متصلون = صلاحية مسحوبة.
       شرط !doc.metadata.fromCache مهم: القراءة من الذاكرة المحلية قد تعطي
       "غير موجود" لمجرد أن السجل لم يُنزَّل بعد، وكان ذلك يطرد عضواً سليماً. */
    if (navigator.onLine && doc.metadata && !doc.metadata.fromCache) { clearCachedShopUser(); return null; }
  } catch (e) {
    /* ⚠️ إصلاح 8.9.3 — الرسالة كانت تكذب على المستخدم.
       ثلاثة أسباب مختلفة تماماً كانت تنتهي كلها إلى نفس النتيجة (null)
       ونفس الرسالة («هذا الحساب غير مصرّح له بالدخول»):

         ١) سجل العضو محذوف فعلاً من members  → صلاحية مسحوبة حقاً
         ٢) القراءة رُفضت (permission-denied) → خلل في قواعد السيرفر
         ٣) القراءة لم تصل أصلاً (unavailable / حجب CSP / لا شبكة)

       والفرق بينها هو الفرق بين «كلّم المشرف» و«أصلح القواعد» و«افحص
       الاتصال». وإخفاؤه خلف رسالة واحدة يجعل العطل غير قابل للتشخيص
       — وهو ما وقع فعلاً: دخولٌ ثم خروجٌ فوري بلا أي دليل على السبب.

       الآن يُحفظ سبب الفشل ليعرضه استدعاء الخروج، ويُطبع في السجل. */
    window.wsLastAuthError = {
      code: (e && e.code) || 'unknown',
      message: (e && e.message) || String(e),
      online: navigator.onLine,
      at: Date.now()
    };
    console.warn('resolveShopUser فشلت:', window.wsLastAuthError);
  }
  // تعذّرت القراءة أو نحن دون اتصال: نكمل بالهوية المحفوظة محلياً بدل طرد المستخدم
  const cached = readCachedShopUser(user.uid);
  if (!cached && !window.wsLastAuthError) {
    window.wsLastAuthError = { code: 'no-member-doc', message: 'لا سجل عضوية لهذا الحساب', online: navigator.onLine, at: Date.now() };
  }
  return cached;
}

/* رسالة تشرح سبب المنع فعلاً بدل الرسالة الواحدة لكل الحالات. */
function wsAuthFailureMessage() {
  const e = window.wsLastAuthError;
  if (!e) return '⛔ هذا الحساب غير مصرّح له بالدخول، تواصل مع المشرف.';
  if (e.code === 'permission-denied')
    return '⛔ رفض السيرفر قراءة بيانات حسابك (permission-denied).\n\n' +
           'هذا خلل في قواعد الأمان لا في حسابك: انشر firestore.rules من Firebase Console.';
  if (e.code === 'unavailable' || e.code === 'auth/network-request-failed' || !e.online)
    return '📡 تعذّر الوصول إلى الخادم للتحقق من حسابك.\n\n' +
           'تحقّق من الاتصال. وإن كان الاتصال سليماً فالسبب على الأرجح أن سياسة الأمان\n' +
           'في الصفحة (CSP) تحجب الاتصال — حدّث النظام من زر «تحديث النظام إجبارياً».';
  if (e.code === 'no-member-doc')
    return '⛔ لا يوجد سجل عضوية لهذا الحساب في النظام.\n\n' +
           'اطلب من المشرف إضافتك من «إدارة الأعضاء».';
  return '⛔ تعذّر التحقق من الحساب (' + e.code + ').\n\n' +
         'أطلع المشرف على هذا الرمز — فهو يحدّد السبب بدقة.';
}
window.wsAuthFailureMessage = wsAuthFailureMessage;

/* ⚠️⚠️ 9.2.0 — «لا خروج خاطئ»: التمييز بين الرفض والتعذّر.

   كل مسارات الخروج التلقائي تنطلق من شرط واحد: resolveShopUser أعادت
   null. وهي تُعيدها لسببين مختلفين اختلافاً كاملاً:

     • **رفض**: لا سجل عضوية لهذا الحساب، أو رفض السيرفر القراءة.
       هذا قرار نهائي، والخروج هو الصواب.

     • **تعذّر**: الشبكة انقطعت، أو تأخّر الخادم، أو حجبت CSP الطلب.
       وهذا **مؤقّت** — والحساب سليم تماماً.

   وكان الاثنان يُعامَلان سواءً: خروجٌ فوري. فمن يفتح النظام على شبكة
   ضعيفة — وهو حال الورشة — يُطرد، ثم يُسجّل دخوله، فيُطرد ثانيةً، لأن
   السبب لم يكن حسابه أصلاً. وتلك حلقة «الدخول المتكرّر والخروج الخاطئ».

   الآن: لا يُخرَج أحد إلا على سبب **نهائي**. وما عداه يبقى داخلاً،
   ويُنبَّه، ويُعاد التحقق تلقائياً عند عودة الشبكة. */
function wsAuthFailureIsDefinitive() {
  const e = window.wsLastAuthError;
  if (!e) return true;                       // لا خطأ مسجَّل: غياب السجل نفسه
  if (!e.online) return false;               // دون اتصال: لا قرار
  return e.code === 'no-member-doc' || e.code === 'permission-denied';
}
window.wsAuthFailureIsDefinitive = wsAuthFailureIsDefinitive;

/* إعادة محاولة واحدة مؤجَّلة، وتُلغى إن عادت الشبكة قبلها */
function wsRetryAuthSoon(fn) {
  let done = false;
  const go = () => { if (done) return; done = true; try { fn(); } catch (e) {} };
  window.addEventListener('online', go, { once: true });
  setTimeout(go, 6000);
}
window.wsRetryAuthSoon = wsRetryAuthSoon;

/* ============================================================
   4) رسائل الأخطاء والتنبيهات
   ============================================================ */
function fsErrorMessage(e, label) {
  const code = e && e.code;
  if (!navigator.onLine || code === 'unavailable') {
    return '🔴 لا يوجد اتصال — حُفظت البيانات داخل الجهاز وسترتفع تلقائياً (' + label + ').';
  }
  if (code === 'permission-denied') {
    /* هذه أخطر رسالة في النظام كله، ولهذا صيغتها صريحة:
       رفض السيرفر يعني أن Firestore يتراجع عن التعديل محلياً أيضاً،
       فالسجل لا يوجد لا على السيرفر ولا على الجهاز — رغم أن الشاشة
       قد تبدو طبيعية تماماً بعدها. الصياغة القديمة («لا توجد صلاحية
       كافية») كان يمكن أن تُفهم كتحذير عابر فيتابع المستخدم عمله. */
    return '⛔ لم تُحفظ هذه العملية إطلاقاً (' + label + ') — رفضها السيرفر لنقص الصلاحية.\n'
         + 'أعد إدخالها بعد معالجة الصلاحيات، ولا تعتمد عليها.';
  }
  return '⚠️ تعذّرت مزامنة البيانات (' + label + '): ' + (e && e.message ? e.message : e);
}

/* تنبيه مرئي مشترك لأخطاء الحفظ — بدونه كان فشل الحفظ (نقص صلاحية مثلاً)
   يظهر في console فقط ولا يراه المستخدم، فيبدو أن شيئاً "لم يحدث" بلا تفسير.
   عدم التكرار: نفس الرسالة لا تُعرض أكثر من مرة كل 8 ثوانٍ. */
let _lastFsErrorMsg = '', _lastFsErrorAt = 0;
function showFsErrorToast(msg) {
  const now = Date.now();
  if (msg === _lastFsErrorMsg && (now - _lastFsErrorAt) < 8000) return;
  _lastFsErrorMsg = msg; _lastFsErrorAt = now;
  if (!document.body) { document.addEventListener('DOMContentLoaded', () => showFsErrorToast(msg)); return; }
  let el = document.getElementById('fs-error-toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'fs-error-toast';
    el.setAttribute('role', 'alert');
    el.style.cssText = 'position:fixed;bottom:calc(16px + env(safe-area-inset-bottom));left:16px;right:16px;max-width:420px;margin:0 auto;z-index:10000;background:#7c2d12;color:#fff;padding:12px 16px;border-radius:14px;font-family:Cairo,Tajawal,sans-serif;font-size:13px;font-weight:700;box-shadow:0 10px 30px rgba(0,0,0,.3);text-align:center;line-height:1.6;transition:opacity .3s, transform .3s;';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.style.opacity = '1'; el.style.transform = 'translateY(0)';
  clearTimeout(el._hideTimer);
  el._hideTimer = setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(8px)'; }, 5000);
}

/* ============================================================
   5) صندوق الصادر — متابعة الكتابات التي لم تصل السيرفر بعد
   ------------------------------------------------------------
   مع التخزين المحلي، أي كتابة أثناء الانقطاع تُحفظ فوراً في الجهاز
   لكن وعدها (promise) يبقى معلّقاً حتى يستلمها السيرفر فعلاً. نستغل
   ذلك كعدّاد دقيق. لا تنتظر الواجهة شيئاً إطلاقاً.

   إصلاح مهم: العدّاد كان يبدأ من صفر عند كل فتح للتطبيق، فتظهر رسالة
   "تم رفع كل البيانات" بينما لا تزال كتابات الجلسة السابقة في طابور
   Firestore لم تُرفع. الآن نفحص عند الإقلاع عبر waitForPendingWrites.
   ============================================================ */
window.wsPendingWrites = 0;
window.wsResumingFromPreviousSession = false;
window.wsPendingByType = {};   // تفصيل ما ينتظر الرفع: فواتير؟ كراسات؟ دفعات؟

// أسماء مفهومة بدل أسماء المجموعات التقنية
const WS_LABELS = {
  sales: 'فواتير', payments: 'دفعات', expenses: 'مصروفات', returns: 'مرتجعات',
  store: 'أصناف المخزن', creditBalances: 'أرصدة عملاء', collections: 'تحصيلات',
  measurementJobs: 'كراسات قياسات', cuttingArchive: 'أعمال قص', trash: 'سلة المحذوفات',
  members: 'أعضاء', meta: 'إعدادات', editedInvoicesLog: 'سجل التعديلات'
};
const wsLabelOf = c => WS_LABELS[c] || c;

function _wsBump(label, delta) {
  const k = wsLabelOf(label);
  window.wsPendingByType[k] = (window.wsPendingByType[k] || 0) + delta;
  if (window.wsPendingByType[k] <= 0) delete window.wsPendingByType[k];
}

function _wsTrack(promise, label) {
  window.wsPendingWrites++;
  _wsBump(label, +1);
  updateSyncStatus();
  return promise
    .then(v => { window.wsPendingWrites--; _wsBump(label, -1); updateSyncStatus(true); return v; })
    .catch(e => {
      window.wsPendingWrites--; _wsBump(label, -1); updateSyncStatus();
      const m = fsErrorMessage(e, label); console.error(m);
      // انقطاع الشبكة ليس خطأً هنا: البيانات محفوظة محلياً وسترتفع تلقائياً
      if (navigator.onLine && !(e && e.code === 'unavailable')) showFsErrorToast(m);
      throw e;
    });
}

/* عند الإقلاع: هل بقيت كتابات من جلسة سابقة لم تُرفع؟ */
window.wsReady.then(() => {
  if (!db.waitForPendingWrites) return;
  let settled = false;
  db.waitForPendingWrites().then(() => {
    settled = true;
    if (window.wsResumingFromPreviousSession) {
      window.wsResumingFromPreviousSession = false;
      updateSyncStatus(true);
      showSyncToast('✅ اكتمل رفع العمل المحفوظ من آخر مرة');
    }
  }).catch(() => { settled = true; });
  // إن لم تُحسم فوراً فهناك طابور قديم قيد الرفع
  setTimeout(() => {
    if (settled) return;
    window.wsResumingFromPreviousSession = true;
    updateSyncStatus();
  }, 900);
});

/* هذه الدوال تعود فور تسجيل التغيير محلياً ولا تنتظر السيرفر إطلاقاً.
   هذا جوهر العمل دون اتصال: بدونه كان أي await fsSet(...) أثناء الانقطاع
   يبقى معلّقاً للأبد فلا يُنفَّذ السطر الذي بعده (حفظ فاتورة، تسجيل دفعة،
   أرشفة كراسة…) فتضيع العملية كلها. الرفع يتم في الخلفية. */
function fsSet(col, id, data)     { _wsTrack(db.collection(col).doc(String(id)).set(data), col).catch(() => {});    return Promise.resolve(true); }
/* v291: measurementJobs may be deleted from the archive while another
   screen/device still holds its old ID. Never turn that stale update into
   a set() (which could resurrect a deleted notebook). Verify existence,
   skip missing docs, and silence only the expected not-found race if the
   document is deleted between get() and update(). Other errors remain visible. */
function fsUpdate(col, id, patch) {
  const ref = db.collection(col).doc(String(id));
  if (col !== 'measurementJobs') {
    _wsTrack(ref.update(patch), col).catch(() => {});
    return Promise.resolve(true);
  }
  const operation = ref.get().then(snap => {
    if (!snap || !snap.exists) {
      console.warn('[v291] Skipped update for missing measurementJobs document:', String(id));
      return { skippedMissingMeasurementJob: true };
    }
    return ref.update(patch).catch(err => {
      const msg = String(err && err.message || '');
      if (err && (err.code === 'not-found' || /No document to update/i.test(msg))) {
        console.warn('[v291] Document was deleted before update completed; update skipped:', String(id));
        return { skippedMissingMeasurementJob: true };
      }
      throw err;
    });
  });
  _wsTrack(operation, col).catch(err => {
    // Permission/network failures are not treated as deletion; retain the normal warning.
    console.error('[v291] Could not safely update measurementJobs document:', err);
  });
  return Promise.resolve(true);
}
function fsDelete(col, id)        { _wsTrack(db.collection(col).doc(String(id)).delete(), col).catch(() => {});      return Promise.resolve(true); }
function fsAdd(col, data) {
  const ref = db.collection(col).doc();   // معرّف يُولَّد محلياً، فيعود فوراً — يعمل دون اتصال تماماً
  _wsTrack(ref.set(data), col).catch(() => {});
  return Promise.resolve(ref.id);
}

/* ============================================================
   زيادة/نقصان ذرّي لحقل رقمي تراكمي (كميات المخزن تحديداً)
   ------------------------------------------------------------
   لماذا هذه الدالة ضرورية؟
   الكتابة العادية ترسل «القيمة النهائية» المحسوبة من نسخة الجهاز:
     عامل أ (دون اتصال) يبيع 3 من رصيد 10 → يرسل «الكمية = 7»
     عامل ب (دون اتصال) يبيع 4 من رصيد 10 → يرسل «الكمية = 6»
   وعند عودة الاتصال تفوز آخر رسالة، فيصبح المخزون 6 بدل 3 —
   أي أن كمية كاملة تختفي من الدفاتر بلا أي أثر ولا رسالة خطأ.

   increment يرسل «الفرق» لا «القيمة»، ويطبّقه السيرفر على رصيده هو،
   ويعمل دون اتصال (يُحفظ كتحويل مؤجَّل ويُطبَّق عند الوصول). فتُجمع
   العمليتان معاً: 10 − 3 − 4 = 3، وهو الصحيح.
   ============================================================ */
function fsIncrement(col, id, field, delta) {
  const d = Number(delta) || 0;
  if (!d) return Promise.resolve(true);
  const patch = {};
  patch[field] = firebase.firestore.FieldValue.increment(d);
  _wsTrack(db.collection(col).doc(String(id)).update(patch), col).catch(() => {});
  return Promise.resolve(true);
}
window.fsIncrement = fsIncrement;

/* ============================================================
   زيادة ذرّية على مستند قد لا يكون موجوداً أصلاً
   ------------------------------------------------------------
   fsIncrement تستخدم update، وهي تفشل إن لم يكن المستند موجوداً.
   أرصدة العملاء تحديداً تبدأ غير موجودة لأول عميل، فنحتاج set بدمج.

   لماذا ذرّية لا «اقرأ ثم اكتب»؟ لأن القراءة ثم الكتابة تخسر أي تعديل
   يقع بينهما: جهازان يعتمدان فاتورتين لنفس العميل في نفس اللحظة، فيقرأ
   كلاهما الرصيد القديم ويكتب فوق الآخر — فيضيع أحد المبلغين. والزيادة
   الذرّية يجمعها السيرفر، ولا تحتاج قراءة إطلاقاً فتعمل دون اتصال.
   ============================================================ */
function fsMergeIncrement(col, id, field, delta, extra) {
  const d = Number(delta) || 0;
  if (!d) return Promise.resolve(true);
  const patch = Object.assign({}, extra || {});
  patch[field] = firebase.firestore.FieldValue.increment(d);
  _wsTrack(db.collection(col).doc(String(id)).set(patch, { merge: true }), col).catch(() => {});
  return Promise.resolve(true);
}
window.fsMergeIncrement = fsMergeIncrement;

/* ============================================================
   إضافة عنصر إلى مصفوفة داخل مستند — ذرّياً
   ------------------------------------------------------------
   arrayUnion يضيف العنصر على السيرفر بلا قراءة مسبقة، فلا يضيع عنصر
   حين يضيف جهازان في اللحظة نفسها. و«اقرأ ثم اكتب» هنا كارثية تحديداً:
   عضوان يبدآن العمل في نفس الخدمة من هاتفيهما، فيقرأ كلاهما القائمة
   القديمة ويكتب فوق الآخر — فيختفي أحدهما من سجل من بدأ العمل.
   ============================================================ */
function fsArrayUnion(col, id, field, item, extra) {
  const patch = Object.assign({}, extra || {});
  patch[field] = firebase.firestore.FieldValue.arrayUnion(item);
  _wsTrack(db.collection(col).doc(String(id)).set(patch, { merge: true }), col).catch(() => {});
  return Promise.resolve(true);
}
window.fsArrayUnion = fsArrayUnion;

/* ============================================================
   توليد معرّف فريد لا يتصادم بين الأجهزة
   ------------------------------------------------------------
   كان النمط المتّبع `'INV-' + Date.now()`. وهو فريد على جهاز واحد، لكن
   جهازين يُنشئان فاتورة في **نفس المللي ثانية** يحصلان على نفس المعرّف
   بالضبط — و fsSet يكتب أحدهما فوق الآخر، فتضيع فاتورة كاملة بلا أي
   رسالة.

   الاحتمال ضئيل بضغطة واحدة، لكنه يكبر مع كل موظف يُضاف ومع كل يوم عمل:
   محل بثلاثة موظفين يُصدرون مئة فاتورة يومياً يقترب من التصادم خلال
   شهور. وثمنه فاتورة مفقودة لا يعرف أحد أنها كانت.

   الحل: لاحقة عشوائية قصيرة بعد الطابع الزمني. تبقى المعرّفات مرتّبة
   زمنياً (الطابع أولاً) وتبقى مقروءة، ويستحيل التصادم عملياً — احتمال
   تكرار أربعة أحرف من 36 في نفس المللي ثانية أقلّ من واحد في المليون.
   ============================================================ */
/* ⚠️ تشديد 8.8.5 — معرّف قابل للتصادم، وثمن التصادم كتابة فوق سجل آخر.

   كان: Date.now() + أربعة محارف من Math.random().toString(36).slice(2,6).
   وفيه علّتان:

   ١) `Math.random().toString(36)` لا يعطي طولاً ثابتاً. القيم التي تنتهي
      بأصفار تُختصر — فقد تعود القطعة بمحرف أو محرفين لا بأربعة، فتنكمش
      المساحة العشوائية من ١.٧ مليون إلى ثلاثين احتمالاً في تلك الحالات.

   ٢) و`Math.random()` ليس مولّداً معمّى: من رأى بضعة معرّفات استطاع
      استنتاج تسلسل المولّد والتنبّؤ بالتالي.

   وثمن التصادم ليس رسالة خطأ: `fsSet` تستعمل `.set()` التي **تكتب فوق**
   المستند الحامل لنفس المعرّف. أي أن فاتورتين تُنشآن في الملّي ثانية
   نفسها بنفس القطعة العشوائية — من جهازين، وهو ما يقع حين يخرج فريق
   من نفس الاجتماع ويسجّل كلٌّ فاتورته — تصير واحدة، وتختفي الأخرى بلا
   أثر ولا رسالة، ولا شيء في الواجهة يلمّح إلى ما جرى.

   الآن: crypto.getRandomValues (المولّد المعمّى في المتصفح) وثمانية
   محارف بدل أربعة — أي نحو 2.8 تريليون احتمال في الملّي ثانية الواحدة
   بدل 1.7 مليون. ويبقى Math.random بديلاً احتياطياً لمتصفّح قديم لا
   يوفّر crypto، مع تثبيت الطول بالحشو حتى لا تنكمش المساحة. */

/* ⚠️ إصلاح البطء 8.9.1 — html2canvas كانت تُحمَّل مع كل صفحة.
   حجمها نحو 200KB، وهي سكربت **حاجب** (بلا defer) — أي أن المتصفح يتوقف
   عن بناء الصفحة حتى ينتهي من جلبها وتحليلها. وهي لا تُستعمل إلا في موضع
   واحد: تصدير الصورة. فكان كل من يفتح الصفحة ليسجّل فاتورة أو يراجع ديناً
   يدفع ثمن ميزة لن يلمسها.
   الآن: تُحمَّل عند أول استعمال فقط، بنفس أسلوب _gdriveEnsureGIS. */
function ensureHtml2Canvas() {
  if (window.html2canvas) return Promise.resolve(window.html2canvas);
  if (window._h2cPromise) return window._h2cPromise;
  window._h2cPromise = new Promise(function (resolve, reject) {
    var s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
    s.crossOrigin = 'anonymous';
    s.onload  = function () { window.html2canvas ? resolve(window.html2canvas) : reject(new Error('html2canvas لم تُحمَّل')); };
    s.onerror = function () { window._h2cPromise = null; reject(new Error('تعذّر تحميل أداة الصور — تحقّق من الاتصال')); };
    document.head.appendChild(s);
  });
  return window._h2cPromise;
}
window.ensureHtml2Canvas = ensureHtml2Canvas;

/* ⚠️⚠️ إصلاح 8.9.3 — سببُ حلقة «يدخل ثم يخرج فوراً». وهو خطأ أدخلتُه في 8.9.1.

   كانت هذه الدالة معرَّفة في **الكتلة الرابعة** من سكربتات invoices.html،
   ومعها علمُها:  let _iconsScheduled = false;

   وتُستدعى من showAppForUser() في **الكتلة الثالثة**. والدالة نفسها مرفوعة
   (function declaration) فالنداء يجدها — لكن `let` **لا تُرفع**: تبقى في
   «المنطقة الميتة الزمنية» حتى يُنفَّذ سطر تعريفها في الكتلة الرابعة.

   والسباق الذي يقع فعلياً على جهاز فيه جلسة محفوظة:

     الكتلة ٣ تُنفَّذ، وفيها auth.onAuthStateChanged(...)
        ↓ الجلسة محفوظة، فالنداء يعود بسرعة كمهمّة مُجدوَلة
     المتصفح ينفّذ المهمّة **قبل أن يُنفِّذ الكتلة الرابعة**
        ↓ showAppForUser() → refreshIcons() → قراءة _iconsScheduled
     ReferenceError: Cannot access '_iconsScheduled' before initialization

   ثم يلتقط الخطأَ معالجُ المصادقة في invoices.html، فيُنفّذ signOut ويعيد
   التوجيه برسالة «تعذّر التحقق من الحساب، تحقق من الاتصال» — والاتصال سليم
   تماماً. فتتكرّر الحلقة: دخول ← تحميل ← طرد ← دخول.

   وكان تعليلي في 8.9.1 خاطئاً: قلتُ إن الدالة مرفوعة فالنداء آمن. صحيحٌ
   أن **الدالة** مرفوعة، لكنني أغفلتُ أن **المتغيّر الذي تقرؤه** ليس كذلك.

   الحلّ: مكانها shared.js — يُنفَّذ كاملاً قبل أي كتلة في الصفحة، فلا منطقة
   ميتة أصلاً. وهي أداة واجهة عامة لا تخصّ صفحة بعينها. */
let _iconsScheduled = false;
/* 9.9.3 — حارس التنقل: اللمس المزدوج على شبكة ضعيفة كان يفتح الصفحة
   مرتين قبل أن تستجيب الأولى. نحتفظ بالضغط الأول ونمنع التكرار القصير. */
(function installNavigationGuard(){
  if (window.__wsNavGuardInstalled) return;
  window.__wsNavGuardInstalled = true;
  document.addEventListener('click', function(e){
    const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || a.target === '_blank' || a.hasAttribute('download') || a.getAttribute('href') === '#') return;
    const now = Date.now();
    if (a.dataset.wsNavAt && now - Number(a.dataset.wsNavAt) < 900) { e.preventDefault(); e.stopPropagation(); return; }
    a.dataset.wsNavAt = String(now);
  }, true);
})();

function refreshIcons() {
  if (_iconsScheduled || !window.lucide) return;
  _iconsScheduled = true;
  requestAnimationFrame(function () {
    _iconsScheduled = false;
    try { lucide.createIcons(); } catch (e) {}
  });
}
window.refreshIcons = refreshIcons;

/* ══════════════════════════════════════════════════════════════════════
   شبكة الأمان للأخطاء — 9.0.3
   ══════════════════════════════════════════════════════════════════════
   لم يكن في النظام معالج أخطاء عام واحد. لا window.onerror ولا
   unhandledrejection — في أربع صفحات و‏١٥ ألف سطر.

   وأثر ذلك تكرّر في كل عطل عولج في هذه النسخ: الخطأ يقع، فيتوقف تنفيذ
   بقية الدالة، ولا يظهر شيء إطلاقاً. فيظنّ المستخدم أن ما فعله تمّ،
   ويكتشف بعد أيام أن الفاتورة لم تُحفظ أو الرسم لم يُرفق. والأسوأ أن
   السبب يكون قد ضاع: لا سجل ولا رسالة ولا رمز يُسأل عنه.

   هذا المعالج لا يمنع الأخطاء — يمنع **اختفاءها**:

     • يلتقط الاستثناءات غير المعالَجة ووعود الرفض غير الملتقطة.
     • يحتفظ بآخر ٣٠ خطأً في سجل محلي (مع الصفحة والسطر والوقت)،
       يُقرأ بـ wsErrorLog() من وحدة التحكم أو يُصدَّر للمراجعة.
     • يُظهر تنبيهاً واحداً موجزاً — مرة واحدة لكل خطأ متكرّر، فلا
       يتحوّل العطل إلى وابل رسائل يغرق الشاشة.
     • **ولا يُخرج المستخدم أبداً.** هذا شرط مطلق: عطل ٨.٩.٤ كان خطأً
       واحداً في الرسم انتهى بطرد المستخدم وحلقة دخول لا تنتهي، لأن
       الخطأ عولج في مكان لا يعرف إلا الخروج.

   وضوضاء المتصفح المعروفة (فشل تحميل مورد خارجي دون اتصال، تحذير
   ResizeObserver) تُستبعد: التنبيه الذي يُطلق على ما لا يضرّ يُدرَّب
   المستخدم على تجاهله، فيفقد قيمته حين يهمّ فعلاً. */
window.wsErrors = [];
const _WS_ERR_KEY = 'ws_error_log';
let _wsErrSeen = {};

function _wsIsNoise(msg, src) {
  const m = String(msg || '');
  if (/ResizeObserver loop/i.test(m)) return true;
  if (/Script error\.?$/i.test(m) && !src) return true;      // خطأ من نطاق آخر بلا تفاصيل
  if (/Load failed|Failed to fetch|NetworkError|ERR_/i.test(m) && !navigator.onLine) return true;
  return false;
}

function wsLogError(kind, msg, src, line, err) {
  try {
    if (_wsIsNoise(msg, src)) return;
    const page = (location.pathname.split('/').pop() || 'index.html');
    const rec = {
      kind: kind, message: String(msg || '').slice(0, 300),
      where: (src ? src.split('/').pop() : page) + (line ? (':' + line) : ''),
      page: page, at: new Date().toLocaleString('ar-EG'),
      build: (window.WS_BUILD || ''),
      stack: (err && err.stack ? String(err.stack).slice(0, 600) : '')
    };
    window.wsErrors.push(rec);
    if (window.wsErrors.length > 30) window.wsErrors.shift();
    try { localStorage.setItem(_WS_ERR_KEY, JSON.stringify(window.wsErrors)); } catch (e) {}
    console.error('[ws]', kind, rec.message, rec.where);

    /* التوحيد على **نصّ الرسالة وحده** لا على موضعها: الخطأ الواحد يقع
       من عدة مواضع (ثلاث نداءات مؤجَّلة، حلقة، معالج حدث يتكرر)، فلو
       دخل الموضع في المفتاح لانهال على المستخدم عشرات التنبيهات لعلّة
       واحدة — وذلك يُغرق الشاشة ويدرّبه على تجاهلها.
       والسقف الصارم فوق ذلك: ثلاثة تنبيهات في الجلسة مهما تنوّعت الأخطاء.
       السجل يحتفظ بكل شيء؛ التنبيه للفت النظر لا للسرد. */
    if (_wsErrSeen[rec.message] || Object.keys(_wsErrSeen).length >= 3) {
      _wsErrSeen[rec.message] = true;
      return;
    }
    _wsErrSeen[rec.message] = true;
    if (typeof showFsErrorToast === 'function') {
      showFsErrorToast('⚠️ حدث خطأ غير متوقّع — قد لا تكتمل العملية الأخيرة. ' +
                       'أعد المحاولة، وإن تكرّر أطلع المشرف على: ' + rec.where);
    }
  } catch (e) { /* المعالج نفسه لا يجوز أن يرمي */ }
}

window.addEventListener('error', function (ev) {
  if (ev && ev.target && ev.target !== window && ev.target.tagName) return;   // فشل تحميل مورد: لا يعنينا
  wsLogError('error', ev && ev.message, ev && ev.filename, ev && ev.lineno, ev && ev.error);
});
window.addEventListener('unhandledrejection', function (ev) {
  const r = ev && ev.reason;
  wsLogError('promise', (r && r.message) || String(r), '', 0, r);
});

/* يُستدعى من وحدة التحكم أو من زر: نصّ جاهز للإرسال إلى المشرف */
window.wsErrorLog = function () {
  let list = window.wsErrors;
  if (!list.length) { try { list = JSON.parse(localStorage.getItem(_WS_ERR_KEY) || '[]'); } catch (e) { list = []; } }
  if (!list.length) { console.log('لا أخطاء مسجّلة ✅'); return []; }
  console.table(list.map(function (r) { return { الوقت: r.at, الصفحة: r.page, الموضع: r.where, الرسالة: r.message }; }));
  return list;
};

/* ══════════════════════════════════════════════════════════════════════
   وضع «القسم المنفصل» — 9.2.0
   ══════════════════════════════════════════════════════════════════════
   حين يُفتح النظام من أحد تطبيقات أندرويد الثلاثة، يحمل رابطه معاملاً:
       measurements.html?app=qiyasat
   فيُخفى شريط التنقّل إلى الأقسام الأخرى.

   ولماذا الإخفاء أصلاً؟ لأن التطبيقات الثلاثة تشترك في **أصل واحد**
   (نفس النطاق)، فالضغط على «الفواتير» داخل تطبيق القياسات يُحمّل صفحة
   الفواتير **في نافذة تطبيق القياسات نفسه** — فيجد المستخدم نفسه في
   قسم لم يفتح تطبيقه، وأيقونة شريط المهام تقول شيئاً والشاشة تقول
   آخر. والفصل الذي طُلب يصير فصلاً في الأيقونات لا في العمل.

   والإخفاء لا يمسّ المتصفّح: الرابط بلا معامل يُبقي الشريط كما هو،
   فمن يفتح النظام من الويب يتنقّل بين الأقسام الثلاثة كالمعتاد.

   ويبقى زر تسجيل الخروج وشارة المستخدم ظاهرين: الخروج لازم في كل تطبيق،
   ومعرفةُ من سجّل الدخول لازمة قبل أي عملية مالية. */
function wsStandaloneSection() {
  try {
    const p = new URLSearchParams(location.search).get('app');
    return p ? String(p).replace(/[^a-z]/gi, '').slice(0, 20) : '';
  } catch (e) { return ''; }
}

function wsApplyStandaloneNav() {
  if (!wsStandaloneSection()) return;
  try {
    document.documentElement.classList.add('ws-standalone');
    /* القاعدة بنيوية لا انتقائية: **كل** رابط يقود إلى صفحة أخرى من
       النظام يُخفى، أينما كان في الصفحة.

       والمحدّد الانتقائي (nav a, header a) بدا كافياً وليس كذلك: صفحة
       الفواتير وحدها فيها طقمان — شريط علوي، وأزرار اختصار داخل شبكة
       الأقسام خارج أي <nav>. فأخفى الأول وترك الثاني ظاهراً، وهو ما
       كشفه الاختبار: «روابط لأقسام أخرى: 6 — الظاهر منها: 3».
       وكل طقم يُضاف مستقبلاً كان سيفلت بنفس الطريقة. */
    const here = (location.pathname.split('/').pop() || 'index.html');
    const PAGES = ['index.html', 'invoices.html', 'measurements.html', 'cutting.html'];
    document.querySelectorAll('a[href]').forEach(function (a) {
      const target = (a.getAttribute('href') || '').split('/').pop().split('?')[0].split('#')[0];
      if (PAGES.indexOf(target) !== -1 && target !== here) {
        a.style.display = 'none';
        a.setAttribute('aria-hidden', 'true');
      }
    });
  } catch (e) { if (typeof wsSilent === 'function') wsSilent('standaloneNav', e); }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', wsApplyStandaloneNav);
} else {
  wsApplyStandaloneNav();
}
window.wsStandaloneSection = wsStandaloneSection;

/* ══════════════════════════════════════════════════════════════════════
   حارس التمرير — 9.4.1
   ══════════════════════════════════════════════════════════════════════
   النوافذ المنبثقة تقفل تمرير الصفحة أثناء فتحها:
       document.body.style.overflow = 'hidden'
   ويُفترض أن تُحرّره عند الإغلاق. وهذا صحيح **ما دام الإغلاق يمرّ بدالته**.

   لكن للخروج طرقاً لا تمرّ بها:
     • زرّ الرجوع في الهاتف يُغلق اللوحة عبر معالج السجلّ لا عبر دالة
       الإغلاق.
     • استثناء يقع بين فتح النافذة وإغلاقها فيتوقّف التنفيذ قبل التحرير.
     • إغلاقٌ من مسار أُضيف لاحقاً ونُسي فيه السطر.

   وفي كل هذه الحالات تبقى `overflow: hidden` على body، **فتتجمّد الصفحة
   تماماً**: لا نزول ولا صعود، والمحتوى كله ظاهر وسليم. والمستخدم لا
   يربط بين رسمٍ فتحه قبل دقائق وبين صفحة لا تتحرك الآن، فيظنّ العطل في
   الجدول الذي أمامه.

   وعلاجُ كل مسار على حدة يعالج ما نعرفه اليوم ويترك ما يُضاف غداً.
   فالحارس هنا عكس ذلك: لا يسأل **كيف** قُفلت، بل يسأل سؤالاً واحداً —
   هل ثمّة نافذة مفتوحة فعلاً؟ فإن لم تكن، حرّر التمرير.

   ويُستدعى عند اللمس وعند الرجوع وعند العودة للصفحة: أي في اللحظات
   التي يحاول فيها المستخدم التمرير فعلاً. فلا مؤقّت يعمل بلا داعٍ. */
function wsAnyModalOpen() {
  const sel = '#bigDrawModal, .modal, .overlay, #main-panel.open, [data-modal-open="1"]';
  try {
    return [...document.querySelectorAll(sel)].some(el => {
      const cs = getComputedStyle(el);
      return cs.display !== 'none' && cs.visibility !== 'hidden' && el.offsetHeight > 0;
    });
  } catch (e) { return false; }
}

function wsReleaseScrollIfStuck() {
  try {
    const b = document.body;
    if (!b) return;
    const locked = b.style.overflow === 'hidden' || b.style.position === 'fixed';
    if (!locked || wsAnyModalOpen()) return;
    b.style.overflow = '';
    b.style.position = '';
    if (typeof wsSilent === 'function') wsSilent('scrollGuard', new Error('تُرك قفل التمرير مفتوحاً — حُرِّر'));
  } catch (e) {}
}
window.wsReleaseScrollIfStuck = wsReleaseScrollIfStuck;

(function () {
  let last = 0;
  const check = () => {
    const now = Date.now();
    if (now - last < 400) return;      // خنق: اللمس يتكرّر عشرات المرات
    last = now;
    wsReleaseScrollIfStuck();
  };
  window.addEventListener('touchstart', check, { passive: true });
  window.addEventListener('popstate', wsReleaseScrollIfStuck);
  window.addEventListener('pageshow', wsReleaseScrollIfStuck);
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) wsReleaseScrollIfStuck();
  });
})();

/* يُجمّد الحركة، ينفّذ الالتقاط، ثم يُعيدها مهما كانت النتيجة.
   والإعادة في finally شرط: لو بقي الصفّ مجمَّداً بعد فشل الالتقاط،
   لماتت حركة الواجهة كلها حتى إعادة التحميل — عطلٌ صامت من علاج عطل. */
async function wsCaptureSafe(fn) {
  const el = document.documentElement;
  el.classList.add('ws-capturing');
  /* إطاران قبل الرسم: الأول يُطبّق القاعدة، والثاني يضمن أن المتصفح
     أعاد التخطيط قبل أن يستنسخ html2canvas. */
  await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
  try { return await fn(); }
  finally { el.classList.remove('ws-capturing'); }
}
window.wsCaptureSafe = wsCaptureSafe;

function wsUid(prefix) {
  let rnd;
  try {
    const a = new Uint8Array(6);
    (self.crypto || window.crypto).getRandomValues(a);
    rnd = Array.from(a, b => b.toString(36).padStart(2, '0')).join('').slice(0, 8);
  } catch (e) {
    rnd = (Math.random().toString(36).slice(2) + '00000000').slice(0, 8);
  }
  return String(prefix || '') + Date.now() + '-' + rnd;
}
window.wsUid = wsUid;

/* ============================================================
   قناة موحّدة للأخطاء الصامتة
   ------------------------------------------------------------
   الكود مليء بـ `catch (e) {}` فارغة. ومعظمها مقصود ومقبول: تنسيق
   تاريخ يفشل، أو عنصر واجهة غائب — لا يستحق إزعاج المستخدم.

   لكن بعضها يلفّ **عمليات كتابة في قاعدة البيانات**. وفشلها هناك يعني
   عملية مالية لم تُسجَّل، ولا أحد يعلم: لا رسالة، ولا سطر في السجل،
   ولا حتى أثر يُراجَع لاحقاً. فيُكتشف الفرق عند الجرد بعد أسابيع بلا
   دليل على سببه.

   wsSilent تجعل الفشل **مرئياً بلا إزعاج**: يُسجَّل في وحدة التحكّم
   دائماً، ويُحتفظ بآخر خمسين خطأ في الذاكرة ليقرأها المطوّر عند
   الشكوى (wsErrors()). والمستخدم لا يُزعَج إلا حين يكون الخطأ من
   النوع الذي يمسّ عمله — وذلك من شأن _wsTrack لا هذه.
   ============================================================ */
window._wsErrorLog = [];

function wsSilent(where, e) {
  try {
    const rec = {
      at: new Date().toISOString(),
      where: String(where || ''),
      msg: (e && (e.message || e.code)) || String(e),
      user: (window.currentShopUser && window.currentShopUser.name) || ''
    };
    window._wsErrorLog.push(rec);
    if (window._wsErrorLog.length > 50) window._wsErrorLog.shift();
    console.warn('[ws] ' + rec.where + ':', e);
  } catch (_) { /* لا شيء هنا يستحق أن يُفشل الاستدعاء */ }
}
window.wsSilent = wsSilent;

// يُستدعى من وحدة التحكّم عند التشخيص: wsErrors()
/* ══ رسالة نجاح صادقة ══
   المطلب: ألا تُقال «تم الحفظ» إلا بعد تأكيد السيرفر.

   وهذا **متعذّر بالتصميم**: Firestore مع التخزين المحلي لا تُحلّ وعودها
   إلا بعد تأكيد السيرفر، فانتظارها دون اتصال يعني تعليق الدالة إلى أن
   تعود الشبكة — لا فاتورة تُحفظ ولا رسالة تظهر. والورشة تعمل في مواقع
   بلا تغطية، فذلك تعطيل لا إصلاح.

   البديل الصحيح: **قول الحقيقة كاملة**. العملية محفوظة فعلاً — محلياً
   وبشكل دائم — والرفع يقع تلقائياً. فنقول ذلك صراحةً بدل الإيهام بأن
   السيرفر أكّدها.

   wsSaveNote() تُلحَق برسائل النجاح: فارغة حين لا شيء معلّق، وتوضيحية
   حين يكون هناك ما ينتظر الرفع. */
function wsSaveNote() {
  const pending = window.wsPendingWrites || 0;
  if (!navigator.onLine) {
    return '\n\n📴 محفوظة على الجهاز — سترتفع تلقائياً عند عودة الشبكة.';
  }
  if (pending > 0) {
    return '\n\n⏳ محفوظة، وجارٍ رفعها (' + pending + ' عملية معلّقة).';
  }
  return '';
}
window.wsSaveNote = wsSaveNote;

window.wsErrors = function () {
  console.table(window._wsErrorLog);
  return window._wsErrorLog;
};
window.fsSet = fsSet; window.fsAdd = fsAdd; window.fsUpdate = fsUpdate; window.fsDelete = fsDelete;

/* ============================================================
   6) حارس الدخول الموحّد
   ============================================================ */
function guardPage(onAuthed, requiredAccess) {
  let done = false;
  let nullStateTimer = null;
  // لو تأخر التحقق (إنترنت ضعيف) نوضّح السبب بدل ترك شاشة "جاري التحقق..." معلّقة
  const slowNoticeTimer = setTimeout(() => {
    if (done) return;
    const p = document.querySelector('#auth-gate p');
    if (p) p.textContent = navigator.onLine
      ? 'الاتصال بطيء، جارٍ استعادة جلسة الدخول...'
      : '🔴 لا يوجد اتصال — جارٍ محاولة استعادة الجلسة المحفوظة';
  }, 6000);

  // Firebase قد يمر بحالة null مؤقتة أثناء استعادة الجلسة المحلية.
  // لا نعيد توجيه المستخدم فوراً؛ ننتظر قليلاً ونعيد فحص currentUser.
  // هذا يمنع الخروج الفوري عند فتح وحدة من اختصار/PWA أو بعد تحديث SW.
  const handleAuthed = async function(user) {
    if (!user) {
      if (nullStateTimer) return;
      nullStateTimer = setTimeout(async () => {
        nullStateTimer = null;
        if (done) return;
        const current = auth.currentUser;
        if (current) return handleAuthed(current);
        clearTimeout(slowNoticeTimer);
        window.location.replace('index.html');
      }, 3500);
      return;
    }
    if (nullStateTimer) { clearTimeout(nullStateTimer); nullStateTimer = null; }
    const shopUser = await resolveShopUser(user);
    clearTimeout(slowNoticeTimer); done = true;
    if (!shopUser) {
      /* 9.2.0 — الخروج على سبب نهائي وحده */
      if (!wsAuthFailureIsDefinitive()) {
        showFsErrorToast('📡 تعذّر التحقق من حسابك مؤقتاً — لن تُعاد الصفحة. سيُعاد التحقق تلقائياً.');
        wsRetryAuthSoon(function () {
          try {
            if (auth.currentUser) handleAuthed(auth.currentUser);
          } catch (e) { wsSilent('auth:retry', e); }
        });
        return;
      }
      await auth.signOut().catch(() => {});
      window.location.replace('index.html?msg=' + encodeURIComponent(wsAuthFailureMessage()));
      return;
    }
    window.currentShopUser = shopUser;
    try { applyModuleAccessUI(shopUser); } catch (e) {}
    const page = requiredAccess || (location.pathname.toLowerCase().endsWith('measurements.html') ? 'measurements' : location.pathname.toLowerCase().endsWith('cutting.html') ? 'cutting' : '');
    if (page && !wsCanAccess(page, shopUser)) {
      try { showFsErrorToast(page === 'measurements' ? '⛔ ليس لديك صلاحية الدخول إلى كراسة القياسات.' : '⛔ ليس لديك صلاحية الدخول إلى القص والمواد الخام.'); } catch(e) {}
      window.location.replace('index.html?denied=' + encodeURIComponent(page));
      return;
    }
    onAuthed(shopUser);
  };

  // انتظر اكتمال ضبط Firebase Auth persistence قبل بدء حارس الصفحة.
  // لا نعتمد عليه وحده لاستعادة الجلسة، لكنه يمنع سباقاً بين setPersistence
  // و onAuthStateChanged عند فتح التطبيق من PWA/اختصار على الهاتف.
  Promise.resolve(window.wsAuthReady).catch(() => {}).then(() => {
    auth.onAuthStateChanged(handleAuthed);
  });
}

/* ============================================================
   7) Service Worker — هيكل التطبيق يعمل دون إنترنت
   ------------------------------------------------------------
   لا علاقة له بمزامنة البيانات (تلك عبر Firestore) — مهمته فتح
   الصفحات نفسها فوراً حتى بلا شبكة، بعد أول زيارة ناجحة.
   ============================================================ */
if (!window.WS_ANDROID && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').then(reg => {
      try { reg.update(); } catch (e) {}
      // فحص دوري خفيف للتحديثات كل ساعة أثناء بقاء التطبيق مفتوحاً
      setInterval(() => { try { reg.update(); } catch (e) {} }, 3600000);
    }).catch(() => {});
  });

  /* v249: Service Worker لا يعيد تحميل الصفحة تلقائياً.
     إعادة التحميل القهري هنا كانت تجعل التطبيق يبدو وكأنه «يخرج» أو
     يعيد الصفحة عند الضغط، خصوصاً أثناء تنشيط نسخة جديدة على الهاتف.
     النسخة الجديدة تصبح فعالة للملاحة التالية، أما الصفحة الحالية
     فتبقى ثابتة ولا تُفقد حالة الإدخال أو النوافذ المفتوحة. */

  /* ⚠️ إصلاح 8.8 — التحديث كان يمحو الشغل غير المحفوظ.
     الحارس القديم ينتظر wsPendingWrites، وهي تعدّ **الكتابات المرسَلة
     إلى Firestore فقط**. أما فاتورة فيها اثنا عشر صنفاً لم تُحفظ بعد،
     أو كراسة قياسات قيد الإدخال، فليست كتابة معلّقة — فتُعاد الصفحة
     ويضيع كل ما كُتب. والتحديث يُفحص كل ساعة، أي أن هذا يقع أثناء
     العمل لا خارجه.

     الآن: كل صفحة تُعرّف wsHasUnsavedWork، ولا نُعيد التحميل ما دام
     هناك شغل مفتوح. نُبلغ المستخدم مرة واحدة فقط ونترك التحديث
     يُطبَّق عند أول انتقال أو إغلاق طبيعي — لا نقاطعه أبداً. */
  function _wsWorkInProgress() {
    try {
      return (window.wsPendingWrites || 0) > 0 ||
             (typeof window.wsHasUnsavedWork === 'function' && window.wsHasUnsavedWork() === true);
    } catch (e) { return false; }
  }

  navigator.serviceWorker.addEventListener('controllerchange', () => {
    try {
      if (typeof showSyncToast === 'function') {
        showSyncToast('🔄 تم تحديث ملفات التطبيق — لن تُعاد الصفحة أثناء العمل.');
      }
    } catch (e) {}
  });
}

function isOffline() { return !navigator.onLine; }

/* ============================================================
   إبقاء الشاشة مضاءة أثناء استخدام التطبيق
   ------------------------------------------------------------
   القياس في الورشة يجري باليدين: يقيس العامل ثم يُدخل الرقم ثم يقيس مرة
   أخرى. وانطفاء الشاشة بين مقاسين يعني إعادة فتح الجهاز في كل مرة، وأحياناً
   ضياع ما كُتب ولم يُضَف بعد.

   الإذن يتحرّر تلقائياً حين يخفي المتصفح الصفحة (تبديل تطبيق، قفل الجهاز)،
   ولذلك نعيد طلبه عند العودة — وإلا انطفأت الشاشة بعد أول تبديل ولم تعد.
   ويُحرَّر نهائياً عند مغادرة الصفحة، فلا يستهلك البطارية بعد الخروج.
   ============================================================ */
(function keepScreenAwake() {
  if (!('wakeLock' in navigator)) return;   // غير مدعوم: لا شيء نفعله
  let lock = null;
  let released = false;   // المستخدم أوقفه بنفسه

  async function acquire() {
    if (released || lock || document.visibilityState !== 'visible') return;
    try {
      lock = await navigator.wakeLock.request('screen');
      lock.addEventListener('release', () => { lock = null; });
    } catch (e) {
      // يفشل عادةً لبطارية منخفضة جداً أو سياسة الجهاز — لا نُزعج المستخدم
      lock = null;
    }
  }

  function drop() {
    if (!lock) return;
    try { lock.release(); } catch (e) {}
    lock = null;
  }

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') acquire(); else drop();
  });
  window.addEventListener('pagehide', drop);
  window.addEventListener('beforeunload', drop);

  // إتاحة إيقافه يدوياً لمن أراد توفير البطارية
  window.wsKeepAwake = function (on) {
    released = (on === false);
    if (released) drop(); else acquire();
    return !released;
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', acquire);
  else acquire();
})();

/* ============================================================
   8) رصد الاتصال — في الخلفية، بلا شريط أحمر يغطي أعلى الصفحة
   ------------------------------------------------------------
   تُضاف الفئة is-offline على <html> ويُطلَق حدث connectivity-change،
   ويبقى مؤشر صغير جداً (نقطة نابضة) لأن إخفاء كل أثر للانقطاع يجعل
   المستخدم يظن أن بياناته وصلت لبقية الأعضاء وهي لم تصل بعد.
   لإخفاء النقطة أيضاً: SHOW_OFFLINE_DOT = false.
   ============================================================ */
const SHOW_OFFLINE_DOT = true;

function initConnectivityBanner() {
  const legacy = document.getElementById('connectivity-banner');
  if (legacy) { legacy.classList.add('hidden'); legacy.style.display = 'none'; }

  if (SHOW_OFFLINE_DOT) {
    const st = document.createElement('style');
    st.textContent =
      '#offline-dot{position:fixed;top:calc(6px + env(safe-area-inset-top));' +
      'left:10px;z-index:2000;width:9px;height:9px;border-radius:50%;' +
      'background:#ef4444;box-shadow:0 0 0 3px rgba(239,68,68,.22);' +
      'opacity:0;visibility:hidden;pointer-events:none;' +
      'transition:opacity .3s ease,visibility .3s;}' +
      'html.is-offline #offline-dot{opacity:1;visibility:visible;animation:offPulse 1.9s ease-in-out infinite;}' +
      '@keyframes offPulse{0%,100%{box-shadow:0 0 0 3px rgba(239,68,68,.22);}' +
      '50%{box-shadow:0 0 0 7px rgba(239,68,68,0);}}' +
      '@media (prefers-reduced-motion: reduce){html.is-offline #offline-dot{animation:none;}}';
    (document.head || document.documentElement).appendChild(st);

    const dot = document.createElement('div');
    dot.id = 'offline-dot';
    dot.title = 'غير متصل — يُحفظ محلياً ويُزامَن تلقائياً فور عودة الاتصال';
    document.body.appendChild(dot);
  }

  function update() {
    const offline = !navigator.onLine;
    document.documentElement.classList.toggle('is-offline', offline);
    if (legacy) legacy.style.display = 'none';
    updateSyncStatus();
    try { window.dispatchEvent(new CustomEvent('connectivity-change', { detail: { offline } })); } catch (e) {}
  }

  window.addEventListener('online', update);
  window.addEventListener('offline', update);
  update();

  /* عند عودة الاتصال: Firestore يرفع تلقائياً كل ما حُفظ محلياً.
     ننتظر اكتمال الرفع فعلياً ثم نطمئن المستخدم. */
  let wasOffline = !navigator.onLine;
  window.addEventListener('offline', () => { wasOffline = true; });
  window.addEventListener('online', () => {
    if (!wasOffline) return;
    wasOffline = false;
    if (!db.waitForPendingWrites) return;
    db.waitForPendingWrites()
      .then(() => showSyncToast('✅ عاد الاتصال — رُفعت كل التعديلات بنجاح'))
      .catch(() => {});
  });

  /* تحذير قبل إغلاق الصفحة — فقط إن كان هناك عمل لم يصل السيرفر بعد.
     الخلل السابق: كان التحذير يظهر لمجرد أن الجهاز غير متصل، حتى بلا أي
     تعديل، فيزعج المستخدم في كل إغلاق ويفقد معناه فيتجاهله دائماً. */
  window.addEventListener('beforeunload', (e) => {
    if ((window.wsPendingWrites || 0) === 0 && !window.wsResumingFromPreviousSession) return;
    e.preventDefault();
    e.returnValue = '';
  });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initConnectivityBanner);
else initConnectivityBanner();

/* ============================================================
   9) مؤشر حالة المزامنة — شارة صغيرة أعلى الشاشة
   ------------------------------------------------------------
   لا تظهر إطلاقاً حين يكون كل شيء مرفوعاً ومتصلاً.
   ============================================================ */
let _syncPill = null, _syncHideTimer = null;

function ensureSyncPill() {
  if (_syncPill) return _syncPill;
  if (!document.body) return null;
  const st = document.createElement('style');
  st.textContent =
    '#ws-sync-pill{position:fixed;top:calc(6px + env(safe-area-inset-top));left:50%;transform:translateX(-50%) translateY(-6px);' +
    'z-index:2001;padding:5px 12px;border-radius:999px;font-family:Cairo,Tajawal,sans-serif;font-size:11px;font-weight:800;' +
    'color:#fff;box-shadow:0 4px 14px rgba(0,0,0,.18);opacity:0;visibility:hidden;pointer-events:auto;cursor:pointer;' +
    'transition:opacity .25s ease,transform .25s ease,background .25s ease;white-space:nowrap;max-width:92vw;overflow:hidden;text-overflow:ellipsis;}' +
    '#ws-sync-pill.show{opacity:1;visibility:visible;transform:translateX(-50%) translateY(0);}' +
    '@media print{#ws-sync-pill{display:none !important;}}';
  (document.head || document.documentElement).appendChild(st);

  _syncPill = document.createElement('div');
  _syncPill.id = 'ws-sync-pill';
  _syncPill.setAttribute('role', 'status');
  _syncPill.onclick = () => {
    const n = window.wsPendingWrites || 0;
    const parts = Object.keys(window.wsPendingByType || {})
      .map(k => '   • ' + k + ': ' + window.wsPendingByType[k]);
    const detail = parts.length ? '\n\nبانتظار الرفع:\n' + parts.join('\n') : '';
    if (!navigator.onLine) {
      alert('🔴 لا يوجد اتصال بالإنترنت.\n\n' +
            'استمر في العمل بشكل طبيعي — كل شيء يُحفظ داخل الجهاز فوراً، ' +
            'ويُرفع تلقائياً لبقية الأجهزة فور عودة الإنترنت.' + detail +
            '\n\n⚠️ لا تحذف بيانات المتصفح ولا تُلغِ تثبيت التطبيق قبل عودة الاتصال.');
    } else if (n || window.wsResumingFromPreviousSession) {
      alert('⏳ جارٍ رفع التغييرات إلى السيرفر…' + detail + '\n\nلا داعي للانتظار، يمكنك متابعة العمل.');
    }
  };
  document.body.appendChild(_syncPill);
  return _syncPill;
}

function updateSyncStatus(justSynced) {
  const pill = ensureSyncPill();
  if (!pill) return;
  const n = window.wsPendingWrites || 0;
  clearTimeout(_syncHideTimer);

  const types = Object.keys(window.wsPendingByType || {});
  const topType = types.length === 1 ? (' ' + types[0]) : '';
  if (!navigator.onLine) {
    pill.style.background = '#b91c1c';
    pill.textContent = n ? ('🔴 غير متصل — ' + n + topType + ' بانتظار الرفع') : '🔴 غير متصل — يُحفظ داخل الجهاز';
    pill.classList.add('show');
    return;
  }
  if (n > 0 || window.wsResumingFromPreviousSession) {
    pill.style.background = '#b45309';
    pill.textContent = n ? ('⏳ جارٍ الرفع… (' + n + ')') : '⏳ جارٍ رفع العمل المحفوظ…';
    pill.classList.add('show');
    return;
  }
  if (justSynced) {
    pill.style.background = '#047857';
    pill.textContent = '✅ تم رفع كل البيانات';
    pill.classList.add('show');
    _syncHideTimer = setTimeout(() => pill.classList.remove('show'), 2200);
    return;
  }
  pill.classList.remove('show');
}

// إشعار خفيف موحّد لكل الصفحات
function showSyncToast(text) {
  if (!document.body) return;
  const t = document.createElement('div');
  t.textContent = text;
  t.style.cssText =
    'position:fixed;bottom:calc(18px + env(safe-area-inset-bottom));left:50%;' +
    'transform:translateX(-50%) translateY(14px);z-index:3000;' +
    'background:#0f172a;color:#fff;padding:12px 20px;border-radius:14px;' +
    'font-family:Cairo,Tahoma,sans-serif;font-size:13.5px;font-weight:800;' +
    'box-shadow:0 14px 34px -10px rgba(0,0,0,.55);opacity:0;' +
    'transition:opacity .25s ease,transform .25s ease;max-width:90vw;text-align:center;';
  document.body.appendChild(t);
  requestAnimationFrame(() => { t.style.opacity = '1'; t.style.transform = 'translateX(-50%) translateY(0)'; });
  setTimeout(() => {
    t.style.opacity = '0'; t.style.transform = 'translateX(-50%) translateY(14px)';
    setTimeout(() => t.remove(), 300);
  }, 3200);
}

/* ============================================================
   9.5) قفل الشاشة — أُزيلت النسخة المكررة   (إصلاح 8.8)
   ------------------------------------------------------------
   كانت هنا كتلة ثانية (initScreenWakeLock) تفعل نفس ما تفعله
   keepScreenAwake أعلاه بالضبط: تطلب wake lock وتسجّل نفس المستمعات
   على visibilitychange و pagehide و beforeunload.

   الأثر العملي لم يكن مجرد تكرار: القفلان مستقلّان، فاستدعاء
   wsKeepAwake(false) كان يحرّر واحداً منهما فقط — والشاشة تبقى مضاءة
   والبطارية تُستنزف رغم أن المستخدم أوقف الخاصية صراحةً، بلا أي مؤشر
   على السبب.

   بقيت النسخة الأولى وحدها (keepScreenAwake)، وواجهتها window.wsKeepAwake.
   ونُبقي wsScreenAwake اسماً بديلاً لها حتى لا ينكسر أي استدعاء قديم. */
window.wsScreenAwake = function (on) {
  return (typeof window.wsKeepAwake === 'function') ? window.wsKeepAwake(on) : false;
};

/* ============================================================
   10) الانتقال بين الصفحات — ناعم ومتصل
   ------------------------------------------------------------
   ثلاث طبقات تعمل معاً:
   (أ) View Transitions للمتصفحات الحديثة: انتقال حقيقي بين مستندين،
       بلا أي وميض أبيض إطلاقاً.
   (ب) تلاشٍ لطيف كبديل في المتصفحات الأقدم.
   (ج) تحميل مسبق عند أول لمسة على الرابط، فتكون الصفحة جاهزة
       قبل رفع الإصبع.
   ============================================================ */
(function initSmoothPageTransitions() {
  /* كشف دقيق لدعم الانتقال بين مستندين تحديداً.
     لا يصلح 'startViewTransition' in document هنا، فهو يدل على الانتقال
     داخل المستند الواحد وقد شُحن قبله بإصدارات — فنظن الدعم موجوداً
     ونلغي التلاشي البديل، فيظهر وميض أبيض حاد عند كل انتقال.
     onpagereveal شُحن مع الانتقال بين المستندين نفسه، فهو المؤشر الصحيح. */
  const supportsVT = ('onpagereveal' in window) && ('startViewTransition' in document);

  const st = document.createElement('style');
  st.textContent =
    /* (أ) انتقال بين مستندين — يعمل تلقائياً حيث يُدعم */
    '@view-transition{navigation:auto;}' +
    '::view-transition-old(root){animation:wsFadeOut .18s ease both;}' +
    '::view-transition-new(root){animation:wsFadeIn .24s ease both;}' +
    '@keyframes wsFadeOut{to{opacity:0;transform:translateY(-4px);}}' +
    '@keyframes wsFadeIn{from{opacity:0;transform:translateY(6px);}}' +
    /* (ب) البديل: تلاشٍ يدوي */
    (supportsVT ? '' :
      'body{transition:opacity .18s ease, transform .18s ease;}' +
      'body.page-leaving{opacity:0 !important;transform:translateY(-6px) !important;}') +
    '@media (prefers-reduced-motion: reduce){' +
      '::view-transition-old(root),::view-transition-new(root){animation:none !important;}' +
      'body,body.page-leaving{transition:none !important;transform:none !important;opacity:1 !important;}}';
  (document.head || document.documentElement).appendChild(st);

  const isInternal = (href) => /^[\w.\-]+\.html(\?|#|$)/i.test(href || '');

  // (ج) تحميل مسبق عند اللمس/التحويم — الصفحة جاهزة قبل رفع الإصبع
  const prefetched = new Set();
  function prefetch(href) {
    const file = (href || '').split('#')[0];
    if (!file || prefetched.has(file) || !isInternal(file)) return;
    prefetched.add(file);
    const l = document.createElement('link');
    l.rel = 'prefetch'; l.href = file;
    document.head.appendChild(l);
  }
  ['pointerenter', 'touchstart'].forEach(evt => {
    document.addEventListener(evt, (e) => {
      const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      if (a) prefetch(a.getAttribute('href'));
    }, { capture: true, passive: true });
  });

  let navigating = false;
  window.wsNavigateTo = function (href) {
    if (navigating) return;              // يمنع نقرتين متتاليتين من فتح صفحتين
    navigating = true;
    try { sessionStorage.setItem('ws_scroll_' + location.pathname, String(window.scrollY || 0)); } catch (e) {}
    // انتقال مباشر بلا مؤقّت أو حركة تلاشي تؤخر فتح القسم.
    // يبقى حاجز navigating لمنع النقر المزدوج، ويُحفظ موضع التمرير أعلاه.
    window.location.href = href;
  };

  document.addEventListener('click', function (e) {
    if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    if (a.target === '_blank' || a.hasAttribute('download')) return;
    const href = a.getAttribute('href') || '';
    if (!isInternal(href)) return;
    e.preventDefault();
    window.wsNavigateTo(href);
  }, true);

  // الرجوع من ذاكرة المتصفح: نُعيد الصفحة لوضوحها الكامل ونستعيد موضع التمرير
  window.addEventListener('pageshow', function () {
    navigating = false;
    if (document.body) document.body.classList.remove('page-leaving');
    try {
      const y = parseInt(sessionStorage.getItem('ws_scroll_' + location.pathname) || '0', 10);
      if (y > 0) window.scrollTo(0, y);
    } catch (e) {}
  });
})();

/* ============================================================
   11) شريط التبويبات العلوي المشترك
   ------------------------------------------------------------
   تنقّل سلس: المؤشر ينزلق أولاً ثم تُفتح الصفحة التالية ومؤشرها في
   مكانه الصحيح، فيبدو الأمر تطبيقاً واحداً لا صفحات منفصلة.
   يدعم أيضاً: السحب بالإصبع يميناً/يساراً للانتقال بين الأقسام،
   وزر الرئيسية، ولوحة المفاتيح (الأسهم).
   ============================================================ */
(function initAppNavigation() {
  const TABS = [
    { file: 'measurements.html', label: 'القياسات',          icon: '\uD83D\uDCCF' },
    { file: 'invoices.html',     label: 'الفواتير',           icon: '\u1F9FE' },
    { file: 'cutting.html',      label: 'القص والمواد الخام', icon: '\u2702\uFE0F' }
  ];

  const here = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  if (here === '' || here === 'index.html') return;   // البوابة ليست وحدة من الوحدات
  const activeIdx = TABS.findIndex(t => t.file === here);
  if (activeIdx === -1) return;

  /* ══ لا شريط تبويبات محقون بعد اليوم ══
     كان هذا الجزء يُنشئ شريطاً علوياً ثابتاً، وكل صفحة تحمل شريط تنقّل
     خاصاً بها في متنها. فيظهر شريطان فوق بعضهما بنفس الأقسام: أحدهما
     بأيقونات والآخر بأزرار — تكرار يشغل ثلث الشاشة على الجوال ويجعل
     المستخدم يتساءل أيّهما يضغط.

     أُزيل المحقون وأُبقي شريط الصفحة (#app-nav) لأنه الأقرب للمحتوى
     ويحمل اسم المستخدم وزر الخروج. أما ما يستحق البقاء من هنا فهو
     ما لا واجهة له: السحب بالإصبع بين الأقسام، وأسهم لوحة المفاتيح. */
  function goToTab(idx) {
    if (idx === activeIdx || idx < 0 || idx >= TABS.length) return;
    window.wsNavigateTo(TABS[idx].file);
  }

  /* السحب بالإصبع للانتقال بين الأقسام — الحركة الطبيعية على الجوال.
     شروط صارمة حتى لا يتعارض مع التمرير أو مع لوحة الرسم:
     • حركة أفقية واضحة (ضعف الرأسية على الأقل) وأطول من 70 بكسل
     • بإصبع واحد فقط
     • لا تبدأ من داخل عنصر قابل للتمرير أفقياً أو لوحة رسم أو مُدخل */
  let sx = 0, sy = 0, tracking = false;
  const BLOCK = 'canvas,input,textarea,select,[contenteditable],table,' +
                '.no-swipe,.modal,[role="dialog"],.overflow-x-auto,.overflow-auto,' +
                '.archive-item-wrapper,.swipe-item';
  document.addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1) { tracking = false; return; }
    const t = e.touches[0];
    const el = e.target;
    if (el && el.closest && el.closest(BLOCK)) { tracking = false; return; }
    // أي عنصر أب قابل للتمرير أفقياً فعلياً: السحب فيه تمرير لا تنقّل
    for (let n = el; n && n !== document.body; n = n.parentElement) {
      if (n.scrollWidth > n.clientWidth + 4) { tracking = false; return; }
    }
    // نافذة منبثقة مفتوحة: لا تنقّل بين الأقسام من داخلها
    if (document.querySelector('.modal:not(.hidden),[role="dialog"]:not(.hidden)')) { tracking = false; return; }
    sx = t.clientX; sy = t.clientY; tracking = true;
  }, { passive: true });

  document.addEventListener('touchend', (e) => {
    if (!tracking) return;
    tracking = false;
    const t = e.changedTouches && e.changedTouches[0];
    if (!t) return;
    const dx = t.clientX - sx, dy = t.clientY - sy;
    if (Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 2) return;
    // RTL: السحب يميناً يذهب للقسم السابق، ويساراً للقسم التالي
    goToTab(activeIdx + (dx > 0 ? -1 : 1));
  }, { passive: true });

  // الأسهم في لوحة المفاتيح (مفيد على الأجهزة اللوحية بلوحة مفاتيح)
  document.addEventListener('keydown', (e) => {
    if (e.altKey || e.ctrlKey || e.metaKey) return;
    const tag = (document.activeElement && document.activeElement.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
    if (e.key === 'ArrowLeft')  goToTab(activeIdx + 1);
    if (e.key === 'ArrowRight') goToTab(activeIdx - 1);
  });

  /* لا شيء يُركَّب في الصفحة: السحب وأسهم لوحة المفاتيح تعمل على
     document مباشرةً، وشريط التنقّل صار في متن كل صفحة. */

  /* لم يعد هنا شريط يُخفى قبل الدخول: كل صفحة تُظهر شريطها بنفسها بعد
     التحقق من الجلسة (display:none في المتن، ثم flex بعد الدخول). */
})();

/* ============================================================
   12) تسجيل الخروج المشترك
   ------------------------------------------------------------
   حماية مهمة: تسجيل الدخول نفسه يحتاج إنترنت. فالخروج وأنت دون اتصال
   يعني أنك لن تستطيع العودة إلى التطبيق إطلاقاً حتى تعود الشبكة —
   ومعك عمل لم يُرفع بعد. لذلك نمنع ذلك بتحذير صريح.
   ============================================================ */
let _wsLoggingOut = false;
async function sharedLogout() {
  if (_wsLoggingOut) return;
  _wsLoggingOut = true;
  const buttons = Array.from(document.querySelectorAll('[onclick*="sharedLogout"], [onclick*="logoutUser"]'));
  buttons.forEach(b => { try { b.disabled = true; b.setAttribute('aria-busy','true'); } catch(e) {} });
  const pending = Number(window.wsPendingWrites || 0);
  if (pending > 0) {
    if (!confirm('⏳ ما زال هناك ' + pending + ' تغييراً قيد الرفع للسيرفر.\n\nيمكنك الخروج الآن، لكن التغييرات غير المرفوعة قد تتأخر حتى يعود الاتصال.\n\nهل تريد المتابعة؟')) {
      _wsLoggingOut = false;
      buttons.forEach(b => { try { b.disabled = false; b.removeAttribute('aria-busy'); } catch(e) {} });
      return;
    }
  } else if (!confirm('هل تريد تسجيل الخروج؟')) {
    _wsLoggingOut = false;
    buttons.forEach(b => { try { b.disabled = false; b.removeAttribute('aria-busy'); } catch(e) {} });
    return;
  }
  // Firebase signOut محلي بالأساس؛ لا نمنع المستخدم من الخروج بسبب انقطاع الشبكة.
  try { await auth.signOut(); }
  catch (e) { console.warn('[ws] logout signOut warning:', e); }
  try { clearCachedShopUser(); } catch(e) {}
  // إيقاف المستمعات/المؤقتات قبل الانتقال حتى لا تتسابق مع الصفحة التالية.
  try {
    if (Array.isArray(window._firestoreUnsubscribers)) {
      window._firestoreUnsubscribers.forEach(fn => { try { if (typeof fn === 'function') fn(); } catch(e) {} });
    }
  } catch(e) {}
  window.location.replace('index.html?logout=' + Date.now());
}
window.sharedLogout = sharedLogout;
