
    // الأقسام المقتصرة على المشرف فقط — الأعضاء الآخرون لا يرون أزرارها ولا يمكنهم فتحها
    const ADMIN_ONLY_SECTIONS = ['credits','returns','expenses','inventory','salesaudit','editedinv','payments','trash','backup'];
    // تطبيق منفصل (ثانوي) يُستخدم فقط لإنشاء حسابات الأعضاء الجدد دون تسجيل خروج المشرف من جلسته الحالية
    const secondaryApp = firebase.initializeApp(firebaseConfig, 'secondary');
    const secondaryAuth = secondaryApp.auth();
  