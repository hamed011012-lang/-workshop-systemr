/* v222 — Firestore incremental pagination helper (compat SDK)
 * Read-only by design. Never writes to Firestore.
 * Uses __name__ ordering so legacy documents without business timestamps are not skipped.
 */
(function (global) {
  'use strict';

  const DEFAULT_PAGE_SIZE = 100;
  const MAX_PAGE_SIZE = 250;

  function clampPageSize(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return DEFAULT_PAGE_SIZE;
    return Math.max(1, Math.min(MAX_PAGE_SIZE, Math.floor(n)));
  }

  function assertDb(db) {
    if (!db || typeof db.collection !== 'function') {
      throw new Error('Firestore غير متاح');
    }
  }

  function makeQuery(db, collectionName, pageSize, cursor) {
    assertDb(db);
    if (!collectionName || typeof collectionName !== 'string') {
      throw new Error('اسم المجموعة غير صالح');
    }
    const docIdPath = (global.firebase && global.firebase.firestore && global.firebase.firestore.FieldPath && typeof global.firebase.firestore.FieldPath.documentId === 'function') ? global.firebase.firestore.FieldPath.documentId() : '__name__';
    let q = db.collection(collectionName).orderBy(docIdPath).limit(clampPageSize(pageSize));
    if (cursor) q = q.startAfter(cursor);
    return q;
  }

  async function fetchPage(db, collectionName, options) {
    options = options || {};
    const pageSize = clampPageSize(options.pageSize);
    const cursor = options.cursor || null;
    const snap = await makeQuery(db, collectionName, pageSize, cursor).get();
    const docs = snap.docs.map(d => ({ id: d.id, data: d.data() || {}, ref: d.ref }));
    return {
      collection: collectionName,
      pageSize,
      docs,
      count: docs.length,
      hasMore: docs.length === pageSize,
      lastDoc: snap.docs.length ? snap.docs[snap.docs.length - 1] : null,
      firstId: docs.length ? docs[0].id : null,
      lastId: docs.length ? docs[docs.length - 1].id : null
    };
  }

  function cleanSearchTerm(value) {
    return String(value == null ? '' : value).replace(/[\u200c\u200d\u200e\u200f\ufeff]/g, '').trim();
  }

  function digitVariants(value) {
    const v = cleanSearchTerm(value);
    if (!/^[0-9٠-٩۰-۹]+$/.test(v)) return [v];
    const toLatin = v.replace(/[٠-٩]/g, c => String(c.charCodeAt(0) - 0x0660)).replace(/[۰-۹]/g, c => String(c.charCodeAt(0) - 0x06f0));
    const toArabic = toLatin.replace(/[0-9]/g, c => String.fromCharCode(0x0660 + Number(c)));
    const toPersian = toLatin.replace(/[0-9]/g, c => String.fromCharCode(0x06f0 + Number(c)));
    return [...new Set([v, toLatin, toArabic, toPersian])];
  }

  async function fetchPrefix(db, collectionName, fieldPath, term, options) {
    options = options || {};
    assertDb(db);
    if (!collectionName || typeof collectionName !== 'string') throw new Error('اسم المجموعة غير صالح');
    if (!fieldPath || typeof fieldPath !== 'string') throw new Error('مسار الحقل غير صالح');
    const value = cleanSearchTerm(term);
    if (!value) return { collection: collectionName, fieldPath, term: value, docs: [], count: 0, hasMore: false };
    const pageSize = clampPageSize(options.pageSize || DEFAULT_PAGE_SIZE);
    const end = value + '\uf8ff';
    const snap = await db.collection(collectionName)
      .where(fieldPath, '>=', value)
      .where(fieldPath, '<=', end)
      .limit(pageSize)
      .get();
    const docs = snap.docs.map(d => ({ id: d.id, data: d.data() || {}, ref: d.ref }));
    return { collection: collectionName, fieldPath, term: value, pageSize, docs, count: docs.length, hasMore: docs.length === pageSize };
  }

  async function fetchPrefixVariants(db, collectionName, fieldPath, term, options) {
    const variants = digitVariants(term);
    const results = await Promise.all(variants.map(v => fetchPrefix(db, collectionName, fieldPath, v, options)));
    const byId = Object.create(null);
    results.forEach(r => r.docs.forEach(d => { if (!Object.prototype.hasOwnProperty.call(byId, d.id)) byId[d.id] = d; }));
    const docs = Object.keys(byId).map(k => byId[k]);
    return { collection: collectionName, fieldPath, term: cleanSearchTerm(term), variants, docs, count: docs.length, hasMore: results.some(r => r.hasMore) };
  }

  async function scan(db, collectionName, options) {
    options = options || {};
    const pageSize = clampPageSize(options.pageSize);
    const onPage = typeof options.onPage === 'function' ? options.onPage : null;
    const maxDocs = Number.isFinite(Number(options.maxDocs)) && Number(options.maxDocs) > 0
      ? Math.floor(Number(options.maxDocs)) : Infinity;
    let cursor = null;
    let total = 0;
    let pages = 0;
    const started = Date.now();

    while (total < maxDocs) {
      const remaining = maxDocs - total;
      const page = await fetchPage(db, collectionName, {
        pageSize: Math.min(pageSize, remaining),
        cursor
      });
      pages++;
      total += page.count;
      if (onPage) await onPage(page, { pages, total, elapsedMs: Date.now() - started });
      if (!page.hasMore || !page.lastDoc || page.count === 0 || total >= maxDocs) break;
      cursor = page.lastDoc;
    }

    return { collection: collectionName, pages, total, elapsedMs: Date.now() - started };
  }

  global.FirestorePager = Object.freeze({ fetchPage, fetchPrefix, fetchPrefixVariants, digitVariants, cleanSearchTerm, scan, clampPageSize, MAX_PAGE_SIZE });
})(window);
