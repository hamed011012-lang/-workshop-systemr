/* Workshop Data v139 — generic IndexedDB repository.
 * Business modules use this contract instead of knowing storage details.
 */
(function (g) {
  'use strict';
  if (g.AppRepository) return;

  function key(collection, id) { return String(collection) + ':' + String(id); }
  function cleanId(id) { const s = String(id == null ? '' : id).trim(); if (!s) throw new Error('معرّف السجل مطلوب'); return s; }

  function create(collection) {
    const name = String(collection || '').trim();
    if (!name) throw new Error('اسم المجموعة مطلوب');
    return Object.freeze({
      name,
      async get(id) { const x = await g.AppDB.get('records', key(name, cleanId(id))); return x ? x.data : null; },
      async set(id, data) {
        const rid = cleanId(id), now = Date.now();
        await g.AppDB.put('records', { key: key(name, rid), collection: name, id: rid, data, createdAt: now, updatedAt: now });
        return data;
      },
      async update(id, patch) {
        const rid = cleanId(id), k = key(name, rid), old = await g.AppDB.get('records', k);
        const data = Object.assign({}, old && old.data || {}, patch || {}), now = Date.now();
        await g.AppDB.put('records', { key: k, collection: name, id: rid, data, createdAt: old && old.createdAt || now, updatedAt: now });
        return data;
      },
      async remove(id) { await g.AppDB.del('records', key(name, cleanId(id))); },
      async query(limit) {
        const rows = await g.AppDB.list('records', Math.max(1, Number(limit) || 500));
        return rows.filter(x => x && x.collection === name).map(x => x.data);
      }
    });
  }

  g.AppRepository = Object.freeze({ create });
})(window);
