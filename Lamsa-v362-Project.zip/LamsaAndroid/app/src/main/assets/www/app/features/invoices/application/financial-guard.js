/* v238 — UI command guard for financial integrity. Blocks malformed values before mutation. */
(function(g){'use strict'; if(g.FinancialGuard)return;
  function fail(msg){try{alert('⚠️ لم تُنفّذ العملية لأسباب تتعلق بسلامة الحسابات.\n\n'+msg);}catch(_){} return false;}
  function wrap(name,check){
    const original=g[name]; if(typeof original!=='function'||original.__wsFinancialGuardWrapped)return false;
    function wrapped(){const v=check.apply(this,arguments); if(v!==true)return fail(v||'بيانات مالية غير صالحة.'); return original.apply(this,arguments);}
    wrapped.__wsFinancialGuardWrapped=true; wrapped.__wsFinancialGuardOriginal=original; g[name]=wrapped; return true;
  }
  function install(){
    wrap('saveCurrentInvoice',function(){
      const F=g.FinancialIntegrity, items=Array.isArray(g.currentInvoiceItems)?g.currentInvoiceItems:[];
      if(!F)return true;
      const paidEl=document.getElementById('pos-amount-paid'); const paid=Number(g.toLatinDigits?g.toLatinDigits(paidEl&&paidEl.value||0):paidEl&&paidEl.value||0);
      if(!Number.isFinite(paid)||paid<0)return 'مبلغ المدفوع غير صالح.';
      if(!items.length)return 'الفاتورة فارغة.';
      for(const x of items){const v=F.item(x,true);if(!v.ok)return 'بيانات أحد الأصناف غير صالحة: '+v.reason;}
      return true;
    });
    wrap('savePaymentReceipt',function(){
      const F=g.FinancialIntegrity;if(!F)return true;const e=document.getElementById('receipt-amount');const amount=Number(g.toLatinDigits?g.toLatinDigits(e&&e.value||0):e&&e.value||0);if(!Number.isFinite(amount)||amount<=0)return 'مبلغ الواصل يجب أن يكون أكبر من صفر.';return true;
    });
    wrap('savePaymentReceiptAndPrint',function(){
      const F=g.FinancialIntegrity;if(!F)return true;const e=document.getElementById('receipt-amount');const amount=Number(g.toLatinDigits?g.toLatinDigits(e&&e.value||0):e&&e.value||0);if(!Number.isFinite(amount)||amount<=0)return 'مبلغ الواصل يجب أن يكون أكبر من صفر.';return true;
    });
    wrap('confirmReturn',function(){
      const F=g.FinancialIntegrity,src=g.returnSource;if(!F||!src)return true;if(!Array.isArray(src.items))return 'بيانات الفاتورة الأصلية غير صالحة.';
      for(let i=0;i<src.items.length;i++){const qEl=document.getElementById('ret-qty-'+i);const q=Number(g.toLatinDigits?g.toLatinDigits(qEl&&qEl.value||0):qEl&&qEl.value||0);if(!Number.isFinite(q)||q<0)return 'كمية إرجاع غير صالحة.';if(q>Number(src.items[i].qty||0)+F.EPS)return 'كمية الإرجاع تتجاوز الكمية المتبقية.';}
      return true;
    });
    g.__wsFinancialGuardInstalled=true;
  }
  install(); g.FinancialGuard=Object.freeze({install});
})(window);
