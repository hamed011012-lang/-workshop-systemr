/* v142 — durable receipt bridge using the repository contract.
 * No new receipt writes depend on localStorage. Legacy pending data is still
 * read for backward compatibility and is migrated into IndexedDB on flush.
 */
(function(g){'use strict';if(g.AppReceiptOffline)return;
 const QUEUE_TYPE='receipt.sync', legacyKey='ws_pending_receipt_writes_v1';
 const legacyRead=()=>{try{const x=JSON.parse(localStorage.getItem(legacyKey)||'[]');return Array.isArray(x)?x:[]}catch(_){return[]}};
 const legacyWrite=a=>{try{localStorage.setItem(legacyKey,JSON.stringify(a.slice(-100)));}catch(_){} };
 async function stage(item){
   if(!g.ReceiptRepository) throw new Error('مخزن الواصل المحلي غير جاهز');
   const operation=String(item&&item.payEntry&&(item.payEntry.clientOperationId||item.payEntry.id)||item&&item.id||'').trim();
   if(!operation) throw new Error('معرّف عملية الواصل مطلوب');
   await g.ReceiptRepository.put(item);
   if(g.AppOutbox&&typeof g.AppOutbox.enqueue==='function') g.AppOutbox.enqueue(QUEUE_TYPE,item,operation);
   if(g.AppAudit&&typeof g.AppAudit.record==='function') await g.AppAudit.record('receipt:staged',{id:item.id,operation});
   return true;
 }
 async function migrateLegacy(){
   const old=legacyRead(); if(!old.length||!g.ReceiptRepository)return [];
   const keep=[];
   for(const item of old){try{await stage(item);}catch(_){keep.push(item);}}
   legacyWrite(keep); return old.length-keep.length;
 }
 async function pending(){
   await migrateLegacy();
   return g.ReceiptRepository?g.ReceiptRepository.pending(1000):[];
 }
 async function markSynced(id){if(g.ReceiptRepository)await g.ReceiptRepository.markSynced(id);}
 async function remove(id){if(g.ReceiptRepository)await g.ReceiptRepository.remove(id);}
 g.AppReceiptOffline=Object.freeze({stage,pending,markSynced,remove,migrateLegacy});
})(window);
