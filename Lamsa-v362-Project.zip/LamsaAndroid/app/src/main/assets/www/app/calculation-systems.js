(function(g){'use strict';
const KEY='ws_calculation_systems_v1';
const names={pvc:'PVC',xtype_alum:'الألمنيوم',xtype_pvc_slide:'PVC سحاب',xtype_ser_normal:'سرانتي عادي',xtype_ser_out:'سرانتي خارجي',xtype_net_move:'ناموسية متحركة',xtype_net_fix:'ناموسية ثابتة',xtype_kitchen_skirt:'سكارات مطبخ'};
const kinds={constant:'قيمة ثابتة',area:'مساحة العرض × الارتفاع',max:'البعد الأكبر',w:'العرض',h:'الارتفاع',perimeter:'المحيط'};
const n=v=>g.WSSymbolFormulas.num(v);
function rule(x={}){return {lowW:0,lowH:0,maxW:0,maxH:0,inclusive:false,kind:'area',value:1,minW:0,minH:0,addW:0,addH:0,divisor:10000,step:0,round:'nearest',...x};}
function defaults(id){return /ser_|net_/.test(id)?[rule({minW:100,minH:100})]:[rule({maxW:50,maxH:50,kind:'constant',value:.5}),rule({maxW:70,maxH:70,kind:'max',divisor:100}),rule({maxW:100,maxH:100,inclusive:true,kind:'constant',value:1}),rule({minW:100,minH:100})];}
function normalize(d){
 if(!d||!/^[-\w]+$/.test(d.id)||['__proto__','constructor','prototype'].includes(d.id)||!String(d.name||'').trim()||!Array.isArray(d.rules)||!d.rules.length||d.rules.length>30)throw Error('اسم النظام وقواعده مطلوبة');
 const rules=d.rules.map(r=>{r=rule(r);for(const k of ['lowW','lowH','maxW','maxH','value','minW','minH','addW','addH','divisor','step']){r[k]=n(r[k]);if(!Number.isFinite(r[k])||Math.abs(r[k])>1000000)throw Error('رقم غير صالح في قواعد الأمتار');}
 if(r.divisor<=0||r.step<0||r.lowW<0||r.lowH<0||r.maxW<0||r.maxH<0||r.minW<0||r.minH<0||r.value<0||!Object.hasOwn(kinds,r.kind)||!['nearest','up','down'].includes(r.round))throw Error('راجع حدود القاعدة وطريقة الحساب');
 if((r.maxW&&r.maxW<r.lowW)||(r.maxH&&r.maxH<r.lowH))throw Error('الحد الأعلى أصغر من الأدنى');
 return r;});
 const last=rules[rules.length-1];if(last.lowW||last.lowH||last.maxW||last.maxH)throw Error('القاعدة الأخيرة يجب أن تغطي كل المقاسات: اترك حدود شرطها صفراً');
 if(d.cutProfile&&(!String(d.cutProfile).trim()||String(d.cutProfile).length>160||['__proto__','constructor','prototype'].includes(d.cutProfile)))throw Error('اسم نظام القص غير صالح');
 if(d.parentSystem&&(!/^[-\w]+$/.test(d.parentSystem)||d.parentSystem===d.id))throw Error('أصل النظام غير صالح');
 return {...(d.parentSystem?{parentSystem:d.parentSystem,inheritMeters:d.inheritMeters!==false}:{}),id:d.id,name:String(d.name).trim().slice(0,100),enabled:d.enabled!==false,rules,...(d.baseMaterial?{baseMaterial:String(d.baseMaterial)}:{}),...(d.cutProfile?{cutProfile:String(d.cutProfile)}:{})};
}
function all(){try{return JSON.parse(localStorage.getItem(KEY)||'[]').map(d=>{try{return normalize(d);}catch(e){return null;}}).filter(Boolean);}catch(e){return [];}}
function get(id){const list=all();if(!list.some(d=>d.id===id))return null;return g.WSEngine?g.WSEngine.systemFromList(id,list):list.find(d=>d.id===id);}
function save(d){d=normalize(d);const list=all().filter(x=>x.id!==d.id);if(list.some(x=>x.name===d.name)||Object.entries(names).some(([id,name])=>id!==d.id&&name===d.name))throw Error('اسم النظام مستخدم؛ اختر اسمًا مميزًا');list.push(d);localStorage.setItem(KEY,JSON.stringify(list));return d;}
function calculate(d,w,h){
 if(!d||d.enabled===false)return null;w=n(w);h=n(h);if(!(w>0&&h>0))return null;
 const r=d.rules.find(r=>w>=r.lowW&&h>=r.lowH&&(!r.maxW||(r.inclusive?w<=r.maxW:w<r.maxW))&&(!r.maxH||(r.inclusive?h<=r.maxH:h<r.maxH)));
 if(!r)return null;const W=Math.max(w+r.addW,r.minW),H=Math.max(h+r.addH,r.minH);
 if(!(W>0&&H>0))throw Error('زيادة/خصم الأمتار أنتج بعدًا غير موجب');
 let result=r.kind==='constant'?r.value:({area:W*H,max:Math.max(W,H),w:W,h:H,perimeter:2*(W+H)}[r.kind])/r.divisor;
 if(r.step)result=({up:Math.ceil,down:Math.floor,nearest:Math.round}[r.round])(Math.round(result/r.step*1e10)/1e10)*r.step;
 if(!Number.isFinite(result)||result<0)throw Error('نتيجة أمتار غير صالحة');return result.toFixed(2);
}
function importBundle(data,replace=false){
 if(data?.format!=='workshop-systems-v1'||!Array.isArray(data.systems)||!Array.isArray(data.bindings)||data.systems.length>1000||data.bindings.length>1000)throw Error('ملف أنظمة غير صالح');
 const systems=data.systems.map(normalize),bindings=data.bindings.map(g.WSSymbolFormulas.normalize);
 if(new Set(systems.map(x=>x.id)).size!==systems.length||new Set(bindings.map(x=>x.key)).size!==bindings.length)throw Error('معرّفات مكررة داخل الملف');
 const old=all(),oldBindings=g.WSSymbolFormulas.all();
 if(!replace&&(systems.some(d=>old.some(x=>x.id===d.id))||bindings.some(d=>oldBindings.some(x=>x.key===d.key))))throw Error('يوجد معرّف مستخدم؛ فعّل خيار تحديث الأنظمة القائمة إذا أردت استبداله');
 const nextSystems=old.filter(x=>!systems.some(d=>d.id===x.id)).concat(systems),nextBindings=oldBindings.filter(x=>!bindings.some(d=>d.key===x.key)).concat(bindings);
 const previous={systems:localStorage.getItem(KEY),bindings:localStorage.getItem('ws_symbol_formulas_v1')};
 localStorage.setItem('ws_systems_import_backup',JSON.stringify(previous));
 try{localStorage.setItem(KEY,JSON.stringify(nextSystems));localStorage.setItem('ws_symbol_formulas_v1',JSON.stringify(nextBindings));}
 catch(e){for(const [k,v] of [[KEY,previous.systems],['ws_symbol_formulas_v1',previous.bindings]]){if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v);}throw e;}
 return {systems:systems.length,bindings:bindings.length};
}
function customTypes(){return all().filter(d=>d.id.startsWith('sys_')).map(d=>({id:d.id,name:d.name,color:'#336677',icon:'fa-shapes',calc:/ser_|net_/.test(d.baseMaterial||'')?'ser':'pvc'}));}
function el(t,text){const e=document.createElement(t);if(text!=null)e.textContent=text;return e;}
function field(parent,label,value){const box=el('label',label),i=el('input');box.style.cssText='display:grid;gap:3px;font-size:12px';i.value=value;i.style.width='105px';box.append(i);parent.append(box);return i;}
function open(){
 if(!g.WSCanManageSystems){alert('إدارة أنظمة الحساب من حساب المدير');return;}
 const dlg=el('dialog');dlg.dir='rtl';dlg.style.cssText='width:min(1000px,94vw);max-height:92vh;overflow:auto;border-radius:16px;padding:20px;font-family:inherit';
 dlg.append(el('h2','أنظمة الأمتار ومعادلات الرموز'),el('p','التعديلات محلية على هذا المتصفح. المقاسات المحفوظة تحتفظ بنتائجها؛ القواعد الجديدة تستخدم عند الإدخال أو إعادة حساب مقاس. صدّر الأنظمة لنقلها لجهاز آخر.'));
 const pick=el('select');Object.entries(names).forEach(([id,t])=>pick.add(new Option(t,id)));customTypes().forEach(d=>pick.add(new Option(d.name,d.id)));dlg.append(pick);
 const newBtn=el('button','+ نظام جديد بالكامل');newBtn.type='button';dlg.append(newBtn);
 const name=field(dlg,'اسم النظام','');name.style.width='100%';const enabled=el('input');enabled.type='checkbox';const enabledLabel=el('label',' تفعيل قواعد الأمتار المخصصة ');enabledLabel.prepend(enabled);dlg.append(enabledLabel);
 dlg.append(el('p','تُطبق أول قاعدة مطابقة من الأعلى. شروط العرض والارتفاع معًا. صفر في الحد الأعلى يعني بلا حد. القسمة: 10000 لتحويل سم² إلى م²، و100 لتحويل سم إلى متر. التقريب صفر يعني دون خطوة إضافية.'));
 const list=el('div');dlg.append(list);let current=pick.value;
 function row(data){const box=el('fieldset');box.style.cssText='display:flex;flex-wrap:wrap;gap:9px;margin:10px 0';const controls={};
 for(const [k,t] of [['lowW','شرط عرض من'],['maxW','شرط عرض أقل من'],['lowH','شرط ارتفاع من'],['maxH','شرط ارتفاع أقل من'],['minW','أقل عرض محاسبي'],['minH','أقل ارتفاع محاسبي'],['addW','زيادة/خصم العرض'],['addH','زيادة/خصم الارتفاع'],['value','القيمة الثابتة'],['divisor','القسمة على'],['step','خطوة التقريب']])controls[k]=field(box,t,data[k]);
 const incl=el('input');incl.type='checkbox';incl.checked=data.inclusive;const il=el('label',' شمول الحد الأعلى');il.prepend(incl);box.append(il);controls.inclusive=incl;
 for(const [k,opts] of [['kind',kinds],['round',{nearest:'الأقرب',up:'تقريب أعلى',down:'تقريب أسفل'}]]){const sel=el('select');Object.entries(opts).forEach(([v,t])=>sel.add(new Option(t,v)));sel.value=data[k];box.append(sel);controls[k]=sel;}
 const up=el('button','أعلى'),down=el('button','أسفل'),del=el('button','حذف');up.type=down.type=del.type='button';up.onclick=()=>{if(box.previousElementSibling)list.insertBefore(box,box.previousElementSibling);};down.onclick=()=>{if(box.nextElementSibling)list.insertBefore(box.nextElementSibling,box);};del.onclick=()=>box.remove();box.append(up,down,del);box.controls=controls;list.append(box);}
 function load(){current=pick.value;const d=get(current)||{name:names[current]||'نظام جديد',enabled:false,rules:defaults(current)};name.value=d.name;enabled.checked=d.enabled;list.replaceChildren();d.rules.forEach(row);}
 pick.onchange=load;newBtn.onclick=()=>{const id='sys_'+Date.now();pick.add(new Option('نظام جديد',id));pick.value=id;load();enabled.checked=true;};load();
 const add=el('button','+ قاعدة');add.type='button';add.onclick=()=>row(rule());const reset=el('button','استعادة القواعد الأصلية');reset.type='button';reset.onclick=()=>{list.replaceChildren();defaults(current).forEach(row);enabled.checked=true;};dlg.append(add,reset);
 const info=el('pre');info.style.whiteSpace='pre-wrap';const testBox=el('div');testBox.style.cssText='display:flex;gap:10px';const w=field(testBox,'عرض تجربة',120),h=field(testBox,'ارتفاع تجربة',150);const test=el('button','معاينة الحساب');test.type='button';testBox.append(test);dlg.append(testBox,info);
 function read(){return normalize({...((get(current)?.parentSystem)?{parentSystem:get(current).parentSystem,inheritMeters:get(current).inheritMeters}:{}),id:current,name:name.value,enabled:enabled.checked,...(get(current)?.baseMaterial?{baseMaterial:get(current).baseMaterial}:{}),...(get(current)?.cutProfile?{cutProfile:get(current).cutProfile}:{}),rules:Array.from(list.children).map(b=>Object.fromEntries(Object.entries(b.controls).map(([k,v])=>[k,k==='inclusive'?v.checked:v.value])))});}
 test.onclick=()=>{try{info.textContent='الناتج: '+(calculate({...read(),enabled:true},w.value,h.value)??'مقاس غير صالح');}catch(e){info.textContent=e.message;}};
 const saveBtn=el('button','حفظ نظام الأمتار');saveBtn.type='button';saveBtn.onclick=()=>{try{save(read());info.textContent='تم حفظ النظام. افتح كراسة القياسات من جديد لتظهر الإعدادات الجديدة.';Array.from(pick.options).find(o=>o.value===current).textContent=name.value;}catch(e){info.textContent='لم يُحفظ: '+e.message;}};dlg.append(saveBtn);
 const eq=el('button','إضافة / تعديل معادلة رمز لهذا النظام');eq.type='button';eq.onclick=()=>{try{save(read());const sd=el('dialog');sd.dir='rtl';const symbols=el('select');g.WSOpeningSymbols.catalog.filter(x=>(get(current)?.baseMaterial||current)==='xtype_kitchen_skirt'?x.group==='kitchen':x.group!=='kitchen').forEach(x=>symbols.add(new Option(x.label,x.id)));const go=el('button','فتح المعادلة'),close=el('button','إغلاق');go.onclick=()=>{const symbol=symbols.value;sd.close();sd.remove();g.WSSymbolFormulas.open(current,symbol);};close.onclick=()=>{sd.close();sd.remove();};sd.append(el('h3','اختر الرمز'),symbols,go,close);document.body.append(sd);sd.showModal();}catch(e){info.textContent=e.message;}};dlg.append(eq);
 const profiles=el('a','إدارة أنظمة معادلات القص القائمة');profiles.href='cutting.html?manageProfiles=1';profiles.style.cssText='display:block;margin:15px 0';dlg.append(profiles);
 const exportBtn=el('button','تنزيل الملف الكامل للأمتار ومعادلات القص'),importInput=el('input');exportBtn.type='button';importInput.type='file';importInput.accept='.json';importInput.setAttribute('aria-label','استيراد أنظمة ومعادلات رموز');
 exportBtn.onclick=()=>{try{const data=g.WSFullSystemFile.exportFile();const a=el('a');const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json;charset=utf-8'}));a.href=url;a.download='workshop-full-system.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);fileStatus.textContent='تم تنزيل جميع قواعد الأمتار وبروفايلات القص ومعادلات الرموز في ملف واحد.';}catch(e){fileStatus.textContent='تعذر التنزيل: '+e.message;}};
 const importMode=el('select');importMode.add(new Option('إضافة نسخة جديدة — إبقاء الحالي','new'));importMode.add(new Option('استبدال الأنظمة الموجودة في الملف','replace'));importMode.setAttribute('aria-label','طريقة استيراد النظام');
 const copyName=el('input');copyName.value='نسخة مستوردة';copyName.placeholder='اسم النسخة الجديدة';copyName.setAttribute('aria-label','اسم النسخة الجديدة');
 const fileStatus=el('p');fileStatus.setAttribute('aria-live','polite');
 importInput.onchange=async()=>{try{const file=importInput.files[0];if(!file)return;if(file.size>10*1024*1024)throw Error('حد الملف 10 ميجابايت');const data=JSON.parse(await file.text());
 if(data.format==='workshop-systems-v1'){const r=importBundle(data,importMode.value==='replace');fileStatus.textContent='استُورد ملف الصيغة القديمة: '+r.systems+' نظام؛ لا يحتوي بروفايلات القص الكاملة.';return;}
 const check=g.WSFullSystemFile.importFile(data,importMode.value,copyName.value,true);
 if(!confirm((importMode.value==='new'?'إضافة نسخ جديدة':'تحديث الأنظمة الحالية')+' تشمل '+check.systems+' نظام أمتار و'+check.profiles+' نظام قص و'+check.bindings+' معادلة رمز. متابعة؟'))return;
 const result=g.WSFullSystemFile.importFile(data,importMode.value,copyName.value);fileStatus.textContent='تم الاستيراد: '+result.systems+' نظام أمتار، '+result.profiles+' نظام قص، '+result.bindings+' معادلة رمز. أغلق النافذة وأعد فتحها لعرضها.';
 }catch(e){fileStatus.textContent='لم يتم الاستيراد: '+e.message;}finally{importInput.value='';}};
 dlg.append(exportBtn,importInput);const close=el('button','إغلاق');close.type='button';close.onclick=()=>{dlg.close();dlg.remove();};dlg.append(close);
 const localEditor=el('details');const localTitle=el('summary','التعديل داخل التطبيق — اختياري');localTitle.style.cssText='cursor:pointer;padding:14px;font-weight:bold';localEditor.append(localTitle);
 for(const child of Array.from(dlg.children).slice(2)){if(![exportBtn,importInput,close].includes(child))localEditor.append(child);}
 const files=el('section');files.style.cssText='padding:16px;border:1px solid #cbd5e1;border-radius:12px;display:grid;gap:12px';
 files.append(el('h3','ملف واحد لكل أنظمة الحساب'),el('p','1. نزّل ملف JSON الكامل. 2. عدّل القواعد والمعادلات في الملف. 3. اختر إضافة نسخة جديدة أو استبدال الحالي ثم ارفع الملف. معادلات القص الأصلية موجودة أيضًا، حتى قبل إجراء أي تخصيص.'),exportBtn,el('label','طريقة إعادة الرفع'),importMode,copyName,importInput,fileStatus);
 dlg.insertBefore(files,close);dlg.insertBefore(localEditor,close);document.body.append(dlg);dlg.showModal();
}
g.WSSystems=Object.freeze({all,get,save,defaults,normalize,calculate,customTypes,importBundle,open});
})(window);
