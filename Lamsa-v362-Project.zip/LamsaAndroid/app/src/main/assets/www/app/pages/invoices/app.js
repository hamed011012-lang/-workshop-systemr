
// حارس: بلا هذا كان فشل تحميل lucide (أول فتح دون اتصال) يوقف بقية السكربت كلياً
if (typeof lucide !== 'undefined') refreshIcons(); else window.lucide = { createIcons(){}, };

let selectedRetMethod = 'استرداد نقدي'; // الخيار المحدد لطريقة الإرجاع

// ============================================================
// HELPERS
// ============================================================
// r2: تقريب مالي دقيق لأقرب قرش (رقمين عشريين).
// ملاحظة هامة: الاعتماد على Math.round(v*100)/100 وحدها غير كافٍ إطلاقاً، لأن جافاسكريبت
// يخزّن الأعداد العشرية بصيغة ثنائية تقريبية، فمثلاً 35.855 قد تُخزَّن فعلياً كـ 35.85499999999999...
// وهذا يجعل قيمة مثل 35.855 تُقرَّب خطأً إلى 35.85 بدلاً من 35.86. لذلك نضيف هامش تصحيح دقيق جداً
// (1e-9) في الاتجاه الصحيح قبل التقريب لضمان أن كل .x5 تُقرَّب لأعلى كما هو متوقع حسابياً، وهذا يضمن
// دقة مطلقة في كل حسابات الفواتير والمخزون والديون والمدفوعات مهما تعددت وتكررت عمليات الجمع والطرح والضرب.
/* تحويل الأرقام العربية والفارسية إلى لاتينية قبل أي حساب.
   بدونه كان إدخال «١٠٠» في خانة الخصم أو مبلغ السداد يُقرأ صفراً بلا أي
   تنبيه — أي أن الخصم يُهمَل والمبلغ يُرفض والمستخدم لا يفهم السبب. */
/* إصلاح 8.8: صارت غلافاً على wsToLatinDigits في shared.js — نسخة واحدة
   لكل الصفحات بدل ثلاث متفاوتة (والقص لم يكن فيه شيء إطلاقاً). وأُضيف
   حذف محارف الاتجاه غير المرئية التي تأتي مع اللصق من واتساب، وكانت
   تُبقي «١٠٠» الملصوقة NaN حتى بعد تحويل الأرقام. */
function toLatinDigits(v) {
  if (typeof v !== 'string') return v;
  return (typeof wsToLatinDigits === 'function') ? wsToLatinDigits(v) : v;
}
window.toLatinDigits = toLatinDigits;

const r2 = v => {
  v = +toLatinDigits(v);
  if (Number.isNaN(v)) return NaN;      // نحافظ على NaN كما هي لتعمل فحوصات isNaN() في باقي الكود بشكل صحيح
  if (!isFinite(v)) return v;           // Infinity/-Infinity (حالة نادرة جداً) تُعاد كما هي دون كسر الحساب
  const eps = v >= 0 ? 1e-9 : -1e-9;    // هامش أمان أصغر بكثير من أي فرق مالي حقيقي (أقل من جزء من مليون جنيه)
  return Math.round((v + eps) * 100) / 100;
};
// fmt: يقرب لرقمين عشريين، ويحذف الأصفار الزائدة بعد العلامة العشرية
function fmt(v) {
  const n = r2(v);
  if (Number.isInteger(n)) return String(n);
  let s = n.toFixed(2);
  if (s.endsWith('0')) s = s.slice(0, -1);
  return s;
}

// ============================================================
// DATABASE — Firestore، مع مزامنة لحظية بين كل المستخدمين المصرّح لهم
// ============================================================
let DB = {
  store: [], sales: [], expenses: [], payments: [], trash: [], returns: [],
  collections: [], editedInvoicesLog: [], creditBalances: {},
  settings: { name:'اللمسة الاخيرة', tagline:'مطابخ PVC سرانتي ناموسيات', phone:'0924203966', footer:'' }
};

const RECORD_COLLECTIONS = ['store','sales','expenses','payments','trash','returns','collections','editedInvoicesLog'];

function _sortKey(rec) {
  if (typeof rec.timestamp === 'number') return rec.timestamp;
  if (typeof rec.deletedAt === 'number') return rec.deletedAt;
  const m = /-(\d+)$/.exec(rec.id || '');
  return m ? parseInt(m[1], 10) : 0;
}

// يشترك بمجموعة Firestore ويُبقي DB[dbKey] كمصفوفة محدَّثة لحظياً من كل الأجهزة/المستخدمين
// v247: سجل واحد فقط لكل مجموعة؛ منع تكرار onSnapshot كان مهماً للاستقرار على الهاتف.
const _attachedRecordSync = new Set();
const _pendingRecordSync = new Map();
function attachRecordCollectionSync(dbKey) {
  if (_attachedRecordSync.has(dbKey)) return Promise.resolve(false);
  if (_pendingRecordSync.has(dbKey)) return _pendingRecordSync.get(dbKey);
  const promise = new Promise(resolve => {
    let firstSnapshot = true;
    const unsub = db.collection(dbKey).onSnapshot(snapshot => {
    const arr = [];
    snapshot.forEach(doc => arr.push({ id: doc.id, ...doc.data() }));
    arr.sort((a,b) => _sortKey(a) - _sortKey(b));
    DB[dbKey] = arr;
    if (dbKey === 'sales' && window.InvoiceRepository && typeof window.InvoiceRepository.migrateLegacy === 'function') {
      window.InvoiceRepository.migrateLegacy(arr).catch(e => { if (typeof wsSilent === 'function') wsSilent('invoices:repository:migrate', e); });
    }
    /* ══ كان هنا شرط بلا جسم: `if (dbKey === 'trash')` يليه سطر
       renderAllSections() — فصار الرسم **جسماً للشرط**، ولا يُنفَّذ إلا
       عند وصول تحديث لسلة المحذوفات وحدها.

       الأثر: كل بقية المجموعات (الفواتير، المقبوضات، المخزن، المصروفات،
       المرتجعات، التحصيلات) تصل بياناتها وتُخزَّن في DB لكن الشاشة لا
       تُعيد الرسم. فيسجّل زميلك فاتورة ولا تراها أنت، ويُخصم من المخزن
       ولا يتغيّر الرقم أمامك — حتى يقع تحديث في السلة أو الأرصدة أو
       الإعدادات صدفةً فتظهر كلها دفعةً واحدة.
       أي أن العمل المشترك اللحظي كان معطّلاً عملياً. */
    if (firstSnapshot) {
      firstSnapshot = false;
      _attachedRecordSync.add(dbKey);
      _pendingRecordSync.delete(dbKey);
      resolve(true);
    }
    renderAllSections();
  }, err => {
    console.error('sync error:', dbKey, err);
    _pendingRecordSync.delete(dbKey);
    showFsErrorToast(fsErrorMessage(err, dbKey));
    resolve(false);
  });
  });
  _firestoreUnsubscribers.push(() => {
    try { unsub(); } catch (_) {}
    _attachedRecordSync.delete(dbKey);
    _pendingRecordSync.delete(dbKey);
  });
  _pendingRecordSync.set(dbKey, promise);
  return promise;
}

let _creditSyncAttached = false;
let _creditSyncPromise = null;
function attachCreditBalancesSync() {
  if (_creditSyncAttached) return Promise.resolve(true);
  if (_creditSyncPromise) return _creditSyncPromise;
  _creditSyncPromise = new Promise(resolve => {
  _creditSyncAttached = true;
  const unsub = db.collection('creditBalances').onSnapshot(snapshot => {
    const obj = {};
    snapshot.forEach(doc => {
      /* ⚠️ إصلاح 8.8: كان decodeURIComponent مكشوفاً. مستند واحد بمعرّف
         فيه % شاذّة يرمي URIError **داخل** دالة المستمع، فتتوقف مزامنة
         الأرصدة كلياً — لا هذا السجل ولا أي سجل بعده — والشاشة تبدو
         طبيعية. الآن: السجل التالف وحده يُتخطّى ويُسجَّل، والبقية تمرّ. */
      let key;
      try { key = decodeURIComponent(doc.id); }
      catch (e) { wsSilent('invoices:creditBalances:id', new Error('معرّف رصيد تالف: ' + doc.id)); return; }
      const raw = doc.data() ? doc.data().amount : undefined;
      const num = Number(raw);
      if (!isFinite(num)) {
        wsSilent('invoices:creditBalances:val', new Error('رصيد غير رقمي لـ ' + key + ': ' + raw));
        return;
      }
      obj[key] = num;
    });
    DB.creditBalances = obj;
    _creditSyncReady = true;   // وصلت أول لقطة: الكتابة المطلقة صارت آمنة
    renderAllSections();
  }, err => { console.error('sync error: creditBalances', err); showFsErrorToast(fsErrorMessage(err, 'أرصدة العملاء')); });
  _firestoreUnsubscribers.push(() => { try { unsub(); } catch (_) {} _creditSyncAttached = false; _creditSyncPromise = null; });
  resolve(true);
  });
  return _creditSyncPromise;
}

let _settingsSyncAttached = false;
let _settingsSyncPromise = null;
function attachSettingsSync() {
  if (_settingsSyncAttached) return Promise.resolve(true);
  if (_settingsSyncPromise) return _settingsSyncPromise;
  _settingsSyncPromise = new Promise(resolve => {
  const unsub = db.collection('meta').doc('settings').onSnapshot(doc => {
    DB.settings = doc.exists ? doc.data() : (typeof DEFAULT_SETTINGS !== 'undefined' ? DEFAULT_SETTINGS : { name:'اللمسة الاخيرة', tagline:'مطابخ PVC سرانتي ناموسيات', phone:'0924203966', footer:'' });
    renderAllSections();
    if (typeof applySettings === 'function') applySettings();
  }, err => { console.error('sync error: settings', err); showFsErrorToast(fsErrorMessage(err, 'إعدادات المتجر')); });
  _firestoreUnsubscribers.push(() => { try { unsub(); } catch (_) {} _settingsSyncAttached = false; _settingsSyncPromise = null; });
  _settingsSyncAttached = true;
  resolve(true);
  });
  return _settingsSyncPromise;
}

async function attachAllFirestoreListeners(options = {}) {
  // v247: لا تفتح كل مجموعات Firestore الثقيلة عند دخول صفحة الفواتير.
  // البيانات الأساسية تُحمّل أولاً، والأقسام الثقيلة عند فتحها فقط.
  try { await window.wsReady; } catch (e) {}
  const core = ['store','sales','payments','returns'];
  for (const k of core) await attachRecordCollectionSync(k);
  await attachCreditBalancesSync();
  await attachSettingsSync();

  if (isAdmin()) {
    const unsubMembers = db.collection('members').onSnapshot(snapshot => {
      _membersCache = snapshot.docs.map(d => ({ uid: d.id, ...d.data() }));
      _membersCache.sort((a, b) => {
        const ta = a.addedAt && a.addedAt.toMillis ? a.addedAt.toMillis() : (Number(a.addedAt) || 0);
        const tb = b.addedAt && b.addedAt.toMillis ? b.addedAt.toMillis() : (Number(b.addedAt) || 0);
        return (tb - ta) || String(a.name || a.email || '').localeCompare(String(b.name || b.email || ''), 'ar');
      });
      renderMembersListUI();
    }, err => { console.error('sync error: members', err); showFsErrorToast(fsErrorMessage(err, 'قائمة الأعضاء')); });
    _firestoreUnsubscribers.push(unsubMembers);
  }

  // الخيارات الثقيلة لا تُفتح إلا عند طلب القسم فعلياً.
  if (options.all) {
    for (const k of ['expenses','trash','collections','editedInvoicesLog']) {
      if (k === 'editedInvoicesLog' && !isAdmin()) continue;
      await attachRecordCollectionSync(k);
    }
  }
}

// إتاحة صريحة للملف auth.js الذي قد يكتمل قبل هذا الملف في بعض ظروف التحميل.
window.attachAllFirestoreListeners = attachAllFirestoreListeners;

// ===== أدوات كتابة عامة إلى Firestore (تُستخدم بدل التعديل المباشر على localStorage) =====
// رسالة خطأ واضحة بالعربية حسب سبب فشل المزامنة (انقطاع نت / نقص صلاحية / غير ذلك)
// بدون هذا، أي فشل مزامنة صامت (خصوصاً لعضو غير مشرف) قد يُخفي فاتورة أو دين أو سداد عن بقية الأعضاء دون أن يظهر أي تنبيه واضح
function _fsErrorMessage(e, label) {
  const code = e && e.code;
  if (!navigator.onLine || code === 'unavailable') {
    return '🔴 لا يوجد اتصال بالإنترنت — لم تُحفظ هذه العملية بعد على السيرفر (' + label + ').\nستبقى الآن على جهازك فقط، فلا تُغلق التطبيق ولا تخرج من الحساب قبل التأكد من عودة الاتصال ومزامنتها.';
  }
  if (code === 'permission-denied') {
    return '⛔ لا توجد صلاحية كافية لحفظ هذه العملية (' + label + '). تواصل مع المشرف الأساسي.';
  }
  return '⚠️ تعذّرت مزامنة البيانات (' + label + '):\n' + e.message;
}
/* ============================================================
   الكتابة إلى قاعدة البيانات — لا تنتظر السيرفر إطلاقاً
   ------------------------------------------------------------
   كانت هذه الدوال تنتظر تأكيد السيرفر (await)، وأثناء انقطاع الإنترنت
   لا يصل هذا التأكيد أبداً، فتتوقف السلسلة عند أول كتابة ولا تُسجَّل
   الكتابات التي بعدها (الدفعات، تحديث ديون الفواتير الأخرى…) ولو محلياً،
   فتضيع نهائياً إن أُغلق التطبيق قبل عودة الشبكة.
   الآن: تُسجَّل كل كتابة فوراً في مخزن الجهاز وتعود الدالة مباشرة،
   ويتولّى Firestore رفعها تلقائياً عند عودة الاتصال — حتى بعد إغلاق
   التطبيق وإعادة فتحه. والأخطاء تظهر كإشعار خفيف بدل نافذة تقطع العمل.
   ============================================================ */
function _fsTrack(promise, label) {
  if (typeof _wsTrack === 'function') return _wsTrack(promise, label);   // العدّاد المشترك في shared.js
  return promise.catch(e => {
    if (navigator.onLine) {
      const m = _fsErrorMessage(e, label);
      if (typeof showFsErrorToast === 'function') showFsErrorToast(m); else console.error(m);
    }
    throw e;
  });
}
/* fsSet / fsAdd / fsUpdate / fsDelete تأتي من shared.js — مصدر واحد لا نسختان.
   كان تكرارها هنا يحجب النسخة المشتركة، فأي إصلاح فيها لا يصل هذه الصفحة. */
/* ⚠️ إصلاح 8.8 — ثلاث مشاكل في سطر واحد:
   ١) `.set()` بلا merge يمسح بقية حقول المستند. وصفحة القياسات تكتب
      حقل `name` مع كل زيادة رصيد (fsMergeIncrement)، فكانت كل كتابة
      من صفحة الفواتير تمحوه.
   ٢) لا تحقّق من القيمة: NaN أو Infinity من أي حساب مكسور تُكتب في
      السيرفر فيتلوّث الرصيد لدى كل الأجهزة.
   ٣) كتابة قيمة مطلقة قبل وصول أول لقطة تعني اشتقاق الرصيد من DB.sales
      وهي لا تزال [] — أي كتابة صفر فوق رصيد حقيقي (يحرسه _creditSyncReady). */
function fsSetCredit(name, amount) {
  const amt = Number(amount);
  if (!isFinite(amt) || amt < 0) {
    wsSilent('invoices:fsSetCredit', new Error('قيمة رصيد غير صالحة لـ ' + name + ': ' + amount));
    return Promise.resolve(false);
  }
  _fsTrack(
    db.collection('creditBalances').doc(encodeURIComponent(name))
      .set({ amount: r2(amt), name: name, updatedAt: Date.now() }, { merge: true }),
    'رصيد العميل'
  ).catch(() => {});
  return Promise.resolve(true);
}
function fsDeleteCredit(name) {
  _fsTrack(db.collection('creditBalances').doc(encodeURIComponent(name)).delete(), 'رصيد العميل').catch(() => {});
  return Promise.resolve(true);
}
// تُزامن رصيد عميل واحد بالكامل حسب القيمة الحالية في DB.creditBalances (تضيف أو تحذف حسب الحاجة)
/* حارس الجاهزية: لا نكتب قيمة مطلقة مشتقّة قبل أن تصل بيانات الفواتير
   والدفعات فعلاً. بدونه أي مسار يمسّ الرصيد في الثواني الأولى بعد فتح
   الصفحة يشتقّه من مصفوفات فارغة ويكتب النتيجة فوق الرصيد الحقيقي. */
let _creditSyncReady = false;

async function syncCreditBalance(name) {
  if (!_creditSyncReady) {
    wsSilent('invoices:syncCreditBalance', new Error('تجاهُل مزامنة رصيد قبل اكتمال أول تحميل: ' + name));
    return;
  }
  const val = DB.creditBalances[name];
  if (val === undefined) await fsDeleteCredit(name);
  else await fsSetCredit(name, val);
}

function saveDB() {
  renderAllSections();
  /* v143: مرآة محلية خفيفة للفواتير. لا ننتظر IndexedDB ولا نربط نجاح
     الحفظ بعملية المزامنة؛ الواجهة تستمر فوراً، والمستودع يكتب فقط ما تغيّر. */
  try {
    if (window.InvoiceRepository && typeof window.InvoiceRepository.scheduleMirror === 'function') {
      window.InvoiceRepository.scheduleMirror(DB.sales);
    }
    if (window.CustomerRepository && typeof window.CustomerRepository.scheduleMirror === 'function') {
      window.CustomerRepository.scheduleMirror();
    }
    if (window.DebtRepository && typeof window.DebtRepository.scheduleMirror === 'function') {
      window.DebtRepository.scheduleMirror();
    }
    if (window.InventoryRepository && typeof window.InventoryRepository.mirrorAll === 'function' && Array.isArray(DB.store)) {
      Promise.resolve().then(() => window.InventoryRepository.mirrorAll(DB.store)).catch(e => { if (typeof wsSilent === 'function') wsSilent('inventory:repository', e); });
    }
    if (window.AppEvents && typeof window.AppEvents.emit === 'function') {
      window.AppEvents.emit('invoices:db-changed', { sales: Array.isArray(DB.sales) ? DB.sales.length : 0, payments: Array.isArray(DB.payments) ? DB.payments.length : 0, at: Date.now() });
    }
  } catch (e) { if (typeof wsSilent === 'function') wsSilent('invoices:repository', e); }
}

/* ============================================================
   سلة محذوفات الفواتير — لا حذف تلقائي إطلاقاً
   ------------------------------------------------------------
   كانت السلة تمحو نفسها تلقائياً بعد 90 يوماً: فواتير ودفعات ومصروفات
   محذوفة تختفي نهائياً بلا إشعار ولا أثر. وهذه سجلات مالية، وقد تُطلب
   بعد سنة في مراجعة أو خلاف مع عميل. فأُلغي المحو التلقائي نهائياً.

   ⚠️ إصلاح 8.8 — رفع قفل الـ90 يوماً:
   بعد إلغاء المحو التلقائي بقي قفلٌ يمنع **المدير نفسه** من المحو قبل
   مرور 90 يوماً. وهذا يخالف ثلاثة مواضع أخرى: تعليق هذه الدالة نفسها،
   وقواعد Firestore (allow delete: if isManager())، وسلة الكراسات في
   measurements.html التي أُلغيت مهلتها بطلب المالك. فكان لسلّتين في
   نظام واحد سلوكان مختلفان، والتعليق يناقض الكود فوقه.

   الآن: السياستان متطابقتان — لا محو تلقائي، والمحو النهائي بيد المدير
   متى شاء وبتأكيد صريح. والضمانة الباقية أن الحذف من الأرشيف ينقل إلى
   السلة ولا يمحو، فلا شيء يُفقد بضغطة عابرة.
   ============================================================ */

function trashAgeDays(item) {
  return Math.floor((Date.now() - (item.deletedAt || 0)) / 86400000);
}

function purgeTrashItem(idx) {
  if (!isManager()) { alert('⛔ الحذف النهائي متاح للمدير فقط.'); return; }
  const t = DB.trash[idx];
  if (!t) return;
  const desc = t.payload && (t.payload.id || t.payload.name || t.payload.title) || '';
  if (!confirm('⚠️ حذف «' + t.type + ' — ' + desc + '» نهائياً؟\n\nلا رجعة في هذا الحذف.')) return;
  if (!confirm('تأكيد أخير: امحُ هذا السجل نهائياً؟')) return;
  DB.trash.splice(idx, 1);
  saveDB();
  showSuccessToast('تم الحذف النهائي.');
  fsDelete('trash', t.id).catch(() => {});
}

// ============================================================
// NAV
// ============================================================
// بيانات كل قسم (الأيقونة والعنوان) — تُعرض في رأس اللوحة المنبثقة
const SECTION_META = {
  pos:        { icon: '\uD83E\uDDFE', title: 'إصدار فاتورة جديدة' },
  sales:      { icon: '\uD83D\uDCCB', title: 'أرشيف المبيعات' },
  debts:      { icon: '\u26A0\uFE0F', title: 'الديون' },
  credits:    { icon: '\uD83D\uDCB0', title: 'أرصدة العملاء' },
  returns:    { icon: '\u21A9\uFE0F', title: 'فواتير الإرجاع' },
  expenses:   { icon: '\uD83D\uDCB8', title: 'المصروفات' },
  store:      { icon: '\uD83D\uDCE6', title: 'المخزن' },
  inventory:  { icon: '\uD83D\uDCCA', title: 'لوحة الجرد' },
  salesaudit: { icon: '\uD83E\uDDEE', title: 'جرد الكميات المباعة' },
  editedinv:  { icon: '\uD83D\uDD53', title: 'الفواتير الأصلية المعدّلة' },
  payments:   { icon: '\uD83D\uDCB3', title: 'سجل المدفوعات' },
  search:     { icon: '\uD83D\uDD0D', title: 'البحث الشامل' },
  trash:      { icon: '\uD83D\uDDD1\uFE0F', title: 'سلة المهملات' },
  backup:     { icon: '\uD83D\uDCBE', title: 'النسخ الاحتياطي' }
};

let _activeSection = null;

/* ============================================================
   صلاحيات التعديل والحذف
   - المدير: يعدّل ويحذف أي شيء بلا أي قيد زمني.
   - بقية الأعضاء: يعدّلون فواتيرهم هم فقط، وخلال ساعتين من إصدارها.
     فاتورة عضو آخر مقفولة عليهم من أول لحظة مهما كان وقتها.
   ============================================================ */
const EDIT_WINDOW_MS = 2 * 60 * 60 * 1000;   // ساعتان

function isManager() { return getCurrentUserRole() === 'manager'; }
function getCurrentUserUid() { return _currentUser ? _currentUser.uid : ''; }

/* هل أصدر المستخدم الحالي هذه الفاتورة بنفسه؟
   نعتمد المعرّف (uid) لأنه لا يتكرر ولا يتغيّر بتغيّر الاسم،
   ومع الفواتير القديمة التي لا تحمل معرّفاً نرجع لمقارنة اسم الموقّع. */
function isOwnInvoice(inv) {
  if (!inv || !_currentUser) return false;
  if (inv.signedByUid) return inv.signedByUid === _currentUser.uid;
  return !!inv.signedBy && inv.signedBy === _currentUser.name;
}

// الوقت المرجعي للفاتورة: نعتمد timestamp، وإن غاب نستخرجه من رقم الفاتورة INV-<ms>
/* ============================================================
   تحويل تاريخ خانة الإدخال إلى توقيت الجهاز المحلي
   ------------------------------------------------------------
   الخلل الذي يعالجه: خانة <input type="date"> تعطي نصاً بصيغة
   YYYY-MM-DD، و new Date('2026-08-01') يفسّرها المعيار على أنها
   **منتصف ليل بتوقيت غرينتش** لا بتوقيت الجهاز. وبفارق ساعتين (ليبيا
   ومصر) ينزاح مدى التقرير كله:

     تقرير «1 → 31 أغسطس» يبدأ فعلياً 1 أغسطس الساعة 2:00 صباحاً
     وينتهي 1 سبتمبر الساعة 1:59 صباحاً.

   فتختفي من التقرير فواتير أول يوم بين منتصف الليل والثانية، وتدخل فيه
   فواتير اليوم التالي للشهر في نفس النافذة. أي أن الجرد الشهري يخطئ في
   طرفيه، بمقدار فرق التوقيت، بلا أن يظهر ذلك في أي مكان.
   ============================================================ */
function dayStartTs(v) {
  if (!v) return null;
  const p = String(v).split('-').map(Number);
  if (p.length !== 3 || p.some(isNaN)) return null;
  return new Date(p[0], p[1] - 1, p[2], 0, 0, 0, 0).getTime();
}
function dayEndTs(v) {
  if (!v) return null;
  const p = String(v).split('-').map(Number);
  if (p.length !== 3 || p.some(isNaN)) return null;
  return new Date(p[0], p[1] - 1, p[2], 23, 59, 59, 999).getTime();
}

function invoiceTime(inv) {
  if (!inv) return 0;
  if (inv.timestamp) return inv.timestamp;
  const m = String(inv.id || '').match(/INV-(\d+)/);
  return m ? parseInt(m[1], 10) : 0;
}

function editWindowLeftMs(inv) {
  const t = invoiceTime(inv);
  if (!t) return 0;
  return EDIT_WINDOW_MS - (Date.now() - t);
}

function canEditInvoice(inv) {
  if (isManager()) return true;              // المدير: كل شيء مسموح
  if (!isOwnInvoice(inv)) return false;      // فاتورة عضو آخر: ممنوعة تماماً
  return editWindowLeftMs(inv) > 0;          // فاتورته هو: خلال ساعتين فقط
}

// نص ودود بالوقت المتبقي للتعديل
function editWindowLabel(inv) {
  const left = editWindowLeftMs(inv);
  if (left <= 0) return '';
  const mins = Math.max(1, Math.ceil(left / 60000));
  if (mins < 60) return 'باقي ' + mins + ' د';
  const h = Math.floor(mins / 60), m = mins % 60;
  return 'باقي ' + h + ' س' + (m ? ' ' + m + ' د' : '');
}

// رسالة الرفض: تفرّق بين "ليست فاتورتك" و"انتهت المهلة"
function denyEditMessage(inv) {
  if (!isOwnInvoice(inv)) {
    const who = (inv && inv.signedBy) ? ('العضو: ' + inv.signedBy) : 'عضو آخر';
    return '\u26D4 هذه ليست فاتورتك.\n\nأصدرها ' + who + '، ولا يعدّلها إلا مُصدِرها خلال ساعتين، أو المدير في أي وقت.';
  }
  const t = invoiceTime(inv);
  const since = t ? Math.floor((Date.now() - t) / 60000) : 0;
  const hrs = Math.floor(since / 60);
  const passed = hrs >= 1 ? (hrs + ' ساعة') : (since + ' دقيقة');
  return '\u26D4 انتهت مهلة التعديل.\n\nتعديل الفاتورة متاح لمُصدِرها خلال ساعتين من إصدارها فقط، ومضى عليها ' + passed + '.\nيرجى مراجعة المدير لإجراء أي تعديل.';
}

/* تبديل عرض أيقونات الأقسام بين شبكة وقائمة — مع تذكّر اختيار المستخدم */
function setSidebarView(mode) {
  const grid = document.getElementById('sidebar-sections-grid');
  if (!grid) return;
  const isList = (mode === 'list');
  grid.classList.toggle('list-view', isList);
  const gBtn = document.getElementById('btn-view-grid');
  const lBtn = document.getElementById('btn-view-list');
  if (gBtn) gBtn.classList.toggle('active', !isList);
  if (lBtn) lBtn.classList.toggle('active', isList);
  try { localStorage.setItem('sidebar_view_mode', isList ? 'list' : 'grid'); } catch (e) {}
}

// استعادة آخر وضع عرض محفوظ عند فتح الصفحة
(function restoreSidebarView() {
  const apply = () => {
    let saved = 'grid';
    try { saved = localStorage.getItem('sidebar_view_mode') || 'grid'; } catch (e) {}
    setSidebarView(saved);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply);
  else apply();
})();

// switchTab أُبقيت كاسم للتوافق مع كل الاستدعاءات القديمة في الملف،
// لكنها الآن تفتح القسم كلوحة منبثقة بدل إظهاره أسفل الصفحة.
function switchTab(id) { openSectionModal(id); }

/* يفتح القسم فوراً كلوحة كاملة تنزلق فوق كل شيء.
   - لا حاجة إطلاقاً للتمرير لأسفل للوصول للمحتوى.
   - يحترم الصلاحيات: الأقسام الخاصة بالمدير لا تُفتح لغيره حتى لو استُدعيت برمجياً.
   - زر الرجوع في الهاتف يغلق اللوحة بدل الخروج من الصفحة. */
const _SECTION_DATA_COLLECTIONS = {
  sales:['sales'], debts:['sales','payments'], credits:['sales','creditBalances'],
  returns:['returns'], expenses:['expenses'], store:['store'], inventory:['store','sales','returns'],
  salesaudit:['sales'], editedinv:['editedInvoicesLog'], payments:['payments'],
  search:['sales','payments','returns','expenses','store','trash','collections','editedInvoicesLog'],
  trash:['trash'], backup:['sales','payments','returns','expenses','store','trash','collections','editedInvoicesLog']
};
let _sectionLoadToken = 0;
async function _ensureSectionData(id) {
  const token = ++_sectionLoadToken;
  const keys = _SECTION_DATA_COLLECTIONS[id] || [];
  for (const k of keys) {
    if (k === 'creditBalances') { if (!_creditSyncReady) await attachCreditBalancesSync(); continue; }
    if (k === 'settings') { await attachSettingsSync(); continue; }
    if (k === 'editedInvoicesLog' && !isAdmin()) continue;
    await attachRecordCollectionSync(k);
  }
  return token === _sectionLoadToken;
}

function openSectionModal(id) {
  const meta = SECTION_META[id];
  const panel = document.getElementById('main-panel');
  const target = document.getElementById('section-' + id);
  if (!meta || !panel || !target) return;

  // حماية الصلاحيات — نفس صلاحيات المدير الكاملة وصلاحيات الأعضاء المحدودة كما هي
  if (ADMIN_ONLY_SECTIONS.indexOf(id) !== -1 && !(_currentUser && _currentUser.role === 'manager')) {
    showSuccessToast('\u26D4 هذا القسم متاح للمدير فقط');
    return;
  }

  document.querySelectorAll('.tab-content').forEach(el => { el.classList.add('hidden'); el.classList.remove('block'); });
  target.classList.remove('hidden');
  target.classList.add('block');

  document.querySelectorAll('.tab-btn').forEach(b => { b.classList.remove('active','text-blue-600','bg-blue-50/80'); });
  const btn = document.getElementById('btn-' + id);
  if (btn) btn.classList.add('active');

  document.getElementById('panel-icon').textContent = meta.icon;
  document.getElementById('panel-title').textContent = meta.title;

  const body = document.getElementById('panel-scroll');
  if (body) body.scrollTop = 0;

  _activeSection = id;
  /* v248: افتح اللوحة أولاً مهما حدث في الرسم أو جلب البيانات.
     كان مسار التفاعل يربط فتح اللوحة بالرسم وجلب البيانات؛ أي استثناء
     غير متوقع كان يجعل المستخدم يرى كأن الزر لم يعمل. اللوحة الآن تصبح
     مرئية قبل أي عمل ثقيل، وأي خطأ يُعرض داخلها ولا يُغلق الصفحة. */
  if (!panel.classList.contains('open')) {
    panel.classList.add('open');
    document.body.classList.add('panel-open');
    try { history.pushState({ shopPanel: true }, ''); } catch (e) {}
  }
  try {
    if (_sectionDirty[id] !== false) renderSection(id);
  } catch (e) {
    console.error('initial section render:', id, e);
    const safe = document.createElement('div');
    safe.style.cssText = 'margin:16px;padding:18px;border-radius:16px;background:#fff3f2;color:#8b1e16;font-family:Cairo,sans-serif;font-weight:800;text-align:center;';
    safe.textContent = 'تعذّر عرض هذا القسم مؤقتاً. أغلقه وافتحه مرة أخرى.';
    target.innerHTML = ''; target.appendChild(safe);
  }
  _ensureSectionData(id).then(() => {
    if (_activeSection !== id) return;
    try { _sectionDirty[id] = true; renderSection(id); }
    catch (e) { console.error('section refresh:', id, e); }
    try { refreshIcons(); } catch (e) {}
  }).catch(e => {
    console.error('section data:', id, e);
    if (_activeSection === id) {
      try { showFsErrorToast('⚠️ تعذّر تحميل بيانات «' + meta.title + '» — بقي القسم مفتوحاً ويمكن إعادة المحاولة.'); } catch (_) {}
    }
  });
  try { refreshIcons(); } catch (e) {}
}

// إغلاق داخلي بدون لمس سجل التصفح (يُستدعى من زر الرجوع في الهاتف)
function _closePanelUI() {
  const panel = document.getElementById('main-panel');
  if (!panel) return false;
  const wasOpen = panel.classList.contains('open');
  panel.classList.remove('open');
  document.body.classList.remove('panel-open');
  // إزالة تمييز القسم من الشاشة الرئيسية عند العودة إليها
  document.querySelectorAll('.tab-btn.active').forEach(b => b.classList.remove('active'));
  _activeSection = null;
  return wasOpen;
}

function closeSectionModal() {
  const panel = document.getElementById('main-panel');
  if (!panel || !panel.classList.contains('open')) return;
  _closePanelUI();
  if (history.state && history.state.shopPanel) { try { history.back(); } catch (e) {} }
}

// زر الرجوع في الهاتف يغلق اللوحة بدل مغادرة الصفحة
window.addEventListener('popstate', function () { _closePanelUI(); });

// زر Escape يغلق اللوحة (على الكمبيوتر)
document.addEventListener('keydown', function (e) {
  if (e.key !== 'Escape') return;
  const anyModalOpen = ['settings-modal','receipt-modal','manager-collect-modal','edit-modal','composite-modal']
    .some(mid => { const m = document.getElementById(mid); return m && !m.classList.contains('hidden') && m.style.display !== 'none'; });
  if (!anyModalOpen) closeSectionModal();
});

// أُبقيت بأسمائها القديمة لأن أزراراً عدة في الصفحة تستدعيها مباشرة
function openNewInvoiceModal() { openSectionModal('pos'); }
function closeNewInvoiceModal() { closeSectionModal(); }

// showSuccessToast: كانت تُستدعى في 5 مواضع (أهمها بعد حفظ كل فاتورة) دون أن تكون معرَّفة إطلاقاً،
// ما كان يوقف تنفيذ أي كود بعدها بالخطأ (مثل تفريغ الفاتورة تلقائياً بعد الحفظ). عُرِّفت هنا باستخدام
// عنصر الإشعار المُجهَّز مسبقاً بالتنسيق (success-toast) في الصفحة.
let _successToastTimer = null;
function showSuccessToast(message) {
  const el = document.getElementById('success-toast');
  const textEl = document.getElementById('success-toast-text');
  if (!el || !textEl) { console.log(message); return; }
  textEl.textContent = message;
  refreshIcons();
  el.classList.add('show');
  clearTimeout(_successToastTimer);
  _successToastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

// ============================================================
// DRAFT / PREVIEW STATE
// ============================================================
let isDraftMode = false; // هل المعاينة مبدئية؟
let draftData = null;    // بيانات الفاتورة المبدئية المؤقتة
let _savedThisSession = false; // منع الحفظ المزدوج للفاتورة الواحدة

// معاينة مبدئية بدون حفظ — تعرض الإجمالي فقط، بدون دفعات أو ديون
function previewDraftInvoice() {
  let custName = document.getElementById('pos-customer-name').value.trim();
  const custPhone = document.getElementById('pos-customer-phone').value.trim();

  if (!custName) { alert('يرجى إدخال اسم العميل أولاً.'); return; }
  if (!currentInvoiceItems.length) { alert('يرجى إضافة صنف واحد على الأقل.'); return; }
  // إصلاح 8.8: تنبيه قبل إنشاء عميل مكرر بهجاء مختلف (أحمد/احمد)
  custName = resolveCustomerName(custName);
  document.getElementById('pos-customer-name').value = custName;

  /* ══ حارس: لا فاتورة مبدئية أثناء تعديل فاتورة قائمة ══
     المبدئية تُنشئ عند اعتمادها فاتورة **جديدة** بمعرّف جديد. فلو ضُغطت
     وشاشة البيع في وضع تعديل فاتورة محفوظة، تبقى الأصلية كما هي وتُضاف
     نسخة ثانية بجانبها — فاتورتان لنفس الشغل، ويُخصم من المخزن مرتين،
     ويُطالَب الزبون بضعف قيمته. */
  const draftEditId = (document.getElementById('pos-edit-id') || {}).value || '';
  if (draftEditId) {
    alert('⛔ أنت تعدّل الفاتورة ' + draftEditId + ' الآن.\n\n' +
          'الفاتورة المبدئية تُنشئ فاتورة جديدة عند اعتمادها، فتصير فاتورتان لنفس الشغل.\n\n' +
          'احفظ التعديل أولاً (أو ألغِه) ثم أنشئ المبدئية.');
    return;
  }

  const itemsTotalD = r2(currentInvoiceItems.reduce((a,i)=>a+(i.total||0),0));
  const discountD   = readDiscount(itemsTotalD);
  const subtotal    = r2(itemsTotalD - discountD);

  draftData = {
    id: wsUid('DRAFT-'),
    date: new Date().toLocaleString('ar-EG'),
    timestamp: Date.now(),
    customerName: custName,
    customerPhone: custPhone,
    items: JSON.parse(JSON.stringify(currentInvoiceItems)),
    subtotal
    // ملاحظة: لا paid / oldDebtPay / netDebt في مرحلة المبدئية — هذه فاتورة استعلام عن قيمة فقط
  };

  isDraftMode = true;
  document.getElementById('draft-mode-badge').classList.remove('hidden');
  generateA4InvoiceView(draftData, true);
}

// تأكيد وحفظ الفاتورة المبدئية — يتحول إلى فاتورة رسمية كاملة بكل التفاصيل
function confirmDraftInvoice() {
  if (!draftData) return;   // يمنع الاعتماد المزدوج: تُصفَّر بعد أول نجاح

  // الحالة قد تتغيّر بين المعاينة والاعتماد — نُعيد الفحص هنا أيضاً
  const cdEditId = (document.getElementById('pos-edit-id') || {}).value || '';
  if (cdEditId) {
    alert('⛔ لا يمكن اعتماد المبدئية وأنت تعدّل الفاتورة ' + cdEditId + ' — احفظ التعديل أولاً.');
    return;
  }

  // عند التأكيد فقط نقرأ المدفوعات/الدين السابق من النموذج (الفاتورة المبدئية كانت إجمالي فقط)
  const payType = document.getElementById('pos-payment-type').value;
  const paid = r2(document.getElementById('pos-amount-paid').value) || 0;
  const oldDebtPay = r2(oldDebtPayEl.value) || 0;
  const netDebt = r2(draftData.subtotal - paid);

  const confirmMsg = paid > 0
    ? `هل تريد اعتماد هذه الفاتورة وحفظها رسمياً؟\
المبلغ المدفوع: ${fmt(paid)}\
سيتم خصم الكميات من المخزن وتسجيل المدفوعات.`
    : `هل تريد اعتماد هذه الفاتورة وحفظها رسمياً؟\
⚠️ لم تُدخل أي مبلغ مدفوع — ستُسجَّل بالكامل كدين على العميل.\
سيتم خصم الكميات من المخزن.`;

  if (!confirm(confirmMsg)) return;

  const invId = wsUid('INV-');
  /* الدفع الزائد يصبح رصيداً للعميل، ولا يُحفظ ديناً بالسالب.
     الخلل السابق: هذا المسار كان يحفظ netDebt سالباً كما هو (بخلاف مسار
     الفاتورة العادية). فلو دفع العميل 800 عن فاتورة 500، يُسجَّل دين −300،
     فيُطرح تلقائياً من ديونه الأخرى في كل التقارير (دين 1200 يظهر 900)،
     ولا تظهر الـ300 كرصيد له في أي مكان — فيضيع حقه ويختل الجرد معاً. */
  const overpayDraft = netDebt < 0 ? r2(-netDebt) : 0;
  let finalNetDebt = netDebt > 0 ? netDebt : 0;
  if (overpayDraft > 0) addCustomerCredit(draftData.customerName, overpayDraft);
  let creditUsed = 0;
  if (finalNetDebt > 0) {
    creditUsed = consumeCustomerCredit(draftData.customerName, finalNetDebt);
    finalNetDebt = r2(finalNetDebt - creditUsed);
  }
  const finalInv = {
    ...draftData,
    id: invId,
    // كما في الفاتورة العادية: الفائض رصيدٌ لا مدفوعٌ على هذه الفاتورة
    paid: r2(Math.min(paid, draftData.subtotal)), cashReceived: paid,
    overpayCredited: (overpayDraft || 0),
    oldDebtPay, netDebt: finalNetDebt,
    paymentType: payType,
    signedBy: getCurrentUserName(),
    signedByUid: getCurrentUserUid(),   // لتمييز صاحب الفاتورة عند التعديل لاحقاً
    creditUsed // مبلغ الرصيد الدائن الذي استُهلك عند إصدار هذه الفاتورة (يُستخدم لعكسه بدقة لو حُذفت لاحقاً)
  };

  // خصم من المخزن
  const touchedStoreItems = [];   // للتوافق فقط — الخصم صار عبر _moveStock بالفرق الذرّي
  /* ⚠️ إصلاح 8.8: كان هنا حارس مزدوج بالمطابقة النصّية التامة قبل
     استدعاء الخصم — فيُبطل بنفسه أي تحسين داخل _moveStock: الصنف الذي
     يختلف بمسافة أو همزة يُرفض هنا ولا يصل إلى الدالة أصلاً.
     والفحص زائد على كل حال: _moveStock تبحث عن الصنف بنفسها وتخرج
     بهدوء إن لم تجده. فمصدر واحد للقرار بدل اثنين متعارضين. */
  finalInv.items.forEach(si => deductStockForInvoiceItem(si));

  DB.sales.push(finalInv);

  const paymentsToSync = [];
  if (finalInv.paid > 0) {
    const p1 = { id:'PAYINV-'+invId, customerName:finalInv.customerName, amount:finalInv.paid, type:payType, reason:`دفعة عن الفاتورة ${invId}`, date:finalInv.date, timestamp:Date.now(), signedBy:getCurrentUserName(), signedByUid:getCurrentUserUid(), receiverRole:getCurrentUserRole(), invId, debtDistribution:[{ saleId: invId, amountApplied: r2(Math.min(finalInv.paid, finalInv.subtotal)) }], creditAdded: overpayDraft || 0 };
    DB.payments.push(p1); paymentsToSync.push(p1);
  }

  const touchedOtherSales = [];
  if (finalInv.oldDebtPay > 0) {
    /* معرّف ثابت كنظيرتها في المسار العادي. بدونه يبقى زر حذفها معطَّلاً
       للأبد ولا يمكن عكس أثرها على ديون الفواتير الأخرى. */
    const p2 = { id:'PAYDEBT-'+invId, customerName:finalInv.customerName, amount:finalInv.oldDebtPay, type:payType, reason:`سداد دين سابق مع الفاتورة ${invId}`, date:finalInv.date, timestamp:Date.now(), signedBy:getCurrentUserName(), signedByUid:getCurrentUserUid(), receiverRole:getCurrentUserRole(), invId };
    DB.payments.push(p2); paymentsToSync.push(p2);
    let rem = finalInv.oldDebtPay;
    const debtPayDistribution = []; // سجل دقيق لما لُمِس من ديون فواتير أخرى، ليُعكَس بدقة لو حُذفت هذه الفاتورة لاحقاً
    for (let i=0; i<DB.sales.length-1; i++) {
      if (DB.sales[i].customerName===finalInv.customerName && DB.sales[i].netDebt>0) {
        if (rem >= DB.sales[i].netDebt) { const applied=DB.sales[i].netDebt; rem = r2(rem - applied); DB.sales[i].paid = r2(DB.sales[i].paid + applied); DB.sales[i].netDebt = 0; touchedOtherSales.push(DB.sales[i]); debtPayDistribution.push({ saleId: DB.sales[i].id, amountApplied: applied }); }
        else { DB.sales[i].paid = r2(DB.sales[i].paid + rem); DB.sales[i].netDebt = r2(DB.sales[i].netDebt - rem); debtPayDistribution.push({ saleId: DB.sales[i].id, amountApplied: rem }); rem=0; touchedOtherSales.push(DB.sales[i]); break; }
      }
    }
    finalInv.debtPayDistribution = debtPayDistribution;
    p2.debtDistribution = debtPayDistribution;   // ليُعكَس أثرها إن حُذفت الدفعة وحدها
    p2.creditAdded = rem > 0.001 ? r2(rem) : 0;
  }

  saveDB();
  isDraftMode = false;
  draftData = null;
  document.getElementById('draft-mode-badge').classList.add('hidden');

  generateA4InvoiceView(DB.sales[DB.sales.length-1], false);
  const creditMsg = creditUsed>0 ? ` — تم خصم ${fmt(creditUsed)} تلقائياً من رصيد العميل السابق.` : '';
  reconcileAndSync(finalInv.customerName, { silent: true });
  showSuccessToast(`✅ تم حفظ الفاتورة رسمياً واعتمادها بنجاح!${creditMsg}`);
  setTimeout(() => { resetPOS(false); }, 1800);

  (async () => {
    try {
      // كميات المخزن تُرسل داخل deductStockForInvoiceItem بالفرق الذرّي، فلا تُكتب هنا
      await fsSet('sales', finalInv.id, finalInv);
      await Promise.all(paymentsToSync.map(p => p.id ? fsSet('payments', p.id, p) : _payWithoutId(p)));
      await Promise.all(touchedOtherSales.map(s => fsUpdate('sales', s.id, { paid: s.paid, netDebt: s.netDebt })));
      if (creditUsed > 0) await syncCreditBalance(finalInv.customerName);
    } catch (e) { /* fsX تعرض التنبيه بنفسها */ }
  })();
}

// ============================================================
// 1. POS
// ============================================================
let currentInvoiceItems = [];

/* ⚠️ تنبيه التكرار — 9.0.2
   بدل الحوار الذي يوقف العمل ويطلب قراراً قبل أن تكتمل الصورة، يظهر
   التنبيه **أثناء الإدخال**: بمجرد أن يتطابق اسم العميل وقيمة الفاتورة
   مع فاتورة اليوم نفسه. فيراه المستخدم مبكراً ويقرّر وهو يعمل، لا وهو
   يُستجوَب عند الحفظ.

   والمعيار «نفس القيمة» لا «نفس الأصناف»: فهكذا ينتبه صاحب المحل عملياً —
   وهو يرى مبلغاً تكرّر لنفس الزبون في يوم واحد، لا قائمة أصناف يقارنها
   سطراً سطراً. وهو أوسع أيضاً: يلتقط التكرار ولو أُعيد إدخال الأصناف
   بترتيب أو تجميع مختلف. */
function findDuplicateInvoiceToday(name, subtotal) {
  if (!name || !(subtotal > 0)) return null;
  const editId = (document.getElementById('pos-edit-id') || {}).value || '';
  const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
  const from = startOfDay.getTime();
  return (DB.sales || []).find(sv =>
    sv.id !== editId &&
    sv.customerName === name &&
    (sv.timestamp || 0) >= from &&
    Math.abs(r2(sv.subtotal || 0) - r2(subtotal)) < 0.01
  ) || null;
}

function checkDuplicateInvoiceHint() {
  const hint = document.getElementById('pos-dup-hint');
  if (!hint) return;
  const name = (document.getElementById('pos-customer-name').value || '').trim();
  const itemsTotal = r2((currentInvoiceItems || []).reduce((a, i) => a + (i.total || 0), 0));
  const subtotal = r2(itemsTotal - readDiscount(itemsTotal));
  const twin = findDuplicateInvoiceToday(name, subtotal);
  if (twin) {
    hint.innerText = '⚠️ لهذا العميل فاتورة اليوم بنفس القيمة (' + fmt(subtotal) + ') — رقم ' + twin.id +
                     '. تأكّد أنها ليست نفس الفاتورة قبل الحفظ.';
    hint.classList.remove('hidden');
  } else {
    hint.classList.add('hidden');
  }
}

function checkCustomerCreditHint() {
  const name = document.getElementById('pos-customer-name').value.trim();
  const hint = document.getElementById('pos-customer-credit-hint');
  if (!hint) return;
  const credit = name ? getCustomerCredit(name) : 0;
  if (credit > 0) {
    hint.innerText = `💰 لهذا العميل رصيد ${fmt(credit)} سيُخصم تلقائياً من الفاتورة عند الحفظ.`;
    hint.classList.remove('hidden');
  } else {
    hint.classList.add('hidden');
  }
}

/* ============================================================
   مطابقة أسماء العملاء — إصلاح 8.8
   ------------------------------------------------------------
   الديون تُجمَّع بمساواة نصية تامة (customerName === name). وفي العربية
   هذا يعني أن «أحمد» و«احمد» و«أحمد » عملاء ثلاثة منفصلون: الدين ينقسم
   على سجلات، والرصيد الدائن لدى أحدها لا يسدّد دين الآخر، ويظهر الاسم
   مكرراً في قائمة المديونين بمبالغ متفرّقة. والهمزة والمسافة الزائدة
   أشيع أخطاء الكتابة عندنا، فالانقسام يقع أسبوعياً لا نادراً.

   ولم يكن الاقتراح يساعد: كان يطابق نصاً خاماً، فمن يكتب «احمد» لا يرى
   «أحمد» فيظنّه عميلاً جديداً وينشئ الانقسام بيده.

   العلاج هنا عند **المدخل** لا عند الحساب: لا نعيد كتابة أي اسم مخزَّن
   ولا نغيّر أي مجموع تاريخي (ذلك قرار مالك لا قرار كود). بل الاقتراح
   يطابق بعد التطبيع، ويُنبَّه المستخدم عند الحفظ قبل أن ينشأ الانقسام.
   ============================================================ */
function _allKnownCustomers() {
  const seen = new Map();
  const add = (nm, ph) => {
    if (!nm) return;
    const k = wsNormName(nm);
    if (!k) return;
    if (!seen.has(k)) seen.set(k, { name: nm, phone: ph || '' });
    else if (ph && !seen.get(k).phone) seen.get(k).phone = ph;
  };
  DB.sales.forEach(x => add(x.customerName, x.customerPhone));
  DB.payments.forEach(x => add(x.customerName, ''));
  return Array.from(seen.values());
}

/* يُعيد اسم عميل قائم يطابق المكتوب بعد التطبيع لكن يختلف عنه حرفياً،
   أو null إن لم يوجد (أو كان مطابقاً تماماً فلا مشكلة أصلاً). */
function findNameVariant(typed) {
  const t = wsNormName(typed);
  if (!t) return null;
  const names = new Set();
  DB.sales.forEach(x => { if (x.customerName) names.add(x.customerName); });
  DB.payments.forEach(x => { if (x.customerName) names.add(x.customerName); });
  if (names.has(typed)) return null;
  for (const n of names) if (wsNormName(n) === t) return n;
  return null;
}

/* يُستدعى قبل الحفظ. يُعيد الاسم الذي يجب استعماله. لا يفرض شيئاً:
   يشرح الأثر المالي ويترك القرار للمستخدم. */
function resolveCustomerName(typed) {
  const variant = findNameVariant(typed);
  if (!variant) return typed;
  const debt = getCustomerNetDebt(variant);
  const cred = getCustomerCredit(variant);
  let msg = 'يوجد عميل مسجَّل باسم «' + variant + '»، وأنت كتبت «' + typed + '».\n\n';
  if (debt > 0) msg += 'عليه دين: ' + fmt(debt) + '\n';
  if (cred > 0) msg += 'له رصيد: ' + fmt(cred) + '\n';
  msg += '\nلو حفظت بالهجاء الجديد صار عميلين منفصلين، ولن يسدّد أحدهما دين الآخر.\n\n' +
         'موافق = استعمل «' + variant + '» (الأصح)\n' +
         'إلغاء = احفظ باسم جديد مستقل';
  return confirm(msg) ? variant : typed;
}

function suggestCustomer() {
  const raw = document.getElementById('pos-customer-name').value.trim();
  const val = wsNormName(raw);
  const box = document.getElementById('customer-suggestions');
  box.innerHTML = '';
  if (!val) { box.classList.add('hidden'); return; }
  const clients = _allKnownCustomers();
  let filtered = clients.filter(c => wsNormName(c.name).includes(val));
  if (!filtered.length) { box.classList.add('hidden'); return; }
  filtered.forEach(c => {
    let d = document.createElement('div');
    d.className = 'p-3 hover:bg-slate-50 cursor-pointer border-b border-slate-100 text-sm font-medium';
    d.innerText = `${c.name} (${c.phone || 'بدون هاتف'})`;
    d.onclick = () => {
      document.getElementById('pos-customer-name').value = c.name;
      document.getElementById('pos-customer-phone').value = c.phone;
      box.classList.add('hidden');
      checkCustomerCreditHint();
    };
    box.appendChild(d);
  });
  box.classList.remove('hidden');
}

/* ============================================================
   اقتراح الأصناف داخل مربع البند — من نفس كتالوج المخزن المشترك
   مع صفحة القياسات تماماً (مجموعة store في Firestore).
   يظهر من أول حرف، ويعرض السعر والمخزون، ويدعم الأسهم و Enter.
   ============================================================ */
let _acIndex = -1;

function _acEsc(t) {
  return String(t == null ? '' : t).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}

function suggestItems() {
  const input = document.getElementById('pos-item-name');
  const box = document.getElementById('item-suggestions');
  const val = input.value.trim().toLowerCase();
  _acIndex = -1;
  box.innerHTML = '';

  // ترتيب ذكي: ما يبدأ بالحروف المكتوبة أولاً، ثم ما يحتويها
  let list = DB.store.slice();
  if (val) {
    list = list.filter(i => (i.name || '').toLowerCase().includes(val));
    list.sort((a, b) => {
      const sa = (a.name || '').toLowerCase().indexOf(val) === 0 ? 0 : 1;
      const sb = (b.name || '').toLowerCase().indexOf(val) === 0 ? 0 : 1;
      return sa - sb || (a.name || '').localeCompare(b.name || '', 'ar');
    });
  } else {
    list.sort((a, b) => (a.name || '').localeCompare(b.name || '', 'ar'));
  }
  list = list.slice(0, 200);   // كل الأصناف المطابقة تقريباً، والقائمة نفسها قابلة للتمرير

  let html = list.map(i => `
    <div class="ac-row" data-name="${_acEsc(i.name)}" data-price="${escapeHtml(i.price)}">
      <span class="ac-name">${_acEsc(i.name)}</span>
      <span class="ac-meta">
        <span class="ac-price">${fmt(i.price)}</span>
        <span class="ac-qty${(i.qty || 0) <= 0 ? ' low' : ''}">مخزون ${fmt(i.qty || 0)}</span>
      </span>
    </div>`).join('');

  // صنف جديد غير موجود بالكتالوج — يُضاف للمخزن المشترك تلقائياً عند حفظ الفاتورة
  if (val && !list.some(i => (i.name || '').trim().toLowerCase() === val)) {
    html += `<div class="ac-row ac-new" data-new="1">＋ صنف جديد: «${_acEsc(input.value.trim())}» — سيُضاف للمخزن تلقائياً</div>`;
  }

  if (!html) { box.classList.add('hidden'); return; }
  box.innerHTML = html;
  box.classList.remove('hidden');

  box.querySelectorAll('.ac-row').forEach(row => {
    // mousedown قبل blur حتى لا تختفي القائمة قبل تنفيذ الاختيار
    row.addEventListener('mousedown', ev => {
      ev.preventDefault();
      if (row.dataset.new) { hideItemSuggestions(); document.getElementById('pos-item-qty').focus(); return; }
      pickSuggestedItem(row.dataset.name, row.dataset.price);
    });
  });
}

function pickSuggestedItem(name, price) {
  document.getElementById('pos-item-name').value = name;
  const priceEl = document.getElementById('pos-item-price');
  const qtyEl = document.getElementById('pos-item-qty');
  priceEl.value = price;
  if (!qtyEl.value) qtyEl.value = 1;
  hideItemSuggestions();
  qtyEl.focus();
  qtyEl.select && qtyEl.select();
}

function hideItemSuggestions() {
  const box = document.getElementById('item-suggestions');
  if (box) { box.classList.add('hidden'); box.innerHTML = ''; }
  _acIndex = -1;
}

function itemSuggestKey(e) {
  const box = document.getElementById('item-suggestions');
  const rows = box && !box.classList.contains('hidden') ? box.querySelectorAll('.ac-row') : [];
  if (e.key === 'Escape') { hideItemSuggestions(); return; }
  if (e.key === 'Enter') {
    if (_acIndex >= 0 && rows[_acIndex] && !rows[_acIndex].dataset.new) {
      e.preventDefault();
      pickSuggestedItem(rows[_acIndex].dataset.name, rows[_acIndex].dataset.price);
    } else {
      hideItemSuggestions();
      document.getElementById('pos-item-qty').focus();
    }
    return;
  }
  if (!rows.length) return;
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault();
    _acIndex += (e.key === 'ArrowDown' ? 1 : -1);
    if (_acIndex < 0) _acIndex = rows.length - 1;
    if (_acIndex >= rows.length) _acIndex = 0;
    rows.forEach(r => r.classList.remove('ac-active'));
    rows[_acIndex].classList.add('ac-active');
    rows[_acIndex].scrollIntoView({ block: 'nearest' });
  }
}

// إخفاء أي قائمة اقتراح عند الضغط خارجها
document.addEventListener('click', function (e) {
  if (!e.target.closest || !e.target.closest('#pos-item-name')) hideItemSuggestions();
  if (!e.target.closest || !e.target.closest('#pos-customer-name')) {
    const cb = document.getElementById('customer-suggestions');
    if (cb) cb.classList.add('hidden');
  }
});

/* أي صنف يُكتب في فاتورة ولا يوجد في الكتالوج يُسجَّل تلقائياً في مجموعة store،
   فيظهر فوراً كبند مالي جاهز في صفحة القياسات — وهذا يحقق التطابق في الاتجاهين. */
function registerInvoiceItemsInCatalog(items) {
  (items || []).forEach(it => {
    const nm = (it.name || '').trim();
    if (!nm) return;
    if (DB.store.some(x => (x.name || '').trim() === nm)) return;
    const id = wsUid('STR-') + '-' + Math.random().toString(36).slice(2, 6);
    const rec = { id: id, name: nm, price: r2(it.price) || 0, qty: 0, recipe: null };
    DB.store.push(rec);
    fsSet('store', id, rec).catch(() => {});
  });
}

function addItemToInvoice() {
  const name = document.getElementById('pos-item-name').value.trim();
  const qty = r2(document.getElementById('pos-item-qty').value);
  const price = r2(document.getElementById('pos-item-price').value);
  if (!name || isNaN(qty) || isNaN(price) || qty <= 0 || price < 0) { alert('يرجى ملء خانات الصنف والكمية والسعر.'); return; }
  /* إصلاح 8.8: الدمج كان بمساواة نصّية تامة، فـ«باب» و«باب » سطران
     منفصلان في الفاتورة الواحدة — ويظهران للزبون كصنفين. */
  let ex = currentInvoiceItems.find(i => i.name === name)
        || currentInvoiceItems.find(i => wsNormName(i.name) === wsNormName(name));
  if (ex) {
    /* السعر الجديد كان يُهمَل بصمت: إدخال «باب» بـ500 ثم «باب» بـ650 كان
       ينتج سطراً بكمية 2 × 500 = 1000 بدل 1150، فتضيع 150 بلا أي تنبيه.
       الآن: إن اختلف السعر نسأل صراحةً بدل التخمين. */
    if (r2(ex.price) !== price) {
      const keepOld = confirm(
        'الصنف «' + name + '» موجود في الفاتورة بسعر ' + fmt(ex.price) +
        '، وأدخلت الآن سعر ' + fmt(price) + '.\n\n' +
        'موافق  = سطر منفصل بالسعر الجديد (يبقى القديم كما هو)\n' +
        'إلغاء  = دمج الكمية وتطبيق السعر الجديد على الكل'
      );
      if (keepOld) {
        currentInvoiceItems.push({ name, qty, price, total: r2(qty*price) });
      } else {
        ex.qty = r2(ex.qty + qty); ex.price = price; ex.total = r2(ex.qty * ex.price);
      }
    } else {
      ex.qty = r2(ex.qty + qty); ex.total = r2(ex.qty * ex.price);
    }
  }
  else currentInvoiceItems.push({ name, qty, price, total: r2(qty*price) });
  ['pos-item-name','pos-item-qty','pos-item-price'].forEach(id => document.getElementById(id).value = '');
  renderPOSTable();
}

function removeInvoiceItem(idx) { currentInvoiceItems.splice(idx,1); renderPOSTable(); }

// تعديل الكمية أو السعر لصنف مُدرج بالفعل في الفاتورة الحالية (قبل الحفظ)
function updateCurrentInvoiceItem(idx, field, val) {
  const item = currentInvoiceItems[idx];
  if (!item) return;
  const v = r2(val);
  if (isNaN(v) || v < 0 || (field === 'qty' && v <= 0)) { renderPOSTable(); return; }
  item[field] = v;
  item.total = r2(item.qty * item.price);
  renderPOSTable();
}

function renderPOSTable() {
  const body = document.getElementById('pos-table-body');
  const focused = document.activeElement;
  const focusInfo = (focused && focused.dataset && focused.dataset.editIdx != null)
    ? { idx: focused.dataset.editIdx, field: focused.dataset.editField, selStart: focused.selectionStart }
    : null;
  body.innerHTML = '';
  currentInvoiceItems.forEach((item,idx) => {
    let tr = document.createElement('tr');
    tr.className = 'text-sm text-slate-700';
    tr.innerHTML = `
      <td class="p-3 font-medium">${escapeHtml(item.name)}</td>
      <td class="p-2">
        <input type="number" value="${escapeHtml(item.qty)}" min="0.01" step="0.01" data-edit-idx="${idx}" data-edit-field="qty"
          onchange="updateCurrentInvoiceItem(${idx},'qty',this.value)"
          class="w-20 p-2 bg-white border border-slate-200 rounded-lg text-center font-bold focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all">
      </td>
      <td class="p-2">
        <input type="number" value="${escapeHtml(item.price)}" min="0" step="0.01" data-edit-idx="${idx}" data-edit-field="price"
          onchange="updateCurrentInvoiceItem(${idx},'price',this.value)"
          class="w-24 p-2 bg-white border border-slate-200 rounded-lg text-center font-bold focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all">
      </td>
      <td class="p-3 font-bold">${fmt(item.total)}</td>
      <td class="p-3 text-center">
        <button onclick="removeInvoiceItem(${idx})" class="p-1 text-rose-600 hover:bg-rose-50 rounded">
          <i data-lucide="x-circle" class="w-5 h-5"></i>
        </button>
      </td>`;
    body.appendChild(tr);
  });
  // إعادة التركيز للحقل الذي كان قيد التعديل (لو كان الإدخال عبر ضغط Enter/تنقل متكرر)
  if (focusInfo) {
    const el = body.querySelector(`input[data-edit-idx="${focusInfo.idx}"][data-edit-field="${focusInfo.field}"]`);
    if (el) { el.focus(); try { el.setSelectionRange(focusInfo.selStart, focusInfo.selStart); } catch(e){} }
  }
  refreshIcons();
  calculateInvoiceTotals();
}

/* يقرأ خانة الخصم: يقبل مبلغاً مباشراً (100) أو نسبة مئوية (10%).
   يُرجع مبلغ الخصم النهائي، ولا يتجاوز مجموع الأصناف أبداً. */
/* يعيد حساب إجمالي الفاتورة بعد تغيّر أصنافها (إرجاع مثلاً)
   مع إبقاء الخصم المسجَّل مطبَّقاً. بدونها كان الإجمالي يقفز لأعلى
   بعد أي إرجاع فيظهر دين وهمي على العميل. */
function recalcInvoiceTotal(inv) {
  /* الخصم يُوزَّع بنسبة ما تبقّى من البضاعة، ولا يبقى مبلغاً ثابتاً.
     الخلل السابق بمثال: فاتورة 1000 بخصم 10% (=100) فالإجمالي 900 ودفعها العميل
     كاملة. ثم أرجع بضاعة بنصف القيمة (500). كان الخصم يبقى 100 فيصير الإجمالي
     400 ويُصرف للعميل 500 — والصحيح 450، لأن نصف البضاعة تحمل نصف الخصم.
     أي أن المحل كان يخسر 50 في كل إرجاع كهذا. */
  const prevItemsTotal = (typeof inv.itemsTotal === 'number' && inv.itemsTotal > 0)
    ? inv.itemsTotal
    : r2((inv.items || []).reduce((a,i)=>a+(i.total||0), 0));
  inv.itemsTotal = r2((inv.items || []).reduce((a,i)=>a+(i.total||0), 0));
  /* فاتورة قديمة بخصم: يُوزَّع بنسبة ما تبقّى كما كان، فلا يتغيّر معنى
     الفاتورة عند تعديلها. أما الجديدة فخصمها صفر أصلاً، فلا أثر لهذا. */
  if (prevItemsTotal > 0 && (inv.discount || 0) > 0) {
    inv.discount = r2(inv.discount * (inv.itemsTotal / prevItemsTotal));
  }
  inv.discount = r2(Math.min(inv.discount || 0, inv.itemsTotal));
  inv.subtotal = r2(inv.itemsTotal - inv.discount);
  return inv.subtotal;
}

/* ══ الخصم أُلغي ══
   لا تُنشأ فاتورة جديدة بخصم إطلاقاً — تُصفَّر هنا في المنبع، فيسري
   الإلغاء على كل مسارات الإنشاء والتعديل بلا استثناء واحد.

   ولا تُحذف الحقول من الفواتير القديمة: فاتورة سُجّلت بخصم 100 إجماليها
   محسوب على ذلك الأساس، وتصفيره فيها يرفع إجماليها ويخلق ديناً وهمياً
   على زبون سدّد حسابه. فتُقرأ كما هي وتُعرض كما هي، ولا يُنشأ جديد
   مثلها.

   ومن أراد تخفيض مبلغ: يُعدّل سعر البند، أو يُعدّل المجموع من كراسة
   القياسات — وكلاهما يظهر في الفاتورة صراحةً لا كرقم خفيّ. */
function readDiscount(itemsTotal) {
  return 0;
}

function _readDiscountLegacy(itemsTotal) {
  const el = document.getElementById('pos-discount');
  if (!el) return 0;
  const raw = toLatinDigits(String(el.value || '')).trim();
  if (!raw) return 0;
  const isPercent = /%|٪/.test(raw);
  /* نُبقي إشارة السالب داخل النص حتى تُرفض القيم السالبة،
     فتجريدها كان يحوّل "-50" إلى خصم 50 بالخطأ.
     ونرفض أي صيغة ملتبسة تماماً (مثل "50-" أو "1.2.3") بدل تخمين المقصود. */
  const cleaned = raw.replace(/[^\d.\-]/g, '');
  if (!/^-?\d*\.?\d+$/.test(cleaned)) return 0;
  const num = parseFloat(cleaned);
  if (isNaN(num) || num <= 0) return 0;
  const amount = isPercent ? (itemsTotal * num / 100) : num;
  // الخصم لا يزيد عن قيمة الأصناف ولا يجعل الفاتورة بالسالب
  return r2(Math.min(Math.max(0, amount), itemsTotal));
}

/* يعرض الإجمالي والمتبقي لحظياً. عند دفع مبلغ أكبر من قيمة الفاتورة يوضّح
   أن الزيادة ستُسجَّل رصيداً دائناً للعميل — بدل إظهار صفر وحفظ دين سالب. */
function calculateInvoiceTotals() {
  try { checkDuplicateInvoiceHint(); } catch (e) {}   // تنبيه التكرار — 9.0.2
  const itemsTotal = r2(currentInvoiceItems.reduce((a,i) => a+(i.total||0), 0));
  const discount = readDiscount(itemsTotal);
  const subtotal = r2(itemsTotal - discount);   // الإجمالي المعتمد في كل الحسابات
  // إصلاح 8.8: parseFloat كانت تسبق التحويل فتُقرأ «١٠٠» صفراً — ويُسجَّل دين على من دفع
  const paid = r2(document.getElementById('pos-amount-paid').value) || 0;
  /* عند تعديل فاتورة استهلكت رصيداً دائناً، يجب طرح ذلك الرصيد من الدين
     المعروض كما يفعل الحفظ تماماً. بدونه تُظهر الشاشة ديناً بمقدار الرصيد
     ثم يُحفظ صفراً — فيظن المدير أن الحفظ لم يعمل ويعيد الكرّة. */
  const editingId = (document.getElementById('pos-edit-id') || {}).value || '';
  const editingInv = editingId ? DB.sales.find(x => x.id === editingId) : null;
  const credUsedNow = r2((editingInv && editingInv.creditUsed) || 0);
  const diff = r2(subtotal - paid - credUsedNow);
  const el = document.getElementById('pos-running-debt');
  const lbl = document.getElementById('pos-running-debt-label');
  const sub = document.getElementById('pos-subtotal-display');

  const itemsEl = document.getElementById('pos-items-display');
  const discRow = document.getElementById('pos-discount-row');
  const discEl  = document.getElementById('pos-discount-display');
  if (itemsEl) itemsEl.innerText = fmt(itemsTotal);
  if (discRow) discRow.classList.toggle('hidden', discount <= 0);
  if (discEl)  discEl.innerText = '- ' + fmt(discount);
  if (sub) sub.innerText = fmt(subtotal);
  if (!el) return;
  if (diff >= 0) {
    el.innerText = fmt(diff);
    el.style.color = diff > 0 ? '#d33722' : '#179baa';
    if (lbl) lbl.innerText = 'المتبقي كدين جديد:';
  } else {
    el.innerText = fmt(-diff);
    el.style.color = '#0e91a0';
    if (lbl) lbl.innerText = 'زيادة تُضاف كرصيد للعميل:';
  }
}

// ============================================================
// إدارة المخزون لأصناف الفاتورة — تدعم الأصناف المركبة (تخصم/تُعيد المكوّنات بدلاً من الصنف نفسه)
// ============================================================
/* ============================================================
   حركة المخزون — بالفرق لا بالقيمة النهائية
   ------------------------------------------------------------
   الخلل الذي عولج هنا هو أخطر ما في النظام على دقة الجرد:
   كانت الدالة تحسب الكمية النهائية من نسخة الجهاز ثم ترسلها كقيمة.
   فلو باع عاملان دون اتصال من نفس الصنف (رصيد 10):
     الأول يبيع 3 ويرسل «الكمية = 7»
     الثاني يبيع 4 ويرسل «الكمية = 6»
   تفوز آخر رسالة عند عودة الشبكة فيستقر المخزون على 6 بدل 3،
   وتختفي كمية كاملة من الدفاتر بلا أي أثر ولا رسالة خطأ.
   الآن نرسل الفرق (fsIncrement) فيجمعه السيرفر: 10 − 3 − 4 = 3.
   ويعمل ذلك دون اتصال أيضاً: يُحفظ كتحويل مؤجَّل ويُطبَّق عند الوصول.

   ملاحظة: لم نعد نقصّ الكمية عند الصفر قبل الإرسال. الرصيد السالب
   إشارة صحيحة إلى بيع أكثر من المسجَّل، وإخفاؤه كان يبتلع الفارق.
   ============================================================ */
/* مطابقة صنف المخزن — إصلاح 8.8
   ------------------------------------------------------------
   كانت المطابقة نصّية تامة: DB.store.find(s => s.name === invItem.name).
   فأي فارق لا يراه المستخدم — مسافة زائدة، همزة (أ/ا)، تاء مربوطة —
   يجعل الصنف «غير موجود» فتخرج الدالة بـ return **صامتاً تماماً**:
   يُباع الصنف ولا يُخصم من المخزن، ولا رسالة ولا سطر في السجل.
   والجرد ينحرف تدريجياً بلا أن يعرف أحد متى بدأ الانحراف.

   والكود كان ينبّه على المكوّن الناقص داخل الوصفة، أما الصنف الأصلي
   المفقود فيمرّ بلا صوت — وهو الحالة الأشيع.

   الآن: مطابقة تامة أولاً (فهي الأدقّ)، ثم مطابقة بعد التطبيع عند
   الإخفاق. والصنف غير الموجود في المخزن إطلاقاً لا يُنبَّه عليه، فبيع
   خدمة أو صنف حرّ ليس خطأً — التنبيه يقتصر على ما يبدو أنه صنف مخزن. */
function _findStoreItemByName(name) {
  if (!name) return null;
  const exact = DB.store.find(s => s.name === name);
  if (exact) return exact;
  const k = wsNormName(name);
  if (!k) return null;
  const near = DB.store.filter(s => wsNormName(s.name) === k);
  /* تطابُق واحد فقط يُعتمد. أكثر من واحد = التباس حقيقي في أسماء
     المخزن، والخصم من الصنف الخطأ أسوأ من عدم الخصم. */
  return near.length === 1 ? near[0] : null;
}

function _moveStock(invItem, sign) {
  const storeItem = _findStoreItemByName(invItem.name);
  if (!storeItem) {
    const k = wsNormName(invItem.name);
    const ambiguous = k && DB.store.filter(s => wsNormName(s.name) === k).length > 1;
    if (ambiguous) {
      showFsErrorToast('⚠️ «' + invItem.name + '» يطابق أكثر من صنف في المخزن — لم يُخصم. وحّد الأسماء.');
    }
    return;
  }
  const parts = (Array.isArray(storeItem.recipe) && storeItem.recipe.length)
    ? storeItem.recipe.map(r => ({ item: DB.store.find(s => s.id === r.componentId), qty: r.qty * invItem.qty }))
    : [{ item: storeItem, qty: invItem.qty }];
  parts.forEach(({ item, qty }) => {
    /* مكوّن مفقود من المخزن (حُذف قبل تفعيل الحارس، أو لم يصل من المزامنة
       بعد): كان يُتخطّى بصمت تام فيُباع الصنف بلا خصم. صار يُنبَّه عليه
       ليعرف المدير أن هذا الصنف يحتاج ضبط مكوّناته. */
    if (!item) {
      showFsErrorToast('⚠️ مكوّن ناقص في «' + (storeItem.name || '') + '» — لم يُخصم من المخزن. راجع مكوّنات الصنف.');
      return;
    }
    const delta = r2(sign * qty);
    if (!delta) return;
    item.qty = r2((item.qty || 0) + delta);      // تحديث فوري للواجهة
    fsIncrement('store', item.id, 'qty', delta); // والفرق وحده هو ما يُرسل
  });
}

function deductStockForInvoiceItem(invItem)  { _moveStock(invItem, -1); }
function restoreStockForInvoiceItem(invItem) { _moveStock(invItem, +1); }

// ============================================================
// سجل الفواتير الأصلية التي تم تعديلها — للاطلاع فقط (لا يؤثر إطلاقاً على حسابات النظام)
// يحفظ أول نسخة أصلية للفاتورة قبل أي تعديل عليها إطلاقاً، مع عدد مرات التعديل وآخر موعد تعديل
// ============================================================
function logOriginalInvoiceBeforeEdit(oldInv) {
  if (!Array.isArray(DB.editedInvoicesLog)) DB.editedInvoicesLog = [];
  let entry = DB.editedInvoicesLog.find(e => e.originalId === oldInv.id);
  const who = (typeof getCurrentUserName === 'function') ? getCurrentUserName() : '';
  const now = new Date().toLocaleString('ar-EG');
  if (!entry) {
    entry = {
      originalId: oldInv.id,
      original: JSON.parse(JSON.stringify(oldInv)), // نسخة كاملة وثابتة من الفاتورة كما كانت قبل أول تعديل
      firstEditedAt: now,
      firstEditedBy: who,
      editCount: 0
    };
    DB.editedInvoicesLog.push(entry);
  }
  entry.editCount = (entry.editCount || 0) + 1;
  entry.lastEditedAt = now;
  entry.lastEditedBy = who;
  fsSet('editedInvoicesLog', entry.originalId, entry).catch(() => {});
}

function saveCurrentInvoice() {
  const editEl = document.getElementById('pos-edit-id');
  const nameEl = document.getElementById('pos-customer-name');
  const phoneEl = document.getElementById('pos-customer-phone');
  const payTypeEl = document.getElementById('pos-payment-type');
  const paidEl = document.getElementById('pos-amount-paid');
  const oldDebtPayEl = document.getElementById('pos-old-debt-pay');
  if (!editEl || !nameEl || !phoneEl || !payTypeEl || !paidEl || !oldDebtPayEl) {
    alert('⚠️ نموذج الفاتورة لم يكتمل تحميله. أغلق قسم الفواتير وافتحه من جديد ثم حاول الحفظ.');
    return false;
  }
  const editId = editEl.value;
  // منع الحفظ المزدوج للفاتورة
  if (_savedThisSession && !editId) {
    alert('⚠️ الفاتورة محفوظة بالفعل.\
اضغط «تفريغ الخانات» لإنشاء فاتورة جديدة.');
    return;
  }
  let custName = nameEl.value.trim();
  const custPhone = phoneEl.value.trim();
  const payType = payTypeEl.value;
  const paid = r2(paidEl.value) || 0;
  // الحقل مخفي وقيمته صفر دائماً للفواتير الجديدة (أُلغي السداد من هذه الشاشة)،
  // لكنه يحمل القيمة التاريخية عند تعديل فاتورة قديمة، فنقرأه كما هو للحفاظ عليها.
  const oldDebtPay = r2(oldDebtPayEl.value) || 0;

  if (!custName) { alert('يرجى إدخال اسم العميل.'); return; }
  if (!currentInvoiceItems.length) { alert('الفاتورة فارغة.'); return; }

  /* ⚠️⚠️ إصلاح 9.0.1 — تكرار الفاتورة في الأرشيف.

     الحارس القائم `_savedThisSession` يُرفع **بعد مئتي سطر** من فحصه،
     ويُصفَّر في catch برسالة «البيانات ما زالت في الشاشة — أعد المحاولة».
     ومعرّف الفاتورة يُولَّد جديداً في كل محاولة. فأي خطأ يقع بعد الكتابة
     — أو تأخّر رسالة النجاح على شبكة بطيئة — يدفع المستخدم للحفظ ثانيةً،
     فتُنشأ فاتورة **ثانية بنفس المحتوى ورقم مختلف**.

     وأثره ليس تجميلياً: كل نسخة تخصم المخزون مرة، وتُنشئ ديناً مرة،
     وتظهر في تقارير المبيعات مرة. فيصير الرقم في الشاشة ضعف الرقم في
     الرفّ وفي الصندوق.

     والفرق عن الكراسات مقصود: هناك نتبنّى المستند القائم بصمت، لأن
     الكراسة عملٌ متواصل. أما الفاتورة فسجلٌّ مالي مستقل — قد يشتري
     العميل الشيء نفسه مرتين في اليوم فعلاً. فلا نقرّر عنه: نُظهر
     الفاتورة القائمة ونسأله. */
  /* تُعيد true إذا قرّر المستخدم عدم الحفظ. والفحص هنا **قبل** كتلة
     try — فلا يجوز الخروج منه برمي استثناء، إذ لا catch يلتقطه فيصير
     خطأً غير معالَج يوقف الدالة بلا رسالة. نُعيد قيمة ونخرج بـ return. */
  if (_isDuplicateInvoiceAborted(custName, editId)) return;

  function _isDuplicateInvoiceAborted(custName, editId) {
    if (editId) return false;
    /* الحارس الأخير عند الحفظ — مبسَّط في 9.0.2.

       كان حواراً من فقرتين يطلب قراءة ستة أسطر قبل الضغط، وكان يظهر
       فجأةً بعد أن يكون المستخدم قد أنهى عمله. وهذا يدفع للضغط دون قراءة
       فيفقد التأكيد معناه — وهي علّة كل تأكيد طويل.

       الآن التنبيه الأساسي يظهر **أثناء الإدخال** (checkDuplicateInvoiceHint)،
       فيراه مبكراً ويقرّر وهو يعمل. ولا يبقى هنا إلا سطران يذكّران بما
       رآه، لأن ثمن الخطأ حقيقي: خصم مزدوج من المخزون ودين مزدوج. */
    const itemsTotal = r2((currentInvoiceItems || []).reduce((a, i) => a + (i.total || 0), 0));
    const subtotal   = r2(itemsTotal - readDiscount(itemsTotal));
    const twin = findDuplicateInvoiceToday(custName, subtotal);
    if (!twin) return false;
    const go = confirm('⚠️ لهذا العميل فاتورة اليوم بنفس القيمة — رقم ' + twin.id + '.\n\n' +
                       'هل هذه فاتورة جديدة فعلاً؟');
    if (go) return false;
    showSuccessToast('✅ اكتُفي بالفاتورة ' + twin.id + ' — لم تُنشأ نسخة ثانية.');
    resetPOS(false);
    return true;
  }
  // إصلاح 8.8: تنبيه قبل إنشاء عميل مكرر بهجاء مختلف (أحمد/احمد)
  custName = resolveCustomerName(custName);
  document.getElementById('pos-customer-name').value = custName;
  /* بلا هوية مسجَّلة سيرفض السيرفر الفاتورة حتماً (قاعدة signedByUid)،
     فنمنعها هنا برسالة مفهومة بدل تركها تُحفظ ظاهرياً ثم تختفي. */
  if (!getCurrentUserUid()) {
    alert('⚠️ لم يكتمل التحقق من حسابك بعد.\n\nانتظر لحظة ثم أعد المحاولة، أو أعد فتح التطبيق.');
    return;
  }

  const btn = document.getElementById('btn-save-invoice');
  btn.disabled = true;

  /* ⚠️ إصلاح 8.8 — الزر كان يموت إلى الأبد:
     btn.disabled = true يقع هنا، وبين هذا السطر وإعادة التفعيل مئتا
     سطر من الحساب والكتابة بلا أي try/catch يغطّيها. فأي استثناء —
     صنف بلا سعر، حقل ناقص، خلل في عنصر واجهة — يترك الزر معطّلاً
     والفاتورة غير محفوظة. والمستخدم لا يملك إلا إعادة تحميل الصفحة
     وإدخال كل الأصناف من جديد، بلا رسالة تشرح ما جرى.
     الآن: أي خطأ يُعيد الزر ويشرح، والفاتورة تبقى في الشاشة كما هي. */
  try {

    const itemsTotal = r2(currentInvoiceItems.reduce((a,i)=>a+(i.total||0),0));
    const discount   = readDiscount(itemsTotal);
    // subtotal = القيمة المعتمدة بعد الخصم. كل الحسابات (الدين، الأرصدة،
    // التقارير، الجرد) تعتمد عليها، فيبقى النظام متسقاً بلا استثناءات.
    const subtotal   = r2(itemsTotal - discount);
    const rawDiff    = r2(subtotal - paid);
    // الدين لا يكون سالباً أبداً. أي زيادة في المدفوع عن قيمة الفاتورة تُسجَّل رصيداً
    // دائناً للعميل، وإلا لظهرت كدين بالسالب يُنقص مجموع ديون بقية العملاء خطأً.
    const netDebt = rawDiff > 0 ? rawDiff : 0;
    const overpay = rawDiff < 0 ? r2(-rawDiff) : 0;

    if (editId) {
      const oldIdx = DB.sales.findIndex(s => s.id === editId);
      if (oldIdx === -1) { btn.disabled=false; alert('لم يُعثر على الفاتورة.'); return; }
      const oldInv = DB.sales[oldIdx];
      if (!canEditInvoice(oldInv)) { btn.disabled=false; alert(denyEditMessage(oldInv)); return; }
      logOriginalInvoiceBeforeEdit(oldInv);
      oldInv.items.forEach(oi => restoreStockForInvoiceItem(oi));
      currentInvoiceItems.forEach(ni => deductStockForInvoiceItem(ni));
      /* ══ هذا المسار (التعديل من شاشة البيع) كان قد فاتته كل إصلاحات
         مسار التعديل الآخر، فحُوِّل هنا إلى المنطق نفسه بالضبط.
         ثلاثة أخطاء كانت مجتمعة فيه:
         1) يخزّن كل ما دفعه العميل على الفاتورة بما فيه الفائض، فيُصرف
            الفائض مرة أخرى عند أي إرجاع لاحق.
         2) يتجاهل الرصيد الدائن المستهلك عند حساب الدين، فيُنشئ ديناً
            وهمياً بمقداره على عميل لا دين عليه.
         3) لا يسجّل تصحيح المبلغ بالنقصان في دفتر المقبوضات إطلاقاً،
            فينفصل النقد المسجَّل عن النقد الحقيقي بلا أثر يكشف الفارق. */
      const editCredUsed = r2(oldInv.creditUsed || 0);
      const roomOnInv    = r2(Math.max(0, subtotal - editCredUsed));
      const appliedPaid  = r2(Math.min(paid, roomOnInv));
      const newOverpay   = r2(paid - appliedPaid);
      const editNetDebt  = r2(Math.max(0, subtotal - appliedPaid - editCredUsed));

      // النقد الذي سلّمه العميل سابقاً — لا ما خُصم على الفاتورة منه
      const oldCash  = r2(oldInv.cashReceived != null ? oldInv.cashReceived : (oldInv.paid || 0));
      const paidDiff = r2(paid - oldCash);
      let editPayment = null;
      if (paidDiff !== 0) {
        const up = paidDiff > 0;
        editPayment = { id:wsUid('PAYEDIT-'), customerName:custName, amount: up ? paidDiff : r2(-paidDiff), type:payType,
          reason:`تعديل على الفاتورة ${editId} - ${up ? 'فرق مدفوعات' : 'تصحيح بالنقصان'}`,
          date:new Date().toLocaleString('ar-EG'), timestamp:Date.now(),
          signedBy:getCurrentUserName(), signedByUid:getCurrentUserUid(), receiverRole:getCurrentUserRole(),
          isRefund: !up, debtDistribution:[{ saleId: editId, amountApplied: up ? paidDiff : r2(-paidDiff) }] };
        DB.payments.push(editPayment);
      }

      /* تسوية الرصيد الدائن بالفرق لا بالقيمة، وإلا تضاعف الرصيد مع كل
         تعديل جديد لنفس الفاتورة. overpayCredited يحفظ ما سبق منحه منها. */
      const prevOverpay = r2(oldInv.overpayCredited != null
        ? oldInv.overpayCredited
        : Math.max(0, (oldInv.paid || 0) - (oldInv.subtotal || 0)));
      const creditDelta = r2(newOverpay - prevOverpay);
      if (creditDelta > 0) addCustomerCredit(custName, creditDelta);
      else if (creditDelta < 0) consumeCustomerCredit(custName, r2(-creditDelta));

      registerInvoiceItemsInCatalog(currentInvoiceItems);
      // التوقيع الأصلي يبقى كما هو: القواعد ترفض تغيير مالك الفاتورة، والتعديل يُسجَّل في editedBy
      DB.sales[oldIdx] = { ...oldInv, customerName:custName, customerPhone:custPhone, items:JSON.parse(JSON.stringify(currentInvoiceItems)), itemsTotal, discount, subtotal, paid:appliedPaid, cashReceived:paid, overpayCredited:newOverpay, oldDebtPay, netDebt:editNetDebt, creditUsed:editCredUsed, paymentType:payType, signedBy:oldInv.signedBy || getCurrentUserName(), signedByUid:oldInv.signedByUid || getCurrentUserUid(), editedAt:new Date().toLocaleString('ar-EG'), editedAtMs:Date.now(), editedBy:getCurrentUserName() };
      saveDB();
      generateA4InvoiceView(DB.sales[oldIdx], false);
      btn.disabled=false;
      refreshIcons();
      exitEditMode();
      reconcileAndSync(custName, { silent: true });
      showSuccessToast('✅ تم تعديل الفاتورة وتحديث المخزن والمدفوعات بنجاح.');
      (async () => {
        try {
          if (editPayment) await fsSet('payments', editPayment.id, editPayment);
          if (creditDelta !== 0) await syncCreditBalance(custName);
          await fsSet('sales', DB.sales[oldIdx].id, DB.sales[oldIdx]);
        } catch (e) { wsSilent('invoices:payments', e); }
      })();
    } else {
      const invId = wsUid('INV-');
      currentInvoiceItems.forEach(si => deductStockForInvoiceItem(si));
      // أي صنف جديد يُسجَّل بالكتالوج المشترك بعد خصم المخزون مباشرة،
      // فيصبح متاحاً فوراً كبند مالي في صفحة القياسات
      /* ══ تغيير اسم العميل في فاتورة لها حركة مالية ══
         الفاتورة تنتقل للاسم الجديد، لكن **دفعاتها ومرتجعاتها تبقى باسم
         القديم** — فهي سجلات مستقلة تحمل customerName بنفسها.

         والنتيجة حسابان مكسوران معاً: القديم عليه دفعات بلا بضاعة (فيظهر
         له رصيد دائن وهمي)، والجديد عليه بضاعة بلا دفعات (فيظهر مديناً
         بما دُفع فعلاً). ويُطالَب زبون بمال سدّده.

         والنقل التلقائي لكل السجلات ممكن، لكنه يعيد كتابة تاريخ مالي كامل
         بضغطة: إن كان التغيير تصحيحاً لخطأ إملائي فالنقل صحيح، وإن كان
         تحويل فاتورة لزبون آخر فهو تزوير — والنظام لا يميّز بينهما.

         فالمنع مع بيان الطريق: تُحذف الفاتورة (تبقى في السلة) وتُعاد
         بالاسم الصحيح، فيبقى لكل عملية أثرها. */
      if (oldInv && custName !== oldInv.customerName) {
        const hasMoney =
          r2(oldInv.paid || 0) > 0.001 ||
          DB.returns.some(r => r.originalInvId === oldInv.id) ||
          DB.payments.some(p => Array.isArray(p.debtDistribution) &&
                                p.debtDistribution.some(d => d.saleId === oldInv.id));
        if (hasMoney) {
          alert('⛔ لا يمكن تغيير اسم العميل في هذه الفاتورة.\n\n' +
                'لها حركة مالية مرتبطة باسم «' + oldInv.customerName + '» (دفعات أو مرتجعات).\n' +
                'وتغيير الاسم يترك تلك الحركة على الاسم القديم — فيظهر له رصيد لا يملكه، ' +
                'ويظهر الجديد مديناً بما دُفع فعلاً.\n\n' +
                'الطريق الصحيح: احذف هذه الفاتورة (تبقى في السلة) وأنشئ واحدة بالاسم الصحيح.');
          btn.disabled = false;
          return;
        }
      }

      registerInvoiceItemsInCatalog(currentInvoiceItems);
      if (overpay > 0) addCustomerCredit(custName, overpay);
      let finalNetDebt = netDebt;
      let creditUsed = 0;
      if (finalNetDebt > 0) {
        creditUsed = consumeCustomerCredit(custName, finalNetDebt);
        finalNetDebt = r2(finalNetDebt - creditUsed);
      }
      /* signedBy / signedByUid إلزاميان.
         كانت الفاتورة العادية تُحفظ بدونهما (المبدئية وحدها كانت تحملهما)، ولذلك:
         • قواعد Firestore ترفض إنشاءها من أي عضو غير المدير
           (allow create: ... newv('signedByUid','') == uid())، فتُحفظ على الجهاز
           ثم يفشل رفعها للسيرفر ولا يراها أحد غيره.
         • ولا يستطيع مُصدِرها تعديلها ضمن مهلة الساعتين، لأن ملكيتها غير مسجَّلة. */
      /* creditUsed إلزامي: بدونه لا يستطيع النظام إعادة رصيد العميل إن حُذفت
         الفاتورة لاحقاً. مثال: للعميل رصيد 400 استُهلك في هذه الفاتورة، ثم حذفها
         المدير — كان الرصيد يضيع نهائياً لأن المبلغ المستهلك غير مسجَّل أصلاً.
         (مسار الفاتورة المبدئية كان يحفظه، والعادي لا — ومن هنا جاء الفرق.) */
      /* paid على الفاتورة = ما خُصم منها فعلاً، لا كل ما دفعه العميل.
         الفائض صار رصيداً دائناً ومسجَّلاً في دفتر المقبوضات، فتخزينه هنا
         أيضاً يعني احتسابه مرتين. وأثره كارثي عند الإرجاع تحديداً:
         عميل دفع 733 عن فاتورة 575 فأخذ 158 رصيداً، ثم أرجع بضاعة بـ175 —
         كان النظام يحسب «دفع 733 واحتفظ بـ400» فيصرف له 333 نقداً
         ويترك له الـ158 رصيداً أيضاً. أي أن المحل يدفع الفائض مرتين.
         (cashReceived يحفظ ما سلّمه العميل فعلاً لأغراض الإيصال.) */
      const appliedPaid = r2(Math.min(paid, subtotal));
      const inv = { id:invId, date:new Date().toLocaleString('ar-EG'), timestamp:Date.now(), customerName:custName, customerPhone:custPhone, items:JSON.parse(JSON.stringify(currentInvoiceItems)), itemsTotal, discount, subtotal, paid:appliedPaid, cashReceived:paid, overpayCredited:(overpay || 0), oldDebtPay, netDebt:finalNetDebt, paymentType:payType, signedBy:getCurrentUserName(), signedByUid:getCurrentUserUid(), creditUsed };
      DB.sales.push(inv);
      const paymentsToSync = [];
      /* معرّف ثابت + سجل توزيع لدفعة البيع.
         كانت تُسجَّل بلا id إطلاقاً، فزر حذفها يبقى معطَّلاً للأبد ولا يستطيع
         المدير تصحيح مبلغ أُدخل خطأً. وبلا سجل توزيع لا يمكن عكس أثرها
         على الفاتورة حتى لو حُذفت بأي طريق آخر. */
      if (paid > 0) {
        const p1 = { id:'PAYINV-'+invId, invId, customerName:custName, amount:paid, type:payType, reason:`دفعة عن الفاتورة ${invId}`, date:inv.date, timestamp:Date.now(), signedBy:getCurrentUserName(), signedByUid:getCurrentUserUid(), receiverRole:getCurrentUserRole(), debtDistribution:[{ saleId: invId, amountApplied: appliedPaid }], creditAdded: overpay || 0 };
        DB.payments.push(p1); paymentsToSync.push(p1);
      }
      const touchedOtherSales = [];
      if (oldDebtPay > 0) {
        const p2 = { id:'PAYDEBT-'+invId, customerName:custName, amount:oldDebtPay, type:payType, reason:`سداد دين سابق مع الفاتورة ${invId}`, date:inv.date, timestamp:Date.now(), signedBy:getCurrentUserName(), signedByUid:getCurrentUserUid(), receiverRole:getCurrentUserRole() };
        DB.payments.push(p2); paymentsToSync.push(p2);
        let rem = oldDebtPay;
        /* سجل دقيق لما لُمِس من ديون فواتير أخرى.
           بدونه كان حذف هذه الفاتورة لاحقاً يترك ديون الفواتير الأخرى مسدَّدة
           بمبلغ لم يعد له وجود، ولا يملك النظام ما يعكسه به — فيكتفي بتحذير
           للمدير ليراجع الديون يدوياً. (مسار الفاتورة المبدئية كان يحفظه.) */
        const debtPayDistribution = [];
        for (let i=0; i<DB.sales.length-1; i++) {
          if (DB.sales[i].customerName===custName && DB.sales[i].netDebt>0) {
            if (rem >= DB.sales[i].netDebt) { const applied = DB.sales[i].netDebt; rem = r2(rem - applied); DB.sales[i].paid = r2(DB.sales[i].paid + applied); DB.sales[i].netDebt = 0; touchedOtherSales.push(DB.sales[i]); debtPayDistribution.push({ saleId: DB.sales[i].id, amountApplied: applied }); }
            else { DB.sales[i].paid = r2(DB.sales[i].paid + rem); DB.sales[i].netDebt = r2(DB.sales[i].netDebt - rem); debtPayDistribution.push({ saleId: DB.sales[i].id, amountApplied: rem }); rem=0; touchedOtherSales.push(DB.sales[i]); break; }
          }
        }
        inv.debtPayDistribution = debtPayDistribution;
        p2.debtDistribution = debtPayDistribution;          // ليُعكس أثرها إن حُذفت الدفعة وحدها
        p2.creditAdded = rem > 0.001 ? r2(rem) : 0;
        // الفائض بعد تغطية كل الديون السابقة يُحفظ رصيداً للعميل بدل ضياعه
        if (rem > 0.001) addCustomerCredit(custName, r2(rem));
      }
      saveDB();
      generateA4InvoiceView(inv, false);
      _savedThisSession = true;
      btn.innerHTML = '<i data-lucide="check-circle" class="w-5 h-5"></i> <span>تم الحفظ ✓ — جاري تجهيز فاتورة جديدة...</span>';
      btn.className = 'flex-1 py-4 bg-emerald-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 text-lg shadow-lg shadow-emerald-100 opacity-75 cursor-not-allowed';
      refreshIcons();
      (async () => {
        try {
          await fsSet('sales', inv.id, inv);
          await Promise.all(paymentsToSync.map(p => p.id ? fsSet('payments', p.id, p) : _payWithoutId(p)));
          await Promise.all(touchedOtherSales.map(s => fsUpdate('sales', s.id, { paid: s.paid, netDebt: s.netDebt })));
          if (creditUsed > 0) await syncCreditBalance(custName);
        } catch (e) { wsSilent('invoices:sales', e); }
      })();
      let creditMsg = creditUsed>0 ? ` — تم خصم ${fmt(creditUsed)} تلقائياً من رصيد العميل السابق.` : '';
      if (overpay > 0) creditMsg += ` — الزيادة ${fmt(overpay)} أُضيفت كرصيد دائن للعميل.`;
      reconcileAndSync(custName, { silent: true });
      /* تسوية الحساب القديم أيضاً: فاتورة انتقلت عنه قد تُغيّر حسابه.
         (لا تقع إلا لفاتورة بلا حركة مالية — الحارس أعلاه يمنع غيرها.) */
      if (oldInv && oldInv.customerName && oldInv.customerName !== custName) {
        reconcileAndSync(oldInv.customerName, { silent: true });
      }
      showSuccessToast(`✅ تم حفظ الفاتورة رقم ${invId} بنجاح!${creditMsg}`);
      // تفريغ تلقائي وبدء فاتورة جديدة — مع إبقاء معاينة آخر فاتورة ظاهرة للطباعة
      setTimeout(() => { resetPOS(false); }, 1800);
    }
  } catch (_saveErr) {
    console.error('saveCurrentInvoice:', _saveErr);
    try {
      btn.disabled = false;
      btn.innerHTML = '<i data-lucide="save" class="w-5 h-5"></i> <span id="save-btn-label">حفظ الفاتورة</span>';
      btn.className = 'flex-1 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 text-lg shadow-lg shadow-blue-100';
      refreshIcons();
    } catch (e) {}
    _savedThisSession = false;   // لم تُحفظ فعلاً: نسمح بإعادة المحاولة
    alert('⚠️ تعذّر إتمام حفظ الفاتورة.\n\n' +
          (_saveErr && _saveErr.message ? _saveErr.message : _saveErr) +
          '\n\nالبيانات ما زالت في الشاشة — راجعها وأعد المحاولة.');
  }
}

// ======================================================
// GENERATE A4 PREVIEW  — يدعم المبدئية والرسمية
// ======================================================
function generateA4InvoiceView(inv, isDraft) {
  isDraftMode = isDraft;
  // تطبيق إعدادات النظام على الفاتورة
  const _s = getSettings();
  // نسخة ثابتة من الفاتورة تُستخدم لبناء الصورة/الطباعة بتنسيق مستقل ونظيف
  _lastInvoiceForExport = {
    inv: JSON.parse(JSON.stringify(inv)),
    isDraft: !!isDraft,
    settings: JSON.parse(JSON.stringify(_s || {})),
    signedBy: inv.signedBy || (typeof getCurrentUserName === 'function' && getCurrentUserName() !== 'غير معروف' ? getCurrentUserName() : ''),
    signedByUid: inv.signedByUid || (typeof getCurrentUserUid === 'function' ? getCurrentUserUid() : '')
  };
  const _ni = document.getElementById('sys-name-invoice');
  const _ti = document.getElementById('sys-tagline-invoice');
  const _fp = document.getElementById('inv-footer-phone');
  const _fc = document.getElementById('inv-footer-custom');
  if (_ni) _ni.innerText = _s.name;
  if (_ti) _ti.innerText = _s.tagline;
  if (_fp) _fp.innerText = _s.phone || '';
  if (_fc) _fc.innerText = _s.footer || '';
  document.getElementById('live-invoice-preview').classList.remove('hidden');
  document.getElementById('inv-preview-id').innerText = inv.id;
  document.getElementById('inv-preview-date').innerText = inv.date;
  document.getElementById('inv-preview-cust-name').innerText = inv.customerName;
  document.getElementById('inv-preview-cust-phone').innerText = inv.customerPhone || 'لا يوجد';

  const tbody = document.getElementById('inv-preview-items');
  tbody.innerHTML = '';
  inv.items.forEach(i => {
    let tr = document.createElement('tr');
    tr.className = 'text-slate-700 border-b border-slate-100';
    tr.innerHTML = `<td class="py-2.5 font-medium">${escapeHtml(i.name)}</td><td class="py-2.5 text-center">${fmt(i.qty)}</td><td class="py-2.5 text-left">${fmt(i.price)}</td><td class="py-2.5 text-left font-bold">${fmt(i.total)}</td>`;
    tbody.appendChild(tr);
  });

  const wm = document.getElementById('draft-watermark');
  const draftWarn = document.getElementById('draft-warning-banner');
  const draftLbl = document.getElementById('draft-label');
  const finalLbl = document.getElementById('final-label');
  const confirmBtn = document.getElementById('btn-confirm-draft');
  const badge = document.getElementById('inv-status-badge');
  const draftTotalsView = document.getElementById('draft-totals-view');
  const finalTotalsView = document.getElementById('final-totals-view');
  const methodLine = document.getElementById('inv-preview-method-line');

  if (isDraft) {
    // وضع مبدئي: إجمالي فقط، بدون مدفوع/دين/طريقة دفع
    wm.classList.remove('hidden');
    draftWarn.classList.remove('hidden');
    draftLbl.classList.remove('hidden');
    finalLbl.classList.add('hidden');
    confirmBtn.classList.remove('hidden');
    badge.style.background = '#e1a709';
    badge.innerText = 'DRAFT';

    draftTotalsView.classList.remove('hidden');
    finalTotalsView.classList.add('hidden');
    methodLine.classList.add('hidden');
    document.getElementById('inv-preview-draft-total').innerText = fmt(inv.subtotal);
  } else {
    // وضع رسمي: كل التفاصيل
    wm.classList.add('hidden');
    draftWarn.classList.add('hidden');
    draftLbl.classList.add('hidden');
    finalLbl.classList.remove('hidden');
    confirmBtn.classList.add('hidden');
    badge.style.background = '#272928';
    badge.innerText = 'INVOICE';

    draftTotalsView.classList.add('hidden');
    finalTotalsView.classList.remove('hidden');
    methodLine.classList.remove('hidden');

    // إجمالي الفاتورة قبل الخصم، ثم الخصم، ثم الإجمالي بعده
    const hasDisc = (inv.discount || 0) > 0;
    const itemsTot = (inv.itemsTotal != null) ? inv.itemsTotal : r2((inv.subtotal || 0) + (inv.discount || 0));
    document.getElementById('inv-preview-items-total').innerText = fmt(itemsTot);
    document.getElementById('inv-preview-subtotal').innerText = fmt(inv.subtotal);

    const dRow  = document.getElementById('inv-preview-discount-row');
    const dVal  = document.getElementById('inv-preview-discount');
    const adRow = document.getElementById('inv-preview-after-discount-row');
    if (dRow && dVal) {
      dRow.classList.toggle('hidden', !hasDisc);
      if (hasDisc) dVal.innerText = '\u2212 ' + fmt(inv.discount);
    }
    if (adRow) adRow.classList.toggle('hidden', !hasDisc);

    // سطر الدين السابق يختفي إن لم يوجد، بدل عرض صفر بلا فائدة
    const oRow = document.getElementById('inv-preview-old-paid-row');
    if (oRow) oRow.classList.toggle('hidden', !((inv.oldDebtPay || 0) > 0));

    // شريط المتبقي: أحمر عند وجود دين، أخضر عند السداد الكامل
    const debtVal = inv.netDebt || 0;
    const bar = document.getElementById('inv-preview-debt-bar');
    const lbl = document.getElementById('inv-preview-debt-label');
    if (bar) bar.style.background = debtVal > 0 ? '#b12c1b' : '#047480';
    if (lbl) lbl.innerText = debtVal > 0 ? 'المتبقي:' : 'تم السداد بالكامل:';
    document.getElementById('inv-preview-paid').innerText = fmt(inv.paid || 0);
    document.getElementById('inv-preview-old-paid').innerText = fmt(inv.oldDebtPay || 0);
    document.getElementById('inv-preview-debt').innerText = fmt(inv.netDebt || 0);
    document.getElementById('inv-preview-method').innerText = inv.paymentType || '';
  }

  // التمرير للمعاينة داخل لوحة القسم نفسها
  setTimeout(() => {
    const prev = document.getElementById('live-invoice-preview');
    if (prev) prev.scrollIntoView({ behavior:'smooth', block:'start' });
  }, 80);
  // عرض التوقيع في الفاتورة
  const sigBox = document.getElementById('inv-sig-box');
  const sigName = document.getElementById('inv-sig-name');
  if (sigBox && sigName && inv.signedBy) {
    sigName.textContent = inv.signedBy;
    sigBox.style.display = '';
  } else if (sigBox) {
    const curUser = getCurrentUserName();
    if (curUser && curUser !== 'غير معروف') {
      sigName.textContent = curUser;
      sigBox.style.display = '';
    } else {
      sigBox.style.display = 'none';
    }
  }
  refreshIcons();
}

function resetPOS(hidePreview) {
  if (hidePreview === undefined) hidePreview = true;
  currentInvoiceItems = [];
  isDraftMode = false;
  draftData = null;
  _savedThisSession = false;
  ['pos-customer-name','pos-customer-phone','pos-amount-paid','pos-old-debt-pay','pos-edit-id','pos-discount'].forEach(id => { const e=document.getElementById(id); if(e) e.value=''; });
  document.getElementById('pos-customer-credit-hint')?.classList.add('hidden');
  document.getElementById('pos-dup-hint')?.classList.add('hidden');
  if (hidePreview) document.getElementById('live-invoice-preview').classList.add('hidden');
  document.getElementById('draft-mode-badge').classList.add('hidden');
  // استعادة زر الحفظ لحالته الأصلية
  const saveBtn = document.getElementById('btn-save-invoice');
  if (saveBtn) {
    saveBtn.disabled = false;
    saveBtn.innerHTML = '<i data-lucide="check-square"></i> <span id="save-btn-label">حفظ واعتماد الفاتورة</span>';
    saveBtn.className = 'flex-1 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 text-lg shadow-lg shadow-blue-100';
  }
  exitEditMode();
  renderPOSTable();
  refreshIcons();
}

function exitEditMode() {
  document.getElementById('pos-edit-id').value = '';
  document.getElementById('pos-title').innerText = 'إنشاء فاتورة بيع جديدة';
  document.getElementById('edit-mode-badge').classList.add('hidden');
  const lbl = document.getElementById('save-btn-label');
  if (lbl) lbl.innerText = 'حفظ واعتماد الفاتورة';
}

// ============================================================================
//  تصدير الفاتورة كصورة / طباعة  —  نسخة مُعاد بناؤها بالكامل
//  ----------------------------------------------------------------------------
//  المشكلة السابقة: كانت الصورة تُلتقط من عنصر الصفحة نفسه، وهذا العنصر مبني
//  على ألوان Tailwind الحديثة بصيغة oklch() التي لا تفهمها مكتبة html2canvas،
//  فكانت عملية "مشاركة صورة" تفشل أو تخرج بألوان خاطئة. كذلك كانت أسماء الملفات
//  ونصوص واتساب مكتوبة بترميز خاطئ فتظهر رموزاً غير مقروءة بدل الحروف العربية.
//  الحل: نبني ورقة فاتورة مستقلة بتنسيقات مباشرة بألوان hex فقط، ونلتقطها.
// ============================================================================

let _lastInvoiceForExport = null;   // { inv, isDraft, settings, signedBy }

function _ie(t) {
  return String(t == null ? '' : t).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}

// اسم ملف آمن ومقروء بالعربية
function _invoiceFileName() {
  const id = (_lastInvoiceForExport && _lastInvoiceForExport.inv && _lastInvoiceForExport.inv.id) || 'فاتورة';
  return 'فاتورة_' + String(id).replace(/[\\/:*?"<>|]/g, '-') + '.png';
}

/* يبني ورقة الفاتورة جاهزة للتصدير — HTML مستقل تماماً بألوان hex فقط */
function buildInvoiceExportHTML() {
  const d = _lastInvoiceForExport;
  if (!d) return '';
  const inv = d.inv || {}, isDraft = !!d.isDraft, s = d.settings || {};
  const items = inv.items || [];

  const itemsTotal = (inv.itemsTotal != null)
    ? inv.itemsTotal
    : r2((inv.subtotal || 0) + (inv.discount || 0));
  const hasDiscount = (inv.discount || 0) > 0;

  const INK   = '#111212';   // حبر داكن للنصوص الأساسية
  const SOFT  = '#505552';
  const LINE  = '#d1d4d3';
  const BRAND = isDraft ? '#157f4a' : '#111212';

  // ===== صفوف الأصناف =====
  const rows = items.map((i, idx) => `
      <tr style="background:${idx % 2 ? '#f9f8f6' : '#ffffff'};">
        <td style="padding:13px 14px;border-bottom:1px solid #e9ebea;font-weight:800;font-size:14.5px;color:${INK};">${_ie(i.name)}</td>
        <td style="padding:13px 14px;border-bottom:1px solid #e9ebea;text-align:center;font-weight:800;font-size:14.5px;color:${INK};direction:ltr;">${fmt(i.qty)}</td>
        <td style="padding:13px 14px;border-bottom:1px solid #e9ebea;text-align:left;font-weight:700;font-size:14.5px;color:${SOFT};direction:ltr;">${fmt(i.price)}</td>
        <td style="padding:13px 14px;border-bottom:1px solid #e9ebea;text-align:left;font-weight:900;font-size:15px;color:${INK};direction:ltr;">${fmt(i.total)}</td>
      </tr>`).join('');

  // ===== سطر في جدول الإجماليات =====
  const line = (label, value, color, opts) => {
    const o = opts || {};
    return `
      <tr>
        <td style="padding:${o.pad || '9px'} 16px;color:${o.labelColor || SOFT};font-size:${o.size || 14}px;font-weight:${o.weight || 700};${o.border ? 'border-top:2px solid ' + LINE + ';' : ''}">${_ie(label)}</td>
        <td style="padding:${o.pad || '9px'} 16px;text-align:left;direction:ltr;font-weight:900;font-size:${o.valueSize || o.size || 15}px;color:${color};${o.border ? 'border-top:2px solid ' + LINE + ';' : ''}">${_ie(value)}</td>
      </tr>`;
  };

  // ===== صندوق الإجماليات =====
  let totals;
  if (isDraft) {
    totals = `
      <table style="width:100%;border-collapse:collapse;background:#fffbf0;border:2px solid #e1a709;border-radius:14px;overflow:hidden;">
        ${hasDiscount ? line('إجمالي الفاتورة', fmt(itemsTotal), SOFT, { size: 14 }) : ''}
        ${hasDiscount ? line('الخصم', '\u2212 ' + fmt(inv.discount), '#157f4a', { size: 14 }) : ''}
        <tr>
          <td style="padding:15px 16px;font-weight:900;color:#3c4a43;font-size:16px;${hasDiscount ? 'border-top:2px solid #fcd260;' : ''}">
            ${hasDiscount ? 'الإجمالي بعد الخصم' : 'إجمالي الفاتورة'}
          </td>
          <td style="padding:15px 16px;text-align:left;direction:ltr;font-weight:900;color:#157f4a;font-size:26px;${hasDiscount ? 'border-top:2px solid #fcd260;' : ''}">${fmt(inv.subtotal)}</td>
        </tr>
      </table>`;
  } else {
    const debt = inv.netDebt || 0;
    totals = `
      <table style="width:100%;border-collapse:collapse;background:#fbfaf8;border:2px solid ${LINE};border-radius:14px;overflow:hidden;">
        ${line('إجمالي الفاتورة', fmt(itemsTotal), INK, { size: 14.5 })}
        ${hasDiscount ? line('الخصم', '\u2212 ' + fmt(inv.discount), '#157f4a', { size: 14.5 }) : ''}
        ${hasDiscount ? line('الإجمالي بعد الخصم', fmt(inv.subtotal), INK, { size: 15, valueSize: 18, weight: 900, border: true }) : ''}
        ${line('المبلغ المدفوع', fmt(inv.paid || 0), '#047480', { size: 14.5, border: !hasDiscount })}
        ${(inv.oldDebtPay || 0) > 0 ? line('مسدد من دين سابق', fmt(inv.oldDebtPay), '#14693e', { size: 14.5 }) : ''}
        <tr>
          <td style="padding:15px 16px;font-weight:900;font-size:16px;color:#ffffff;background:${debt > 0 ? '#b12c1b' : '#047480'};">
            ${debt > 0 ? 'المتبقي' : 'تم السداد بالكامل'}
          </td>
          <td style="padding:15px 16px;text-align:left;direction:ltr;font-weight:900;font-size:26px;color:#ffffff;background:${debt > 0 ? '#b12c1b' : '#047480'};">${fmt(debt)}</td>
        </tr>
      </table>`;
  }

  const watermark = isDraft
    ? `<div style="position:absolute;top:42%;left:0;right:0;text-align:center;font-size:96px;font-weight:900;color:#fbecc5;">مبدئية</div>`
    : '';

  const sig = d.signedBy
    ? `<div style="margin-top:22px;padding-top:14px;border-top:2px dashed ${LINE};display:flex;justify-content:space-between;align-items:flex-end;">
         <div>
           <div style="font-size:11.5px;color:#9da3a0;font-weight:800;">التوقيع</div>
           <div style="font-size:14px;color:${INK};font-weight:900;margin-top:5px;">${_ie(d.signedBy)}</div>
         </div>
         <div style="text-align:left;">
           <div style="font-size:11.5px;color:#9da3a0;font-weight:800;">الختم</div>
           <div style="width:74px;height:38px;border:2px dashed ${LINE};border-radius:9px;margin-top:5px;"></div>
         </div>
       </div>`
    : '';

  return `
  <div style="position:relative;width:794px;box-sizing:border-box;background:#ffffff;padding:0;
              font-family:'Cairo','Tajawal','Segoe UI',Arial,sans-serif;color:${INK};direction:rtl;text-align:right;
              -webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
              font-feature-settings:'liga' 1,'calt' 1;font-variant-ligatures:common-ligatures;">

    <!-- ===== الترويسة ===== -->
    <div style="background:${BRAND};padding:26px 36px 22px;position:relative;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;">
        <div>
          <div style="font-size:31px;font-weight:900;color:#ffffff;line-height:1.15;">${_ie(s.name || 'اللمسة الاخيرة')}</div>
          <div style="font-size:12.5px;color:rgba(255, 255, 255, .72);margin-top:6px;font-weight:700;">${_ie(s.tagline || '')}</div>
        </div>
        <div style="text-align:left;">
          <span style="display:inline-block;background:#ffffff;color:${BRAND};
                       padding:6px 15px;border-radius:7px;font-size:11.5px;font-weight:900;letter-spacing:2px;">
            ${isDraft ? 'DRAFT' : 'INVOICE'}</span>
          <div style="font-size:14px;margin-top:9px;color:#ffffff;font-weight:900;direction:ltr;">${_ie(inv.id)}</div>
          <div style="font-size:12px;color:rgba(255, 255, 255, .65);margin-top:3px;font-weight:700;">${_ie(inv.date)}</div>
        </div>
      </div>
    </div>
    <div style="height:5px;background:linear-gradient(90deg,#147d49,#1db267,#28dc82);"></div>

    <div style="padding:26px 36px 34px;position:relative;">
      ${watermark}
      <div style="position:relative;">

        <!-- ===== بيانات العميل ===== -->
        <table style="width:100%;border-collapse:separate;border-spacing:10px 0;margin-bottom:22px;">
          <tr>
            <td style="width:50%;padding:14px 16px;background:#f9f8f6;border-radius:12px;border-right:4px solid ${INK};">
              <div style="font-size:11.5px;color:#9da3a0;margin-bottom:5px;font-weight:800;">صادرة إلى</div>
              <div style="font-size:17px;font-weight:900;color:${INK};">${_ie(inv.customerName)}</div>
            </td>
            <td style="width:50%;padding:14px 16px;background:#f9f8f6;border-radius:12px;border-right:4px solid #9da3a0;">
              <div style="font-size:11.5px;color:#9da3a0;margin-bottom:5px;font-weight:800;">رقم الهاتف</div>
              <div style="font-size:17px;font-weight:900;color:${INK};direction:ltr;text-align:right;">${_ie(inv.customerPhone || 'لا يوجد')}</div>
            </td>
          </tr>
        </table>

        <!-- ===== الأصناف ===== -->
        <table style="width:100%;border-collapse:collapse;margin-bottom:22px;border:2px solid ${INK};border-radius:12px;overflow:hidden;">
          <thead>
            <tr style="background:${INK};color:#ffffff;">
              <th style="padding:13px 14px;text-align:right;font-weight:900;font-size:13.5px;">الصنف</th>
              <th style="padding:13px 14px;text-align:center;font-weight:900;font-size:13.5px;width:80px;">الكمية</th>
              <th style="padding:13px 14px;text-align:left;font-weight:900;font-size:13.5px;width:110px;">السعر</th>
              <th style="padding:13px 14px;text-align:left;font-weight:900;font-size:13.5px;width:120px;">الإجمالي</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>

        <!-- ===== الإجماليات ===== -->
        <div style="display:flex;justify-content:flex-start;">
          <div style="width:62%;">${totals}</div>
        </div>

        <!-- ===== التذييل ===== -->
        <div style="margin-top:28px;padding-top:16px;border-top:2px solid #e9ebea;
                    display:flex;justify-content:space-between;align-items:flex-end;font-size:12px;">
          <div style="line-height:1.9;">
            ${isDraft ? '' : `<div style="color:${SOFT};font-weight:700;">طريقة الدفع: <span style="color:${INK};font-weight:900;">${_ie(inv.paymentType || '')}</span></div>`}
            <div style="color:${INK};font-weight:900;direction:ltr;text-align:right;">${_ie(s.phone || '')}</div>
            <div style="color:#9da3a0;font-weight:700;">${_ie(s.footer || '')}</div>
          </div>
          <div style="color:${SOFT};font-weight:800;font-size:13px;">شكراً لثقتكم بنا</div>
        </div>
        ${sig}
      </div>
    </div>
  </div>`;
}

/* يضع الورقة خارج الشاشة، يلتقطها بدقة عالية، ثم يزيلها */
function captureInvoiceCanvas() {
  const html = buildInvoiceExportHTML();
  if (!html) return Promise.reject(new Error('no-invoice'));

  const holder = document.createElement('div');
  holder.setAttribute('dir', 'rtl');
  holder.style.cssText = 'position:fixed;top:0;left:-12000px;width:794px;background:#ffffff;z-index:-1;';
  holder.innerHTML = html;
  document.body.appendChild(holder);

  /* تحميل أوزان خط Cairo المستخدمة فعلياً قبل الالتقاط.
     لو التُقطت الصورة قبل جاهزية الخط، يسقط المتصفح على خط بديل
     لا يصل الحروف العربية، فتظهر الكلمات حروفاً منفصلة. */
  const loadFonts = () => {
    if (!document.fonts) return Promise.resolve();
    const weights = ['400 15px Cairo', '700 15px Cairo', '800 15px Cairo', '900 31px Cairo'];
    return Promise.all(weights.map(f => document.fonts.load(f).catch(() => {})))
      .then(() => document.fonts.ready)
      .catch(() => {});
  };

  return loadFonts()
    .then(() => new Promise(r => setTimeout(r, 150)))
    .then(() => ensureHtml2Canvas())          // تحميل عند الطلب — 8.9.1
    .then(() => wsCaptureSafe(() => html2canvas(holder.firstElementChild, {
      scale: 2,
      backgroundColor: '#ffffff',
      useCORS: true,
      logging: false,
      imageTimeout: 15000
    })))
    .then(canvas => { holder.remove(); return canvas; })
    .catch(err => { holder.remove(); throw err; });
}

// تُبقى للتوافق مع أي استدعاء قديم
function renderInvoiceCanvas() { return captureInvoiceCanvas(); }

function _withExportBtn(btn, work) {
  const orig = btn ? btn.innerHTML : '';
  if (btn) { btn.disabled = true; btn.innerText = 'جارٍ التحضير...'; }
  const done = () => { if (btn) { btn.innerHTML = orig; btn.disabled = false; refreshIcons(); } };
  return work().then(done, err => { console.error(err); done(); alert('تعذّر إنشاء صورة الفاتورة، حاول مجدداً.'); });
}

function _canvasToBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(b => b ? resolve(b) : reject(new Error('blob-failed')), 'image/png', 1);
  });
}

function _downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1500);
}

/* ===== حفظ الفاتورة كصورة PNG على الجهاز ===== */
function saveInvoiceAsImage() {
  if (!_lastInvoiceForExport) { alert('لا توجد فاتورة معروضة للحفظ.'); return; }
  const btn = document.getElementById('btn-save-invoice-image');
  _withExportBtn(btn, () => captureInvoiceCanvas()
    .then(_canvasToBlob)
    .then(blob => {
      _downloadBlob(blob, _invoiceFileName());
      showSuccessToast('🖼️ تم حفظ صورة الفاتورة في مجلد التنزيلات');
    }));
}

/* ===== مشاركة الفاتورة كصورة (واتساب/أي تطبيق) ===== */
function shareInvoiceDirectly() {
  if (!_lastInvoiceForExport) { alert('لا توجد فاتورة للمشاركة.'); return; }
  const btn = document.querySelector('[onclick="shareInvoiceDirectly()"]');
  _withExportBtn(btn, () => captureInvoiceCanvas()
    .then(_canvasToBlob)
    .then(blob => {
      const name = _invoiceFileName();
      const file = new File([blob], name, { type: 'image/png' });
      if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
        return navigator.share({
          files: [file],
          title: 'فاتورة مبيعات',
          text: 'فاتورة من ' + ((_lastInvoiceForExport.settings || {}).name || 'اللمسة الاخيرة')
        }).catch(() => { _downloadBlob(blob, name); });
      }
      _downloadBlob(blob, name);
      showSuccessToast('🖼️ تم حفظ صورة الفاتورة — يمكنك إرفاقها الآن');
    }));
}

/* ============================================================================
   إرسال الفاتورة عبر واتساب مباشرة إلى رقم العميل المكتوب
   ----------------------------------------------------------------------------
   ملاحظة تقنية مهمة: واتساب لا يسمح بإرفاق صورة وتحديد رقم المستلم في رابط
   واحد — هذا قيد من واتساب نفسه لا يمكن تجاوزه من المتصفح. لذلك:
     • نفتح محادثة الرقم مباشرة ومعها نص الفاتورة كاملاً (يعمل دائماً).
     • ومن يريد الصورة، تُحفظ له تلقائياً ليرفقها من المعرض بضغطة.
   ويمكن اختيار واتساب أعمال أو العادي — على أندرويد نستهدف التطبيق بعينه
   عبر intent، وعلى الآيفون ومتصفحات سطح المكتب نستخدم الرابط القياسي.
   ============================================================================ */

// يحوّل الرقم المحلي إلى صيغة دولية يقبلها واتساب: بلا + وبلا صفر بادئ
function normalizeWaNumber(raw, country) {
  let n = String(raw || '').replace(/[^\d+]/g, '');
  let cc = String(country || '').replace(/\D/g, '');
  if (n.startsWith('00')) n = n.slice(2);
  else if (n.startsWith('+')) n = n.slice(1);
  if (cc && n.startsWith('0')) n = cc + n.slice(1);        // 092... → 218 92...
  else if (cc && !n.startsWith(cc)) n = cc + n;            // 92...  → 218 92...
  return n;
}

function openWaModal() {
  const d = _lastInvoiceForExport;
  if (!d) { alert('لا توجد فاتورة معروضة للإرسال.'); return; }
  const s = d.settings || {};
  const modal = document.getElementById('wa-modal');
  const ccEl = document.getElementById('wa-country');
  const numEl = document.getElementById('wa-number');

  ccEl.value = s.countryCode || '218';
  let raw = String((d.inv || {}).customerPhone || '').replace(/[^\d+]/g, '');
  numEl.value = raw;

  document.getElementById('wa-modal-sub').textContent =
    'إلى: ' + ((d.inv || {}).customerName || 'العميل');

  const sync = () => {
    const full = normalizeWaNumber(numEl.value, ccEl.value);
    const prev = document.getElementById('wa-preview');
    prev.textContent = full ? '+' + full : 'أدخل رقم الهاتف';
    prev.style.color = full.length >= 8 ? '#6e7471' : '#d33722';
  };
  ccEl.oninput = sync; numEl.oninput = sync;
  sync();

  // شرح الطريقة المتاحة على هذا الجهاز
  const hint = document.getElementById('wa-hint');
  if (hint) {
    hint.innerHTML = canShareInvoiceImage()
      ? '\uD83D\uDCF7 ستُرسل <b>صورة الفاتورة</b>. بعد الضغط تظهر قائمة التطبيقات — اختر واتساب المطلوب ثم العميل.'
      : '\uD83D\uDCF7 ستُنسخ <b>صورة الفاتورة</b> وتُحفظ، ثم تُفتح محادثة العميل مباشرة — الصقها أو أرفقها من المعرض.';
  }

  modal.classList.remove('hidden');
  modal.classList.add('flex');
  if (!raw) setTimeout(() => numEl.focus(), 150);
}

function closeWaModal() {
  const modal = document.getElementById('wa-modal');
  modal.classList.add('hidden');
  modal.classList.remove('flex');
}

// هل يستطيع هذا المتصفح مشاركة ملف صورة فعلياً؟
function canShareInvoiceImage() {
  try {
    if (!navigator.canShare || !navigator.share) return false;
    const probe = new File([new Blob([''], { type: 'image/png' })], 'x.png', { type: 'image/png' });
    return navigator.canShare({ files: [probe] });
  } catch (e) { return false; }
}

// نسخ الصورة للحافظة (لتُلصق داخل المحادثة مباشرة)
function copyImageToClipboard(blob) {
  try {
    if (!navigator.clipboard || !window.ClipboardItem) return Promise.resolve(false);
    return navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
      .then(() => true).catch(() => false);
  } catch (e) { return Promise.resolve(false); }
}

// تعليق قصير يرافق الصورة (ليس بديلاً عنها)
function buildWaCaption() {
  const d = _lastInvoiceForExport;
  if (!d) return '';
  const inv = d.inv || {}, s = d.settings || {};
  let t = 'فاتورة رقم ' + (inv.id || '') + ' من ' + (s.name || 'اللمسة الاخيرة');
  t += '\nالإجمالي: ' + fmt(inv.subtotal);
  if (!d.isDraft && (inv.netDebt || 0) > 0) t += ' — المتبقي: ' + fmt(inv.netDebt);
  return t;
}

// يفتح محادثة الرقم في التطبيق المحدد (أعمال أو عادي)
function openWaChat(app, num, text) {
  const isAndroid = /Android/i.test(navigator.userAgent);
  const enc = encodeURIComponent(text || '');
  if (isAndroid) {
    const pkg = app === 'business' ? 'com.whatsapp.w4b' : 'com.whatsapp';
    window.location.href =
      'intent://send?phone=' + num + '&text=' + enc +
      '#Intent;scheme=whatsapp;package=' + pkg +
      ';S.browser_fallback_url=' + encodeURIComponent('https://wa.me/' + num + '?text=' + enc) + ';end';
  } else {
    window.location.href = 'https://wa.me/' + num + '?text=' + enc;
  }
}

/* ============================================================
   إرسال الفاتورة كصورة عبر واتساب
   ------------------------------------------------------------
   واتساب لا يقبل إرفاق صورة داخل رابط المحادثة — هذا قيد من واتساب
   نفسه. لذلك نسلك أقوى مسار متاح:
     1) مشاركة ملف الصورة عبر نظام التشغيل (Web Share) — تُرسل الصورة
        فعلياً، ويظهر واتساب أعمال والعادي كليهما في القائمة.
     2) إن لم يدعمها المتصفح: تُنسخ الصورة للحافظة وتُحفظ، ثم تُفتح
        محادثة الرقم في التطبيق المختار مباشرة، فتُلصق بضغطة.
   في الحالتين المُرسَل صورة لا نص.
   ============================================================ */
function launchWhatsApp(app) {
  const num = normalizeWaNumber(
    document.getElementById('wa-number').value,
    document.getElementById('wa-country').value
  );
  if (num.length < 8) { alert('رقم الهاتف غير صالح. تأكد من الرقم ومفتاح الدولة.'); return; }

  const appName = app === 'business' ? 'واتساب أعمال' : 'واتساب العادي';
  const btn = document.getElementById(app === 'business' ? 'wa-btn-business' : 'wa-btn-normal');
  const orig = btn ? btn.innerHTML : '';
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="text-xs">جارٍ تجهيز الصورة...</span>'; }
  const restore = () => { if (btn) { btn.innerHTML = orig; btn.disabled = false; } };

  const caption = buildWaCaption();

  captureInvoiceCanvas()
    .then(_canvasToBlob)
    .then(blob => {
      const file = new File([blob], _invoiceFileName(), { type: 'image/png' });

      // 1) المسار الأساسي: مشاركة الصورة نفسها
      if (canShareInvoiceImage() && navigator.canShare({ files: [file] })) {
        return navigator.share({ files: [file], title: 'فاتورة', text: caption })
          .then(() => {
            restore();
            closeWaModal();
            showSuccessToast('\uD83D\uDCF7 تم إرسال صورة الفاتورة');
          })
          .catch(err => {
            restore();
            // إلغاء المستخدم للقائمة ليس خطأً — لا نفتح شيئاً بعده
            if (err && (err.name === 'AbortError' || err.name === 'NotAllowedError')) return;
            return imageFallback(blob, app, num, caption, appName, restore);
          });
      }

      // 2) المسار البديل
      return imageFallback(blob, app, num, caption, appName, restore);
    })
    .catch(err => {
      console.error(err);
      restore();
      alert('تعذّر إنشاء صورة الفاتورة. تحقّق من اتصال الإنترنت وحاول مجدداً.');
    });
}

function imageFallback(blob, app, num, caption, appName, restore) {
  return copyImageToClipboard(blob).then(copied => {
    _downloadBlob(blob, _invoiceFileName());
    restore();
    closeWaModal();
    showSuccessToast(copied
      ? '\uD83D\uDCCB نُسخت صورة الفاتورة — الصقها في محادثة ' + appName
      : '\uD83D\uDDBC\uFE0F حُفظت صورة الفاتورة — أرفقها من المعرض في ' + appName);
    setTimeout(() => openWaChat(app, num, caption), 1000);
  });
}

function sendInvoiceWhatsApp() { openWaModal(); }

/* ===== طباعة / حفظ PDF ===== */
function downloadInvoiceImage() { _openInvoicePrintWindow(); }

function _openInvoicePrintWindow() {
  const html = buildInvoiceExportHTML();
  if (!html) { alert('لا توجد فاتورة للطباعة.'); return; }
  const invId = (_lastInvoiceForExport.inv || {}).id || 'فاتورة';

  const pw = window.open('', '_blank', 'width=880,height=1120,noopener,noreferrer');
  if (!pw) {
    alert('يرجى السماح بالنوافذ المنبثقة في المتصفح لإتمام الطباعة.\n(الإعدادات ← الخصوصية ← النوافذ المنبثقة)');
    return;
  }
  pw.document.open();
  pw.document.write(
    '<!doctype html><html dir="rtl" lang="ar"><head><meta charset="UTF-8">' +
    /* ⚠️ ثغرة 8.8.5 — عنوان نافذة الطباعة كان بلا تهريب.
       رقم الفاتورة يأتي من مستند Firestore، ومعرّف المستند يختاره من
       يكتبه — فأي أداة تتحدّث إلى Firestore مباشرة تستطيع إنشاء فاتورة
       معرّفها:  x</title><img src=y onerror="…">
       فيُغلق وسم العنوان وتُفتح حمولة تُنفَّذ في نافذة **من نفس المصدر**،
       ولها وصول كامل إلى جلسة من فتحها عبر window.opener.
       وبقيةُ هذه النافذة مهرَّبة بعناية — العنوان وحده فاته ذلك. */
    '<title>فاتورة ' + escapeHtml(invId) + '</title>' +
    '<link rel="preconnect" href="https://fonts.googleapis.com">' +
    '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&amp;family=Tajawal:wght@400;500;700;800;900&amp;family=JetBrains+Mono:wght@500;600;700&amp;display=swap" rel="stylesheet">' +
    '<style>' +
    '*{box-sizing:border-box;font-family:"Cairo",Arial,sans-serif;}' +
    'body{margin:0;padding:6mm;background:#ffffff;display:flex;justify-content:center;}' +
    '@page{size:A4;margin:6mm;}' +
    '@media print{body{padding:0;}}' +
    '</style></head><body>' + html +
    '<scr' + 'ipt>' +
    'function go(){setTimeout(function(){window.print();},400);}' +
    'if(document.fonts&&document.fonts.ready){document.fonts.ready.then(go);}else{setTimeout(go,1500);}' +
    '</scr' + 'ipt></body></html>'
  );
  pw.document.close();
}

// ============================================================
// 2. SALES ARCHIVE
// ============================================================
/* ترتيب أرشيف المبيعات — يُحفظ محلياً فيبقى بين الجلسات.
   بالتاريخ لمتابعة اليوم، وبالحروف للبحث عن زبون. */
let salesSort = (localStorage.getItem('inv_sales_sort') === 'name') ? 'name' : 'date';
function setSalesSort(m) {
  salesSort = (m === 'name') ? 'name' : 'date';
  salesArchivePage = 1;
  try { localStorage.setItem('inv_sales_sort', salesSort); } catch (e) {}
  renderSalesArchive();
}

/* ⚠️ 9.2.0 — شارة التكرار داخل أرشيف الفواتير نفسه.

   أداة التنظيف (🧹) تعرض المكرّرات في نافذة منفصلة، ومن لا يفتحها لا
   يعلم بها. والتكرار يُكتشف عادةً وأنت تتصفّح الأرشيف لا وأنت تبحث عنه.

   فتُحسب المجموعات مرة واحدة لكل رسمة (لا مرة لكل صف: ذلك يجعل الرسم
   تربيعياً فيبطئ الأرشيف الكبير)، وتوضع شارة على كل فاتورة لها توأم. */
let _dupIdSet = null;
let salesArchivePage = 1;
const SALES_ARCHIVE_PAGE_SIZE = 50;
let salesArchiveLastQuery = null;
function _refreshDupIndex() {
  _dupIdSet = new Set();
  try {
    wsFindDuplicateInvoices().forEach(g => g.forEach(s => _dupIdSet.add(s.id)));
  } catch (e) { /* لا يجوز أن يمنع خطأٌ هنا عرض الأرشيف */ }
}

function renderSalesArchive() {
  _refreshDupIndex();
  const body = document.getElementById('sales-archive-body');
  body.innerHTML = '';

  try {
    document.querySelectorAll('.sales-sort-btn').forEach(b => {
      const on = b.dataset.ssort === salesSort;
      b.className = 'sales-sort-btn flex-1 py-2 rounded-lg text-xs font-extrabold border-2 ' +
        (on ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-50 text-slate-500 border-slate-200');
    });
  } catch (e) {}

  const q = (document.getElementById('sales-arch-search')?.value || '').trim().toLowerCase();
  if (salesArchiveLastQuery !== q) { salesArchivePage = 1; salesArchiveLastQuery = q; }
  let rows = DB.sales.filter(inv => !q ||
    ((inv.customerName || '') + ' ' + (inv.id || '') + ' ' + (inv.customerPhone || '')).toLowerCase().includes(q));

  rows = rows.slice().sort((a, b) => {
    const na = a.customerName || '', nb = b.customerName || '';
    const ta = _sortKey(a), tb = _sortKey(b);
    return salesSort === 'name'
      ? na.localeCompare(nb, 'ar') || (tb - ta)
      : (tb - ta) || na.localeCompare(nb, 'ar');
  });

  const totalRows = rows.length;
  const pageCount = Math.max(1, Math.ceil(totalRows / SALES_ARCHIVE_PAGE_SIZE));
  if (salesArchivePage > pageCount) salesArchivePage = pageCount;
  const startRow = (salesArchivePage - 1) * SALES_ARCHIVE_PAGE_SIZE;
  const visibleRows = rows.slice(startRow, startRow + SALES_ARCHIVE_PAGE_SIZE);

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="7" class="p-8 text-center text-sm text-slate-400">' +
      (q ? 'لا فواتير مطابقة للبحث.' : 'لا توجد فواتير بعد.') + '</td></tr>';
    renderSalesArchivePager(0, 1);
    return;
  }
  visibleRows.forEach(inv => {
    let tr = document.createElement('tr');
    tr.className = 'text-sm text-slate-700 hover:bg-blue-50/40 transition-colors';
    const edited = inv.editedAt ? `<span class="text-xs text-amber-500 block">معدّلة</span>` : '';
    tr.innerHTML = `
      <td class="p-3">
        <button onclick="quickViewInvoice('${escapeAttr(inv.id)}')"
          style="font-family:monospace;font-size:12px;font-weight:900;color:#14693e;background:#eef7f3;border:1.5px solid #bbe2ce;border-radius:8px;padding:4px 10px;cursor:pointer;transition:all .15s;white-space:nowrap;"
          onmouseover="this.style.background='#d7eee2';this.style.transform='scale(1.03)'" onmouseout="this.style.background='#eef7f3';this.style.transform=''"
          title="انقر لعرض الفاتورة">${escapeHtml(inv.id)}</button>${edited}${
        (_dupIdSet && _dupIdSet.has(inv.id))
          ? `<span class="dup-badge" title="توجد فاتورة أخرى بنفس العميل ونفس القيمة خلال ساعة — راجعها من «الفواتير المكرّرة»">مكرّرة؟</span>`
          : ''}
      </td>
      <td class="p-3 text-xs text-slate-500">${escapeHtml(inv.date)}${inv.signedBy ? '<br><span class="text-blue-500 font-bold">✍️ '+escapeHtml(inv.signedBy)+'</span>' : ''}</td>
      <td class="p-3 font-medium">${escapeHtml(inv.customerName)}</td>
      <td class="p-3 font-bold">${fmt(inv.subtotal)}</td>
      <td class="p-3 text-emerald-600 font-bold">${fmt(inv.paid)}</td>
      <td class="p-3 font-bold ${inv.netDebt>0?'text-rose-600':'text-emerald-600'}">${fmt(inv.netDebt)}</td>
      <td class="p-3 text-center">
        <div class="flex flex-wrap gap-1 justify-center">
          ${canEditInvoice(inv)
            ? `<button onclick="openEditInvoice('${escapeAttr(inv.id)}')" style="padding:5px 10px;border-radius:8px;background:#fef2d2;color:#157f4a;border:none;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:pointer;">✏️ تعديل${isManager() ? '' : ` <span style="opacity:.75;font-size:9.5px;">${editWindowLabel(inv)}</span>`}</button>`
            : `<button onclick="alert(denyEditMessage(DB.sales.find(s=>s.id==='${escapeAttr(inv.id)}')))" style="padding:5px 10px;border-radius:8px;background:#f1f6f3;color:#9da3a0;border:none;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:not-allowed;" title="${isOwnInvoice(inv) ? 'انتهت مهلة الساعتين' : 'فاتورة عضو آخر'}">🔒 ${isOwnInvoice(inv) ? 'تعديل' : 'عضو آخر'}</button>`}
          <button onclick="openReturnForInvoice('${escapeAttr(inv.id)}')" style="padding:5px 10px;border-radius:8px;background:#fff8e5;color:#147d49;border:none;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:pointer;">↩️ إرجاع</button>
          ${isManager() ? `<button onclick="deleteInvoiceToTrash('${escapeAttr(inv.id)}')" style="padding:5px 10px;border-radius:8px;background:#fee2df;color:#d33722;border:none;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:pointer;">🗑️ حذف</button>` : ''}
        </div>
      </td>`;
    body.appendChild(tr);
  });
  renderSalesArchivePager(totalRows, pageCount);
}

function renderSalesArchivePager(totalRows, pageCount) {
  const body = document.getElementById('sales-archive-body');
  if (!body) return;
  const table = body.closest('table');
  if (!table) return;
  let box = document.getElementById('sales-archive-pager');
  if (!box) {
    box = document.createElement('div'); box.id = 'sales-archive-pager';
    box.className = 'flex items-center justify-between gap-2 mt-3 p-2 rounded-xl bg-slate-50 border border-slate-200';
    table.parentNode.insertBefore(box, table.nextSibling);
  }
  if (!totalRows) { box.innerHTML = ''; return; }
  const from = (salesArchivePage - 1) * SALES_ARCHIVE_PAGE_SIZE + 1;
  const to = Math.min(totalRows, salesArchivePage * SALES_ARCHIVE_PAGE_SIZE);
  box.innerHTML = `
    <button type="button" ${salesArchivePage <= 1 ? 'disabled' : ''} onclick="salesArchiveGoPage(${salesArchivePage - 1})" class="px-3 py-2 rounded-lg text-xs font-bold ${salesArchivePage <= 1 ? 'bg-slate-100 text-slate-300' : 'bg-white text-slate-700 border border-slate-200'}">السابق</button>
    <span class="text-[11px] font-bold text-slate-500">${from}–${to} من ${totalRows} · صفحة ${salesArchivePage}/${pageCount}</span>
    <button type="button" ${salesArchivePage >= pageCount ? 'disabled' : ''} onclick="salesArchiveGoPage(${salesArchivePage + 1})" class="px-3 py-2 rounded-lg text-xs font-bold ${salesArchivePage >= pageCount ? 'bg-slate-100 text-slate-300' : 'bg-white text-slate-700 border border-slate-200'}">التالي</button>`;
}

function salesArchiveGoPage(page) {
  const n = Number(page);
  if (!Number.isFinite(n) || n < 1) return;
  salesArchivePage = Math.max(1, Math.floor(n));
  renderSalesArchive();
}

// فتح الفاتورة بسرعة بالنقر على رقمها
// ============================================================
// رقم الفاتورة القابل للنقر — يُستخدم في كل الأقسام (المبيعات، الديون،
// المرتجعات، جرد الكميات، السجلات، الفواتير المعدّلة...) لفتح نفس الفاتورة أينما ظهر رقمها
// ============================================================
function invLinkHtml(id, opts) {
  if (!id) return '';
  opts = opts || {};
  const pad = opts.small ? '3px 8px' : '4px 10px';
  const size = opts.small ? '11px' : '12px';
  /* ⚠️ إصلاح 8.8.3 — رقم الفاتورة كان يُوضع خاماً داخل onclick="...('${id}')"
     وداخل نص الزر. ومعرّفات الفواتير القديمة أو المستوردة من نسخة
     احتياطية قد تحمل أي محرف، وعلامة اقتباس واحدة فيها تكسر الزر
     فلا يعمل بلا رسالة — وهو نفس الخلل الذي عولج في بقية الأزرار. */
  const safeId = escapeAttr(id);
  return `<button onclick="event.stopPropagation();quickViewInvoice('${safeId}')"
    style="font-family:monospace;font-size:${size};font-weight:900;color:#14693e;background:#eef7f3;border:1.5px solid #bbe2ce;border-radius:8px;padding:${pad};cursor:pointer;transition:all .15s;white-space:nowrap;"
    onmouseover="this.style.background='#d7eee2';this.style.transform='scale(1.03)'" onmouseout="this.style.background='#eef7f3';this.style.transform=''"
    title="انقر لعرض الفاتورة">${escapeHtml(id)}</button>`;
}

/* يحوّل أي إشارة لرقم فاتورة (مثل INV-1735...) داخل نص حر إلى رابط قابل
   للنقر، دون المساس ببقية النص.

   ⚠️ إصلاح 8.8.3 — كانت هذه الدالة تُعيد **النص الخام** بعد استبدال
   أرقام الفواتير وحدها، ونتيجتها تُوضع مباشرةً في innerHTML (سجل
   المقبوضات: بيان الدفعة). و«البيان» حقل حرّ يكتبه أي عضو من الواجهة.
   فمن يكتب في البيان وسم <img src=x onerror=...> ينفّذه على جهاز كل
   من يفتح سجل المقبوضات — بصلاحيات حسابه هو.

   الآن: يُهرَّب النص كاملاً أولاً، ثم تُبنى الروابط على النص المهرَّب.
   وترتيب الخطوتين ليس تفصيلاً: التهريب بعد البناء كان سيهرّب وسوم
   الروابط نفسها فتظهر كنص. */
function linkifyInvoiceRefs(text) {
  if (!text) return '';
  return escapeHtml(String(text)).replace(/INV-\d+/g, m => invLinkHtml(m, { small: true }));
}

function quickViewInvoice(id) {
  let inv = DB.sales.find(s => s.id === id);
  if (!inv) {
    // ربما الفاتورة في سلة المهملات — نعرضها للمدير بدل رسالة اعتذار
    const trashed = (DB.trash || []).find(t => t.data && t.data.id === id && t.type === 'invoice');
    if (trashed && isManager()) {
      generateA4InvoiceView(trashed.data, false);
      switchTab('pos');
      showSuccessToast('\uD83D\uDDD1\uFE0F هذه الفاتورة موجودة حالياً في سلة المهملات');
      return;
    }
    alert('تعذر العثور على هذه الفاتورة — ربما نُقلت إلى سلة المهملات أو حُذفت.');
    return;
  }
  switchTab('pos');
  generateA4InvoiceView(inv, false);
}

/* ============================================================
   جعل أي رقم فاتورة قابلاً للنقر تلقائياً في كل مكان
   يمسح النصوص المعروضة ويحوّل كل ما يطابق INV-<رقم> إلى زر يفتح
   الفاتورة نفسها، فتعمل الميزة حتى في الجداول التي تكتب الرقم كنص عادي.
   ============================================================ */
const INV_ID_RE = /INV-\d{6,}/g;
const _SKIP_TAGS = { INPUT:1, TEXTAREA:1, SCRIPT:1, STYLE:1, BUTTON:1, A:1, SELECT:1, OPTION:1 };

function _linkifyTextNode(node) {
  const text = node.nodeValue;
  if (!text || text.indexOf('INV-') === -1) return false;
  INV_ID_RE.lastIndex = 0;
  if (!INV_ID_RE.test(text)) return false;

  const frag = document.createDocumentFragment();
  let last = 0;
  INV_ID_RE.lastIndex = 0;
  let m;
  while ((m = INV_ID_RE.exec(text)) !== null) {
    if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'inv-chip';
    b.textContent = m[0];
    b.title = 'انقر لفتح الفاتورة';
    b.dataset.invId = m[0];
    frag.appendChild(b);
    last = m.index + m[0].length;
  }
  if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
  node.parentNode.replaceChild(frag, node);
  return true;
}

function autoLinkInvoiceIds(root) {
  if (!root) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      const p = n.parentNode;
      if (!p || _SKIP_TAGS[p.nodeName]) return NodeFilter.FILTER_REJECT;
      if (p.classList && p.classList.contains('inv-chip')) return NodeFilter.FILTER_REJECT;
      if (!n.nodeValue || n.nodeValue.indexOf('INV-') === -1) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  const targets = [];
  let n;
  while ((n = walker.nextNode())) targets.push(n);
  targets.forEach(_linkifyTextNode);
}

// نقرة واحدة على أي رقم فاتورة تفتحها
document.addEventListener('click', function (e) {
  const chip = e.target.closest && e.target.closest('.inv-chip');
  if (!chip) return;
  e.preventDefault();
  e.stopPropagation();
  quickViewInvoice(chip.dataset.invId);
});

// مراقبة المحتوى المعروض وتحويل أي رقم جديد فور ظهوره
(function watchInvoiceIds() {
  const start = () => {
    const root = document.getElementById('panel-scroll') || document.body;
    autoLinkInvoiceIds(root);
    let pending = false;
    const obs = new MutationObserver(muts => {
      if (pending) return;
      pending = true;
      requestAnimationFrame(() => {
        pending = false;
        obs.disconnect();                       // نوقف المراقبة أثناء تعديلنا لتفادي الدوران
        muts.forEach(mu => {
          mu.addedNodes.forEach(nd => {
            if (nd.nodeType === 1) autoLinkInvoiceIds(nd);
            else if (nd.nodeType === 3 && nd.parentNode) _linkifyTextNode(nd);
          });
        });
        obs.observe(root, { childList: true, subtree: true });
      });
    });
    obs.observe(root, { childList: true, subtree: true });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();

function previewArchiveInvoice(id) {
  let inv = DB.sales.find(s => s.id===id);
  if (inv) { switchTab('pos'); generateA4InvoiceView(inv, false); }
}

// حذف فاتورة نهائياً (متاح للمدير فقط) — يُعيد كل شيء كأن الفاتورة لم تُصدَر إطلاقاً:
// يعيد كميات المخزن، يحذف كل دفعة مرتبطة بها من سجل المدفوعات، يعكس أي دين سابق
// سُدِّد عبرها على فواتير أخرى، ويعيد أي رصيد دائن استُهلك عند إصدارها.
/* الوسيط الثاني `bulk` أُضيف في 9.0.1 لأداة تنظيف المكرّرات:
   الدالة تسأل تأكيداً لكل فاتورة، وحذف عشرين مكرّرة كان يعني عشرين
   نافذة متتالية — وهو ما يدفع المستخدم للضغط دون قراءة، فيفقد التأكيد
   معناه أصلاً. الأداة تأخذ تأكيداً واحداً شاملاً قبل البدء، ثم تمرّ
   هنا بلا سؤال. وكل ما عداها يسأل كما كان بلا تغيير. */
function deleteInvoiceToTrash(id, bulk) {
  if (getCurrentUserRole() !== 'manager') { alert('⛔ حذف الفواتير متاح للمدير فقط.'); return; }
  let idx = DB.sales.findIndex(s => s.id===id);
  if (idx===-1) return;
  let inv = DB.sales[idx];

  /* فاتورة عليها مرتجعات: الإرجاع غيّر أصنافها وقد أضاف للعميل رصيداً
     أو صرف له نقداً أو سدّد ديناً على فواتير أخرى. حذفها بعد ذلك يترك
     تلك الآثار قائمة بلا مصدر — رصيد لعميل بلا فاتورة، وبضاعة عادت
     للمخزن مرتين. لا نحاول فكّ هذه السلسلة تلقائياً: نوقف الحذف ونشرح.
     المخرج الصحيح: حذف فاتورة الإرجاع أولاً، ثم حذف الفاتورة. */
  const linkedReturns = (DB.returns || []).filter(r => r.originalInvId === id);
  if (linkedReturns.length) {
    alert('⛔ لا يمكن حذف هذه الفاتورة مباشرةً.\n\n' +
          'عليها ' + linkedReturns.length + ' عملية إرجاع (' +
          linkedReturns.map(r => r.id).join('، ') + ') غيّرت أصنافها وحساباتها.\n\n' +
          'احذف فاتورة الإرجاع أولاً من قسم المرتجعات، ثم أعد المحاولة.');
    return;
  }

  let warnMsg = '';
  if (inv.oldDebtPay > 0 && !inv.debtPayDistribution) {
    warnMsg = '\n\n⚠️ هذه فاتورة قديمة سدّدت جزءاً من دين سابق على فواتير أخرى، ولا يمكن تتبّع توزيعه بدقة تلقائياً — راجع ديون هذا العميل يدوياً بعد الحذف.';
  }
  if (!bulk && !confirm(`هل أنت متأكد من حذف هذه الفاتورة نهائياً؟\nسيُعاد المخزون، وتُحذف كل الدفعات المرتبطة بها، ويُعكَس أي دين سابق سُدِّد عبرها.${warnMsg}`)) return;
  let postMsg = '';

  // 1) إعادة المخزون
  inv.items.forEach(si => restoreStockForInvoiceItem(si));

  // 2) عكس الرصيد الدائن الذي استُهلك عند إصدارها (إن كان محفوظاً)
  if (inv.creditUsed > 0) addCustomerCredit(inv.customerName, inv.creditUsed);

  // 3) عكس توزيع سداد الدين السابق على الفواتير الأخرى (إن كان محفوظاً)
  const touchedOtherSales = [];
  (inv.debtPayDistribution || []).forEach(d => {
    const s = DB.sales.find(x => x.id === d.saleId);
    if (s) { s.paid = r2(s.paid - d.amountApplied); s.netDebt = r2(s.netDebt + d.amountApplied); touchedOtherSales.push(s); }
  });

  // 4) حذف كل دفعة مرتبطة بهذه الفاتورة من سجل المدفوعات (منقولة لسلة المهملات أيضاً، قابلة للاسترجاع)
  const linkedPayments = DB.payments.filter(p => p.invId === id || (p.reason && p.reason.includes(id)));
  linkedPayments.forEach(p => {
    const pIdx = DB.payments.indexOf(p);
    if (pIdx > -1) DB.payments.splice(pIdx, 1);
  });

  /* دفعات مستقلة سدّدت دين هذه الفاتورة (واصل سداد مسجَّل على حدة).
     هذه لا تُحذف مع الفاتورة — ولا يصح ذلك، فالمال دخل الصندوق فعلاً.
     لكن البضاعة المقابلة له اختفت من الدفاتر، فالمبلغ يصير حقاً للعميل:
     يُحوَّل إلى رصيد دائن باسمه. بدون ذلك كان النقد يبقى مسجَّلاً بلا
     بضاعة ولا دين ولا رصيد — أي فارق صامت في حساب العميل يظهر لاحقاً
     كأن المحل قبض مالاً بلا سبب. */
  let orphanPaid = 0;
  DB.payments.forEach(p => {
    if (!Array.isArray(p.debtDistribution)) return;
    p.debtDistribution.forEach(d => {
      if (d.saleId === id) orphanPaid = r2(orphanPaid + (d.amountApplied || 0));
    });
  });
  if (orphanPaid > 0.011) {
    addCustomerCredit(inv.customerName, orphanPaid);
    postMsg = ' وحُوِّل ' + fmt(orphanPaid) + ' كان مسدَّداً عليها إلى رصيد دائن للعميل.';
  }

  const trashEntry = { type:'فاتورة مبيعات', id:inv.id, deletedAt:Date.now(), dateStr:new Date().toLocaleString('ar-EG'), payload:inv, linkedPayments };
  DB.trash.push(trashEntry);
  DB.sales.splice(idx,1);
  saveDB();
  reconcileAndSync(inv.customerName, { silent: true });
  showSuccessToast('🗑️ تم حذف الفاتورة وعكس كل آثارها بنجاح.' + postMsg);

  /* ══ ترتيب الكتابات مقصود ══
       السلة **أولاً** ثم حذف الفاتورة. لو انعكس الترتيب وفشلت كتابة
       السلة، ضاعت الفاتورة بلا نسخة. وبهذا الترتيب أسوأ ما يقع نسخة
       زائدة في السلة — وهي ظاهرة وقابلة للحذف.

       ولا try/catch هنا: fsSet وأخواتها لا ترمي أخطاءً إطلاقاً (تُعيد
       Promise.resolve دائماً لتعمل دون اتصال). الإبلاغ عن الفشل يقع في
       _wsTrack: يعرض رسالة على الشاشة ويسجّل في وحدة التحكّم، ويميّز
       انقطاع الشبكة — وهو ليس خطأً لأن البيانات تُرفع تلقائياً بعده.
       فكتلة catch فارغة هنا كانت تُوهم بمعالجة لا تقع. */
  fsSet('trash', trashEntry.id, trashEntry);
  fsDelete('sales', inv.id);
  linkedPayments.filter(p => p.id).forEach(p => fsDelete('payments', p.id));
  touchedOtherSales.forEach(s2 => fsUpdate('sales', s2.id, { paid: s2.paid, netDebt: s2.netDebt }));
  if (inv.creditUsed > 0 || orphanPaid > 0.011) syncCreditBalance(inv.customerName);
}

// حذف دفعة/واصل سداد من سجل المدفوعات نهائياً (متاح للمدير فقط) — إن كانت الدفعة سدّدت
// ديناً سابقاً على فواتير أخرى ولا يوجد سجل توزيع دقيق، يُعرض تنبيه بذلك لمراجعته يدوياً.
function deletePaymentToTrash(id) {
  if (!isManager()) { alert('\u26D4 حذف المبالغ المستلمة متاح للمدير فقط.'); return; }
  const idx = DB.payments.findIndex(p => p.id === id);
  if (idx === -1) return;
  const p = DB.payments[idx];
  /* ══ عكس أثر الدفعة على الفواتير ══
     الخلل السابق: الدالة كانت تحذف سجل الدفعة فقط ولا تمس الفواتير
     إطلاقاً، رغم أن رسالة التأكيد تَعِد صراحةً بأن «المبلغ سيُحسب ديناً
     غير مسدَّد مجدداً». النتيجة: المبلغ يختفي من المقبوضات بينما يبقى
     العميل مسجَّلاً كأنه دفع — فيضيع الدين من الدفاتر بلا أثر. */
  const dist = Array.isArray(p.debtDistribution) ? p.debtDistribution : null;
  const legacy = !dist;

  /* تعديل الفاتورة يضبط «المدفوع» عليها كقيمة مطلقة يختارها المدير،
     فيُبطل سجل توزيع الدفعات الأقدم منه: المبلغ المسجَّل فيها لم يعد
     يطابق ما هو مخصوم على الفاتورة فعلاً. حذف دفعة كهذه يُنقص من دفتر
     المقبوضات أكثر مما يُعيد من الدين، فتختل الحسابات بفارق صامت.
     نمنع الحذف ونوجّه للمخرج الصحيح بدل إفساد الدفاتر. */
  if (dist) {
    /* الحارس كان يقارن بـ new Date(inv.editedAt) — و editedAt نص محلّي
       عربي («٢٤‏/٨‏/٢٠٢٦، ٨:٠١ ص») لا يفهمه محرّك جافاسكريبت، فتعطي
       Invalid Date ثم NaN. وأي مقارنة مع NaN تعطي false دائماً، فكان
       الحارس **معطّلاً بالكامل** ولا يمنع شيئاً إطلاقاً رغم وجوده.
       الآن نعتمد ختماً رقمياً (editedAtMs) لا يعتمد على لغة الجهاز. */
    const staleOn = dist
      .map(d => DB.sales.find(x => x.id === d.saleId))
      .filter(inv => inv && Number(inv.editedAtMs) > 0 &&
                     Number(inv.editedAtMs) > (p.timestamp || 0));
    if (staleOn.length) {
      alert('⛔ لا يمكن حذف هذه الدفعة.\n\n' +
            'الفاتورة ' + staleOn.map(x => x.id).join('، ') +
            ' عُدِّلت بعد تسجيل هذه الدفعة، فلم يعد توزيعها مطابقاً لما هو مخصوم عليها.\n\n' +
            'المخرج الصحيح: افتح الفاتورة وصحّح المبلغ المدفوع فيها مباشرةً، أو احذف الفاتورة كاملة.');
      return;
    }
  }
  const warnMsg = legacy
    ? '\n\n⚠️ دفعة قديمة سُجِّلت قبل تفعيل سجل التوزيع، فلا يمكن إرجاع الدين تلقائياً — راجع ديون هذا العميل يدوياً بعد الحذف.'
    : '';
  if (!confirm(`هل تريد حذف هذه الدفعة (${fmt(p.amount)} من ${p.customerName})؟ سيُحسب المبلغ ديناً غير مسدَّد مجدداً.${warnMsg}`)) return;

  /* فحص قبلي: هل يمكن عكس أثر الدفعة كاملاً؟
     إن كانت الفاتورة قد تغيّرت بعدها (إرجاع خفّض المدفوع مثلاً) فلن نستطيع
     إرجاع كامل المبلغ إلى الدين، بينما يخرج المبلغ كاملاً من دفتر المقبوضات
     — فيبقى فارق صامت يظهر لاحقاً كنقص في الصندوق لا يعرف أحد سببه. */
  if (dist) {
    const shortfall = dist.reduce((a, d) => {
      const inv = DB.sales.find(x => x.id === d.saleId);
      if (!inv) return a;   // الفاتورة نفسها حُذفت — لا شيء نعكسه عليها
      return r2(a + Math.max(0, r2((d.amountApplied || 0) - (inv.paid || 0))));
    }, 0);
    if (shortfall > 0.011) {
      alert('⛔ لا يمكن حذف هذه الدفعة.\n\n' +
            'تغيّرت الفاتورة بعد تسجيلها (إرجاع أو تسوية)، فلم يبقَ عليها ما يكفي لعكس ' +
            fmt(shortfall) + ' من المبلغ.\n\n' +
            'المخرج الصحيح: تراجع عن الإرجاع أو التعديل أولاً، أو احذف الفاتورة كاملة.');
      return;
    }
  }

  /* حارس وقائي: هل يجعل حذفُ هذه الدفعة صافي نقد العميل سالباً؟
     يعني أن استرداداً خرج من الصندوق اعتماداً عليها. حذفها يترك مالاً
     خارجاً بلا مصدر — نمنعه ونوجّه لحذف الاسترداد أولاً. */
  {
    const netAfter = r2((DB.payments || [])
      .filter(x => x.customerName === p.customerName && x.id !== p.id)
      .reduce((a, x) => a + (x.isRefund ? -(x.amount || 0) : (x.amount || 0)), 0));
    if (netAfter < -0.011) {
      alert('⛔ لا يمكن حذف هذه الدفعة.\n\n' +
            'حذفها يجعل ما صُرف نقداً لـ' + p.customerName + ' أكثر مما دخل منه بمقدار ' +
            fmt(-netAfter) + '.\n\nاحذف الاسترداد النقدي المرتبط أولاً، ثم أعد المحاولة.');
      return;
    }
  }

  const touchedSales = [];
  if (dist) {
    dist.forEach(d => {
      const inv = DB.sales.find(x => x.id === d.saleId);
      if (!inv) return;
      const back = r2(Math.min(d.amountApplied || 0, inv.paid || 0));
      if (back <= 0) return;
      inv.paid = r2(inv.paid - back);
      inv.netDebt = r2(Math.max(0, inv.subtotal - invoiceSettled(inv)));
      touchedSales.push(inv);
    });
  }
  /* الفائض الذي تحوّل رصيداً للعميل يُسحب أيضاً، وإلا بقي رصيد بلا مقابل.
     لكن إن كان ذلك الرصيد قد صُرف نقداً أو استُهلك في فاتورة لاحقة فلا
     سبيل لاستعادته — وحذف الدفعة عندها يترك الدفاتر غير متزنة بصمت.
     نمنع الحذف ونشرح السبب بدل إفساد الحسابات. */
  let creditPulled = 0;
  if (p.creditAdded > 0) {
    const availCred = getCustomerCredit(p.customerName);
    if (availCred < r2(p.creditAdded) - 0.011) {
      alert('⛔ لا يمكن حذف هذه الدفعة الآن.\n\n' +
            'الفائض منها (' + fmt(p.creditAdded) + ') أُضيف رصيداً للعميل، ' +
            'ولم يبقَ من ذلك الرصيد سوى ' + fmt(availCred) + ' — صُرف الباقي نقداً أو استُهلك في فاتورة لاحقة.\n\n' +
            'ألغِ صرف الرصيد أو احذف الفاتورة التي استهلكته أولاً، ثم أعد المحاولة.');
      return;
    }
    creditPulled = consumeCustomerCredit(p.customerName, r2(p.creditAdded));
  }

  DB.payments.splice(idx, 1);
  const trashEntry = { type:'دفعة/واصل سداد', id:p.id, deletedAt:Date.now(), dateStr:new Date().toLocaleString('ar-EG'), payload:p };
  DB.trash.push(trashEntry);
  reconcileCustomerAccounts(p.customerName, { silent: true });   // اشتقاق فوري بعد عكس الأثر
  saveDB();
  renderPaymentsLedger();
  renderAllSections();
  if (document.getElementById('manager-collect-modal') && !document.getElementById('manager-collect-modal').classList.contains('hidden')) renderReceivedAmountsList();
  const backMsg = touchedSales.length
    ? ` وأُعيد الدين على ${touchedSales.length} فاتورة.`
    : (legacy ? '' : ' (لم تكن قد سدّدت ديناً على أي فاتورة).');
  const credMsg = creditPulled > 0 ? ` وسُحب ${fmt(creditPulled)} من رصيد العميل.` : '';
  showSuccessToast('🗑️ تم حذف الدفعة.' + backMsg + credMsg);
  (async () => {
    try {
      await fsSet('trash', trashEntry.id, trashEntry);
      await fsDelete('payments', p.id);
      // الاشتقاق يعيد حساب كل فواتير العميل ويرفعها — أدق من رفع المتأثرة وحدها
      reconcileAndSync(p.customerName, { silent: true });
    } catch (e) { wsSilent('invoices:trash', e); }
  })();
}


// ============================================================
// EDIT INVOICE MODAL
// ============================================================
let editingInvItems = [];

function openEditInvoice(id) {
  const inv = DB.sales.find(s => s.id===id);
  if (!inv) return;
  if (!canEditInvoice(inv)) { alert(denyEditMessage(inv)); return; }
  document.getElementById('modal-inv-id').value = id;
  document.getElementById('edit-modal-inv-id-label').textContent = id;
  document.getElementById('modal-cust-name').value = inv.customerName;
  document.getElementById('modal-cust-phone').value = inv.customerPhone||'';
  /* نملأ الخانة بما سلّمه العميل نقداً (cashReceived) لا بما خُصم على
     الفاتورة (paid). الفرق يظهر مع الدفع الزائد تحديداً:
     عميل دفع 733 عن فاتورة 575 فأخذ 158 رصيداً — الفاتورة تحفظ paid=575.
     لو ملأنا الخانة بـ575 وقارنّاها بـ733 عند الحفظ، لظهر «تصحيح بالنقصان»
     بـ158 فيُسجَّل استرداد نقدي لم يحدث، ويُسحب من رصيد العميل 158
     يستحقها — لمجرد أن المدير فتح الفاتورة وحفظها بلا أي تغيير. */
  document.getElementById('modal-paid').value = (inv.cashReceived != null ? inv.cashReceived : inv.paid);
  editingInvItems = JSON.parse(JSON.stringify(inv.items));
  renderModalItems();
  recalcModalDebt();
  // إخفاء صف الإضافة
  document.getElementById('modal-add-item-row').style.display = 'none';
  document.getElementById('modal-new-item-name').value = '';
  document.getElementById('modal-new-item-qty').value = '';
  document.getElementById('modal-new-item-price').value = '';
  document.getElementById('edit-modal').classList.remove('hidden');
}

function renderModalItems() {
  const c = document.getElementById('modal-items-list');
  c.innerHTML = '';
  editingInvItems.forEach((item, idx) => {
    let div = document.createElement('div');
    div.style.cssText = 'background:white;border:1.5px solid #d1fae5;border-radius:14px;padding:12px;display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;';
    div.innerHTML = `
      <div style="font-size:13px;font-weight:800;color:#176069;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</div>
      <div style="display:flex;flex-direction:column;gap:2px;">
        <label style="font-size:10px;font-weight:700;color:#9da3a0;">كمية</label>
        <input type="number" value="${escapeHtml(item.qty)}" min="0.01" step="0.01"
          onchange="updateModalItem(${idx},'qty',this.value)"
          style="width:72px;padding:6px 8px;border-radius:8px;border:1.5px solid #d6f7fb;background:#f1fcfd;font-size:13px;font-weight:800;font-family:Cairo,sans-serif;text-align:center;outline:none;">
      </div>
      <div style="display:flex;flex-direction:column;gap:2px;">
        <label style="font-size:10px;font-weight:700;color:#9da3a0;">سعر</label>
        <input type="number" value="${escapeHtml(item.price)}" min="0" step="0.01"
          onchange="updateModalItem(${idx},'price',this.value)"
          style="width:80px;padding:6px 8px;border-radius:8px;border:1.5px solid #d6f7fb;background:#f1fcfd;font-size:13px;font-weight:800;font-family:Cairo,sans-serif;text-align:center;outline:none;">
      </div>
      <button onclick="removeEditModalItem(${idx})"
        style="width:30px;height:30px;border-radius:8px;border:none;background:#fee2df;color:#d33722;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;">🗑</button>`;
    c.appendChild(div);
  });
  if (!editingInvItems.length) {
    c.innerHTML = '<div style="text-align:center;padding:16px;color:#9da3a0;font-size:13px;font-weight:700;">لا توجد أصناف — أضف صنفاً جديداً</div>';
  }
}

function removeEditModalItem(idx) {
  editingInvItems.splice(idx, 1);
  renderModalItems();
  recalcModalDebt();
}

function addEditModalItem() {
  document.getElementById('modal-add-item-row').style.display = '';
  document.getElementById('modal-new-item-name').focus();
}

function suggestModalNewItem() {
  const q = document.getElementById('modal-new-item-name').value.trim().toLowerCase();
  const box = document.getElementById('modal-new-item-suggestions');
  if (!q) { box.classList.add('hidden'); return; }
  const matches = DB.store.filter(s => s.name.toLowerCase().includes(q)).slice(0, 8);
  if (!matches.length) { box.classList.add('hidden'); return; }
  box.innerHTML = matches.map(s => `<div onclick="selectModalNewItem('${escapeAttr(s.name)}',${Number(s.price) || 0})"
    style="padding:10px 14px;cursor:pointer;font-size:13px;font-weight:700;border-bottom:1px solid #f1f6f3;"
    onmouseover="this.style.background='#f1fcfd'" onmouseout="this.style.background=''">${escapeHtml(s.name)} — ${fmt(s.price)}</div>`).join('');
  box.classList.remove('hidden');
}

function selectModalNewItem(name, price) {
  document.getElementById('modal-new-item-name').value = name;
  document.getElementById('modal-new-item-price').value = price;
  document.getElementById('modal-new-item-qty').value = 1;
  document.getElementById('modal-new-item-suggestions').classList.add('hidden');
  document.getElementById('modal-new-item-qty').focus();
}

function confirmAddModalItem() {
  const name  = document.getElementById('modal-new-item-name').value.trim();
  // إصلاح 8.8: كمية وسعر الصنف الجديد كانا يُقرآن صفراً بالأرقام العربية
  const qty   = r2(document.getElementById('modal-new-item-qty').value) || 0;
  const price = r2(document.getElementById('modal-new-item-price').value) || 0;
  if (!name) { alert('يرجى إدخال اسم الصنف.'); return; }
  if (qty <= 0) { alert('يرجى إدخال كمية صحيحة.'); return; }
  editingInvItems.push({ name, qty: r2(qty), price: r2(price), total: r2(qty * price) });
  renderModalItems();
  recalcModalDebt();
  document.getElementById('modal-add-item-row').style.display = 'none';
  document.getElementById('modal-new-item-name').value = '';
  document.getElementById('modal-new-item-qty').value = '';
  document.getElementById('modal-new-item-price').value = '';
}

function updateModalItem(idx, field, val) {
  /* رفض الصفر والسالب، كما في شاشة البيع تماماً.
     كانت هذه النافذة تقبل أي رقم بلا فحص: كمية سالبة تُنتج سطراً بقيمة
     سالبة يخصم من الفاتورة بلا أن يظهر كخصم — أي تخفيض صامت لا أثر له
     في أي تقرير. (شاشة البيع كانت ترفضه، فاختلف المساران في شيء واحد.) */
  const v = r2(val);
  if (isNaN(v) || v <= 0) { renderModalItems(); recalcModalDebt(); return; }
  editingInvItems[idx][field] = v;
  editingInvItems[idx].total = r2(editingInvItems[idx].qty * editingInvItems[idx].price);
  recalcModalDebt();
}

function recalcModalDebt() {
  const itemsTotalR = r2(editingInvItems.reduce((a,i)=>a+(i.total||0),0));
  const mInv = DB.sales.find(x => x.id === document.getElementById('modal-inv-id').value);

  /* المعاينة تستخدم **نفس** معادلة الحفظ حرفياً، لا معادلة مبسّطة.
     كانت تحسب الخصم `min(الخصم القديم, إجمالي الأصناف)` بينما الحفظ
     يوزّعه بنسبة ما تبقّى. مثال: فاتورة 1000 بخصم 100، يحذف المدير نصف
     الأصناف — تعرض النافذة إجمالي 400 ويُحفظ 450. فيرى رقماً ويوقّع على
     غيره، ويكتشف الفارق لاحقاً بلا تفسير. */
  const prevItemsTotal = (mInv && mInv.itemsTotal > 0) ? mInv.itemsTotal : itemsTotalR;
  let discR = (mInv && mInv.discount) || 0;
  if (prevItemsTotal > 0 && discR > 0) discR = r2(discR * (itemsTotalR / prevItemsTotal));
  discR = r2(Math.min(discR, itemsTotalR));

  const subtotal = r2(itemsTotalR - discR);
  const credUsed = r2((mInv && mInv.creditUsed) || 0);
  const cash = r2(document.getElementById('modal-paid').value) || 0;   // إصلاح 8.8
  const room = r2(Math.max(0, subtotal - credUsed));
  const applied = r2(Math.min(cash, room));
  const debt = r2(Math.max(0, subtotal - applied - credUsed));
  const debtEl = document.getElementById('modal-debt-display');
  const subEl  = document.getElementById('modal-subtotal-display');
  if (debtEl) {
    debtEl.innerText = fmt(debt);
    debtEl.style.color = debt > 0 ? '#b92512' : '#179baa';
  }
  if (subEl)  subEl.innerText  = fmt(subtotal);
}

function saveEditedInvoice() {
  const id = document.getElementById('modal-inv-id').value;
  const idx = DB.sales.findIndex(s => s.id===id);
  if (idx===-1) return;
  const oldInv = DB.sales[idx];
  // حماية أخيرة: قد تكون المهلة انتهت والنافذة مفتوحة منذ فترة
  if (!canEditInvoice(oldInv)) { alert(denyEditMessage(oldInv)); closeEditModal(); return; }
  logOriginalInvoiceBeforeEdit(oldInv);
  oldInv.items.forEach(oi => restoreStockForInvoiceItem(oi));
  editingInvItems.forEach(ni => deductStockForInvoiceItem(ni));
  const itemsTotalM = r2(editingInvItems.reduce((a,i)=>a+(i.total||0),0));
  /* الخصم يُوزَّع بنسبة ما تبقّى من البضاعة، تماماً كما في الإرجاع.
     كان يبقى مبلغاً ثابتاً، فحذف نصف الأصناف أثناء التعديل يُبقي الخصم
     كاملاً على النصف الباقي — ويخسر المحل الفرق. */
  const prevItemsTotal = (oldInv.itemsTotal > 0) ? oldInv.itemsTotal : itemsTotalM;
  let discM = oldInv.discount || 0;
  if (prevItemsTotal > 0 && discM > 0) discM = r2(discM * (itemsTotalM / prevItemsTotal));
  discM = r2(Math.min(discM, itemsTotalM));
  const subtotal = r2(itemsTotalM - discM);
  const newPaid = r2(document.getElementById('modal-paid').value) || 0;   // إصلاح 8.8
  const newName = document.getElementById('modal-cust-name').value.trim();
  const newPhone = document.getElementById('modal-cust-phone').value.trim();
  const oldCashModal = r2(oldInv.cashReceived != null ? oldInv.cashReceived : (oldInv.paid || 0));
  const paidDiff = r2(newPaid - oldCashModal);
  const editCredUsed = r2(oldInv.creditUsed || 0);

  let editPayment2 = null;
  if (paidDiff !== 0) {
    /* الفرق يُسجَّل في دفتر المقبوضات في الاتجاهين.
       كان يُسجَّل عند الزيادة فقط: فلو صحّح المدير مبلغاً أُدخل خطأً
       (500 → 300) يبقى الدفتر يقول 500 بينما الفاتورة تقول 300،
       فينفصل النقد المسجَّل عن النقد الحقيقي بلا أثر يكشف الفارق. */
    const up = paidDiff > 0;
    editPayment2 = {
      id: wsUid('PAYEDIT-'),
      customerName:newName, amount: up ? paidDiff : r2(-paidDiff),
      type:'كاش',
      reason:`تعديل فاتورة ${id} - ${up ? 'فرق مدفوعات' : 'تصحيح بالنقصان'}`,
      date:new Date().toLocaleString('ar-EG'), timestamp:Date.now(),
      signedBy:getCurrentUserName(), signedByUid:getCurrentUserUid(), receiverRole:getCurrentUserRole(),
      isRefund: !up,                       // النقصان يُحسب خروجاً لا دخولاً
      debtDistribution: [{ saleId: id, amountApplied: up ? paidDiff : r2(-paidDiff) }]
    };
    DB.payments.push(editPayment2);
  }

  /* الدين = الإجمالي − (النقد + الرصيد الدائن المستهلك).
     إغفال creditUsed كان يُنشئ ديناً وهمياً بمقدار الرصيد كاملاً:
     فاتورة 600 سُدِّد منها 150 من رصيد العميل و450 نقداً ودينها صفر،
     يفتحها المدير ويغيّر رقم الهاتف فقط فيظهر على العميل دين 150
     لا مقابل له — أي أنه يُحاسَب على رصيده مرتين.

     وما زاد عن قيمة الفاتورة يصير رصيداً دائناً، لا يُخزَّن عليها.
     تخزينه كان يجعل الإرجاع لاحقاً يصرفه نقداً مرة أخرى. */
  const roomOnInvoice = r2(Math.max(0, subtotal - editCredUsed));
  const editApplied = r2(Math.min(newPaid, roomOnInvoice));
  const editOverpay = r2(newPaid - editApplied);
  /* بالفرق لا بالقيمة: تعديل الفاتورة مرتين كان يمنح الفائض مرتين. */
  const prevCredited = r2(oldInv.overpayCredited != null
    ? oldInv.overpayCredited
    : Math.max(0, (oldInv.paid || 0) - (oldInv.subtotal || 0)));
  const editCreditDelta = r2(editOverpay - prevCredited);
  if (editCreditDelta > 0) addCustomerCredit(newName, editCreditDelta);
  else if (editCreditDelta < 0) consumeCustomerCredit(newName, r2(-editCreditDelta));
  const newNetDebt = r2(Math.max(0, subtotal - editApplied - editCredUsed));
  DB.sales[idx] = { ...oldInv, customerName:newName, customerPhone:newPhone, items:JSON.parse(JSON.stringify(editingInvItems)), itemsTotal:itemsTotalM, discount:discM, subtotal, paid:editApplied, cashReceived:newPaid, overpayCredited:editOverpay, netDebt:newNetDebt, creditUsed:editCredUsed, editedAt:new Date().toLocaleString('ar-EG'), editedAtMs:Date.now(), editedBy:getCurrentUserName() };
  saveDB();
  closeEditModal();
  reconcileAndSync(newName, { silent: true });
  showSuccessToast('✅ تم حفظ تعديلات الفاتورة بنجاح.');
  (async () => {
    try {
      if (editPayment2) await fsSet('payments', editPayment2.id, editPayment2);
      if (editCreditDelta !== 0) await syncCreditBalance(newName);
      await fsSet('sales', DB.sales[idx].id, DB.sales[idx]);
    } catch (e) { wsSilent('invoices:payments', e); }
  })();
}

function closeEditModal() {
  document.getElementById('edit-modal').classList.add('hidden');
  editingInvItems = [];
}

function openEditInvoiceInPOS(id) {
  const inv = DB.sales.find(s => s.id===id);
  if (!inv) return;
  if (!canEditInvoice(inv)) { alert(denyEditMessage(inv)); return; }
  switchTab('pos');
  document.getElementById('pos-edit-id').value = id;
  document.getElementById('pos-customer-name').value = inv.customerName;
  document.getElementById('pos-customer-phone').value = inv.customerPhone||'';
  // نفس السبب: ما سلّمه العميل نقداً، لا ما خُصم على الفاتورة منه
  document.getElementById('pos-amount-paid').value = (inv.cashReceived != null ? inv.cashReceived : inv.paid);
  document.getElementById('pos-old-debt-pay').value = inv.oldDebtPay||0;
  const dEl = document.getElementById('pos-discount');
  if (dEl) dEl.value = inv.discount ? inv.discount : '';
  document.getElementById('pos-payment-type').value = inv.paymentType||'كاش';
  currentInvoiceItems = JSON.parse(JSON.stringify(inv.items));
  document.getElementById('pos-title').innerText = `تعديل الفاتورة: ${id}`;
  document.getElementById('edit-mode-badge').classList.remove('hidden');
  const lbl = document.getElementById('save-btn-label');
  if (lbl) lbl.innerText = 'حفظ التعديلات';
  renderPOSTable();
}

// ============================================================
// 3. DEBTS
// ============================================================
/* ============================================================
   فحص سلامة الحسابات — للبيانات المسجَّلة قبل إصلاح الأخطاء
   ------------------------------------------------------------
   الإصلاحات تمنع تكرار الأخطاء، لكنها لا تُصلّح ما سُجِّل خطأً من قبل.
   هذا الفحص يكشف السجلات المشوّهة ليصحّحها المدير يدوياً وهو يعلم.
   يُستدعى تلقائياً مرة عند دخول المدير، ويدوياً بـ wsAuditFinances().
   ============================================================ */

/* ══════════════════════════════════════════════════════════════════════
   أداة تنظيف الفواتير المكرّرة — 9.0.1
   ══════════════════════════════════════════════════════════════════════
   المنع في مسار الحفظ يوقف التكرار من اليوم فصاعداً، ولا يمسّ ما تراكم
   قبله. وهذه الأداة للماضي.

   وهي **لا تحذف شيئاً من تلقاء نفسها**. تعرض المجموعات المتطابقة وتترك
   القرار للمدير، لسبب واضح: قد يكون العميل اشترى الشيء نفسه مرتين فعلاً،
   ولا أحد يعرف ذلك إلا صاحب المحل. والحذف يمرّ بسلة المهملات لا بالمحو —
   فإن أخطأ، الرجوع ممكن.

   والمعيار: نفس العميل، ونفس الأصناف بكمياتها وأسعارها، خلال ساعة واحدة.
   الساعةُ حدٌّ متحفّظ عمداً: التكرار الآلي يقع خلال دقائق، وما تباعد
   أكثر من ذلك يُرجَّح أنه بيع حقيقي، فلا نعرضه أصلاً حتى لا يُحذف خطأً. */
function wsFindDuplicateInvoices() {
  /* ⚠️ 9.0.3 — المعيار صار «نفس الزبون ونفس السعر» كما هو مطلوب عملياً.
     كان تطابق الأصناف سطراً سطراً، وهو أضيق مما ينبغي: الفاتورة المكرّرة
     قد تُعاد بأصناف مجمَّعة أو بترتيب مختلف فتفلت من الفحص، بينما المبلغ
     واحد لا يتغيّر. والمبلغ هو ما ينتبه له صاحب المحل أصلاً. */
  const key = (s) => (s.customerName || '') + '|' + r2(s.subtotal || 0);
  const groups = {};
  (DB.sales || []).forEach(s => {
    const k = key(s);
    if (!k || k === '|') return;
    (groups[k] = groups[k] || []).push(s);
  });
  const HOUR = 60 * 60 * 1000;
  const dups = [];
  Object.values(groups).forEach(list => {
    if (list.length < 2) return;
    const sorted = list.slice().sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    let run = [sorted[0]];
    for (let i = 1; i < sorted.length; i++) {
      if ((sorted[i].timestamp || 0) - (run[run.length - 1].timestamp || 0) < HOUR) run.push(sorted[i]);
      else { if (run.length > 1) dups.push(run); run = [sorted[i]]; }
    }
    if (run.length > 1) dups.push(run);
  });
  return dups;
}

function wsShowDuplicateInvoices() {
  if (!isManager()) { alert('⛔ هذه الأداة للمدير فقط.'); return; }
  const dups = wsFindDuplicateInvoices();
  if (!dups.length) { alert('✅ لا توجد فواتير مكرّرة في الأرشيف.'); return; }

  let extra = 0, money = 0;
  dups.forEach(g => { extra += g.length - 1; g.slice(1).forEach(s => { money = r2(money + (s.subtotal || 0)); }); });

  let msg = '⚠️ وُجدت ' + dups.length + ' مجموعة فواتير مكرّرة\n' +
            'النسخ الزائدة: ' + extra + ' فاتورة، بقيمة ' + fmt(money) + '\n' +
            '(أي أن مبيعاتك المعروضة أعلى من الحقيقة بهذا المقدار)\n\n';
  dups.slice(0, 8).forEach(g => {
    msg += '• ' + (g[0].customerName || '') + ' — ' + fmt(g[0].subtotal || 0) + '\n';
    g.forEach((s, i) => { msg += '    ' + (i === 0 ? 'يُبقى: ' : 'زائدة: ') + s.id + '  (' + (s.date || '') + ')\n'; });
  });
  if (dups.length > 8) msg += '… و' + (dups.length - 8) + ' مجموعة أخرى\n';
  msg += '\nاضغط «موافق» لنقل النسخ الزائدة إلى سلة المهملات\n' +
         '(تُبقى الأقدم من كل مجموعة، ويمكن استرجاع أي منها).';

  if (!confirm(msg)) return;
  if (!confirm('تأكيد أخير: سيُنقل ' + extra + ' فاتورة إلى السلة.\n' +
               'يُستعاد المخزون ويُصحَّح الدين تلقائياً لكل واحدة.')) return;

  let done = 0;
  dups.forEach(g => g.slice(1).forEach(s => {
    try { deleteInvoiceToTrash(s.id, true); done++; } catch (e) { console.error('dup delete', s.id, e); }
  }));
  saveDB();
  alert('✅ نُقلت ' + done + ' فاتورة مكرّرة إلى سلة المهملات.\n' +
        'راجع «سلة المهملات» إن أردت استرجاع أي منها.');
}

/* ═════════════════════════════════════════════════════════════════════
   تنبيه الدفعات المتشابهة — للمراجعة فقط، لا يحذف ولا يعدّل أي حركة.
   الهدف: كشف ضغطتين على زر السداد أو تكرار واصل بنفس المبلغ لنفس العميل
   خلال فترة قصيرة، مع إبقاء القرار للمدير لأن تكرار المبلغ قد يكون مشروعاً.
   ═════════════════════════════════════════════════════════════════════ */
function wsFindDuplicatePayments() {
  const rows = Array.isArray(DB.payments) ? DB.payments.filter(p => p && !p.isRefund && p.customerName && Number(p.amount) > 0) : [];
  const groups = [];
  const used = new Set();
  const WINDOW = 15 * 60 * 1000;

  // 1) تكرار صريح لنفس receiptId (إن وجد في أكثر من سجل بسبب استيراد/مزامنة قديمة).
  const byReceipt = {};
  rows.forEach(p => {
    const rid = p.receiptId || p.id;
    if (!rid) return;
    (byReceipt[rid] = byReceipt[rid] || []).push(p);
  });
  Object.values(byReceipt).forEach(list => {
    if (list.length > 1) {
      const clean = list.slice().sort((a,b)=>(a.timestamp||0)-(b.timestamp||0));
      groups.push({ reason:'نفس رقم الواصل مكرر', rows:clean });
      clean.forEach(p => used.add(p.id));
    }
  });

  // 2) نفس العميل + نفس المبلغ خلال 15 دقيقة. هذا تنبيه فقط لأن التكرار قد يكون مقصوداً.
  const byCustomerAmount = {};
  rows.forEach(p => {
    const nm = typeof wsNormName === 'function' ? wsNormName(p.customerName) : String(p.customerName).trim().toLowerCase();
    const key = nm + '|' + r2(p.amount);
    (byCustomerAmount[key] = byCustomerAmount[key] || []).push(p);
  });
  Object.values(byCustomerAmount).forEach(list => {
    const sorted = list.slice().sort((a,b)=>(a.timestamp||0)-(b.timestamp||0));
    let run = [];
    sorted.forEach(p => {
      const t = Number(p.timestamp || 0);
      run = run.filter(x => !t || !x.timestamp || t - Number(x.timestamp) <= WINDOW);
      run.push(p);
      if (run.length >= 2) {
        const candidate = run.slice();
        const fresh = candidate.filter(x => !used.has(x.id));
        if (fresh.length >= 2) {
          groups.push({ reason:'نفس العميل ونفس المبلغ خلال 15 دقيقة', rows:candidate });
          candidate.forEach(x => used.add(x.id));
        }
      }
    });
  });
  return groups;
}

function updatePaymentDuplicateAlert() {
  const badge = document.getElementById('payment-duplicate-alert-badge');
  if (!badge) return;
  const groups = wsFindDuplicatePayments();
  if (!groups.length) {
    badge.classList.add('hidden');
    badge.textContent = '⚠️ دفعات متشابهة';
    return;
  }
  const count = groups.reduce((n,g)=>n + Math.max(1, g.rows.length - 1), 0);
  badge.classList.remove('hidden');
  badge.textContent = `⚠️ ${count} دفعة تحتاج مراجعة`;
}

function wsShowDuplicatePayments() {
  const groups = wsFindDuplicatePayments();
  if (!groups.length) {
    alert('✅ سلامة الحسابات\n\nلم أجد دفعات متشابهة بشكل مريب في السجلات الحالية.');
    return;
  }
  let msg = `⚠️ تنبيه سلامة الحسابات\n\nوجد النظام ${groups.length} مجموعة دفعات متشابهة تحتاج مراجعة.\n`;
  groups.slice(0, 12).forEach((g, idx) => {
    const first = g.rows[0];
    msg += `\n${idx + 1}) ${g.reason}\n`;
    msg += `العميل: ${first.customerName}\nالمبلغ: ${fmt(first.amount)}\n`;
    g.rows.forEach(p => msg += `   • ${p.id || '—'} — ${p.date || '—'} — ${p.type || '—'}\n`);
  });
  if (groups.length > 12) msg += `\n… وهناك ${groups.length - 12} مجموعات أخرى.`;
  msg += '\n\nهذه مجرد إشارة للمراجعة — لم يتم حذف أو تعديل أي دفعة.';
  alert(msg);
}
window.wsFindDuplicatePayments = wsFindDuplicatePayments;
window.wsShowDuplicatePayments = wsShowDuplicatePayments;
window.updatePaymentDuplicateAlert = updatePaymentDuplicateAlert;

function wsAuditFinances(silent) {
  const issues = [];

  // تنبيه دفعات متشابهة: يظهر في سلامة الحسابات ليُراجعها المستخدم قبل اتخاذ أي إجراء.
  wsFindDuplicatePayments().forEach(g => {
    const first = g.rows[0];
    issues.push({
      kind: 'دفعات متشابهة تحتاج مراجعة',
      id: g.rows.map(p => p.id || '—').join(' / '),
      who: first.customerName,
      detail: `${g.reason} — ${fmt(first.amount)} — ${g.rows.map(p => p.date || '—').join(' | ')}`
    });
  });

  DB.sales.forEach(inv => {
    // دين بالسالب: أثر خلل الفاتورة المبدئية القديم — يطرح من ديون العميل الأخرى
    if (inv.netDebt < -0.001) {
      issues.push({ kind:'دين بالسالب', id:inv.id, who:inv.customerName,
        detail:`الدين ${fmt(inv.netDebt)} — يُفترض أن يكون رصيداً للعميل بمقدار ${fmt(-inv.netDebt)}` });
    }
    // المدفوع أكبر من الإجمالي بلا رصيد مقابل
    const over = r2(invoiceSettled(inv) - (inv.subtotal || 0));
    if (over > 0.001 && getCustomerCredit(inv.customerName) < over - 0.001) {
      issues.push({ kind:'دفع زائد بلا رصيد', id:inv.id, who:inv.customerName,
        detail:`دفع ${fmt(inv.paid)} عن فاتورة ${fmt(inv.subtotal)} — الزائد ${fmt(over)} لا يقابله رصيد` });
    }
    // الدين لا يطابق (الإجمالي − المدفوع)
    // دين الاسترداد الزائد جزء مشروع من الدين، وله حقله الخاص
    const expected = r2(Math.max(0, (inv.subtotal || 0) - invoiceSettled(inv)) + (inv.overRefundDebt || 0));
    if (Math.abs(r2((inv.netDebt || 0) - expected)) > 0.011) {
      issues.push({ kind:'دين غير مطابق', id:inv.id, who:inv.customerName,
        detail:`المسجَّل ${fmt(inv.netDebt)} — والمفروض ${fmt(expected)} (الإجمالي ${fmt(inv.subtotal)} ناقص المُسدَّد ${fmt(invoiceSettled(inv))})` });
    }
    if ((inv.overRefundDebt || 0) > 0.011) {
      issues.push({ kind:'استرداد زائد', id:inv.id, who:inv.customerName,
        detail:`صُرف للعميل ${fmt(inv.overRefundDebt)} أكثر مما دفع — مُسجَّل ديناً عليه` });
    }
    // مجموع الأصناف لا يطابق الإجمالي المسجَّل
    const it = r2((inv.items || []).reduce((a,i)=>a+(i.total||0), 0));
    const sub = r2(it - (inv.discount || 0));
    if (Math.abs(r2(sub - (inv.subtotal || 0))) > 0.011) {
      issues.push({ kind:'إجمالي غير مطابق', id:inv.id, who:inv.customerName,
        detail:`مجموع الأصناف ${fmt(it)} ناقص الخصم ${fmt(inv.discount||0)} = ${fmt(sub)} — والمسجَّل ${fmt(inv.subtotal)}` });
    }
  });

  // أرصدة عملاء بالسالب
  Object.keys(DB.creditBalances || {}).forEach(n => {
    if (DB.creditBalances[n] < -0.001) {
      issues.push({ kind:'رصيد بالسالب', id:'—', who:n, detail:`الرصيد ${fmt(DB.creditBalances[n])}` });
    }
  });

  /* ══ الفحص المحوري: ترابط حساب كل عميل ══
     لكل عميل يجب أن يتحقق دائماً:
        البضاعة المُسلَّمة = صافي النقد الداخل + الدين الباقي − رصيده لدينا
     أي خلل في ترابط عمليتين (حذف بترتيب خاطئ، إرجاع على فاتورة معدَّلة،
     رصيد بلا مصدر…) يكسر هذه المعادلة فوراً مهما كان سببه — فهي شبكة
     أمان تكشف ما لا تتوقّعه الفحوص المفردة أعلاه، وتكشف كذلك التشوّه
     الموروث من سجلات قديمة سُجِّلت قبل الإصلاحات. */
  const allNames = {};
  DB.sales.forEach(s2 => { allNames[s2.customerName] = 1; });
  Object.keys(DB.creditBalances || {}).forEach(n => { allNames[n] = 1; });
  (DB.payments || []).forEach(p2 => { if (p2.customerName) allNames[p2.customerName] = 1; });

  Object.keys(allNames).forEach(n => {
    const inv = DB.sales.filter(s2 => s2.customerName === n);
    const goods = r2(inv.reduce((a, s2) => a + (s2.subtotal || 0), 0));
    const debts = r2(inv.reduce((a, s2) => a + (s2.netDebt || 0), 0));
    const cashIn = r2((DB.payments || []).filter(p2 => p2.customerName === n)
      .reduce((a, p2) => a + (p2.isRefund ? -(p2.amount || 0) : (p2.amount || 0)), 0));
    const cred = getCustomerCredit(n);
    const gap = r2(goods - r2(cashIn + debts - cred));
    if (Math.abs(gap) > 0.011) {
      issues.push({ kind:'ترابط حساب مكسور', id:'—', who:n,
        detail:`بضاعة ${fmt(goods)} ≠ نقد ${fmt(cashIn)} + دين ${fmt(debts)} − رصيد ${fmt(cred)} · الفارق ${fmt(gap)}` });
    }
    // رصيد لعميل لا فواتير له ولا دفعات إطلاقاً = رصيد يتيم بلا مصدر
    if (cred > 0.011 && !inv.length && cashIn === 0) {
      issues.push({ kind:'رصيد بلا مصدر', id:'—', who:n,
        detail:`رصيد ${fmt(cred)} بلا أي فاتورة أو دفعة تقابله` });
    }
  });

  if (!silent) {
    if (!issues.length) { alert('✅ فحص الحسابات: لا توجد أي سجلات مشوّهة.'); return issues; }
    const byKind = {};
    issues.forEach(i => { (byKind[i.kind] = byKind[i.kind] || []).push(i); });
    let msg = `⚠️ فحص الحسابات: ${issues.length} سجلاً يحتاج مراجعة\n`;
    Object.keys(byKind).forEach(k => {
      msg += `\n■ ${k} (${byKind[k].length})\n`;
      byKind[k].slice(0, 6).forEach(i => { msg += `   ${i.id} — ${i.who}\n     ${i.detail}\n`; });
      if (byKind[k].length > 6) msg += `   … و${byKind[k].length - 6} غيرها\n`;
    });
    msg += '\nهذه سجلات قديمة سُجِّلت قبل إصلاح الأخطاء. صحّحها يدوياً بتعديل الفاتورة المعنية.';
    alert(msg);
    console.table(issues);
  }
  return issues;
}
window.wsAuditFinances = wsAuditFinances;

/* ما سُدِّد فعلاً على الفاتورة = النقد المدفوع + الرصيد الدائن الذي استُهلك.
   الخلل الذي تعالجه: عند إصدار الفاتورة يُخصم رصيد العميل من الدين، لكن
   حقل paid لا يزيد — فيبقى «الإجمالي ناقص المدفوع» أكبر من الدين الحقيقي.
   وكانت حسابات الإرجاع تعتمد على paid وحده، فتظن أن العميل ما زال مديناً
   بمقدار الرصيد المستهلك، وتُنقص من حقّه بنفس المقدار.
   مثال واقعي: فاتورة 600 سُدِّد منها 150 من رصيده و450 نقداً. أرجع بضاعة
   بـ200 فيُصرف له 50 فقط بدل 200 — أي أن 150 من ماله تختفي. */
/* ════════════════════════════════════════════════════════════
   إعادة اشتقاق حساب العميل — مصدر الحقيقة الوحيد
   ------------------------------------------------------------
   المشكلة الجذرية التي يعالجها هذا:

   كان «المدفوع على الفاتورة» و«الدين» و«رصيد العميل» حقولاً **مخزَّنة**
   تعدّلها عشر عمليات مختلفة، كلٌّ منها يعدّلها بطريقته: البيع، السداد،
   الإرجاع بطرقه الثلاث، التعديل، الحذف، الاسترجاع، صرف الرصيد. وكل عملية
   تحمل معها «سجل توزيع» يصف ما فعلته وقت تنفيذها.

   والسجل يقادم: تُعدَّل الفاتورة أو يقع إرجاع عليها بعد الدفعة، فلا يعود
   ما في السجل مطابقاً للواقع. ثم يأتي حذف أو استرجاع فيعكس أرقاماً لم تعد
   صحيحة — ويستقر الحساب على قيمة لا تطابق لا النقد ولا البضاعة.
   وهذا مصدر كل الاختلالات المتبقية: لا خطأ في أي عملية على حدة، بل في
   تراكبها بترتيب غير متوقَّع.

   الحل هنا بنيوي لا ترقيعي: هذه الحقول لم تعد تُصدَّق كما هي، بل تُشتق
   من مصدرين لا يكذبان:

      • سجلات المقبوضات  → المال الذي دخل وخرج فعلاً
      • الفواتير          → البضاعة التي سُلِّمت فعلاً

   والمعادلة المحورية تصير **صحيحة بالبناء** لا بالمصادفة:

      البضاعة المُسلَّمة = صافي النقد + الدين − الرصيد

   لأن التوزيع نفسه مشتق منها: يُوزَّع النقد على الفواتير من الأقدم فالأحدث،
   وما فاض يصير رصيداً، وما لم يُغطَّ يصير ديناً. لا ثالث لهما.

   والدالة **حيادية**: تشغيلها مرتين أو عشراً لا يغيّر شيئاً بعد أول مرة.
   ════════════════════════════════════════════════════════════ */
function reconcileCustomerAccounts(name, opts) {
  if (!name) return { changed: false, sales: [], creditChanged: false };
  const silent = opts && opts.silent;

  const invoices = DB.sales
    .filter(s2 => s2.customerName === name)
    .sort((a, b) => _sortKey(a) - _sortKey(b));   // الأقدم أولاً — نفس ترتيب السداد المعتاد

  // صافي النقد: الداخل ناقص الخارج (المستردات وصرف الأرصدة)
  const netCash = r2((DB.payments || [])
    .filter(p => p.customerName === name)
    .reduce((a, p) => a + (p.isRefund ? -(p.amount || 0) : (p.amount || 0)), 0));

  let pool = netCash;
  const touched = [];

  invoices.forEach(inv => {
    const due = r2(Math.max(0, inv.subtotal || 0));
    const applied = r2(Math.max(0, Math.min(Math.max(pool, 0), due)));
    pool = r2(pool - applied);
    const debt = r2(Math.max(0, due - applied));

    const oldPaid = r2(inv.paid || 0);
    const oldDebt = r2(inv.netDebt || 0);
    const oldCred = r2(inv.creditUsed || 0);
    if (Math.abs(r2(oldPaid - applied)) > 0.005 ||
        Math.abs(r2(oldDebt - debt)) > 0.005 || oldCred !== 0) {
      inv.paid = applied;
      inv.netDebt = debt;
      if (inv.overRefundDebt) inv.overRefundDebt = 0;
      /* creditUsed لم يعد له معنى مستقل: الرصيد صار مجرد نقد لم يُوزَّع بعد،
         ويُوزَّع تلقائياً على أي فاتورة تالية. إبقاؤه كان يعني احتساب نفس
         المبلغ مرتين — مرة في النقد ومرة كرصيد مستهلك. */
      inv.creditUsed = 0;
      touched.push(inv);
    }
  });

  /* ══ حالة صافي النقد السالب ══
     تعني أن ما صُرف للعميل نقداً أكثر مما دخل منه — وتقع حين يُحذف سجل
     دخول بعد أن يكون استرداده قد خرج فعلاً. المال خرج من الصندوق حقيقةً،
     فلا يصح ابتلاعه ولا إظهاره رصيداً له.

     الصحيح محاسبياً أنه **دَين عليه**: قبض مبلغاً لا يستحقه. نضيفه إلى
     دين آخر فاتورة له (أو نُنشئ له ديناً على أحدثها)، فتظل المعادلة
     صحيحة بالبناء في كل الحالات بلا استثناء واحد. */
  if (pool < -0.005) {
    const owed = r2(-pool);
    const target = invoices.length ? invoices[invoices.length - 1] : null;
    if (target) {
      /* نسجّله في حقل مستقل أيضاً، لا مدموجاً بلا أثر: بدونه يظهر دين
         أكبر من قيمة الفاتورة بلا تفسير، ويبلّغ عنه فحص السلامة كخلل. */
      target.netDebt = r2((target.netDebt || 0) + owed);
      target.overRefundDebt = owed;
      if (touched.indexOf(target) === -1) touched.push(target);
    }
    pool = 0;
    if (!silent) {
      showFsErrorToast('⚠️ ' + name + ': صُرف نقداً أكثر مما دخل بمقدار ' + fmt(owed) +
                       ' — سُجّل ديناً عليه. راجع المستردات.');
    }
  }

  // ما فاض عن كل الفواتير = رصيد للعميل
  const newCredit = r2(Math.max(0, pool));
  const oldCredit = r2(DB.creditBalances[name] || 0);
  let creditChanged = false;
  if (Math.abs(r2(newCredit - oldCredit)) > 0.005) {
    if (newCredit > 0.005) DB.creditBalances[name] = newCredit;
    else delete DB.creditBalances[name];
    creditChanged = true;
  }

  return { changed: touched.length > 0 || creditChanged, sales: touched, creditChanged, netCash, credit: newCredit };
}

/* تُشغّل الاشتقاق وترفع ما تغيّر إلى السيرفر. تُستدعى بعد كل عملية
   تمسّ المال، فيستحيل أن يبقى الحساب متناقضاً ولو للحظة واحدة. */
function reconcileAndSync(name, opts) {
  const res = reconcileCustomerAccounts(name, opts);
  if (!res.changed) return res;
  (async () => {
    try {
      await Promise.all(res.sales.map(x => fsUpdate('sales', x.id, {
        paid: x.paid, netDebt: x.netDebt, creditUsed: 0, overRefundDebt: x.overRefundDebt || 0
      })));
      if (res.creditChanged) await syncCreditBalance(name);
    } catch (e) { wsSilent('invoices:sales', e); }
  })();
  return res;
}

// إعادة ضبط حسابات كل العملاء — لتصحيح ما شُوّه قبل تفعيل الاشتقاق
/* غلاف واجهة لإعادة الضبط: تأكيد صريح ونسخة أمان قبل تعديل أي رقم.
   إعادة الضبط لا تُنشئ ولا تحذف شيئاً — تُعيد توزيع ما هو مسجَّل أصلاً —
   لكنها تغيّر أرقاماً يراها المدير كل يوم، فلا يصح أن تقع بضغطة واحدة. */
function runReconcileAll() {
  if (!isManager()) { alert('⛔ متاح للمدير فقط.'); return; }
  if (!confirm('إعادة ضبط حسابات كل العملاء؟\n\n' +
               'ستُعاد أرقام «المدفوع» و«الدين» و«الرصيد» بحيث تطابق سجلات المقبوضات والفواتير تماماً.\n' +
               'لا تُحذف أي فاتورة ولا دفعة — يُعاد التوزيع فقط.\n\n' +
               'ستُحفظ نسخة من بياناتك الحالية على جهازك أولاً.')) return;
  try { saveSafetySnapshot(); } catch (e) {}
  const fixed = reconcileAllCustomers(false);
  if (fixed) renderAllSections();
}
window.runReconcileAll = runReconcileAll;

function reconcileAllCustomers(silent) {
  const names = {};
  DB.sales.forEach(s2 => { if (s2.customerName) names[s2.customerName] = 1; });
  (DB.payments || []).forEach(p => { if (p.customerName) names[p.customerName] = 1; });
  Object.keys(DB.creditBalances || {}).forEach(n => { names[n] = 1; });

  let fixed = 0;
  Object.keys(names).forEach(n => { if (reconcileAndSync(n, { silent: true }).changed) fixed++; });

  if (!silent) {
    alert(fixed
      ? ('✅ أُعيد ضبط حسابات ' + fixed + ' عميل بحيث تطابق سجلات المقبوضات والفواتير تماماً.')
      : '✅ كل الحسابات مطابقة أصلاً — لا شيء يحتاج ضبطاً.');
  }
  return fixed;
}
window.reconcileAllCustomers = reconcileAllCustomers;

/* ══ سجل مقبوضات بلا معرّف ══
   كل سجل يُنشئه النظام يحمل معرّفاً ثابتاً (PAYINV / PAYDEBT / PAY /
   PAYEDIT / CREDOUT / REFUND) — وهذا مُتحقَّق منه آلياً. فالوصول إلى هنا
   يعني سجلاً أُنشئ من مسار جديد نُسي فيه المعرّف.

   ولا نكتبه بمعرّف عشوائي: بلا معرّف ثابت لا يمكن حذفه ولا عكس أثره،
   ويُكتب من جديد مع كل إعادة مزامنة فتتراكم نسخ منه. نكتبه بمعرّف مشتق
   من محتواه — فتكرار الكتابة يقع على نفس المستند — ونُنبّه المدير. */
function _payWithoutId(p) {
  const seed = 'PAYX-' + String(p.customerName || '').replace(/\s/g, '').slice(0, 16) +
               '-' + Math.round((p.amount || 0) * 100) + '-' + (p.timestamp || 0);
  console.warn('سجل مقبوضات بلا معرّف — استُعمل معرّف مشتق:', seed, p);
  try { showFsErrorToast('⚠️ سجل مقبوضات بلا معرّف — أبلغ المطوّر'); } catch (e) {}
  return fsSet('payments', seed, Object.assign({ id: seed }, p));
}

/* ══ حارس الضغط المزدوج للعمليات المالية ══
   ثلاث عمليات تُنشئ سجلات مالية بضغطة واحدة بلا تأكيد: تسجيل الإرجاع،
   والسداد المباشر، وحفظ إيصال السداد. والضغط مرتين — وهو يقع على الجوال
   حين تتأخر الاستجابة لحظة — يُسجّلها مرتين: إرجاعان لنفس البضاعة، أو
   دفعتان لم يدفع الزبون إلا واحدة.

   ولا يظهر الخلل فوراً: الدفاتر تبدو متزنة (نقد دخل مرتين مقابل دين
   انخفض مرتين)، ولا يُكتشف إلا حين يعترض الزبون على رصيده.

   القفل هنا زمني قصير: يمنع التكرار السريع ولا يعطّل عملاً متتابعاً
   مشروعاً — الموظف قد يسجّل دفعتين لزبونين خلال ثوانٍ. */
function guardOnce(key, ms) {
  window._opGuard = window._opGuard || {};
  if (window._opGuard[key]) return false;
  window._opGuard[key] = true;
  setTimeout(() => { try { delete window._opGuard[key]; } catch (e) {} }, ms || 2500);
  return true;
}

function invoiceSettled(inv) {
  return r2((inv.paid || 0) + (inv.creditUsed || 0));
}

function getCustomerNetDebt(name) {
  return r2(DB.sales.filter(s=>s.customerName===name).reduce((a,s)=>a+(s.netDebt||0),0));
}

// ============================================================
// أرصدة العملاء الدائنة (Credit Balances)
// ============================================================
function getCustomerCredit(name) {
  return r2(DB.creditBalances[name] || 0);
}

function addCustomerCredit(name, amount) {
  if (amount <= 0) return;
  DB.creditBalances[name] = r2((DB.creditBalances[name] || 0) + amount);
  syncCreditBalance(name).catch(() => {});
}

// يخصم مبلغاً من رصيد العميل الدائن (يُستخدم عند تسوية دين جديد بالرصيد). يُعيد المبلغ الفعلي المخصوم.
function consumeCustomerCredit(name, amount) {
  const avail = getCustomerCredit(name);
  const used = Math.min(avail, amount);
  if (used > 0) {
    DB.creditBalances[name] = r2(avail - used);
    if (DB.creditBalances[name] <= 0.001) delete DB.creditBalances[name];
    syncCreditBalance(name).catch(() => {});
  }
  return r2(used);
}

function renderDebtsSection() {
  const c = document.getElementById('debts-aggregation-container');
  c.innerHTML = '';
  let agg = {};
  DB.sales.forEach(s => {
    if (!agg[s.customerName]) agg[s.customerName] = { name:s.customerName, phone:s.customerPhone||'', totalSub:0, totalPaid:0, rawDebt:0, invoices:[] };
    agg[s.customerName].totalSub = r2(agg[s.customerName].totalSub + s.subtotal);
    agg[s.customerName].totalPaid = r2(agg[s.customerName].totalPaid + s.paid);
    agg[s.customerName].rawDebt = r2(agg[s.customerName].rawDebt + s.netDebt);
    agg[s.customerName].invoices.push(s);
  });
  let hasDebt = false;

  /* ⚠️ بحث الديون — 9.3.0.
     المطابقة تمرّ بـ wsNormName لا بالنصّ الخام: فـ«أحمد» و«احمد»
     و«أحـمد» أسماء واحدة في دفتر المحل، ويكتبها الموظفون بهجاءات مختلفة.
     والبحث الذي لا يجد «احمد» لأن المستخدم كتب «أحمد» أسوأ من غياب البحث،
     لأنه يُوهم بأن لا دَين على الرجل. والهاتف يُجرَّد من غير الأرقام
     للسبب نفسه: 0912-345 و0912345 رقم واحد. */
  const _q = ((document.getElementById('debts-search') || {}).value || '').trim();
  const _qName = typeof wsNormName === 'function' ? wsNormName(_q) : _q.toLowerCase();
  const _qDigits = _q.replace(/[^\d]/g, '');
  const matchDebt = (c2) => {
    if (!_q) return true;
    const nm = typeof wsNormName === 'function' ? wsNormName(c2.name) : String(c2.name || '').toLowerCase();
    if (_qName && nm.indexOf(_qName) !== -1) return true;
    if (_qDigits && String(c2.phone || '').replace(/[^\d]/g, '').indexOf(_qDigits) !== -1) return true;
    return false;
  };
  let _shown = 0, _totalDebtors = 0;

  Object.values(agg)
    .sort((a, b) => (a.name || '').localeCompare(b.name || '', 'ar'))
    .forEach(c2 => {
    const netDebt = getCustomerNetDebt(c2.name);
    if (netDebt <= 0.001) return;
    _totalDebtors++;
    if (!matchDebt(c2)) return;
    _shown++;
    hasDebt = true;
    let card = document.createElement('div');
    card.className = 'p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3';
    let invHtml = c2.invoices.filter(inv=>inv.netDebt>0).map(inv=>`
      <div class="text-xs bg-white p-2.5 rounded-lg border border-slate-100 flex justify-between items-center">
        <div>${invLinkHtml(inv.id, {small:true})} <span class="text-slate-400">(${escapeHtml(inv.date)})</span></div>
        <span class="font-bold text-rose-600">دين: ${fmt(inv.netDebt)}</span>
      </div>`).join('');
    card.innerHTML = `
      <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 bg-white p-3 rounded-xl shadow-sm">
        <div>
          <h3 class="font-bold text-slate-900 text-base">${escapeHtml(c2.name)}</h3>
          <p class="text-xs text-slate-500">هاتف: ${escapeHtml(c2.phone||'غير مسجل')}</p>
        </div>
        <div class="text-right">
          <span class="text-xs text-slate-400 block">الدين الصافي الحالي</span>
          <span class="text-xl font-black text-rose-600">${fmt(netDebt)}</span>
        </div>
      </div>
      <div class="flex flex-wrap gap-2">
        <a href="tel:${escapeHtml(c2.phone||'')}" class="px-3 py-2 bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-slate-900">
          <i class="w-3.5 h-3.5" data-lucide="phone"></i> اتصال
        </a>
        <button onclick="sendWhatsAppReminder('${escapeAttr(c2.phone)}','${escapeAttr(c2.name)}',${Number(netDebt) || 0})" class="px-3 py-2 bg-green-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-green-700">
          <i class="w-3.5 h-3.5" data-lucide="message-square"></i> واتساب
        </button>
        <button onclick="openReceiptModal('${escapeAttr(c2.name)}','${escapeAttr(c2.phone||'')}')"  class="px-3 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-blue-700 mr-auto">
          <i class="w-3.5 h-3.5" data-lucide="check-circle"></i> واصل سداد
        </button>
      </div>
      <div>${invHtml}</div>`;
    c.appendChild(card);
  });
  /* رسالتان مختلفتان لحالتين مختلفتين: «لا ديون» خبرٌ سارّ، و«لا نتائج
     للبحث» خطأُ كتابة. وخلطُهما يجعل المستخدم يظن أن دَين زبونه سُدّد. */
  if (!hasDebt) {
    c.innerHTML = _q
      ? `<div class="p-8 text-center text-sm text-slate-500">لا يوجد مدين يطابق «${escapeHtml(_q)}».<br>
         <span class="text-xs text-slate-400">جرّب جزءاً من الاسم أو آخر أرقام الهاتف.</span></div>`
      : '<div class="p-8 text-center text-sm text-slate-400">لا توجد ديون متبقية. رائع!</div>';
  }
  const _cnt = document.getElementById('debts-search-count');
  if (_cnt) {
    _cnt.textContent = _q
      ? ('عُرض ' + _shown + ' من ' + _totalDebtors + ' مدين')
      : (_totalDebtors ? (_totalDebtors + ' مدين') : '');
  }
  refreshIcons();
}

// ============================================================
// 3b. CUSTOMER CREDIT BALANCES — أرصدة العملاء الدائنة
// ============================================================
function renderCreditsSection() {
  const c = document.getElementById('credits-aggregation-container');
  if (!c) return;
  c.innerHTML = '';
  const entries = Object.entries(DB.creditBalances || {})
    .filter(([name, amt]) => amt > 0.001)
    .sort((a, b) => (a[0] || '').localeCompare(b[0] || '', 'ar'));   // ترتيب أبجدي
  if (!entries.length) {
    c.innerHTML = '<div class="p-8 text-center text-sm text-slate-400">لا يوجد عملاء لديهم رصيد حالياً.</div>';
    return;
  }
  entries.forEach(([name, amount]) => {
    const sample = DB.sales.find(s => s.customerName === name);
    const phone = sample ? (sample.customerPhone || '') : '';
    let card = document.createElement('div');
    card.className = 'p-4 bg-emerald-50 rounded-xl border border-emerald-200 flex flex-col sm:flex-row justify-between sm:items-center gap-3';
    card.innerHTML = `
      <div>
        <h3 class="font-bold text-slate-900 text-base">${escapeHtml(name)}</h3>
        <p class="text-xs text-slate-500">هاتف: ${escapeHtml(phone || 'غير مسجل')}</p>
      </div>
      <div class="flex items-center gap-3">
        <div class="text-right">
          <span class="text-xs text-slate-400 block">الرصيد المتاح</span>
          <span class="text-xl font-black text-emerald-600">${fmt(amount)}</span>
        </div>
        ${isManager() ? `<button onclick="refundCustomerCreditCash('${escapeAttr(name)}')" class="px-3 py-2 bg-rose-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-rose-700" title="صرف الرصيد ومسحه (للمدير فقط)">
          <i class="w-3.5 h-3.5" data-lucide="banknote"></i> صرف كاش
        </button>` : '<span class="px-3 py-2 bg-slate-100 text-slate-400 rounded-lg text-xs font-bold" title="مسح أرصدة العملاء للمدير فقط">🔒 للمدير</span>'}
      </div>`;
    c.appendChild(card);
  });
  refreshIcons();
}

// تسوية رصيد العميل نقداً يدوياً (بدل ترك الرصيد لفاتورة قادمة)
function refundCustomerCreditCash(name) {
  if (!isManager()) { alert('\u26D4 مسح أرصدة العملاء وصرفها متاح للمدير فقط.'); return; }
  const avail = getCustomerCredit(name);
  if (avail <= 0) return;
  if (!confirm(`هل تريد صرف رصيد ${name} البالغ ${fmt(avail)} نقداً الآن؟ سيُحذف من رصيده ولن يُخصم من فواتيره القادمة.`)) return;
  delete DB.creditBalances[name];
  /* تسجيل الصرف كحركة خروج نقدي.
     كانت الدالة تمحو الرصيد وتقول «تم الصرف نقداً» بلا أي قيد في دفتر
     المقبوضات إطلاقاً — فيخرج المال من الصندوق ولا يظهر في أي تقرير،
     ويبقى الجرد يُظهر نقداً أكثر مما في الدرج فعلاً. */
  const refundEntry = {
    id: wsUid('CREDOUT-'),
    customerName: name, amount: avail, type: 'استرداد نقدي',
    reason: `صرف رصيد دائن نقداً لـ ${name}`,
    date: new Date().toLocaleString('ar-EG'), timestamp: Date.now(),
    signedBy: getCurrentUserName(), signedByUid: getCurrentUserUid(),
    receiverRole: getCurrentUserRole(), isRefund: true, creditRefund: avail
  };
  DB.payments.push(refundEntry);
  saveDB();
  renderAllSections();
  alert(`تم صرف ${fmt(avail)} نقداً لـ ${name}، وسُجّل خروج المبلغ في دفتر المقبوضات.`);
  (async () => {
    try { await fsSet('payments', refundEntry.id, refundEntry); await fsDeleteCredit(name); } catch (e) { wsSilent('invoices:payments', e); }
  })();
}

function sendWhatsAppReminder(phone,name,amount) {
  if (!phone) { alert('لا يوجد رقم هاتف.'); return; }
  let msg = `تحية طيبة سيد ${name}، نود تذكيركم بأن مستحقاتكم لدينا هي (${fmt(amount)})، شاكرين لتعاونكم.`;
  window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`,'_blank','noopener,noreferrer');
}

function payOffDebtDirectly(name) {
  let amount = r2(prompt(`أدخل المبلغ الواصل من ${name}:`));
  if (isNaN(amount)||amount<=0) return;
  /* القفل **بعد** إدخال المبلغ لا قبله: نافذة prompt تحجب الواجهة أصلاً
     فلا يقع ضغط ثانٍ أثناءها. والمقصود منع تكرار **التنفيذ** بعد الإدخال.
     والمفتاح يشمل المبلغ: من يسدّد 100 ثم 100 أخرى عن قصد يفصل بينهما
     أكثر من ثانيتين، أما ضغطتان في لحظة فتُسجَّل واحدة. */
  if (!guardOnce('paydebt-' + name + '-' + amount)) return;
  let rem = amount;
  const touchedSales = [];
  /* سجل دقيق لما سدّدته هذه الدفعة من كل فاتورة.
     بدونه لا يستطيع النظام عكس الدفعة إن حُذفت لاحقاً، فيبقى الدين
     مسدَّداً بمبلغ لم يعد له وجود — وهذا ما كان يحدث فعلاً. */
  const debtDistribution = [];
  for (let i=0; i<DB.sales.length; i++) {
    if (DB.sales[i].customerName===name && DB.sales[i].netDebt>0) {
      if (rem >= DB.sales[i].netDebt) { const applied = DB.sales[i].netDebt; rem = r2(rem - applied); DB.sales[i].paid = r2(DB.sales[i].paid + applied); DB.sales[i].netDebt=0; touchedSales.push(DB.sales[i]); debtDistribution.push({ saleId: DB.sales[i].id, amountApplied: applied }); }
      else { const applied = rem; DB.sales[i].paid = r2(DB.sales[i].paid + applied); DB.sales[i].netDebt = r2(DB.sales[i].netDebt - applied); rem=0; touchedSales.push(DB.sales[i]); debtDistribution.push({ saleId: DB.sales[i].id, amountApplied: applied }); break; }
    }
  }
  const payEntry = { id: wsUid('PAY-'), customerName:name, amount, type:'كاش', reason:'واصل سداد دين مباشر', date:new Date().toLocaleString('ar-EG'), timestamp:Date.now(), signedBy:getCurrentUserName(), signedByUid:getCurrentUserUid(), receiverRole:getCurrentUserRole(), debtDistribution, creditAdded: rem > 0.001 ? r2(rem) : 0 };
  DB.payments.push(payEntry);
  let creditMsg = '';
  if (rem > 0.001) {
    addCustomerCredit(name, rem);
    creditMsg = `\
تم سداد كامل الدين، والفائض (${fmt(rem)}) أُضيف كرصيد للعميل لصالح مشترياته القادمة.`;
  }
  saveDB();
  reconcileAndSync(name, { silent: true });
  alert(`تم تسجيل واصل ${fmt(amount)} وتحديث الحسابات.${creditMsg}` + wsSaveNote());
  (async () => {
    try {
      await fsSet('payments', payEntry.id, payEntry);
      await Promise.all(touchedSales.map(s => fsUpdate('sales', s.id, { paid: s.paid, netDebt: s.netDebt })));
    } catch (e) { wsSilent('invoices:payments', e); }
  })();
}

// ============================================================
// 4. RETURNS
// ============================================================
let returnSource = null;

function loadInvoiceForReturn() {
  const id = document.getElementById('ret-inv-id').value.trim();
  const inv = DB.sales.find(s => s.id===id);
  if (!inv) { alert('لم يُعثر على فاتورة بهذا الرقم.'); return; }
  returnSource = inv;
  document.getElementById('ret-customer-name').value = inv.customerName;
  const sec = document.getElementById('ret-items-section');
  sec.classList.remove('hidden');
  const list = document.getElementById('ret-items-list');
  list.innerHTML = '';
  inv.items.forEach((item,idx) => {
    const maxQty = item.qty;
    let div = document.createElement('div');
    div.className = 'flex items-center gap-3 bg-slate-50 p-3 rounded-lg border border-slate-100';
    div.innerHTML = `
      <div class="flex-1">
        <div class="font-medium text-sm text-slate-800">${escapeHtml(item.name)}</div>
        <div class="text-xs text-slate-500">سعر الوحدة: ${fmt(item.price)} | الكمية الأصلية: ${fmt(maxQty)}</div>
      </div>
      <div class="w-28">
        <label class="text-xs text-slate-500 block mb-1">كمية الإرجاع</label>
        <input type="number" id="ret-qty-${idx}" value="0" min="0" max="${maxQty}" step="0.01"
          oninput="calcReturnTotal()" class="w-full p-2 bg-white border border-slate-200 rounded text-sm text-center">
      </div>
      <div class="text-sm font-bold text-amber-600 w-20 text-center" id="ret-line-${idx}">0.00</div>`;
    list.appendChild(div);
  });
  calcReturnTotal();
  selectRetMethod('استرداد نقدي');
  updateRetDebtHint();
}

function calcReturnTotal() {
  if (!returnSource) return;
  let total = 0;
  returnSource.items.forEach((item,idx) => {
    const qty = r2(document.getElementById(`ret-qty-${idx}`)?.value||0);
    const line = r2(qty * item.price);
    const el = document.getElementById(`ret-line-${idx}`);
    if (el) el.innerText = fmt(line);
    total = r2(total + line);
  });
  document.getElementById('ret-total-value').innerText = fmt(total);
}

function openReturnForInvoice(id) {
  // إغلاق أي modal مفتوح ثم فتح قسم الإرجاع
  closeSectionModal();
  setTimeout(() => {
    openSectionModal('returns');
    setTimeout(() => {
      document.getElementById('ret-inv-id').value = id;
      loadInvoiceForReturn();
    }, 150);
  }, 200);
}

function confirmReturn() {
  // مفتاح يشمل الفاتورة الأصلية: إرجاعان لفاتورتين مختلفتين لا يتعارضان
  if (!guardOnce('return-' + ((returnSource && returnSource.id) || ''))) return;
  if (!returnSource) { alert('يرجى تحميل فاتورة أولاً.'); return; }
  const method = selectedRetMethod;
  const reason = document.getElementById('ret-reason').value.trim() || 'غير محدد';
  let retItems = [];
  let total = 0;
  /* التحقق أولاً على كل الأسطر قبل تنفيذ أي شيء.
     الخلل السابق: كان return داخل forEach يتخطّى السطر المخالف فقط ثم يُكمل
     بقية الإرجاع وينفّذه فعلياً — فيرى المستخدم رسالة خطأ ثم رسالة نجاح،
     ويظن العملية أُلغيت وهي قد تمّت ناقصة. */
  const planned = [];
  for (let idx = 0; idx < returnSource.items.length; idx++) {
    const item = returnSource.items[idx];
    const qty = r2(document.getElementById(`ret-qty-${idx}`)?.value || 0);
    if (!(qty > 0)) continue;
    if (qty > item.qty) {
      alert(`الكمية المُرجعة (${fmt(qty)}) أكبر من المبيعة (${fmt(item.qty)}) للصنف ${item.name}.\n\nلم تُنفَّذ أي عملية إرجاع — صحّح الكمية وأعد المحاولة.`);
      return;
    }
    planned.push({ idx, item, qty });
  }
  planned.forEach(({ item, qty }) => {
    const line = r2(qty * item.price);
    retItems.push({ name:item.name, qty, price:item.price, total:line });
    total = r2(total + line);
    restoreStockForInvoiceItem({ name: item.name, qty });
    // نعدّل السطر نفسه مباشرة — البحث بالاسم كان يصيب أول سطر مطابق لا هذا السطر
    item.qty = r2(item.qty - qty);
    item.total = r2(item.qty * item.price);
  });
  if (!retItems.length) { alert('لم تحدد أي كمية للإرجاع.'); return; }
  const retId = wsUid('RET-');
  // creditAdded يُملأ بعد تحديد الطريقة، ليُسحب بدقة إن حُذف الإرجاع
  const retObj = { id:retId, creditAdded:0, originalInvId:returnSource.id, customerName:returnSource.customerName, customerPhone:returnSource.customerPhone||'', items:retItems, total, method, reason, date:new Date().toLocaleString('ar-EG'), timestamp:Date.now(), signedBy:getCurrentUserName() };
  DB.returns.push(retObj);
  const origIdx = DB.sales.findIndex(s=>s.id===returnSource.id);
  let creditAdded = 0;
  const touchedSales = [];
  const paymentsToSync = [];
  if (method === 'رصيد للعميل') {
    // الخيار 2: حفظ في أرصدة العملاء (لا يُصرف نقداً)
    if (origIdx !== -1) {
      const inv = DB.sales[origIdx];
      inv.items = returnSource.items;
      recalcInvoiceTotal(inv);
      const rawBalance = r2(inv.subtotal - invoiceSettled(inv));
      if (rawBalance < 0) {
        creditAdded = r2(-rawBalance);
        const dropCredit = r2(Math.min(creditAdded, inv.creditUsed || 0));
        inv.creditUsed = r2((inv.creditUsed || 0) - dropCredit);
        inv.paid = r2((inv.paid || 0) - r2(creditAdded - dropCredit));
        addCustomerCredit(inv.customerName, creditAdded);
      }
      inv.netDebt = r2(Math.max(0, rawBalance));
      touchedSales.push(inv);
    }
  } else if (method === 'تسديد دين') {
    /* الخيار 3: تسديد ديون من قيمة الإرجاع.
       الخلل السابق كان يخصم قيمة الإرجاع مرتين:
       حذف الأصناف من الفاتورة يُنقص إجماليها (وبالتالي دينها) بقيمة الإرجاع،
       ثم كانت القيمة نفسها تُوزَّع مرة أخرى كأنها دفعة نقدية على الديون —
       ومنها دين هذه الفاتورة ذاتها. مثال: فاتورة 1000 بلا دفع، أُرجعت بضاعة
       بـ300، فينزل الدين إلى 400 بدل 700، ويُسجَّل أن العميل دفع 300 وهو لم
       يدفع شيئاً. أي 300 من الدين تضيع بلا مقابل في كل إرجاع.
       الصحيح: الإرجاع يُنقص دين فاتورته تلقائياً، ولا يُوزَّع على بقية
       الديون إلا الفائض الذي دفعه العميل فعلاً فوق قيمة ما احتفظ به. */
    let retRem = 0;
    const sourceId = returnSource.id;
    if (origIdx !== -1) {
      const inv = DB.sales[origIdx];
      inv.items = returnSource.items;
      recalcInvoiceTotal(inv);
      const rawBalance = r2(inv.subtotal - invoiceSettled(inv));
      if (rawBalance < 0) {
        // دفع أكثر مما احتفظ به → الفائض وحده يُسدَّد على بقية ديونه
        retRem = r2(-rawBalance);
        // نُخفّض الرصيد المستهلك أولاً ثم النقد، حتى يبقى مجموعهما = الإجمالي الجديد
        const dropCredit = r2(Math.min(retRem, inv.creditUsed || 0));
        inv.creditUsed = r2((inv.creditUsed || 0) - dropCredit);
        inv.paid = r2((inv.paid || 0) - r2(retRem - dropCredit));
        inv.netDebt = 0;
      } else {
        inv.netDebt = rawBalance;
      }
      touchedSales.push(inv);
    }
    // وزّع الفائض (إن وُجد) على بقية ديون العميل بالترتيب — دون فاتورة الإرجاع نفسها
    for (let i = 0; i < DB.sales.length; i++) {
      if (DB.sales[i].id === sourceId) continue;
      if (DB.sales[i].customerName === returnSource.customerName && DB.sales[i].netDebt > 0) {
        if (retRem >= DB.sales[i].netDebt) {
          retRem = r2(retRem - DB.sales[i].netDebt);
          DB.sales[i].paid = r2(DB.sales[i].paid + DB.sales[i].netDebt);
          DB.sales[i].netDebt = 0;
          touchedSales.push(DB.sales[i]);
        } else {
          DB.sales[i].paid = r2(DB.sales[i].paid + retRem);
          DB.sales[i].netDebt = r2(DB.sales[i].netDebt - retRem);
          retRem = 0;
          touchedSales.push(DB.sales[i]);
          break;
        }
      }
    }
    if (retRem > 0.001) { creditAdded = retRem; addCustomerCredit(returnSource.customerName, retRem); }
  } else {
    // الخيار 1: استرداد نقدي — يخصم من المدفوعات الواردة
    if (origIdx !== -1) {
      const inv = DB.sales[origIdx];
      inv.items = returnSource.items;
      recalcInvoiceTotal(inv);
      const rawBalance = r2(inv.subtotal - invoiceSettled(inv)); // سالب = العميل سدّد أكثر من قيمة ما احتفظ به
      if (rawBalance < 0) {
        /* الفائض يُعاد نقداً، لكن بحدود ما دفعه نقداً فعلاً.
           ما جاء منه من رصيد دائن يعود رصيداً لا نقداً — لا يصح صرف كاش
           عن قيمة لم تدخل الصندوق أصلاً. */
        const surplus = r2(-rawBalance);
        const cashBack = r2(Math.min(surplus, inv.paid || 0));
        const backToCredit = r2(surplus - cashBack);
        inv.paid = r2((inv.paid || 0) - cashBack);
        if (backToCredit > 0) {
          inv.creditUsed = r2((inv.creditUsed || 0) - backToCredit);
          addCustomerCredit(returnSource.customerName, backToCredit);
        }
        inv.netDebt = 0;
        creditAdded = backToCredit;
        // سجّل الصرف النقدي كمبلغ خارج من المدفوعات
        /* معرّف ثابت + هوية المُسجِّل، كبقية سجلات المقبوضات.
           بلا معرّف: يفشل ربط السجل المحلي بنظيره على السيرفر، ويبقى زر
           حذفه معطَّلاً. وبلا هوية المُسجِّل: لا يُعرف من صرف المبلغ من
           الصندوق أصلاً عند مراجعة الحسابات. */
        const refundPay = {
          id: 'REFUND-' + retId,
          customerName: returnSource.customerName, amount: cashBack,
          type: 'استرداد نقدي', reason: `صرف نقدي — إرجاع ${retId}`,
          date: new Date().toLocaleString('ar-EG'), timestamp: Date.now(), isRefund: true,
          signedBy: getCurrentUserName(), signedByUid: getCurrentUserUid(),
          receiverRole: getCurrentUserRole(), originalInvId: returnSource.id
        };
        DB.payments.push(refundPay);
        paymentsToSync.push(refundPay);
      } else {
        // العميل لا يزال مديناً → الإرجاع يُقلّل الدين فقط، لا يُصرف نقداً
        inv.netDebt = rawBalance;
      }
      touchedSales.push(inv);
    }
  }
  /* ══ الاسم يُحفظ قبل تصفير المصدر ══
     كان `reconcileAndSync(returnSource.customerName, …)` في آخر الدالة —
     بعد هذا السطر بعشرين سطراً. فيقرأ خاصية من null ويرمي:
       Cannot read properties of null (reading 'customerName')

     والخطأ يقع **بعد** كتابة الإرجاع والمقبوضات وتحديث الفواتير، وقبل
     إعادة تسوية حساب العميل. فالبضاعة تُرجَع والمبلغ يُسجَّل، ويبقى
     `paid` و`netDebt` على قيمهما القديمة حتى تُعاد التسوية من عملية
     لاحقة — أو لا تُعاد، فيظهر العميل مديناً بما أرجعه. */
  const retCustomerName = returnSource ? returnSource.customerName : '';

  returnSource = null;
  document.getElementById('ret-inv-id').value='';
  document.getElementById('ret-customer-name').value='';
  document.getElementById('ret-items-section').classList.add('hidden');
  document.getElementById('ret-items-list').innerHTML='';

  /* الرصيد الممنوح يُثبَّت في سجل الإرجاع **قبل رفعه** لا بعده.
     بدونه يُرفع بقيمة صفر، فلا يعرف الحذف لاحقاً كم يسحب من رصيد
     العميل — ويبقى له رصيد بلا مقابل. */
  retObj.creditAdded = r2(creditAdded || 0);

  saveDB();
  (async () => {
    try {
      await fsSet('returns', retObj.id, retObj);
      await Promise.all(touchedSales.map(s => fsUpdate('sales', s.id, { items: s.items, itemsTotal: s.itemsTotal, discount: s.discount, subtotal: s.subtotal, paid: s.paid, netDebt: s.netDebt, creditUsed: s.creditUsed || 0 })));
      await Promise.all(paymentsToSync.map(p => p.id ? fsSet('payments', p.id, p) : _payWithoutId(p)));
    } catch (e) { wsSilent('invoices:returns', e); }
  })();
  const creditMsg = creditAdded>0 ? `\
تم إضافة ${fmt(creditAdded)} كرصيد للعميل.` : '';
  const methodLabel = method==='استرداد نقدي'?'✅ سيُسلَّم المبلغ نقداً للعميل':method==='رصيد للعميل'?'💰 محفوظ في أرصدة العملاء':'📋 تم تسديد الديون السابقة';
  if (retCustomerName) reconcileAndSync(retCustomerName, { silent: true });
  alert(`تم تسجيل فاتورة الإرجاع ${retId} بنجاح.\
القيمة: ${fmt(total)}\
${methodLabel}${creditMsg}` + wsSaveNote());
}

/* ════════════════════════════════════════════════════════════
   حذف إرجاع وعكس أثره
   ------------------------------------------------------------
   كان النظام يوجّه المدير إلى «احذف فاتورة الإرجاع أولاً من قسم
   المرتجعات» عند محاولة حذف فاتورة عليها إرجاع — **ولا وجود لهذا
   الإجراء أصلاً**. فيبقى أمام طريق مسدود: لا يحذف الفاتورة ولا يجد ما
   يحذف الإرجاع.

   العكس يعيد ثلاثة أشياء:
     • أصناف الإرجاع إلى الفاتورة الأصلية (كمياتها وإجمالياتها)
     • خصمها من المخزن مرة أخرى (كانت أُعيدت إليه عند الإرجاع)
     • والمال: الاسترداد النقدي يُحذف سجله، والرصيد الممنوح يُسحب

   ثم تتولّى طبقة الاشتقاق إعادة توزيع النقد على الفواتير — فلا نحسب
   المدفوع والدين يدوياً هنا، ولا تتعارض أرقامنا مع أرقامها.
   ════════════════════════════════════════════════════════════ */
function deleteReturnToTrash(id) {
  if (!isManager()) { alert('⛔ حذف المرتجعات متاح للمدير فقط.'); return; }
  const idx = DB.returns.findIndex(r => r.id === id);
  if (idx === -1) return;
  const ret = DB.returns[idx];
  const inv = DB.sales.find(x => x.id === ret.originalInvId);

  if (!inv) {
    if (!confirm('الفاتورة الأصلية ' + (ret.originalInvId || '') + ' لم تعد موجودة.\n\n' +
                 'سيُحذف سجل الإرجاع فقط بلا إعادة أصناف. متابعة؟')) return;
  } else {
    if (!confirm('حذف الإرجاع ' + ret.id + '؟\n\n' +
                 '• تعود أصنافه إلى الفاتورة ' + inv.id + '\n' +
                 '• وتُخصم من المخزن مرة أخرى\n' +
                 (ret.method === 'استرداد نقدي' ? '• ويُلغى الاسترداد النقدي المسجَّل\n' : '') +
                 (ret.method === 'رصيد للعميل' ? '• ويُسحب الرصيد الممنوح\n' : '') +
                 '\nثم يُعاد حساب الدين تلقائياً.')) return;
  }

  const touched = [];
  if (inv) {
    // إعادة الأصناف: نجمع على الموجود ولا نستبدله، فقد بيع الصنف مرة أخرى بعدها
    (ret.items || []).forEach(ri => {
      const line = (inv.items || []).find(x => x.name === ri.name && r2(x.price) === r2(ri.price));
      if (line) { line.qty = r2(line.qty + ri.qty); line.total = r2(line.qty * line.price); }
      else (inv.items = inv.items || []).push({ name: ri.name, qty: ri.qty, price: ri.price, total: r2(ri.qty * ri.price) });
      deductStockForInvoiceItem({ name: ri.name, qty: ri.qty });   // تعود للخصم كما كانت
    });
    recalcInvoiceTotal(inv);
    touched.push(inv);
  }

  // المال: سجل الاسترداد يُحذف، والرصيد الممنوح يُسحب
  const refundId = 'REFUND-' + ret.id;
  const rIdx = DB.payments.findIndex(p => p.id === refundId);
  const hadRefund = rIdx > -1;
  if (hadRefund) DB.payments.splice(rIdx, 1);
  if (r2(ret.creditAdded || 0) > 0) consumeCustomerCredit(ret.customerName, r2(ret.creditAdded));

  const trashEntry = { type:'مرتجع', id:ret.id, deletedAt:Date.now(),
                       dateStr:new Date().toLocaleString('ar-EG'), payload:ret,
                       deletedBy:getCurrentUserName() };
  DB.trash.push(trashEntry);
  DB.returns.splice(idx, 1);
  saveDB();
  reconcileAndSync(ret.customerName, { silent: true });   // الدين والرصيد يُشتقّان لا يُحسبان هنا
  renderAllSections();

  (async () => {
    try {
      await fsSet('trash', trashEntry.id, trashEntry);
      await Promise.all(touched.map(x => fsUpdate('sales', x.id, {
        items: x.items, itemsTotal: x.itemsTotal, discount: x.discount, subtotal: x.subtotal
      })));
      if (hadRefund) await fsDelete('payments', refundId);
      await fsDelete('returns', ret.id);
    } catch (e) { wsSilent('invoices:trash', e); }
  })();
  showSuccessToast('🗑️ حُذف الإرجاع وعادت أصنافه للفاتورة.');
}

function renderReturnsArchive() {
  const body = document.getElementById('returns-archive-body');
  body.innerHTML = '';
  if (!DB.returns.length) { body.innerHTML='<tr><td colspan="7" class="p-8 text-center text-sm text-slate-400">لا توجد مرتجعات بعد.</td></tr>'; return; }
  [...DB.returns].reverse().forEach(r => {
    let tr = document.createElement('tr');
    tr.className = 'text-sm text-slate-700';
    tr.innerHTML = `
      <td class="p-3 font-mono text-xs font-bold text-amber-700">${escapeHtml(r.id)}</td>
      <td class="p-3 text-xs">${invLinkHtml(r.originalInvId, {small:true})}</td>
      <td class="p-3 font-medium">${escapeHtml(r.customerName)}</td>
      <td class="p-3 font-bold text-amber-600">${fmt(r.total)}</td>
      <td class="p-3 text-xs"><span class="px-2 py-1 bg-slate-100 rounded">${escapeHtml(r.method)}</span></td>
      <td class="p-3 text-xs text-slate-400">${escapeHtml(r.date)}</td>
      <td class="p-3 text-center">${isManager()
        ? `<button onclick="deleteReturnToTrash('${escapeAttr(r.id)}')" title="حذف الإرجاع وعكس أثره"
               style="padding:5px 10px;border-radius:8px;background:#fee2df;color:#d33722;border:none;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:pointer;">🗑️</button>`
        : ''}</td>`;
    body.appendChild(tr);
  });
}

// ============================================================
// 5. EXPENSES
// ============================================================
function saveExpense() {
  const title = document.getElementById('exp-title').value.trim();
  const amount = r2(document.getElementById('exp-amount').value);
  const imgFile = document.getElementById('exp-image').files[0];
  if (!title || isNaN(amount)||amount<=0) { alert('يرجى إدخال بيان ومبلغ صحيح.'); return; }
  if (imgFile) {
    const rd = new FileReader();
    rd.onload = e => execSaveExpense(title,amount,e.target.result);
    rd.readAsDataURL(imgFile);
  } else execSaveExpense(title,amount,null);
}

function execSaveExpense(title,amount,img) {
  const expEntry = { id:wsUid('EXP-'), title, amount, image:img, date:new Date().toLocaleString('ar-EG'), timestamp:Date.now(), signedBy:getCurrentUserName() };
  DB.expenses.push(expEntry);
  ['exp-title','exp-amount'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('exp-image').value='';
  saveDB();
  alert('تم تسجيل المصروف.');
  fsSet('expenses', expEntry.id, expEntry).catch(() => {});
}

function deleteExpenseToTrash(id) {
  if (!isManager()) { alert('\u26D4 حذف المصروفات متاح للمدير فقط.'); return; }
  let idx = DB.expenses.findIndex(e=>e.id===id);
  if (idx!==-1) {
    const e0 = DB.expenses[idx];
    if (!confirm(`حذف مصروف «${e0.title}» بمبلغ ${fmt(e0.amount)}؟\n\nسينتقل إلى سلة المحذوفات.`)) return;
    const trashEntry = { type:'مصروفات', id:DB.expenses[idx].id, deletedAt:Date.now(), dateStr:new Date().toLocaleString('ar-EG'), payload:DB.expenses[idx] };
    DB.trash.push(trashEntry);
    DB.expenses.splice(idx,1);
    saveDB();
    (async () => { try { await fsSet('trash', trashEntry.id, trashEntry); await fsDelete('expenses', trashEntry.id); } catch (e) { wsSilent('invoices:trash', e); } })();
  }
}

function renderExpenses() {
  const body = document.getElementById('expenses-table-body');
  body.innerHTML = '';
  if (!DB.expenses.length) { body.innerHTML='<tr><td colspan="5" class="p-8 text-center text-sm text-slate-400">لا توجد مصروفات مسجلة.</td></tr>'; return; }
  [...DB.expenses].reverse().forEach(e => {
    let tr = document.createElement('tr');
    tr.className = 'text-sm text-slate-700';
    /* رابط صورة المصروف: يُهرَّب ويُقيَّد بمخططات آمنة.
       كان يُحقن كما هو، فقيمة تبدأ بـ javascript: تصير رابطاً ينفّذ كوداً
       بضغطة من المدير — وقيمة فيها علامة اقتباس تكسر الوسم وتفتح حقن HTML.
       والصور هنا تُحفظ كـ data:image أو رابط https، فلا شيء آخر مشروع. */
    const imgSrc = String(e.image || '');
    const imgOk = /^(https?:|data:image\/)/i.test(imgSrc);
    let img = imgOk
      ? `<a href="${escapeHtml(imgSrc)}" target="_blank" rel="noopener noreferrer" class="text-xs text-blue-600 underline">عرض</a>`
      : (imgSrc ? `<span class="text-amber-600 text-xs" title="رابط غير مدعوم">رابط غير صالح</span>`
                : `<span class="text-slate-400 text-xs">لا يوجد</span>`);
    tr.innerHTML = `
      <td class="p-3 font-medium">${escapeHtml(e.title)}</td>
      <td class="p-3 font-bold text-rose-600">${fmt(e.amount)}</td>
      <td class="p-3 text-xs text-slate-400">${escapeHtml(e.date)}${e.signedBy ? '<br><span class="text-blue-500 font-bold text-xs">✍️ '+escapeHtml(e.signedBy)+'</span>' : ''}</td>
      <td class="p-3 text-center">${img}</td>
      <td class="p-3 text-center">
        ${isManager() ? `<button onclick="deleteExpenseToTrash('${escapeAttr(e.id)}')" class="p-1 text-rose-600 hover:bg-rose-50 rounded" title="حذف (للمدير فقط)">
          <i data-lucide="trash-2" class="w-4 h-4"></i>
        </button>` : '<span class="text-slate-300 text-xs" title="حذف المصروفات للمدير فقط">🔒</span>'}
      </td>`;
    body.appendChild(tr);
  });
  refreshIcons();
}

// ============================================================
// 6. STORE
// ============================================================
function addOrUpdateStoreItem() {
  const name = document.getElementById('store-item-name').value.trim();
  const qty = r2(document.getElementById('store-item-qty').value);
  const price = r2(document.getElementById('store-item-price').value);
  if (!name||isNaN(qty)||isNaN(price)||qty<0||price<0) { alert('يرجى ملء البيانات بشكل صحيح.'); return; }
  let item = DB.store.find(i=>i.name.toLowerCase()===name.toLowerCase());
  const isNewItem = !item;
  if (item) { item.qty=qty; item.price=price; alert('تم تحديث الصنف.'); }
  else { item = { id:wsUid('STR-'), name, qty, price, recipe: null }; DB.store.push(item); alert('تم إضافة الصنف.'); }
  ['store-item-name','store-item-qty','store-item-price'].forEach(id=>document.getElementById(id).value='');
  saveDB();
  /* ══ لا تكتب حقلاً لا تملكه هذه الشاشة ══
     كانت تكتب `recipe: item.recipe || null`. ونسخة هذا الجهاز قد لا تحمل
     وصفة الصنف بعد (لم تصل المزامنة، أو فُتح التطبيق دون اتصال) — فتُكتب
     null فوقها و**تُمحى وصفة صنف مركّب كاملة**. وأثرها لا يظهر فوراً: يُباع
     الصنف بعدها ولا يُخصم من مكوّناته شيء.

     هذه الشاشة تُدير الاسم والكمية والسعر وحدها، فلا تمسّ غيرها.
     (الكمية تُكتب هنا عن قصد: المستخدم جردَها بنفسه.) */
  if (isNewItem) {
    // مستند جديد: يُكتب كاملاً — fsUpdate يفشل على مستند غير موجود
    fsSet('store', item.id, { id:item.id, name:item.name, qty:item.qty, price:item.price, recipe:null });
  } else {
    fsUpdate('store', item.id, { name: item.name, qty: item.qty, price: item.price });
  }
}

function deleteStoreItemToTrash(id) {
  /* ⚠️ إصلاح 8.8.3 — الحذف الوحيد في هذا الملف بلا حارس مدير.
     كل أخواته محروسة: deleteInvoiceToTrash و deletePaymentToTrash و
     deleteExpenseToTrash و deleteReturnToTrash. وهذا وحده فاته الحارس،
     بينما القاعدة `store: allow delete: if isManager()` تمنعه فعلاً.

     فما كان يقع للعضو: يختفي الصنف من شاشته ومن رصيد المخزن، ويُكتب
     سجل في السلة (وهو مسموح له)، ويُرفض حذف الصنف من السيرفر. فيبقى
     الصنف عند الجميع، ويعود إلى شاشته عند أول تحديث — ومعه سجل في
     السلة لصنف لم يُحذف. أي أن النتيجة ليست «لم يحدث شيء»، بل سجل
     زائد في سلة المحذوفات يوهم بحذف لم يقع. */
  if (getCurrentUserRole() !== 'manager') { alert('⛔ حذف أصناف المخزن متاح للمدير فقط.'); return; }
  let idx = DB.store.findIndex(i=>i.id===id);
  if (idx === -1) return;
  const item = DB.store[idx];

  /* ══ حارس الأصناف المركّبة ══
     الصنف المركّب يخصم من مكوّناته عند البيع عبر recipe[].componentId.
     حذف مكوّن كان يمرّ بلا أي اعتراض، وبعدها يبحث الخصم عن المكوّن فلا
     يجده فيتخطّاه بصمت (`if (!item) return`) — فيُباع الصنف المركّب ولا
     يُخصم منه شيء إطلاقاً. لا خطأ، ولا رسالة، ولا حتى فرق ظاهر في اليوم
     نفسه؛ يظهر الخلل بعد شهور كفارق جرد لا يعرف أحد مصدره. */
  const usedIn = DB.store.filter(s2 =>
    Array.isArray(s2.recipe) && s2.recipe.some(r => r.componentId === id));
  if (usedIn.length) {
    alert('⛔ لا يمكن حذف «' + item.name + '».\n\n' +
          'هو مكوّن في ' + usedIn.length + ' صنف مركّب:\n' +
          usedIn.map(x => '   • ' + x.name).join('\n') +
          '\n\nاحذفه من مكوّنات هذه الأصناف أولاً، وإلا بيعت بلا خصم من المخزن.');
    return;
  }

  const qtyNote = (item.qty > 0) ? ('\n\nرصيده الحالي ' + fmt(item.qty) + ' — سينتقل معه إلى سلة المحذوفات.') : '';
  if (!confirm('حذف الصنف «' + item.name + '» من المخزن؟' + qtyNote)) return;

  const trashEntry = { type:'صنف مخزن', id:item.id, deletedAt:Date.now(), dateStr:new Date().toLocaleString('ar-EG'), payload:item };
  DB.trash.push(trashEntry);
  DB.store.splice(idx,1);
  saveDB();
  renderAllSections();
  (async () => { try { await fsSet('trash', trashEntry.id, trashEntry); await fsDelete('store', trashEntry.id); } catch (e) { wsSilent('invoices:trash', e); } })();
}

function renderStoreItems() {
  const body = document.getElementById('store-table-body');
  body.innerHTML = '';
  if (!DB.store.length) { body.innerHTML='<tr><td colspan="4" class="p-8 text-center text-sm text-slate-400">المخزن فارغ.</td></tr>'; return; }
  [...DB.store].sort((a,b)=>a.name.localeCompare(b.name)).forEach(i => {
    let tr = document.createElement('tr');
    tr.className = 'text-sm text-slate-700';
    const low = i.qty<=5;
    const isComposite = Array.isArray(i.recipe) && i.recipe.length>0;
    const badge = isComposite ? '<span class="text-xs bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded mr-1">مركب</span>' : '';
    tr.innerHTML = `
      <td class="p-3 font-medium text-slate-900">${escapeHtml(i.name)} ${badge}</td>
      <td class="p-3 font-bold ${low?'text-amber-600':''}">${fmt(i.qty)} ${low?'<span class="text-xs bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded mr-1">منخفض</span>':''}</td>
      <td class="p-3 font-bold text-slate-600">${fmt(i.price)}</td>
      <td class="p-3 text-center">
        ${isComposite ? `<button onclick="openCompositeModal('${escapeAttr(i.id)}')" class="px-2 py-1 bg-purple-50 text-purple-700 rounded text-xs hover:bg-purple-100 ml-1">المكوّنات</button>` : ''}
        <button onclick="editStoreItemDirectly('${escapeAttr(i.id)}')" class="px-2 py-1 bg-slate-100 text-slate-700 rounded text-xs hover:bg-slate-200 ml-1">تعديل</button>
        <button onclick="deleteStoreItemToTrash('${escapeAttr(i.id)}')" class="px-2 py-1 bg-rose-50 text-rose-600 rounded text-xs hover:bg-rose-100">حذف</button>
      </td>`;
    body.appendChild(tr);
  });
}

// ============================================================
// 6.1 COMPOSITE ITEMS (الأصناف المركبة) — صنف يأخذ كمية من أصناف موجودة عند البيع
// ============================================================
let currentRecipe = []; // [{ componentId, componentName, qty, unitPrice }]

function openCompositeModal(editId) {
  currentRecipe = [];
  document.getElementById('composite-item-id').value = '';
  document.getElementById('composite-item-name').value = '';
  document.getElementById('composite-component-search').value = '';
  document.getElementById('composite-component-suggestions').classList.add('hidden');

  if (editId) {
    const item = DB.store.find(s => s.id === editId);
    if (item && Array.isArray(item.recipe)) {
      document.getElementById('composite-modal-title').innerText = 'تعديل الصنف المركب';
      document.getElementById('composite-item-id').value = item.id;
      document.getElementById('composite-item-name').value = item.name;
      // إعادة بناء الوصفة من بيانات المخزن الحالية (مع تحديث الأسعار الحية للمكونات)
      currentRecipe = item.recipe.map(r => {
        const comp = DB.store.find(s => s.id === r.componentId);
        return { componentId: r.componentId, componentName: comp ? comp.name : r.componentName, qty: r.qty, unitPrice: comp ? comp.price : r.unitPrice };
      });
    }
  } else {
    document.getElementById('composite-modal-title').innerText = 'صنف مركب جديد';
  }
  renderCompositeComponentsList();
  document.getElementById('composite-modal').classList.remove('hidden');
}

function closeCompositeModal() {
  document.getElementById('composite-modal').classList.add('hidden');
  currentRecipe = [];
}

function suggestCompositeComponents() {
  const val = document.getElementById('composite-component-search').value.trim().toLowerCase();
  const box = document.getElementById('composite-component-suggestions');
  box.innerHTML = '';
  if (!val) { box.classList.add('hidden'); return; }
  const editingId = document.getElementById('composite-item-id').value;
  // لا يمكن لصنف مركب أن يأخذ نفسه كمكوّن (تجنب حلقة لا نهائية)
  let filtered = DB.store.filter(i => i.name.toLowerCase().includes(val) && i.id !== editingId);
  if (!filtered.length) { box.classList.add('hidden'); return; }
  filtered.forEach(i => {
    let d = document.createElement('div');
    d.className = 'p-3 hover:bg-slate-50 cursor-pointer border-b border-slate-100 text-sm flex justify-between items-center';
    d.innerHTML = `<span>${escapeHtml(i.name)}</span><span class="text-xs bg-slate-200 px-2 py-0.5 rounded text-slate-600">المخزون: ${fmt(i.qty)} | السعر: ${fmt(i.price)}</span>`;
    d.onclick = () => {
      addCompositeComponent(i.id);
      document.getElementById('composite-component-search').value = '';
      box.classList.add('hidden');
    };
    box.appendChild(d);
  });
  box.classList.remove('hidden');
}

function addCompositeComponent(componentId) {
  const comp = DB.store.find(s => s.id === componentId);
  if (!comp) return;
  let existing = currentRecipe.find(r => r.componentId === componentId);
  if (existing) { existing.qty = r2(existing.qty + 1); }
  else { currentRecipe.push({ componentId: comp.id, componentName: comp.name, qty: 1, unitPrice: comp.price }); }
  renderCompositeComponentsList();
}

function updateCompositeComponentQty(componentId, qty) {
  const row = currentRecipe.find(r => r.componentId === componentId);
  if (!row) return;
  const q = r2(qty);
  if (isNaN(q) || q <= 0) return;
  row.qty = q;
  renderCompositeComponentsList();
}

function removeCompositeComponent(componentId) {
  currentRecipe = currentRecipe.filter(r => r.componentId !== componentId);
  renderCompositeComponentsList();
}

function renderCompositeComponentsList() {
  const list = document.getElementById('composite-components-list');
  const empty = document.getElementById('composite-no-components');
  list.innerHTML = '';
  if (!currentRecipe.length) {
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    currentRecipe.forEach(r => {
      let row = document.createElement('div');
      row.className = 'flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl p-2.5';
      row.innerHTML = `
        <span class="flex-1 text-sm font-medium text-slate-800">${escapeHtml(r.componentName)}</span>
        <span class="text-xs text-slate-500">السعر: ${fmt(r.unitPrice)}</span>
        <input type="number" min="0.01" step="any" value="${escapeHtml(r.qty)}" class="w-20 p-2 bg-white border border-slate-200 rounded-lg text-center text-sm"
          onchange="updateCompositeComponentQty('${escapeAttr(r.componentId)}', this.value)">
        <button onclick="removeCompositeComponent('${escapeAttr(r.componentId)}')" class="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg"><i data-lucide="x-circle" class="w-4 h-4"></i></button>`;
      list.appendChild(row);
    });
    refreshIcons();
  }
  const total = r2(currentRecipe.reduce((a, r) => a + (r.qty * r.unitPrice), 0));
  document.getElementById('composite-total-price').innerText = fmt(total);
}

function saveCompositeItem() {
  const name = document.getElementById('composite-item-name').value.trim();
  const editId = document.getElementById('composite-item-id').value;
  if (!name) { alert('يرجى إدخال اسم الصنف المركب.'); return; }
  if (!currentRecipe.length) { alert('يرجى إضافة مكوّن واحد على الأقل.'); return; }

  // منع التعارض مع اسم صنف آخر (عدا الصنف الجاري تعديله)
  const dup = DB.store.find(s => s.name.toLowerCase() === name.toLowerCase() && s.id !== editId);
  if (dup) { alert('يوجد صنف آخر بنفس الاسم بالفعل.'); return; }

  const totalPrice = r2(currentRecipe.reduce((a, r) => a + (r.qty * r.unitPrice), 0));
  const recipePayload = currentRecipe.map(r => ({ componentId: r.componentId, componentName: r.componentName, qty: r.qty }));

  let newOrUpdatedItem;
  if (editId) {
    let item = DB.store.find(s => s.id === editId);
    if (item) {
      item.name = name;
      item.price = totalPrice;
      item.recipe = recipePayload;
      newOrUpdatedItem = item;
      alert('تم تحديث الصنف المركب.');
    }
  } else {
    newOrUpdatedItem = { id: wsUid('STR-'), name, qty: 0, price: totalPrice, recipe: recipePayload };
    DB.store.push(newOrUpdatedItem);
    alert('تم إنشاء الصنف المركب بنجاح. سيُخصم من مكوّناته تلقائياً عند بيعه.');
  }
  saveDB();
  closeCompositeModal();

  /* ══ تعديل الصنف يجب ألا يمسّ كميته ══
     fsSet يستبدل المستند كاملاً، فيكتب qty من نسخة هذا الجهاز. ولو كان
     زميل قد باع من الصنف قبل ثوانٍ — أو لم تصل نسخة المخزن بعد — تُمحى
     الكمية الحقيقية وتعود لما كان عليه هذا الجهاز. ويظهر ذلك في الجرد
     كنقص أو زيادة بلا سبب يُعرف.

     التعديل يُحدّث الحقول المعنية وحدها؛ والإنشاء وحده يكتب المستند
     كاملاً لأنه لا كمية سابقة تُخشى عليها. */
  if (newOrUpdatedItem) {
    if (editId) {
      fsUpdate('store', newOrUpdatedItem.id, {
        name: newOrUpdatedItem.name,
        price: newOrUpdatedItem.price,
        recipe: newOrUpdatedItem.recipe
      });
    } else {
      fsSet('store', newOrUpdatedItem.id, newOrUpdatedItem);
    }
  }
}

function editStoreItemDirectly(id) {
  let item = DB.store.find(i=>i.id===id);
  if (item) {
    if (Array.isArray(item.recipe) && item.recipe.length) {
      if (!confirm('هذا صنف مركب — سعره يُحتسب تلقائياً من مكوّناته. لتعديل مكوّناته اضغط زر "المكوّنات" بدلاً من ذلك.\
\
هل تريد المتابعة وتعديل الاسم/السعر يدوياً مع ذلك؟')) return;
    }
    document.getElementById('store-item-name').value = item.name;
    document.getElementById('store-item-qty').value = item.qty;
    document.getElementById('store-item-price').value = item.price;
    document.getElementById('store-item-name').scrollIntoView({behavior:'smooth'});
  }
}

// ============================================================
// 7. INVENTORY DASHBOARD
// ============================================================
function renderInventoryDashboard() {
  const filter = document.getElementById('jard-time-filter').value;
  let fs=DB.sales, fe=DB.expenses, fp=DB.payments, fr=DB.returns;
  if (filter!=='all') {
    const ms = {daily:86400000, monthly:30*86400000, yearly:365*86400000}[filter];
    const lim = Date.now()-ms;
    fs=DB.sales.filter(s=>s.timestamp>=lim);
    fe=DB.expenses.filter(e=>e.timestamp>=lim);
    fp=DB.payments.filter(p=>p.timestamp>=lim);
    fr=DB.returns.filter(r=>r.timestamp>=lim);
  }
  const totalSales = r2(fs.reduce((a,s)=>a+(s.subtotal||0),0));
  // مجموع ما دخل فعلياً (كل المدفوعات ما عدا الرصيد الدائن والاسترداد النقدي)
  const totalGrossIn  = r2(fp.filter(p=>!p.isRefund&&!p.isCredit&&p.type!=='رصيد للعميل').reduce((a,p)=>a+(p.amount||0),0));
  // مجموع ما خرج نقداً كاسترداد
  const totalCashRefund = r2(fp.filter(p=>p.isRefund===true).reduce((a,p)=>a+(p.amount||0),0));
  // صافي المدفوعات الواردة = الداخل - الاسترداد النقدي
  const totalPaid = r2(totalGrossIn - totalCashRefund);
  const totalExp = r2(fe.reduce((a,e)=>a+(e.amount||0),0));
  const totalDebt = r2(fs.reduce((a,s)=>a+(s.netDebt||0),0));
  const totalRet  = r2(fr.reduce((a,r)=>a+(r.total||0),0));
  /* ملاحظتان مهمتان على هذين الرقمين:

     1) totalSales هو مجموع subtotal للفواتير، وقيمة أي إرجاع تُحذف من
        subtotal فاتورتها لحظة تسجيله. فالمرتجعات مخصومة أصلاً، وطرح
        totalRet مرة أخرى كان يخصمها مرتين ويُظهر المبيعات أقل مما هي.
        نعرضها الآن رقماً مستقلاً للعلم، بلا طرح مكرر.

     2) هذا الرقم «صافي النقد» لا «الربح»: النظام لا يسجّل سعر تكلفة
        للأصناف إطلاقاً، فلا سبيل لحساب ربح حقيقي. تسميته ربحاً كانت
        تُظهر المحل رابحاً وهو قد يبيع بأقل من التكلفة دون أن يظهر ذلك. */
  const netCash = r2(totalPaid - totalExp);

  document.getElementById('stats-counters-container').innerHTML = `
    <div class="bg-white p-5 rounded-2xl custom-shadow border-r-4 border-blue-600">
      <span class="text-xs text-slate-400 font-bold block">إجمالي المبيعات</span>
      <span class="text-2xl font-black text-slate-900 block mt-1">${fmt(totalSales)}</span>
      ${totalRet>0?`<span class="text-xs text-amber-600">تتضمّن خصم مرتجعات بقيمة ${fmt(totalRet)}</span>`:''}
    </div>
    <div class="bg-white p-5 rounded-2xl custom-shadow border-r-4 border-emerald-500">
      <span class="text-xs text-slate-400 font-bold block">المدفوعات الواردة</span>
      <span class="text-2xl font-black text-emerald-600 block mt-1">${fmt(totalPaid)}</span>
    </div>
    <div class="bg-white p-5 rounded-2xl custom-shadow border-r-4 border-rose-500">
      <span class="text-xs text-slate-400 font-bold block">المصروفات الكلية</span>
      <span class="text-2xl font-black text-rose-600 block mt-1">${fmt(totalExp)}</span>
    </div>
    <div class="bg-white p-5 rounded-2xl custom-shadow border-r-4 border-purple-500">
      <span class="text-xs text-slate-400 font-bold block">صافي النقد (مقبوضات − مصروفات)</span>
      <span class="text-2xl font-black text-purple-600 block mt-1">${fmt(netCash)}</span>
      <span class="text-[10px] text-slate-400 block mt-1">ليس ربحاً — سعر التكلفة غير مسجَّل في النظام</span>
    </div>
    ${totalCashRefund>0?`
    <div class="bg-white p-5 rounded-2xl custom-shadow border-r-4 border-orange-500">
      <span class="text-xs text-slate-400 font-bold block">استرداد نقدي للعملاء ↑</span>
      <span class="text-2xl font-black text-orange-600 block mt-1">- ${fmt(totalCashRefund)}</span>
      <span class="text-xs text-slate-400">مخصوم من المدفوعات الواردة</span>
    </div>`:''}`;

  const maxV = Math.max(totalSales, totalPaid, totalExp, totalDebt, totalRet, 1);
  const pct = v => r2((v/maxV)*100);
  document.getElementById('jard-bars-visualizer').innerHTML = `
    ${bar('المبيعات الإجمالية', totalSales, 'blue-600', pct(totalSales))}
    ${bar('المرتجعات (كامل القيمة)', totalRet, 'amber-500', pct(totalRet))}
    ${totalCashRefund>0?bar('منها: استرداد نقدي فعلي', totalCashRefund, 'orange-500', pct(totalCashRefund)):''}
    ${bar('المدفوعات المحصلة', totalPaid, 'emerald-500', pct(totalPaid))}
    ${bar('المصروفات', totalExp, 'rose-500', pct(totalExp))}
    ${bar('الديون القائمة', totalDebt, 'purple-500', pct(totalDebt))}`;
}

function bar(label, val, color, pct) {
  return `<div class="space-y-1">
    <div class="flex justify-between text-xs font-bold text-slate-600"><span>${escapeHtml(label)}</span><span>${fmt(val)}</span></div>
    <div class="w-full bg-slate-100 h-3.5 rounded-full overflow-hidden">
      <div class="bg-${color} h-full rounded-full transition-all duration-500" style="width:${pct}%"></div>
    </div>
  </div>`;
}

// ============================================================
// 7b. SALES QTY AUDIT — جرد الكميات المباعة
// ============================================================
let auditSelectedItems = []; // أسماء الأصناف المختارة للجرد
let _auditDataByItem = null; // آخر نتائج جرد تم توليدها (Map: اسم الصنف -> صفوف الحركات)

// يبني قائمة موحّدة بكل أسماء الأصناف المعروفة للنظام:
// أصناف مسجلة حالياً في المخزن + أصناف ظهرت في أرشيف الفواتير (DB.sales) فقط ولو لم تعد/لم تكن مسجلة بالمخزن
function getAllAuditableItems() {
  const map = new Map(); // name -> { inStore, qty }
  DB.store.forEach(i => map.set(i.name, { inStore: true, qty: i.qty }));
  DB.sales.forEach(inv => {
    (inv.items || []).forEach(it => {
      if (!map.has(it.name)) map.set(it.name, { inStore: false, qty: 0 });
    });
  });
  return map;
}

function suggestAuditItems() {
  const val = document.getElementById('audit-item-search').value.trim().toLowerCase();
  const box = document.getElementById('audit-item-suggestions');
  box.innerHTML = '';
  if (!val) { box.classList.add('hidden'); return; }
  const allItems = getAllAuditableItems();
  let filtered = [...allItems.entries()]
    .filter(([name]) => name.toLowerCase().includes(val) && !auditSelectedItems.includes(name))
    .sort((a,b) => a[0].localeCompare(b[0], 'ar'));
  if (!filtered.length) { box.classList.add('hidden'); return; }
  filtered.forEach(([name, info]) => {
    let d = document.createElement('div');
    d.className = 'p-3 hover:bg-slate-50 cursor-pointer border-b border-slate-100 text-sm flex justify-between items-center';
    const badge = info.inStore
      ? `<span class="text-xs bg-slate-200 px-2 py-0.5 rounded text-slate-600">المخزون: ${fmt(info.qty)}</span>`
      : `<span class="text-xs bg-amber-100 px-2 py-0.5 rounded text-amber-700 font-bold">غير مسجل بالمخزن (أرشيف فقط)</span>`;
    d.innerHTML = `<span>${escapeHtml(name)}</span>${badge}`;
    d.onclick = () => addAuditItem(name);
    box.appendChild(d);
  });
  box.classList.remove('hidden');
}

function addAuditItem(name) {
  if (!auditSelectedItems.includes(name)) auditSelectedItems.push(name);
  document.getElementById('audit-item-search').value = '';
  document.getElementById('audit-item-suggestions').innerHTML = '';
  document.getElementById('audit-item-suggestions').classList.add('hidden');
  renderAuditSelectedChips();
}

function removeAuditItem(name) {
  auditSelectedItems = auditSelectedItems.filter(n => n !== name);
  renderAuditSelectedChips();
}

function renderAuditSelectedChips() {
  const box = document.getElementById('audit-selected-items');
  box.innerHTML = '';
  if (!auditSelectedItems.length) {
    box.innerHTML = '<span class="text-xs text-slate-400">لم يتم اختيار أي صنف بعد.</span>';
    return;
  }
  auditSelectedItems.forEach(name => {
    const chip = document.createElement('span');
    chip.className = 'inline-flex items-center gap-1.5 bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold px-3 py-1.5 rounded-full';
    const label = document.createElement('span');
    label.innerText = name;
    const rm = document.createElement('button');
    rm.className = 'text-blue-400 hover:text-blue-700 font-black leading-none';
    rm.innerText = '✕';
    rm.onclick = () => removeAuditItem(name);
    chip.appendChild(label);
    chip.appendChild(rm);
    box.appendChild(chip);
  });
}

function setAuditPeriod(period) {
  const now = new Date();
  let from;
  if (period === 'today') from = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  else if (period === 'week') { from = new Date(now); from.setDate(from.getDate() - 7); }
  else if (period === 'month') from = new Date(now.getFullYear(), now.getMonth(), 1);
  const fmt2 = d => d.toISOString().split('T')[0];
  document.getElementById('audit-date-from').value = fmt2(from);
  document.getElementById('audit-date-to').value = fmt2(new Date(now));
}

function clearAuditFilters() {
  auditSelectedItems = [];
  renderAuditSelectedChips();
  document.getElementById('audit-item-search').value = '';
  document.getElementById('audit-item-suggestions').innerHTML = '';
  document.getElementById('audit-item-suggestions').classList.add('hidden');
  document.getElementById('audit-date-from').value = '';
  document.getElementById('audit-date-to').value = '';
  document.getElementById('audit-summary').classList.add('hidden');
  document.getElementById('audit-summary').innerHTML = '';
  document.getElementById('audit-results').innerHTML = '';
}

function generateSalesQtyAudit() {
  if (!auditSelectedItems.length) { alert('يرجى اختيار صنف واحد على الأقل من قائمة الأصناف.'); return; }

  const fromVal = document.getElementById('audit-date-from').value;
  const toVal   = document.getElementById('audit-date-to').value;
  if (fromVal && toVal && dayStartTs(fromVal) > dayStartTs(toVal)) {
    alert('تاريخ البداية يجب أن يكون قبل تاريخ النهاية.');
    return;
  }
  const fromTs = fromVal ? dayStartTs(fromVal) : 0;
  const toTs   = toVal   ? dayEndTs(toVal) : Infinity;

  const dataByItem = new Map();
  auditSelectedItems.forEach(name => dataByItem.set(name, []));

  DB.sales.forEach(inv => {
    if (!tsInRange(inv.timestamp, fromTs, toTs)) return;
    (inv.items || []).forEach(it => {
      if (dataByItem.has(it.name)) {
        dataByItem.get(it.name).push({
          qty: it.qty,
          customerName: inv.customerName,
          date: inv.date,
          timestamp: inv.timestamp || 0,
          invId: inv.id
        });
      }
    });
  });

  auditSelectedItems.forEach(name => {
    dataByItem.get(name).sort((a,b) => (b.timestamp||0) - (a.timestamp||0));
  });

  _auditDataByItem = dataByItem;
  renderSalesQtyAuditResults(dataByItem);
}

function renderSalesQtyAuditResults(dataByItem) {
  const resultsBox = document.getElementById('audit-results');
  const summaryBox = document.getElementById('audit-summary');

  let controlsHtml = `
    <div class="flex flex-wrap items-center gap-2 mb-1">
      <span class="text-xs font-bold text-slate-500">تحديد الكميات المطلوب جمعها:</span>
      <button onclick="toggleAuditAllGlobal(true)" class="px-3 py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-bold hover:bg-emerald-100">✔️ تحديد الكل</button>
      <button onclick="toggleAuditAllGlobal(false)" class="px-3 py-1.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold hover:bg-rose-100">✖️ إلغاء تحديد الكل</button>
      <span class="text-[11px] text-slate-400">يمكنك أيضاً تحديد كمية واحدة من فاتورة وترك كمية أخرى من نفس الصنف أو فاتورة أخرى دون تحديد.</span>
    </div>`;

  let html = '';

  auditSelectedItems.forEach((name, iIdx) => {
    const rows = dataByItem.get(name) || [];

    html += `
    <div class="border border-slate-200 rounded-xl overflow-hidden" data-audit-block="${iIdx}">
      <div class="bg-slate-50 p-3 flex justify-between items-center flex-wrap gap-2 border-b border-slate-200">
        <label class="flex items-center gap-2 font-black text-slate-800 cursor-pointer">
          <input type="checkbox" class="audit-item-all-chk w-4 h-4" data-iidx="${iIdx}" checked onchange="toggleAuditItemAll(this)">
          ${escapeHtml(name)}
        </label>
        <span class="text-xs font-bold text-slate-500">
          عدد الفواتير: ${rows.length} — المحدد: <span id="audit-item-count-${iIdx}">${rows.length}</span> —
          إجمالي الكمية المحددة: <span id="audit-item-total-${iIdx}" class="text-blue-700">${fmt(r2(rows.reduce((a,r)=>a+(+r.qty||0),0)))}</span>
        </span>
      </div>
      ${rows.length ? `
      <div class="overflow-x-auto">
        <table class="w-full text-right border-collapse text-sm">
          <thead><tr class="bg-slate-50/50 text-slate-500 text-xs">
            <th class="p-2.5 w-10"></th><th class="p-2.5">تاريخ الفاتورة</th><th class="p-2.5">اسم العميل</th><th class="p-2.5">رقم الفاتورة</th><th class="p-2.5 text-left">الكمية</th>
          </tr></thead>
          <tbody class="divide-y divide-slate-100">
            ${rows.map((r,rIdx) => `
            <tr class="hover:bg-slate-50/50">
              <td class="p-2.5"><input type="checkbox" class="audit-row-chk w-4 h-4" data-iidx="${iIdx}" data-ridx="${rIdx}" checked onchange="recalcAuditTotals()"></td>
              <td class="p-2.5 text-xs text-slate-400">${escapeHtml(r.date)}</td>
              <td class="p-2.5 font-bold text-slate-800">${escapeHtml(r.customerName)}</td>
              <td class="p-2.5">${invLinkHtml(r.invId, {small:true})}</td>
              <td class="p-2.5 text-left font-black text-blue-700">${fmt(r.qty)}</td>
            </tr>`).join('')}
          </tbody>
          <tfoot>
            <tr class="bg-blue-50/60 font-black text-blue-800">
              <td class="p-2.5" colspan="4">إجمالي ${escapeHtml(name)} (المحدد فقط)</td>
              <td class="p-2.5 text-left" id="audit-item-total-foot-${iIdx}">${fmt(r2(rows.reduce((a,r)=>a+(+r.qty||0),0)))}</td>
            </tr>
          </tfoot>
        </table>
      </div>` : `<div class="p-6 text-center text-slate-400 text-sm">لا توجد مبيعات لهذا الصنف خلال الفترة المحددة.</div>`}
    </div>`;
  });

  resultsBox.innerHTML = (auditSelectedItems.length ? controlsHtml : '') + html;
  refreshIcons();
  recalcAuditTotals();
}

// إعادة حساب الإجماليات بناءً على الصفوف المحددة فقط (كميات مختارة جزئياً أو كلياً)
function recalcAuditTotals() {
  if (!_auditDataByItem) return;
  const summaryBox = document.getElementById('audit-summary');
  let grandQty = 0, grandLines = 0;
  const allCustomers = new Set();

  auditSelectedItems.forEach((name, iIdx) => {
    const rows = _auditDataByItem.get(name) || [];
    const rowChks = document.querySelectorAll(`.audit-row-chk[data-iidx="${iIdx}"]`);
    let itemQty = 0, itemCount = 0, totalCount = rowChks.length, checkedCount = 0;
    rowChks.forEach(chk => {
      const rIdx = +chk.dataset.ridx;
      const row = rows[rIdx];
      if (!row) return;
      if (chk.checked) {
        itemQty = r2(itemQty + (+row.qty || 0));
        itemCount++;
        checkedCount++;
        allCustomers.add(row.customerName);
      }
    });
    grandQty = r2(grandQty + itemQty);
    grandLines += itemCount;

    const totalEl = document.getElementById(`audit-item-total-${iIdx}`);
    const footEl  = document.getElementById(`audit-item-total-foot-${iIdx}`);
    const countEl = document.getElementById(`audit-item-count-${iIdx}`);
    if (totalEl) totalEl.innerText = fmt(itemQty);
    if (footEl)  footEl.innerText  = fmt(itemQty);
    if (countEl) countEl.innerText = itemCount;

    // تحديث حالة مربع "تحديد الكل" لهذا الصنف (محدد / غير محدد / جزئي)
    const allChk = document.querySelector(`.audit-item-all-chk[data-iidx="${iIdx}"]`);
    if (allChk) {
      allChk.checked = totalCount > 0 && checkedCount === totalCount;
      allChk.indeterminate = checkedCount > 0 && checkedCount < totalCount;
    }
  });

  if (summaryBox) {
    summaryBox.className = 'grid grid-cols-2 md:grid-cols-3 gap-3';
    summaryBox.innerHTML = `
      <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center"><div class="text-xs text-blue-500 font-bold">إجمالي الكمية المحددة (كل الأصناف)</div><div class="text-lg font-black text-blue-700">${fmt(grandQty)}</div></div>
      <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center"><div class="text-xs text-emerald-500 font-bold">عدد الحركات المحددة</div><div class="text-lg font-black text-emerald-700">${grandLines}</div></div>
      <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 text-center"><div class="text-xs text-amber-500 font-bold">عدد العملاء المختلفين (ضمن المحدد)</div><div class="text-lg font-black text-amber-700">${allCustomers.size}</div></div>`;
    summaryBox.classList.remove('hidden');
  }
}

// تحديد/إلغاء تحديد كل صفوف صنف واحد دفعة واحدة
function toggleAuditItemAll(checkboxEl) {
  const iIdx = checkboxEl.dataset.iidx;
  document.querySelectorAll(`.audit-row-chk[data-iidx="${iIdx}"]`).forEach(chk => { chk.checked = checkboxEl.checked; });
  recalcAuditTotals();
}

// تحديد/إلغاء تحديد كل الكميات في كل الأصناف دفعة واحدة
function toggleAuditAllGlobal(state) {
  document.querySelectorAll('.audit-row-chk').forEach(chk => { chk.checked = state; });
  document.querySelectorAll('.audit-item-all-chk').forEach(chk => { chk.checked = state; chk.indeterminate = false; });
  recalcAuditTotals();
}

// ============================================================
// 8. PAYMENTS LEDGER
// ============================================================
function renderPaymentsLedger() {
  const body = document.getElementById('payments-ledger-body');
  body.innerHTML = '';
  if (!DB.payments.length) { body.innerHTML='<tr><td colspan="6" class="p-8 text-center text-sm text-slate-400">لا توجد مدفوعات مسجلة.</td></tr>'; return; }
  let totalIn = 0, totalOut = 0;
  const rows = [...DB.payments].reverse();
  rows.forEach(p => {
    let tr = document.createElement('tr');
    const outgoing = p.isRefund === true;
    const neutral  = p.isCredit || p.type === 'رصيد للعميل';
    tr.className = `text-sm text-slate-700 hover:bg-slate-50 ${outgoing?'bg-rose-50/40':''}`;
    const amtColor = outgoing ? 'text-rose-600' : neutral ? 'text-amber-600' : 'text-emerald-600';
    const amtPrefix = outgoing ? '↑ - ' : '↓ + ';
    const badgeColor = outgoing ? 'bg-rose-100 text-rose-700' : neutral ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700';
    if (outgoing) totalOut = r2(totalOut + p.amount);
    else if (!neutral) totalIn = r2(totalIn + p.amount);
    tr.innerHTML = `
      <td class="p-3 font-medium text-slate-900">${escapeHtml(p.customerName)}</td>
      <td class="p-3 font-black ${amtColor}">${amtPrefix}${fmt(p.amount)}</td>
      <td class="p-3"><span class="${badgeColor} px-2.5 py-1 rounded text-xs font-bold">${escapeHtml(p.type)}</span></td>
      <td class="p-3 text-xs text-slate-500">${linkifyInvoiceRefs(p.reason)}</td>
      <td class="p-3 text-xs text-slate-400">${escapeHtml(p.date)}${p.signedBy ? '<br><span class="text-blue-500 font-bold text-xs">✍️ '+escapeHtml(p.signedBy)+'</span>' : ''}</td>
      <td class="p-3 text-center">${isManager() ? `<button ${p.id?'':'disabled'} onclick="deletePaymentToTrash('${escapeAttr(p.id)}')" style="padding:5px 10px;border-radius:8px;background:${p.id?'#fee2de':'#f2f5f5'};color:${p.id?'#d33722':'#a0a2a1'};border:none;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:${p.id?'pointer':'not-allowed'};">🗑️</button>` : ''}</td>`;
    body.appendChild(tr);
  });
  // صف ملخص في الأسفل
  if (rows.length > 0) {
    const net = r2(totalIn - totalOut);
    let sumTr = document.createElement('tr');
    sumTr.className = 'bg-slate-100 font-bold text-sm border-t-2 border-slate-300';
    sumTr.innerHTML = `
      <td class="p-3 text-slate-700">الإجمالي</td>
      <td class="p-3 text-emerald-700">↓ ${fmt(totalIn)}</td>
      <td class="p-3 text-rose-600">${totalOut>0?'↑ '+fmt(totalOut):''}</td>
      <td class="p-3 text-slate-700 font-black">صافي: ${fmt(net)}</td>
      <td></td>
      <td></td>`;
    body.appendChild(sumTr);
  }
}

// ============================================================
// 9. TRASH
// ============================================================
function renderTrashSection() {
  const body = document.getElementById('trash-table-body');
  body.innerHTML = '';
  if (!DB.trash.length) { body.innerHTML='<tr><td colspan="4" class="p-8 text-center text-sm text-slate-400">السلة فارغة.</td></tr>'; return; }
  [...DB.trash].forEach((item,idx) => {
    let tr = document.createElement('tr');
    tr.className = 'text-sm text-slate-700';
    let desc = item.type==='فاتورة مبيعات' ? `${item.payload.id} — ${item.payload.customerName}` : (item.payload.name||item.payload.title||item.id);
    /* إصلاح 8.8: لا قفل زمني. نعرض عمر السجل في السلة كمعلومة مفيدة
       بدل عدّاد يمنع المدير من التنظيف. */
    const age = trashAgeDays(item);
    tr.innerHTML = `
      <td class="p-3 font-bold text-slate-600">${escapeHtml(item.type)}</td>
      <td class="p-3 text-xs text-slate-500">${escapeHtml(desc)}</td>
      <td class="p-3 text-xs text-rose-500 font-mono">${escapeHtml(item.dateStr)}
        <div class="text-[10px] text-slate-400 font-bold mt-1">
          ${item.deletedAt ? 'في السلة منذ ' + age + ' يوماً' : 'في السلة'}
        </div>
      </td>
      <td class="p-3 text-center whitespace-nowrap">
        ${isManager()
          ? `<button onclick="restoreTrashItem(${idx})" class="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-bold">استعادة</button>`
          : `<span class="px-3 py-1 rounded text-xs font-bold bg-slate-100 text-slate-400" title="الاستعادة للمدير فقط">🔒 للمدير</span>`}
        ${isManager() ? `<button onclick="purgeTrashItem(${idx})"
          class="px-3 py-1 rounded text-xs font-bold mr-1 bg-rose-600 hover:bg-rose-700 text-white"
          title="حذف نهائي لا رجعة فيه">حذف نهائي</button>` : ''}
      </td>`;
    body.appendChild(tr);
  });
}

function restoreTrashItem(idx) {
  /* ⚠️ إصلاح 8.8.3 — زر بلا صلاحية: يعمل على الجهاز ويرفضه السيرفر.

     زر «استعادة» كان ظاهراً لكل عضو، بينما «حذف نهائي» بجواره محجوب
     للمدير. والاستعادة تُصدر ثلاث كتابات، **كلّها ممنوعة على العضو**
     في قواعد السيرفر:

       • fsSet('sales', …)   — الإنشاء يشترط signedByUid == uid، والحمولة
                               تحمل توقيع مُصدِرها الأصلي لا المستعيد.
       • fsDelete('trash',…) — الحذف من السلة للمدير وحده.
       • fsSet('payments',…) — للدفعات المرتبطة، وشرطها التوقيع كذلك.

     فالنتيجة قبل الإصلاح: تظهر «✅ تمت الاستعادة بنجاح»، وتعود الفاتورة
     إلى الشاشة، ويختفي سجلها من السلة — ثم يرفض السيرفر الثلاثة، فتعود
     الفاتورة إلى العدم عند أول تحديث، ويعود سجل السلة كما كان. ولا شيء
     يفسّر ما جرى: الرسالة قالت نجاحاً، والشاشة أكّدته للحظة.

     والأسوأ أن الدالة تُعدّل الحساب قبل الرفع: تخصم المخزون، وتستهلك
     رصيد العميل، وتُعيد توزيع الدفعات على الديون. فهذه كلها تقع محلياً
     ثم تُرفض — فيقرأ العضو أرقاماً لا وجود لها عند بقية الأجهزة.

     الاستعادة عملية مدير بطبيعتها (كالحذف النهائي)، فنُصرّح بذلك في
     الواجهة بدل تركها تفشل بصمت. */
  if (!isManager()) {
    alert('⛔ استعادة السجلات المحذوفة متاحة للمدير فقط.\n\n' +
          'اطلب من المدير استعادتها — الزر يعمل من حسابه.');
    return;
  }
  let t = DB.trash[idx];
  // سجل تالف أو استعادة مكرّرة (نقرتان سريعتان) كانت تنهار على payload غير موجود
  if (!t || !t.payload || !t.payload.id) { alert('⚠️ سجل غير صالح في سلة المحذوفات.'); return; }
  if (t.type === 'فاتورة مبيعات' && DB.sales.some(x => x.id === t.payload.id)) {
    alert('هذه الفاتورة مستعادة بالفعل.'); return;
  }
  if (t.type === 'دفعة/واصل سداد' && DB.payments.some(x => x.id === t.payload.id)) {
    alert('هذه الدفعة مستعادة بالفعل.'); return;
  }
  let targetCol = null;
  const extraSyncs = [];
  if (t.type==='فاتورة مبيعات') {
    t.payload.items.forEach(si => deductStockForInvoiceItem(si));
    DB.sales.push(t.payload);
    targetCol = 'sales';
    // إعادة أي دفعات كانت مرتبطة بالفاتورة وحُذفت معها
    (t.linkedPayments || []).forEach(p => { DB.payments.push(p); extraSyncs.push(() => fsSet('payments', p.id, p)); });
    // إعادة استهلاك الرصيد الدائن الذي كان أُعيد للعميل عند الحذف
    if (t.payload.creditUsed > 0) { consumeCustomerCredit(t.payload.customerName, t.payload.creditUsed); extraSyncs.push(() => syncCreditBalance(t.payload.customerName)); }
    // إعادة تطبيق سداد الدين السابق الذي كان أُلغي عند الحذف
    (t.payload.debtPayDistribution || []).forEach(d => {
      const s = DB.sales.find(x => x.id === d.saleId);
      if (s) { s.paid = r2(s.paid + d.amountApplied); s.netDebt = r2(Math.max(0, s.netDebt - d.amountApplied)); extraSyncs.push(() => fsUpdate('sales', s.id, { paid: s.paid, netDebt: s.netDebt })); }
    });
  } else if (t.type==='صنف مخزن') {
    DB.store.push(t.payload);
    targetCol = 'store';
  } else if (t.type==='مصروفات') {
    DB.expenses.push(t.payload);
    targetCol = 'expenses';
  } else if (t.type==='دفعة/واصل سداد') {
    DB.payments.push(t.payload);
    targetCol = 'payments';
    /* إعادة تطبيق الدفعة على الفواتير التي كانت سدّدتها.
       الحذف صار يعكس التوزيع (يُرجع الدين)، فلو لم تُعِد الاستعادة
       تطبيقه لبقيت الدفعة ظاهرة في المقبوضات والدين قائماً في الوقت
       نفسه — أي أن العميل يُطالَب بمبلغ سدّده فعلاً. */
    /* ما يتعذّر تطبيقه على الديون يعود رصيداً للعميل، ولا يُهمَل.
       الديون قد تكون سُدِّدت بطريق آخر بعد حذف هذه الدفعة، فيصير المبلغ
       بلا مكان يذهب إليه. إهماله كان يُعيد الدفعة إلى دفتر المقبوضات
       (نقد داخل) بلا أي أثر مقابل — فيبدو أن المحل قبض مالاً بلا سبب. */
    let unapplied = r2(t.payload.amount || 0);
    (t.payload.debtDistribution || []).forEach(d => {
      const s2 = DB.sales.find(x => x.id === d.saleId);
      if (!s2) return;
      const applied = r2(Math.min(d.amountApplied || 0, s2.netDebt || 0));
      if (applied <= 0) return;
      s2.paid = r2((s2.paid || 0) + applied);
      s2.netDebt = r2(Math.max(0, s2.subtotal - invoiceSettled(s2)));
      unapplied = r2(unapplied - applied);
      extraSyncs.push(() => fsUpdate('sales', s2.id, { paid: s2.paid, netDebt: s2.netDebt }));
    });
    if (unapplied > 0.011) {
      addCustomerCredit(t.payload.customerName, unapplied);
      extraSyncs.push(() => syncCreditBalance(t.payload.customerName));
    }
  }
  DB.trash.splice(idx,1);
  saveDB();
  if ((t.payload && t.payload.customerName) || '') reconcileAndSync((t.payload && t.payload.customerName) || '', { silent: true });
  showSuccessToast('✅ تمت الاستعادة بنجاح.');
  if (targetCol) {
    (async () => {
      try {
        await fsSet(targetCol, t.payload.id, t.payload);
        await fsDelete('trash', t.id);
        await Promise.all(extraSyncs.map(fn => fn().catch(()=>{})));
      } catch (e) { wsSilent('invoices:trash', e); }
    })();
  }
}

// ============================================================
// 10. BACKUP
// ============================================================
function _buildBackupPayload() {
  return (window.AppBackup && AppBackup.create)
    ? AppBackup.create(DB, { appVersion: 'v173' })
    : DB;
}

function _backupJson() { return JSON.stringify(_buildBackupPayload()); }
async function _backupJsonAsync() {
  return (window.AppBackup && AppBackup.stringifyAsync) ? await AppBackup.stringifyAsync(DB, { appVersion: 'v240' }) : _backupJson();
}

async function exportBackupFile() {
  try {
    const blob = new Blob([await _backupJsonAsync()], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = `نسخة_احتياطية_اللمسة_${Date.now()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  } catch (e) { alert('تعذّر إنشاء النسخة الاحتياطية: ' + (e && e.message ? e.message : e)); }
}

// ============================================================
// GOOGLE DRIVE BACKUP — نسخ احتياطي على Google Drive
// ============================================================
let _gdriveToken = null;
let _gdriveFileId = null;
let _gdriveAutoBackup = false;

/* ⚠️ إصلاح 8.8 — رمز Google Drive لم يعد يُحفظ في localStorage.
   كان يُخزَّن نصاً صريحاً فيقرؤه أي حقن على الصفحة (وقد كان موجوداً
   فعلاً في إيصال السداد) ويبقى بعد إغلاق التطبيق. والرمز يمنح صلاحية
   كتابة على ملفات Drive — أي أن تسريبه يعني العبث بالنسخة الاحتياطية.
   الآن في الذاكرة فقط. الأثر: ضغطة اتصال واحدة في كل جلسة نسخ — والرمز
   أصلاً تنتهي صلاحيته خلال ساعة، فالحفظ لم يكن يوفّر كثيراً.
   ونمسح هنا أي رمز قديم بقي على أجهزة العاملين. */
function _gdriveLoadInit() {
  if (_gdriveFileId === null) _gdriveFileId = localStorage.getItem('gdrive_file_id') || null;
  if (!_gdriveAutoBackup) _gdriveAutoBackup = localStorage.getItem('gdrive_auto') === 'true';
  try { localStorage.removeItem('gdrive_token'); } catch (e) {}
  const autoEl = document.getElementById('gdrive-auto');
  if (autoEl) autoEl.checked = _gdriveAutoBackup;
}

function _gdriveEnsureGIS(cb) {
  if (_isLoaded) { cb(); return; }
  if (document.getElementById('_gis_script')) {
    let t = setInterval(() => { if (window.google?.accounts?.oauth2) { clearInterval(t); _isLoaded=true; cb(); }}, 150);
    return;
  }
  const s = document.createElement('script');
  s.id = '_gis_script';
  s.src = 'https://accounts.google.com/gsi/client';
  s.onload = () => { _isLoaded = true; cb(); };
  s.onerror = () => alert('تعذّر تحميل مكتبة Google Identity. تحقق من الاتصال بالإنترنت.');
  document.head.appendChild(s);
}
let _isLoaded = false;

function gdriveConnect() {
  // Google Drive خدمة سحابية بحتة: بلا شبكة تفشل بخطأ تقني غامض
  if (!navigator.onLine) { alert('🔴 ربط Google Drive يحتاج اتصالاً بالإنترنت.\n\nبياناتك محفوظة داخل الجهاز وسترتفع تلقائياً فور عودة الشبكة.'); return; }
  let clientId = localStorage.getItem('gdrive_client_id') || '';
  if (!clientId) {
    clientId = prompt(
      'لربط التطبيق بـ Google Drive، أدخل OAuth2 Client ID الخاص بك.\
\
' +
      'كيف تحصل عليه:\
' +
      '1. افتح: console.cloud.google.com\
' +
      '2. أنشئ مشروعاً جديداً أو اختر موجوداً\
' +
      '3. فعّل "Google Drive API"\
' +
      '4. أنشئ بيانات اعتماد OAuth2 (Web Application)\
' +
      '5. أضف عنوان هذه الصفحة في "Authorized JavaScript origins"\
' +
      '6. انسخ الـ Client ID هنا:\
',
      ''
    );
    if (!clientId || !clientId.trim()) return;
    clientId = clientId.trim();
    localStorage.setItem('gdrive_client_id', clientId);
  }
  _gdriveEnsureGIS(() => {
    try {
      const tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: 'https://www.googleapis.com/auth/drive.file',
        callback: (resp) => {
          if (resp.error) {
            alert('فشل الاتصال بـ Google Drive: ' + resp.error);
            return;
          }
          _gdriveToken = resp.access_token;   // الذاكرة فقط — لا localStorage (إصلاح 8.8)
          _gdriveUpdateUI(true);
        }
      });
      tokenClient.requestAccessToken({ prompt: 'consent' });
    } catch(e) {
      alert('خطأ في تهيئة Google OAuth2: ' + e.message + '\
\
تحقق من صحة الـ Client ID.');
    }
  });
}

function gdriveDisconnect() {
  _gdriveToken = null;
  _gdriveUpdateUI(false);
  alert('تم فصل الحساب من Google Drive.');
}

function _gdriveUpdateUI(connected) {
  const $ = id => document.getElementById(id);
  if (!$('btn-gdrive-connect')) return;
  if (connected) {
    $('btn-gdrive-connect').classList.add('hidden');
    $('btn-gdrive-upload').classList.remove('hidden');
    $('btn-gdrive-download').classList.remove('hidden');
    $('btn-gdrive-disconnect').classList.remove('hidden');
    $('gdrive-status').textContent = '✅ متصل بـ Google Drive';
    $('gdrive-status').style.color = '#179baa';
    const last = localStorage.getItem('gdrive_last_backup');
    if (last) {
      $('gdrive-last-backup').textContent = 'آخر نسخة: ' + last;
      $('gdrive-last-backup').classList.remove('hidden');
    }
    const autoEl = $('gdrive-auto');
    if (autoEl) autoEl.checked = _gdriveAutoBackup;
  } else {
    $('btn-gdrive-connect').classList.remove('hidden');
    $('btn-gdrive-upload').classList.add('hidden');
    $('btn-gdrive-download').classList.add('hidden');
    $('btn-gdrive-disconnect').classList.add('hidden');
    $('gdrive-status').textContent = '⚪ غير متصل';
    $('gdrive-status').style.color = '#9da3a0';
    $('gdrive-last-backup').classList.add('hidden');
  }
}

async function _gdriveFetchAPI(url, method, body) {
  if (!_gdriveToken) throw new Error('NO_TOKEN');
  const opts = { method, headers: { Authorization: 'Bearer ' + _gdriveToken } };
  if (body) opts.body = body;
  const r = await fetch(url, opts);
  if (r.status === 401) { _gdriveToken = null; _gdriveUpdateUI(false); throw new Error('TOKEN_EXPIRED'); }
  return r;
}

async function gdriveUpload(silent) {
  // Google Drive خدمة سحابية بحتة: بلا شبكة تفشل بخطأ تقني غامض
  if (!navigator.onLine) { alert('🔴 رفع النسخة الاحتياطية يحتاج اتصالاً بالإنترنت.\n\nبياناتك محفوظة داخل الجهاز وسترتفع تلقائياً، والنسخة الاحتياطية يمكن أخذها بعد عودة الشبكة.'); return; }
  if (!_gdriveToken) { if (!silent) alert('يرجى الاتصال بـ Google Drive أولاً.'); return; }
  const btn = document.getElementById('btn-gdrive-upload');
  if (btn && !silent) { btn.innerText = '⏳ جارٍ الرفع...'; btn.disabled = true; }
  try {
    const content = await _backupJsonAsync();
    const blob = new Blob([content], { type: 'application/json' });
    const meta = { name: 'النسخة_الاحتياطية_اللمسة.json', mimeType: 'application/json' };
    if (!_gdriveFileId) meta.parents = ['root'];
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(meta)], { type: 'application/json' }));
    form.append('file', blob);
    const url = _gdriveFileId
      ? `https://www.googleapis.com/upload/drive/v3/files/${_gdriveFileId}?uploadType=multipart`
      : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
    const r = await _gdriveFetchAPI(url, _gdriveFileId ? 'PATCH' : 'POST', form);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const data = await r.json();
    _gdriveFileId = data.id;
    localStorage.setItem('gdrive_file_id', _gdriveFileId);
    const now = new Date().toLocaleString('ar-EG');
    localStorage.setItem('gdrive_last_backup', now);
    const lastEl = document.getElementById('gdrive-last-backup');
    if (lastEl) { lastEl.textContent = 'آخر نسخة: ' + now; lastEl.classList.remove('hidden'); }
    if (!silent) alert('✅ تم رفع النسخة الاحتياطية إلى Google Drive بنجاح!\
' + now);
  } catch(e) {
    if (!silent) {
      if (e.message === 'TOKEN_EXPIRED') alert('انتهت صلاحية رمز Google. يرجى إعادة الاتصال.');
      else alert('فشل الرفع: ' + e.message);
    }
  } finally {
    if (btn && !silent) { btn.innerText = '⬆️ رفع نسخة الآن'; btn.disabled = false; }
  }
}

// يمسح كل مجموعات Firestore ويكتب بدلاً عنها بيانات نسخة احتياطية كاملة (يُستخدم فقط عند استرجاع/استيراد نسخة)
/* ============================================================
   فحص النسخة الاحتياطية قبل استرجاعها
   ------------------------------------------------------------
   الخلل الذي يعالجه: الاسترجاع كان يمرّ على كل المجموعات الثماني ويمسحها
   من السيرفر، ثم يكتب ما في الملف. وأي مجموعة غائبة عن الملف تُمسح ولا
   يُكتب مكانها شيء — لأن `Array.isArray(data[key]) ? data[key] : []`
   تعطي مصفوفة فارغة.

   والتحقق كان يفحص خمس مجموعات فقط من ثمانٍ. فاسترجاع نسخة أُخذت قبل
   إضافة «التحصيلات» يمحو كل سجلات التحصيل — وهي مبالغ حقيقية — بلا أي
   تحذير. وكذلك سجل تعديلات الفواتير والمرتجعات.

   الآن: أي مجموعة غائبة تُترك كما هي على السيرفر ولا تُمسح، ويُعرض على
   المدير بيان صريح بما سيُستبدَل وما سيبقى قبل أن يبدأ أي شيء.
   ============================================================ */
function describeBackup(data) {
  const present = [], missing = [];
  RECORD_COLLECTIONS.forEach(k => {
    if (Array.isArray(data[k])) present.push({ key: k, n: data[k].length });
    else missing.push(k);
  });
  const hasCredit = data.creditBalances && typeof data.creditBalances === 'object';
  return { present, missing, hasCredit };
}

const COLLECTION_LABELS = {
  store:'المخزن', sales:'الفواتير', expenses:'المصروفات', payments:'المقبوضات',
  trash:'سلة المحذوفات', returns:'المرتجعات', collections:'التحصيلات',
  editedInvoicesLog:'سجل تعديلات الفواتير'
};

/* تأكيد الاسترجاع: بيان صريح بالأعداد قبل أي مساس بالبيانات.
   يعود true إن وافق المدير. */
function confirmRestorePlan(data) {
  const info = describeBackup(data);
  if (!info.present.length) { alert('⛔ الملف لا يحتوي أي سجلات معروفة — لن يُنفَّذ شيء.'); return false; }
  let msg = '⚠️ استبدال بيانات الجميع بمحتوى هذه النسخة.\n\nسيُستبدَل:\n';
  info.present.forEach(x => { msg += '   • ' + (COLLECTION_LABELS[x.key] || x.key) + ': ' + x.n + ' سجل\n'; });
  if (info.hasCredit) msg += '   • أرصدة العملاء: ' + Object.keys(data.creditBalances).length + '\n';
  if (info.missing.length) {
    msg += '\nغير موجود في الملف — سيبقى كما هو ولن يُمسح:\n';
    info.missing.forEach(k => { msg += '   • ' + (COLLECTION_LABELS[k] || k) + '\n'; });
  }
  msg += '\nستُحفظ نسخة من بياناتك الحالية على جهازك أولاً.\n\nهل تريد المتابعة؟';
  return confirm(msg);
}

// نسخة أمان من الوضع الحالي قبل الاسترجاع — المخرج الوحيد لو ساء شيء
/* ⚠️ إصلاح 8.8.5 — شبكة الأمان كانت تنقطع في اللحظة التي تلزم فيها.

   كانت تبني رابط `data:` يحمل قاعدة البيانات كاملة داخل العنوان نفسه،
   بعد JSON.stringify(DB, null, 2) — أي بمسافات بادئة تضخّم الحجم نحو
   الثلث — ثم encodeURIComponent يضاعفه مرة أخرى (كل محرف عربي يصير
   تسعة محارف: %D8%A7…). فقاعدة بيانات محل عمره سنة تتجاوز حدّ المتصفح
   لطول العنوان، فيفشل التنزيل بلا أي أثر.

   والأسوأ أن الفشل يقع **طردياً مع حجم البيانات**: كلما كثرت فواتيرك
   زاد احتمال ألا تُحفظ نسخة الأمان — أي أن الحماية تختفي في اللحظة
   التي تعظم فيها الخسارة.

   وكانت الدالة تُعيد false عند الفشل، و**كل مواضع الاستدعاء الثلاثة
   تتجاهل القيمة المعادة**. فيمضي الاسترجاع في محو بيانات الجميع
   واستبدالها، بلا نسخة رجعة، وبلا كلمة تنبيه.

   الآن: Blob (بلا حدّ عملي للحجم) — وهي الطريقة المستعملة أصلاً في
   _downloadBlob بهذا الملف نفسه — وبلا مسافات تجميل لا يقرأها أحد.
   وقيمة الإرجاع صارت تُفحص عند الاستدعاء. */
function saveSafetySnapshot() {
  try {
    const payload = (window.AppBackup && AppBackup.create) ? AppBackup.create(DB, { appVersion: 'v234' }) : DB;
    const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `قبل_الاسترجاع_${new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 4000);
    return true;
  } catch (e) {
    wsSilent('saveSafetySnapshot', e);
    return false;
  }
}

/* تُستدعى قبل كل استرجاع: تحفظ النسخة، وإن تعذّر ذلك لا تمضي بصمت.
   الاسترجاع بلا نسخة رجعة قرارٌ يخصّ المدير وحده، فيُسأل صراحةً. */
function saveSafetySnapshotOrConfirm() {
  if (saveSafetySnapshot()) return true;
  return confirm('⚠️ تعذّر حفظ نسخة الأمان من بياناتك الحالية على هذا الجهاز.\n\n' +
                 'إن تابعت الآن فلا سبيل للرجوع إن ساء شيء في الاسترجاع.\n\n' +
                 'الأفضل: أوقف العملية، وصدّر نسخة يدوياً من «تصدير نسخة احتياطية»،\n' +
                 'وتأكّد من نزولها في مجلد التنزيلات، ثم أعد المحاولة.\n\n' +
                 'هل تريد المتابعة رغم ذلك؟');
}

/* ⚠️ إصلاح 8.8 — أخطر دالة في النظام، وكان فيها خللان:

   ١) الترتيب كان: احذف كل مستندات المجموعة، ثم اكتب الجديد. وبينهما
      عشرات الدفعات (batch) وطلبات شبكة. فأي انقطاع في تلك اللحظة —
      شبكة، أو إغلاق تبويب، أو نفاد بطارية — يترك المجموعة **فارغة
      تماماً**: لا القديم ولا الجديد. ومحو مجموعة الفواتير كاملة ليس
      عطلاً يُصلَّح لاحقاً؛ وشبكة الأمان الوحيدة كانت ملفاً يُنزَّل على
      جهاز المستخدم قد لا ينتبه إليه أصلاً.

      الآن معكوس: نكتب الجديد أولاً (set تكتب فوق نفس المعرّف)، ثم
      نحذف ما لم يعد له وجود في النسخة. فالانقطاع في أي لحظة يترك
      البيانات **زائدة** لا ناقصة — وسجل زائد يُحذف بيد المدير، أما
      السجل الممحو فلا يعود.

   ٢) لا حراسة صلاحية داخل الدالة نفسها: كانت محميّة بإخفاء القسم في
      الواجهة فقط. وهي تمسّ كل مجموعة في قاعدة البيانات، فتستحق حارساً
      في متنها لا في مظهرها.
*/
function stableRestoreId(key, item, index) {
  // السجل بلا id يجب أن يحصل على معرّف ثابت حتى لا تعيد محاولة الاستعادة
  // إنشاء مستند جديد كل مرة. يعتمد على محتوى السجل + المجموعة + موضعه في النسخة.
  const canonical = JSON.stringify({ key, index, item });
  const hash = (window.AppBackup && AppBackup.checksum)
    ? AppBackup.checksum(canonical)
    : String(index);
  return 'restore-' + key + '-' + hash + '-' + index;
}

const RESTORE_JOURNAL_KEY = 'lamsa_restore_journal_v243';
const RESTORE_JOURNAL_LEGACY_KEY = 'lamsa_restore_journal_v242';
const RESTORE_JOURNAL_LEGACY_KEY2 = 'lamsa_restore_journal_v241';
function _restoreDataFingerprint(data){
  try { return (window.AppBackup && AppBackup.checksum) ? AppBackup.checksum(data) : JSON.stringify(data).length.toString(16); }
  catch(e){ return 'unknown'; }
}
function _readRestoreJournal(){
  try {
    const raw=localStorage.getItem(RESTORE_JOURNAL_KEY);
    if(raw) return JSON.parse(raw);
    let legacy=localStorage.getItem(RESTORE_JOURNAL_LEGACY_KEY);
    let migratedFrom='v242';
    if(!legacy){ legacy=localStorage.getItem(RESTORE_JOURNAL_LEGACY_KEY2); migratedFrom='v241'; }
    if(legacy){
      const j=JSON.parse(legacy);
      if(j && typeof j==='object') { j.version=3; j.migratedFrom=migratedFrom; j.verification=j.verification||{status:'not_checked'}; try { localStorage.setItem(RESTORE_JOURNAL_KEY,JSON.stringify(j)); } catch(e){} }
      return j;
    }
    return null;
  } catch(e){ return null; }
}
function _writeRestoreJournal(j){
  try { localStorage.setItem(RESTORE_JOURNAL_KEY, JSON.stringify(j)); return true; } catch(e){ wsSilent('restore:journal-write',e); return false; }
}
function _clearRestoreJournal(){ try { localStorage.removeItem(RESTORE_JOURNAL_KEY); } catch(e){} try { localStorage.removeItem(RESTORE_JOURNAL_LEGACY_KEY); } catch(e){} try { refreshRestoreRecoveryCenter(); } catch(e){} }
function _restoreJournalStatus(data){
  const j=_readRestoreJournal(); if(!j) return null;
  return j.fingerprint===_restoreDataFingerprint(data) ? j : {stale:true,j};
}
function _setRestoreJournal(j){
  if(!_writeRestoreJournal(j)) throw new Error('RESTORE_JOURNAL_UNAVAILABLE');
  try { refreshRestoreRecoveryCenter(); } catch(e){}
}


// ===== مركز تعافي الاستعادة v242 =====
const _restoreRecoveryLabels = {
  writing: 'جاري الكتابة',
  deleting: 'جاري تنظيف السجلات القديمة',
  completed: 'اكتملت المجموعة',
  'verification-failed': 'فشل التحقق — الاستعادة متوقفة'
};
function _restoreRecoveryDate(value){
  if(!value) return '—';
  try { return new Date(value).toLocaleString('ar-LY'); } catch(e){ return String(value); }
}
function refreshRestoreRecoveryCenter(){
  const center=document.getElementById('restore-recovery-center');
  if(!center) return;
  const badge=document.getElementById('restore-recovery-badge');
  const summary=document.getElementById('restore-recovery-summary');
  const details=document.getElementById('restore-recovery-details');
  const j=_readRestoreJournal();
  if(!j){
    if(badge) badge.classList.add('hidden');
    if(details) details.classList.add('hidden');
    if(summary) summary.textContent='لا توجد عملية استعادة غير مكتملة على هذا الجهاز.';
    return;
  }
  if(badge) badge.classList.remove('hidden');
  if(details) details.classList.remove('hidden');
  const phase=_restoreRecoveryLabels[j.phase] || j.phase || 'غير معروف';
  const done=Array.isArray(j.completedCollections)?j.completedCollections.length:0;
  if(summary) summary.textContent=`توجد عملية استعادة غير مكتملة. تم حفظ نقطة التعافي بعد إكمال ${done} مجموعة. استخدم نفس ملف النسخة لمتابعة العملية.`;
  const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=v;};
  set('restore-recovery-phase',phase);
  set('restore-recovery-current',j.currentCollection||'—');
  set('restore-recovery-completed',String(done));
  set('restore-recovery-started',_restoreRecoveryDate(j.startedAt));
}
function openRestoreRecoveryFile(){
  if(!isAdmin()){ alert('⛔ استئناف استعادة النسخة متاح للمدير فقط.'); return; }
  const input=document.getElementById('restore-recovery-file-input');
  if(input){ input.value=''; input.click(); }
}
async function resumeRestoreRecoveryFromFile(e){
  if(!isAdmin()){ if(e&&e.target)e.target.value=''; alert('⛔ استئناف الاستعادة متاح للمدير فقط.'); return; }
  const file=e&&e.target&&e.target.files&&e.target.files[0];
  if(!file) return;
  try{
    if(file.size > (window.AppBackup && AppBackup.MAX_TEXT_BYTES || 50*1024*1024)) throw new Error('BACKUP_TOO_LARGE');
    const raw=await file.text();
    const parsed=window.AppBackup&&AppBackup.parseAsync ? await AppBackup.parseAsync(raw) : (window.AppBackup&&AppBackup.parse ? AppBackup.parse(raw) : {data:JSON.parse(raw)});
    const data=parsed.data;
    const status=_restoreJournalStatus(data);
    if(!status || status.stale) throw new Error('RESTORE_RESUME_MISMATCH');
    if(!confirm('سيتم استئناف الاستعادة من آخر مجموعة مكتملة محفوظة.\n\nلا تغلق الصفحة حتى يكتمل الاسترجاع. هل تريد المتابعة؟')) return;
    if(!saveSafetySnapshotOrConfirm()) return;
    await bulkRestoreToFirestore(data);
    alert('✅ اكتمل استئناف الاستعادة بنجاح.');
  }catch(err){
    if(err&&err.message==='RESTORE_RESUME_MISMATCH') alert('⛔ هذا الملف ليس النسخة نفسها التي بدأت بها عملية التعافي. اختر الملف الأصلي.');
    else if(err&&err.message==='BACKUP_CORRUPTED') alert('⛔ النسخة الاحتياطية تالفة أو تغيّرت.');
    else if(err&&err.message==='RESTORE_JOURNAL_UNAVAILABLE') alert('⛔ تعذّر تحديث سجل التعافي؛ لم يتم بدء مرحلة جديدة.');
    else if(err&&err.message==='RESTORE_VERIFICATION_FAILED') alert('⛔ فشل التحقق من البيانات بعد الاستعادة. تم إيقاف العملية لتجنب الاستمرار على حالة غير مؤكدة. راجع سجل التعافي ثم أعد المحاولة.');
    else alert('فشل استئناف الاستعادة: '+(err&&err.message?err.message:err));
  } finally { refreshRestoreRecoveryCenter(); }
}
function cancelRestoreRecovery(){
  if(!isAdmin()){ alert('⛔ إلغاء عملية التعافي متاح للمدير فقط.'); return; }
  const j=_readRestoreJournal();
  if(!j){ refreshRestoreRecoveryCenter(); return; }
  const done=Array.isArray(j.completedCollections)?j.completedCollections.length:0;
  const ok=confirm('⚠️ سيتم حذف سجل الاستئناف المحلي فقط.\n\nهذا الإجراء لا يعكس البيانات التي كُتبت بالفعل، ولا يعيد السجلات المحذوفة أثناء الاستعادة.\nالمجموعات المكتملة حتى الآن: '+done+'\n\nهل تريد إلغاء إمكانية الاستئناف؟');
  if(!ok) return;
  _clearRestoreJournal();
  refreshRestoreRecoveryCenter();
  alert('✅ أُلغي سجل الاستئناف المحلي. البيانات الحالية لم تُعدّل بهذا الإجراء.');
}
(function initRestoreRecoveryCenter(){
  const start=()=>refreshRestoreRecoveryCenter();
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start);
  else start();
})();


function _restorePlain(value){
  try { return JSON.parse(JSON.stringify(value)); } catch(e){ return value; }
}
function _restoreRecordId(key,item,index){
  return String(item && item.id ? item.id : stableRestoreId(key,item,index));
}
async function _verifyRestoredCollection(key, items){
  const expected=Array.isArray(items)?items:[];
  const snap=await db.collection(key).get();
  const actual=new Map(snap.docs.map(doc=>[doc.id,_restorePlain(doc.data())]));
  const expectedIds=new Set();
  const mismatches=[];
  for(let index=0; index<expected.length; index++){
    const item=expected[index];
    const id=_restoreRecordId(key,item,index);
    expectedIds.add(id);
    const got=actual.get(id);
    if(!got){ mismatches.push({id,reason:'missing'}); continue; }
    const expectedHash=AppBackup.checksum(_restorePlain(item));
    const actualHash=AppBackup.checksum(got);
    if(expectedHash!==actualHash) mismatches.push({id,reason:'content-mismatch'});
  }
  for(const id of actual.keys()) if(!expectedIds.has(id)) mismatches.push({id,reason:'unexpected'});
  return {ok:mismatches.length===0,expected:expected.length,actual:actual.size,mismatches:mismatches.slice(0,20)};
}
async function _verifyCredits(creditObj){
  const expected=creditObj&&typeof creditObj==='object'?creditObj:{};
  const snap=await db.collection('creditBalances').get();
  const actual=new Map(snap.docs.map(doc=>[doc.id,_restorePlain(doc.data())]));
  const expectedIds=new Set(), mismatches=[];
  for(const name of Object.keys(expected)){
    const amt=Number(expected[name]); if(!isFinite(amt)||amt<0) continue;
    const id=encodeURIComponent(name); expectedIds.add(id);
    const got=actual.get(id);
    if(!got || Number(got.amount)!==Number(r2(amt)) || String(got.name)!==String(name)) mismatches.push({id,reason:got?'content-mismatch':'missing'});
  }
  for(const id of actual.keys()) if(!expectedIds.has(id)) mismatches.push({id,reason:'unexpected'});
  return {ok:mismatches.length===0,expected:expectedIds.size,actual:actual.size,mismatches:mismatches.slice(0,20)};
}
async function _verifyRestoreSettings(settings){
  const snap=await db.collection('meta').doc('settings').get();
  if(!snap.exists) return {ok:false,reason:'missing'};
  const a=AppBackup.checksum(_restorePlain(settings)), b=AppBackup.checksum(_restorePlain(snap.data()));
  return {ok:a===b,expected:1,actual:1,mismatches:a===b?[]:[{id:'settings',reason:'content-mismatch'}]};
}
function _restoreVerificationFailed(j, key, result){
  j.phase='verification-failed';
  j.verification={status:'failed',collection:key,at:new Date().toISOString(),result};
  _setRestoreJournal(j);
  const e=new Error('RESTORE_VERIFICATION_FAILED'); e.result=result; throw e;
}

async function bulkRestoreToFirestore(data) {
  if (!isAdmin()) {
    alert('⛔ استرجاع النسخة الاحتياطية متاح للمشرف الأساسي فقط.');
    throw new Error('RESTORE_NOT_ALLOWED');
  }
  if (!data || typeof data !== 'object') throw new Error('ملف غير صالح');
  if (window.AppBackup && AppBackup.validateRestoreData) {
    AppBackup.validateRestoreData(data, { collections: RECORD_COLLECTIONS });
    if (AppBackup.preflightRestore) AppBackup.preflightRestore(data, { collections: RECORD_COLLECTIONS });
  }

  const fingerprint = _restoreDataFingerprint(data);
  const prior = _restoreJournalStatus(data);
  if (prior && prior.stale) {
    throw new Error('RESTORE_RESUME_MISMATCH');
  }
  const journal = prior || {
    version: 1, fingerprint, startedAt: new Date().toISOString(),
    phase: 'writing', completedCollections: [], currentCollection: null
  };
  _setRestoreJournal(journal);

  const overlay = document.createElement('div');
  overlay.id = 'bulk-restore-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,0.8);z-index:99999;display:flex;align-items:center;justify-content:center;color:#fff;font-family:Cairo,sans-serif;font-weight:800;font-size:15px;text-align:center;padding:20px;';
  overlay.innerHTML = '<div>⏳ جارٍ استرجاع النسخة الاحتياطية والتحقق منها ومزامنتها مع الجميع...<br><span style="font-size:12px;font-weight:600;opacity:.8;">لا تُغلق الصفحة</span></div>';
  document.body.appendChild(overlay);

  // كاتب دفعات صغير: يلتزم بحدّ الـ500 عملية للدفعة الواحدة
  const runner = () => {
    let batch = db.batch(), n = 0;
    return {
      async op(fn) {
        fn(batch); n++;
        if (n === 450) { await batch.commit(); batch = db.batch(); n = 0; }
      },
      async flush() { if (n > 0) { await batch.commit(); batch = db.batch(); n = 0; } }
    };
  };

  try {
    for (const key of RECORD_COLLECTIONS) {
      if (journal.completedCollections.includes(key)) continue;
      journal.currentCollection = key;
      journal.phase = 'writing';
      _setRestoreJournal(journal);
      /* غائبة عن الملف = لا نعرف عنها شيئاً، فلا نمسحها. المسح هنا كان
         يمحو مجموعات كاملة لمجرد أن النسخة أقدم من إضافتها للنظام. */
      if (!Array.isArray(data[key])) continue;

      const items   = data[key];
      const keepIds = new Set();
      const w = runner();

      // (أ) الكتابة أولاً
      for (let index = 0; index < items.length; index++) {
        const item = items[index];
        const id = String(item && item.id
          ? item.id
          : stableRestoreId(key, item, index));
        keepIds.add(id);
        await w.op(b => b.set(db.collection(key).doc(id), item));
      }
      await w.flush();

      // (ب) ثم حذف ما لم يعد موجوداً في النسخة
      journal.phase = 'deleting';
      _setRestoreJournal(journal);
      const existing = await db.collection(key).get();
      const d = runner();
      for (const doc of existing.docs) {
        if (keepIds.has(doc.id)) continue;
        await d.op(b => b.delete(doc.ref));
      }
      await d.flush();

      // (ج) تحقق مستقل بعد الكتابة والحذف: لا تُعتبر المجموعة مكتملة إلا إذا
      // تطابقت المعرّفات والمحتويات ولم تبقَ سجلات زائدة.
      journal.phase = 'verifying';
      journal.verification = {status:'running',collection:key,at:new Date().toISOString()};
      _setRestoreJournal(journal);
      const verifyResult = await _verifyRestoredCollection(key, items);
      if(!verifyResult.ok) _restoreVerificationFailed(journal,key,verifyResult);
      journal.verification = {status:'passed',collection:key,at:new Date().toISOString(),result:verifyResult};
      journal.phase = 'completed';
      journal.completedCollections.push(key);
      journal.currentCollection = null;
      _setRestoreJournal(journal);
    }

    // الأرصدة: غائبة عن الملف = تبقى كما هي، وبنفس الترتيب الآمن
    if (data.creditBalances && typeof data.creditBalances === 'object') {
      journal.currentCollection = 'creditBalances';
      journal.phase = 'writing';
      _setRestoreJournal(journal);
      const creditObj = data.creditBalances;
      const keep = new Set();
      const w = runner();
      for (const name of Object.keys(creditObj)) {
        const amt = Number(creditObj[name]);
        if (!isFinite(amt) || amt < 0) continue;   // قيمة تالفة لا تُكتب
        const id = encodeURIComponent(name);
        keep.add(id);
        await w.op(b => b.set(db.collection('creditBalances').doc(id),
                              { amount: r2(amt), name: name, updatedAt: Date.now() }));
      }
      await w.flush();

      journal.phase = 'deleting';
      _setRestoreJournal(journal);
      const existingCredit = await db.collection('creditBalances').get();
      const d = runner();
      for (const doc of existingCredit.docs) {
        if (keep.has(doc.id)) continue;
        await d.op(b => b.delete(doc.ref));
      }
      await d.flush();
      journal.phase = 'verifying';
      journal.verification = {status:'running',collection:'creditBalances',at:new Date().toISOString()};
      _setRestoreJournal(journal);
      const creditVerify = await _verifyCredits(creditObj);
      if(!creditVerify.ok) _restoreVerificationFailed(journal,'creditBalances',creditVerify);
      journal.verification = {status:'passed',collection:'creditBalances',at:new Date().toISOString(),result:creditVerify};
      journal.phase = 'completed';
      journal.completedCollections.push('creditBalances');
      journal.currentCollection = null;
      _setRestoreJournal(journal);
    }

    if (data.settings) {
      journal.currentCollection = 'settings'; journal.phase = 'writing'; _setRestoreJournal(journal);
      await db.collection('meta').doc('settings').set(data.settings);
      journal.phase = 'verifying';
      journal.verification = {status:'running',collection:'settings',at:new Date().toISOString()};
      _setRestoreJournal(journal);
      const settingsVerify = await _verifyRestoreSettings(data.settings);
      if(!settingsVerify.ok) _restoreVerificationFailed(journal,'settings',settingsVerify);
      journal.verification = {status:'passed',collection:'settings',at:new Date().toISOString(),result:settingsVerify};
      journal.phase = 'completed'; journal.completedCollections.push('settings'); journal.currentCollection = null; _setRestoreJournal(journal);
    }
    _clearRestoreJournal();
  } finally {
    overlay.remove();
  }
}

async function gdriveDownload() {
  // Google Drive خدمة سحابية بحتة: بلا شبكة تفشل بخطأ تقني غامض
  if (!navigator.onLine) { alert('🔴 استرجاع النسخة الاحتياطية يحتاج اتصالاً بالإنترنت.\n\nبياناتك محفوظة داخل الجهاز وسترتفع تلقائياً فور عودة الشبكة.'); return; }
  if (!isAdmin()) { alert('استرجاع نسخة احتياطية كاملة متاح للمشرف فقط.'); return; }
  if (!_gdriveToken) { alert('يرجى الاتصال بـ Google Drive أولاً.'); return; }
  if (!_gdriveFileId) { alert('لا توجد نسخة احتياطية محفوظة بعد. ارفع نسخة أولاً.'); return; }
  const btn = document.getElementById('btn-gdrive-download');
  if (btn) { btn.innerText = '⏳ جارٍ الاسترجاع...'; btn.disabled = true; }
  try {
    const r = await _gdriveFetchAPI(`https://www.googleapis.com/drive/v3/files/${_gdriveFileId}?alt=media`, 'GET');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const raw = await r.json();
    let parsed;
    try { parsed = window.AppBackup && AppBackup.normalize ? AppBackup.normalize(raw) : {data:raw};
    if (window.AppBackup && AppBackup.verifyAsync) await AppBackup.verifyAsync(raw); }
    catch (e) { throw new Error(e && e.message === 'BACKUP_CORRUPTED' ? 'النسخة الاحتياطية تالفة' : 'ملف غير متوافق'); }
    const data = parsed.data;
    if (!data || typeof data !== 'object' || (!Array.isArray(data.sales) && !Array.isArray(data.store))) throw new Error('ملف غير متوافق');
    if (!confirmRestorePlan(data)) { if (btn) { btn.innerText='⬇️ استرجاع آخر نسخة'; btn.disabled=false; } return; }
    if (!saveSafetySnapshotOrConfirm()) return;
    if (btn) btn.innerText = '⏳ جارٍ الاسترجاع والمزامنة...';
    await bulkRestoreToFirestore(data);
    if (btn) { btn.innerText='⬇️ استرجاع آخر نسخة'; btn.disabled=false; }
    alert('✅ تم استرجاع قاعدة البيانات من Google Drive ومزامنتها مع الجميع بنجاح!');
  } catch(e) {
    if (btn) { btn.innerText='⬇️ استرجاع آخر نسخة'; btn.disabled=false; }
    if (e.message === 'TOKEN_EXPIRED') alert('انتهت صلاحية رمز Google. يرجى إعادة الاتصال.');
    else if (e.message === 'RESTORE_RESUME_MISMATCH') alert('⛔ توجد عملية استعادة غير مكتملة لنسخة مختلفة. أعد استخدام النسخة الأصلية نفسها لإكمال التعافي.');
    else if (e.message === 'RESTORE_JOURNAL_UNAVAILABLE') alert('⛔ تعذّر إنشاء سجل التعافي المحلي؛ لم يتم استرجاع أي بيانات.');
    else if (e.message === 'RESTORE_VERIFICATION_FAILED') alert('⛔ فشل التحقق بعد الاستعادة؛ تم إيقاف العملية قبل الانتقال للمجموعة التالية.');
    else alert('فشل الاسترجاع: ' + e.message);
  }
}

function toggleGDriveAuto(checked) {
  _gdriveAutoBackup = checked;
  // إصلاح 8.8: امتلاء الحصة كان يرمي فيوقف الدالة
  try { localStorage.setItem('gdrive_auto', checked ? 'true' : 'false'); }
  catch (e) { console.error('تعذّر حفظ إعداد النسخ التلقائي:', e); }
}

/* ⚠️ إصلاح 8.8 — تسريب وعطب معاً:
   كانت الدالة تضع JSON.stringify(DB) كاملةً داخل رابط wa.me — كل
   الفواتير وأسماء العملاء وأرقام هواتفهم وديونهم في نصّ رابط واحد.
   • تسريب خصوصية كامل: الرابط يمرّ في سجلّ المتصفح ويُشارَك بلمسة خطأ.
   • ومعطوب أصلاً: الروابط محدودة الطول، وقاعدة أي محل عامل تتجاوزها —
     فالرابط يُبتر أو يفشل. أي أنه كان يوهم بنسخة احتياطية لا وجود لها.
   البديل: ملف JSON حقيقي يمرّ على واجهة المشاركة في النظام، مع بديل
   تنزيل مباشر. الملف كامل مهما كبر، ويصل كملف لا كنصّ في رابط. */
async function shareBackupViaWhatsApp() {
  if (!isAdmin()) { alert('⛔ تصدير نسخة من قاعدة البيانات متاح للمشرف فقط.'); return; }
  if (!confirm('⚠️ هذا الملف يحتوي على كامل بيانات المحل:\nأسماء العملاء وأرقامهم وفواتيرهم وديونهم.\n\nأرسله لجهة موثوقة فقط. هل تريد المتابعة؟')) return;

  const stamp = new Date().toISOString().slice(0, 10);
  const fname = 'نسخة-اللمسة-' + stamp + '.json';
  let blob;
  try { blob = new Blob([await _backupJsonAsync()], { type: 'application/json' }); }
  catch (e) { alert('تعذّر تجهيز الملف: ' + (e && e.message ? e.message : e)); return; }

  try {
    const file = new File([blob], fname, { type: 'application/json' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: 'نسخة احتياطية — اللمسة الأخيرة' });
      return;
    }
  } catch (e) {
    if (e && e.name === 'AbortError') return;
    wsSilent('invoices:shareBackup', e);
  }

  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = fname;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    alert('✅ نُزِّل الملف: ' + fname + '\n\nأرفقه يدوياً في واتساب أو البريد.');
  } catch (e) { alert('تعذّر تنزيل الملف: ' + (e && e.message ? e.message : e)); }
}

function importBackupFile(e) {
  if (!isAdmin()) { alert('استيراد نسخة احتياطية كاملة متاح للمشرف فقط.'); e.target.value=''; return; }
  const file = e.target.files[0]; if (!file) return;
  if (file.size > (window.AppBackup && AppBackup.MAX_TEXT_BYTES || 50*1024*1024)) { alert('⛔ ملف النسخة الاحتياطية أكبر من الحد المسموح (50 MB). لم يتم استرجاع أي شيء.'); e.target.value=''; return; }
  const rd = new FileReader();
  rd.onload = async function(ev) {
    try {
      let parsed;
      try {
        parsed = window.AppBackup && AppBackup.parseAsync ? await AppBackup.parseAsync(ev.target.result) : (window.AppBackup && AppBackup.parse ? AppBackup.parse(ev.target.result) : {data: JSON.parse(ev.target.result), legacy:true});
      } catch (backupError) {
        const msg = backupError && backupError.message === 'BACKUP_CORRUPTED'
          ? '⛔ النسخة الاحتياطية تالفة أو تغيّرت بعد إنشائها. لم يتم استرجاع أي شيء.'
          : backupError && backupError.message === 'BACKUP_NEWER_THAN_APP'
            ? '⛔ هذه النسخة أحدث من إصدار التطبيق الحالي. حدّث التطبيق أولاً.'
            : '⛔ ملف النسخة الاحتياطية غير متوافق.';
        alert(msg); return;
      }
      let p = parsed.data;
      if (!p || typeof p !== 'object' || (!Array.isArray(p.sales) && !Array.isArray(p.store))) {
        alert('⛔ الملف لا يحتوي بيانات فواتير أو مخزن قابلة للاستعادة.'); return;
      }
      if (!confirmRestorePlan(p)) return;
      if (!saveSafetySnapshotOrConfirm()) return;
      await bulkRestoreToFirestore(p);
      alert('✅ تم استيراد قاعدة البيانات ومزامنتها مع الجميع بنجاح.');
    } catch (err) {
      const msg = err && err.message === 'RESTORE_RESUME_MISMATCH'
        ? '⛔ توجد عملية استعادة غير مكتملة لنسخة مختلفة. لا يمكن المتابعة بهذه النسخة قبل إكمال أو إلغاء العملية السابقة.'
        : err && err.message === 'RESTORE_JOURNAL_UNAVAILABLE'
          ? '⛔ تعذّر إنشاء سجل التعافي المحلي؛ لم يتم استرجاع أي بيانات.'
          : 'فشل قراءة الملف أو مزامنته: ' + (err && err.message ? err.message : err);
      alert(msg);
    }
  };
  rd.readAsText(file);
}



// ============================================================
// إعدادات النظام (الاسم / الوصف / الهاتف / ذيل الفاتورة)
// ============================================================
const DEFAULT_SETTINGS = { name:'اللمسة الاخيرة', tagline:'مطابخ PVC سرانتي ناموسيات', phone:'0924203966', footer:'', countryCode:'218' };

function getSettings() {
  return Object.assign({}, DEFAULT_SETTINGS, DB.settings || {});
}

function applySettings() {
  const s = getSettings();
  // عنوان الصفحة
  document.title = s.name + ' — v3.9';
  // الشريط الجانبي
  const sn = document.getElementById('sys-name-sidebar');
  if (sn) sn.innerText = s.name;
  // الفاتورة
  const ni = document.getElementById('sys-name-invoice');
  const ti = document.getElementById('sys-tagline-invoice');
  const fp = document.getElementById('inv-footer-phone');
  const fc = document.getElementById('inv-footer-custom');
  if (ni) ni.innerText = s.name;
  if (ti) ti.innerText = s.tagline;
  if (fp) fp.innerText = s.phone || '';
  if (fc) fc.innerText = s.footer || '';
}

function openSettings() {
  // رابط إدارة الأعضاء المباشر مخصص للمدير الأساسي فقط.
  if (new URLSearchParams(window.location.search).get('openMembers') === '1' && typeof isAdmin === 'function' && !isAdmin()) {
    alert('⛔ إدارة الأعضاء متاحة للمدير فقط.');
    return;
  }
  const s = getSettings();
  document.getElementById('settings-name').value    = s.name;
  document.getElementById('settings-tagline').value = s.tagline;
  document.getElementById('settings-phone').value   = s.phone;
  document.getElementById('settings-country').value = s.countryCode || '218';
  document.getElementById('settings-footer').value  = s.footer || '';
  updateSettingsPreview();
  const openMembersDirect = new URLSearchParams(window.location.search).get('openMembers') === '1';
  switchSettingsTab(openMembersDirect ? 'members' : 'info');
  document.getElementById('newmember-name').value = '';
  document.getElementById('newmember-email').value = '';
  document.getElementById('newmember-password').value = '';
  document.getElementById('member-msg').textContent = '';
  renderMembersListUI();
  document.getElementById('settings-modal').classList.remove('hidden');
}

// ===== تبويبات الإعدادات =====
function switchSettingsTab(tab) {
  const tabs = ['info', 'members'];
  tabs.forEach(t => {
    const btn = document.getElementById('stab-' + t);
    const con = document.getElementById('stab-content-' + t);
    if (!btn) return;
    if (t === tab) {
      btn.style.background = 'white';
      btn.style.color = '#199959';
      btn.style.boxShadow = '0 2px 10px rgba(59,130,246,0.2)';
      if (con) con.style.display = '';
    } else {
      btn.style.background = 'transparent';
      btn.style.color = '#9da3a0';
      btn.style.boxShadow = 'none';
      if (con) con.style.display = 'none';
    }
  });
}

// ===== إدارة الأعضاء (المشرف فقط) =====
let _membersCache = []; // تُملأ عبر مستمع Firestore الحي في attachAllFirestoreListeners()

/* escapeHtml/escapeAttr يأتيان من shared.js (اسمان ثانيان لـ escHtml/escAttr).
   حُذف التعريف المكرّر في 8.9.2: كان السلوك نفسه معرَّفاً في ثلاثة مواضع،
   وخطر ذلك ليس طول الملف بل أن يُصلَح أحدها يوماً ويُنسى الآخران. */

function renderMembersListUI() {
  const box = document.getElementById('members-list');
  if (!box) return;
  if (!isAdmin()) { box.innerHTML = ''; return; }
  if (!_membersCache.length) {
    box.innerHTML = '<p style="font-size:12px;color:#9da3a0;text-align:center;padding:8px;">لا يوجد أعضاء بعد.</p>';
    return;
  }
  box.innerHTML = _membersCache.map(m => `
    <div style="display:flex;align-items:center;justify-content:space-between;background:white;border:1.5px solid #d7eee2;border-radius:12px;padding:10px 12px;gap:8px;">
      <div style="text-align:right;">
        <div style="font-size:13px;font-weight:800;color:#373a38;">${escapeHtml(m.name)}</div>
        <div style="font-size:11px;color:#9da3a0;direction:ltr;text-align:right;">${escapeHtml(m.email)}</div>
        <div style="font-size:10px;color:#176069;font-weight:800;margin-top:3px;">${m.role === 'manager' ? '🛡️ مشرف · قياسات + قص' : 'صلاحية الوحدات:'}</div>
        ${m.role === 'manager' ? '' : `<select onchange="updateMemberAccess('${escapeAttr(m.uid)}', this.value)" style="margin-top:4px;padding:5px 7px;border:1px solid #c1f2f7;border-radius:8px;font:800 10px Cairo,sans-serif;color:#176069;background:#fff;max-width:190px;">
          <option value="measurements" ${normalizeShopAccess(m.access).measurements && !normalizeShopAccess(m.access).cutting ? 'selected' : ''}>📏 القياسات فقط</option>
          <option value="cutting" ${!normalizeShopAccess(m.access).measurements && normalizeShopAccess(m.access).cutting ? 'selected' : ''}>✂️ القص والمواد فقط</option>
          <option value="both" ${normalizeShopAccess(m.access).measurements && normalizeShopAccess(m.access).cutting ? 'selected' : ''}>📏✂️ القياسات + القص</option>
          <option value="none" ${!normalizeShopAccess(m.access).measurements && !normalizeShopAccess(m.access).cutting ? 'selected' : ''}>🚫 بدون وحدات</option>
        </select>`}
      </div>
      <div style="display:flex;flex-direction:column;gap:6px;">
        <button onclick="toggleMemberRole('${escapeAttr(m.uid)}')" style="background:#ecf7f1;color:#137644;border:none;border-radius:10px;padding:7px 10px;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:pointer;white-space:nowrap;">${m.role === 'manager' ? '⬇️ تنزيل لعضو' : '⬆️ ترقية لمشرف'}</button>
        <button onclick="removeMember('${escapeAttr(m.uid)}')" style="background:#fef2f1;color:#d33722;border:none;border-radius:10px;padding:7px 10px;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:pointer;">🗑️ إزالة</button>
      </div>
    </div>
  `).join('');
}

async function addNewMember() {
  if (!isAdmin()) { alert('⛔ إضافة الأعضاء متاحة للمشرف الأساسي فقط.'); return; }
  const name  = document.getElementById('newmember-name').value.trim();
  const email = document.getElementById('newmember-email').value.trim().toLowerCase();
  const pass  = document.getElementById('newmember-password').value;
  const role  = document.getElementById('newmember-role').value === 'manager' ? 'manager' : 'employee';
  const accessChoice = document.getElementById('newmember-access').value || 'measurements';
  const access = role === 'manager' ? { measurements:true, cutting:true } : {
    measurements: accessChoice === 'measurements' || accessChoice === 'both',
    cutting: accessChoice === 'cutting' || accessChoice === 'both'
  };
  const msg   = document.getElementById('member-msg');
  const btn   = document.getElementById('add-member-btn');

  const show = (text, ok=false) => {
    msg.style.color = ok ? '#179baa' : '#ed4832';
    msg.textContent = text;
  };
  if (!name)  { show('⚠️ أدخل اسم العضو'); return; }
  if (!email) { show('⚠️ أدخل البريد الإلكتروني'); return; }
  if (!/^\S+@\S+\.\S+$/.test(email)) { show('⚠️ أدخل بريداً إلكترونياً صحيحاً'); return; }
  if (!pass || pass.length < 6) { show('⚠️ كلمة المرور يجب أن تكون 6 أحرف على الأقل'); return; }
  if (email === ADMIN_EMAIL.toLowerCase()) { show('⚠️ هذا البريد محجوز للمشرف'); return; }
  if (_membersCache.some(m => String(m.name || '').trim().toLowerCase() === name.toLowerCase())) {
    show('⚠️ يوجد عضو آخر بنفس الاسم، اختر اسماً مميزاً'); return;
  }
  if (!navigator.onLine) { show('🔴 إضافة عضو تحتاج اتصالاً بالإنترنت.'); return; }

  btn.disabled = true;
  btn.textContent = '⏳ جارٍ إنشاء الحساب...';
  msg.textContent = '';

  try {
    if (!secondaryAuth) throw new Error('خدمة إنشاء الحساب غير جاهزة.');

    // مهم: نستخدم تطبيق Firebase ثانوياً حتى لا يتم تسجيل خروج المشرف الحالي.
    // إذا بقيت جلسة قديمة على التطبيق الثانوي، نسجل خروجها أولاً.
    try { await secondaryAuth.signOut(); } catch (_) {}

    const cred = await secondaryAuth.createUserWithEmailAndPassword(email, pass);
    const newUid = cred.user.uid;

    // الكتابة تتم بحساب المشرف الأساسي، وليس بالحساب الجديد.
    await db.collection('members').doc(newUid).set({
      name, email, role, access,
      color: '#199959',
      addedAt: firebase.firestore.FieldValue.serverTimestamp(),
      addedBy: (_currentUser && _currentUser.email) ? _currentUser.email : ADMIN_EMAIL
    });

    try { await secondaryAuth.signOut(); } catch (_) {}
    show('✅ تم إنشاء حساب العضو وإضافته بنجاح.', true);
    document.getElementById('newmember-name').value = '';
    document.getElementById('newmember-email').value = '';
    document.getElementById('newmember-password').value = '';
    document.getElementById('newmember-role').value = 'employee';
    document.getElementById('newmember-access').value = 'measurements';

    // تحديث القائمة فوراً بدلاً من انتظار مستمع Firestore.
    _membersCache = _membersCache.filter(m => m.uid !== newUid);
    _membersCache.push({uid:newUid, name, email, role, access, color:'#199959'});
    renderMembersListUI();
  } catch (e) {
    console.error('addNewMember failed:', e);
    let m = '❌ تعذّر إضافة العضو.';
    switch (e && e.code) {
      case 'auth/email-already-in-use': m = '❌ هذا البريد مستخدم مسبقاً.'; break;
      case 'auth/invalid-email': m = '❌ صيغة البريد الإلكتروني غير صحيحة.'; break;
      case 'auth/weak-password': m = '❌ كلمة المرور ضعيفة؛ استخدم 6 أحرف على الأقل.'; break;
      case 'auth/network-request-failed': m = '📶 تعذر الاتصال بخدمة Firebase. تحقق من الإنترنت.'; break;
      case 'auth/operation-not-allowed': m = '⚠️ تسجيل الدخول بالبريد وكلمة المرور غير مفعّل في Firebase Authentication.'; break;
      case 'auth/admin-restricted-operation': m = '⚠️ إنشاء الحسابات محظور من إعدادات Firebase Authentication.'; break;
      case 'permission-denied': m = '⛔ Firebase رفض إضافة سجل العضو. تأكد أن حساب المشرف هو الحساب الأساسي.'; break;
      case 'failed-precondition': m = '⚠️ العملية تحتاج اتصالاً مباشراً بقاعدة البيانات.'; break;
      default:
        if (e && /permission-denied|Missing or insufficient permissions/i.test(e.message || ''))
          m = '⛔ لا توجد صلاحية لكتابة عضو جديد في Firestore.';
        else if (e && e.message) m += '\n' + e.message;
    }
    show(m);
    // إذا تم إنشاء الحساب ثم فشلت كتابة members، نوضح الحالة بدلاً من الإيحاء بأن كل شيء تم.
    if (e && e.code === 'permission-denied') {
      show('⛔ تم الوصول إلى إنشاء الحساب لكن Firestore رفض حفظ العضو. راجع قواعد members.');
    }
  } finally {
    btn.disabled = false;
    btn.textContent = '➕ إضافة العضو الآن';
  }
}

async function updateMemberAccess(uid, choice) {
  if (!isAdmin()) { alert('⛔ تغيير صلاحيات الوحدات متاح للمشرف الأساسي فقط.'); renderMembersListUI(); return; }
  const member = _membersCache.find(m => m.uid === uid);
  if (!member) return;
  if (member.role === 'manager') { alert('🛡️ المشرف لديه صلاحية الوحدتين تلقائياً.'); renderMembersListUI(); return; }
  const access = {
    measurements: choice === 'measurements' || choice === 'both',
    cutting: choice === 'cutting' || choice === 'both'
  };
  try {
    await db.collection('members').doc(uid).update({ access });
    member.access = access;
    renderMembersListUI();
    showMemberMessage('✅ تم تحديث صلاحية الوحدات للعضو.', true);
  } catch (e) {
    console.error('updateMemberAccess failed:', e);
    renderMembersListUI();
    alert('⛔ تعذّر حفظ صلاحية العضو.\n\n' + (e && e.message ? e.message : 'تحقق من الاتصال وقواعد Firebase.'));
  }
}

function showMemberMessage(text, ok=false) {
  const el = document.getElementById('member-msg');
  if (!el) return;
  el.style.color = ok ? '#179baa' : '#ed4832';
  el.textContent = text;
  setTimeout(() => { if (el.textContent === text) el.textContent = ''; }, 3500);
}

async function removeMember(uid) {
  if (!isAdmin()) { alert('⛔ إزالة الأعضاء متاحة للمشرف الأساسي فقط.'); return; }
  const member = _membersCache.find(m => m.uid === uid);
  const label = member ? (member.name || member.email) : 'هذا العضو';
  if (!confirm(`إزالة "${label}" من الأعضاء؟ لن يستطيع الدخول للتطبيق أو رؤية البيانات بعد الآن.`)) return;

  /* حارس اتصال ومؤشّر انتظار — كما في إضافة العضو.
     الحذف هنا يمنع الدخول فعلاً، ودونهما يضغط المشرف فلا يرى شيئاً
     يتغيّر: لا مؤشّر ولا رسالة. فيضغط ثانيةً وثالثةً ظنّاً أن الزر لا
     يعمل، ثم يكتشف لاحقاً أن العضو ما زال يدخل — لأن الطلب لم يصل أصلاً. */
  if (!navigator.onLine) {
    alert('🔴 إزالة عضو تحتاج اتصالاً بالإنترنت.\n\nأعد المحاولة بعد عودة الشبكة.');
    return;
  }
  const msgEl = document.getElementById('member-msg');
  if (msgEl) { msgEl.style.color = '#6e7471'; msgEl.textContent = '⏳ جارٍ الإزالة…'; }
  try {
    await db.collection('members').doc(uid).delete();
    if (msgEl) { msgEl.style.color = '#0591a1'; msgEl.textContent = `✅ أُزيل "${label}"`; }
  } catch (e) {
    if (msgEl) { msgEl.style.color = '#ed4832'; msgEl.textContent = 'تعذّرت الإزالة: ' + e.message; }
    alert('تعذّرت الإزالة: ' + e.message);
  }
}

async function toggleMemberRole(uid) {
  if (!isAdmin()) { alert('⛔ تغيير الصلاحيات متاح للمشرف الأساسي فقط.'); return; }
  const member = _membersCache.find(m => m.uid === uid);
  if (!member) return;
  const newRole = member.role === 'manager' ? 'employee' : 'manager';
  const label = member.name || member.email;
  const confirmMsg = newRole === 'manager'
    ? `ترقية "${label}" إلى مشرف؟ سيرى كل الأقسام الإدارية (المصروفات، المدفوعات، الجرد...) لكن لن يقدر يضيف أو يحذف أعضاء.`
    : `تنزيل "${label}" إلى عضو عادي؟ سيفقد صلاحية رؤية الأقسام الإدارية.`;
  if (!confirm(confirmMsg)) return;
  try {
    await db.collection('members').doc(uid).update({ role: newRole });
  } catch (e) {
    alert('تعذّر التحديث: ' + e.message);
  }
}

function updateSettingsPreview() {
  const n = document.getElementById('settings-name').value   || DEFAULT_SETTINGS.name;
  const t = document.getElementById('settings-tagline').value;
  const p = document.getElementById('settings-phone').value;
  const f = document.getElementById('settings-footer').value;
  const pn = document.getElementById('prev-name');
  const pt = document.getElementById('prev-tagline');
  const pp = document.getElementById('prev-phone');
  const pf = document.getElementById('prev-footer');
  if (pn) pn.innerText = n;
  if (pt) pt.innerText = t;
  if (pp) pp.innerText = p;
  if (pf) pf.innerText = f;
}

function closeSettings() {
  document.getElementById('settings-modal').classList.add('hidden');
}

function saveSettings() {
  const name = (document.getElementById('settings-name').value.trim())||DEFAULT_SETTINGS.name;
  DB.settings = {
    name,
    tagline: document.getElementById('settings-tagline').value.trim(),
    phone:   document.getElementById('settings-phone').value.trim(),
    footer:  document.getElementById('settings-footer').value.trim(),
    countryCode: (document.getElementById('settings-country').value.trim().replace(/\D/g,'')) || '218'
  };
  saveDB();
  applySettings();
  closeSettings();
  alert('✅ تم حفظ الإعدادات وتطبيقها فوراً على كل مكان.');
  db.collection('meta').doc('settings').set(DB.settings).catch(e => alert('⚠️ تعذّرت مزامنة الإعدادات:\n' + e.message));
}

// ============================================================
// واصل السداد المستقل
// ============================================================
function openReceiptModal(customerName='', phone='') {
  document.getElementById('receipt-cust-name').value = customerName || '';
  document.getElementById('receipt-cust-phone').value = phone || '';
  document.getElementById('receipt-amount').value = '';
  document.getElementById('receipt-notes').value = '';
  document.getElementById('receipt-cust-suggestions').classList.add('hidden');
  const _rm = document.getElementById('receipt-modal');
  if (_rm) _rm.dataset.receiptOpKey = wsUid('RO-');
  const _saveBtn = document.getElementById('btn-save-payment-receipt');
  const _printBtn = document.getElementById('btn-save-print-payment-receipt');
  if (_saveBtn) _saveBtn.disabled = false;
  if (_printBtn) _printBtn.disabled = false;
  document.getElementById('receipt-modal').classList.remove('hidden');
  updateReceiptStatus();
  setTimeout(()=>document.getElementById('receipt-cust-name').focus(),200);
}

function closeReceiptModal() {
  document.getElementById('receipt-modal').classList.add('hidden');
}

function suggestReceiptCustomer() {
  const val = document.getElementById('receipt-cust-name').value.trim().toLowerCase();
  const box = document.getElementById('receipt-cust-suggestions');
  box.innerHTML = '';
  let clients = {};
  DB.sales.forEach(s=>{ if(!clients[s.customerName]) clients[s.customerName]={name:s.customerName,phone:s.customerPhone||''}; });
  DB.payments.forEach(p=>{ if(!clients[p.customerName]) clients[p.customerName]={name:p.customerName,phone:''}; });
  Object.keys(DB.creditBalances||{}).forEach(n=>{ if(!clients[n]) clients[n]={name:n,phone:''}; });
  let list = Object.values(clients);
  if (val) { list = list.filter(c=>c.name.toLowerCase().includes(val)); }
  // الأحدث ظهوراً أولاً (آخر عملية بيع أو سداد لهذا العميل)
  let lastSeen = {};
  DB.sales.forEach(s=>{ lastSeen[s.customerName] = Math.max(lastSeen[s.customerName]||0, s.timestamp||0); });
  DB.payments.forEach(p=>{ lastSeen[p.customerName] = Math.max(lastSeen[p.customerName]||0, p.timestamp||0); });
  list.sort((a,b)=> (lastSeen[b.name]||0) - (lastSeen[a.name]||0));
  const filtered = list.slice(0, 8);
  if (!filtered.length) { box.classList.add('hidden'); return; }
  filtered.forEach(cl => {
    let d=document.createElement('div');
    d.className='p-3 hover:bg-slate-50 cursor-pointer border-b border-slate-100 text-sm font-bold';
    d.innerText=`${cl.name} (${cl.phone||'بدون هاتف'})`;
    d.onclick=()=>{
      document.getElementById('receipt-cust-name').value=cl.name;
      document.getElementById('receipt-cust-phone').value=cl.phone||'';
      box.classList.add('hidden');
      updateReceiptStatus();
    };
    box.appendChild(d);
  });
  box.classList.remove('hidden');
}

function updateReceiptStatus() {
  const name  = document.getElementById('receipt-cust-name').value.trim();
  const amount = r2(document.getElementById('receipt-amount').value)||0;
  const hint  = document.getElementById('receipt-status-hint');
  const preview = document.getElementById('receipt-preview-box');
  if (!name) { hint.classList.add('hidden'); preview.classList.add('hidden'); return; }
  const debt   = getCustomerNetDebt(name);
  const credit = getCustomerCredit(name);
  // تلميح الحالة
  if (debt > 0) {
    hint.innerHTML = `<i data-lucide="alert-circle" class="w-4 h-4 inline-block ml-1"></i>دين على العميل: <strong>${fmt(debt)}</strong>`;
    hint.className = 'mt-1.5 px-3 py-2 rounded-lg text-xs font-bold border bg-rose-50 border-rose-200 text-rose-700';
  } else if (credit > 0) {
    hint.innerHTML = `<i data-lucide="check-circle" class="w-4 h-4 inline-block ml-1"></i>رصيد للعميل: <strong>${fmt(credit)}</strong>`;
    hint.className = 'mt-1.5 px-3 py-2 rounded-lg text-xs font-bold border bg-emerald-50 border-emerald-200 text-emerald-700';
  } else {
    hint.innerHTML = `<i data-lucide="user-plus" class="w-4 h-4 inline-block ml-1"></i>عميل جديد — سيُضاف المبلغ كرصيد في حسابه`;
    hint.className = 'mt-1.5 px-3 py-2 rounded-lg text-xs font-bold border bg-blue-50 border-blue-200 text-blue-700';
  }
  hint.classList.remove('hidden');
  refreshIcons();
  // ملخص توقعي
  if (amount > 0) {
    let lines = '';
    const paidDebt  = Math.min(debt, amount);
    const leftover  = r2(amount - paidDebt);
    if (paidDebt > 0) lines += `<div class="flex justify-between"><span>تسديد دين:</span><span class="text-emerald-600 font-bold">- ${fmt(paidDebt)}</span></div>`;
    if (leftover > 0) lines += `<div class="flex justify-between"><span>رصيد يُضاف للعميل:</span><span class="text-blue-600 font-bold">+ ${fmt(leftover)}</span></div>`;
    preview.innerHTML = `<div class="font-bold text-slate-700 mb-1 text-xs">توزيع المبلغ:</div>${lines}`;
    preview.classList.remove('hidden');
  } else {
    preview.classList.add('hidden');
  }
}

const WS_PENDING_RECEIPTS_KEY = 'ws_pending_receipt_writes_v1';

/* v142: durable queue is owned by AppReceiptOffline/ReceiptRepository.
   These compatibility functions intentionally no longer write new records to localStorage. */
function wsReadPendingReceipts(){ return []; }
function wsWritePendingReceipts(list){ return true; }
function wsQueuePendingReceipt(payEntry,touchedSales,phoneTouched,creditAdded){
  const sales=[...new Map([...touchedSales,...phoneTouched].map(s=>[s.id,{id:s.id,paid:s.paid,netDebt:s.netDebt,customerPhone:s.customerPhone||''}])).values()];
  const item={id:payEntry.id,payEntry,sales,customerName:payEntry.customerName,creditAdded:Number(creditAdded)||0,queuedAt:Date.now()};
  if(window.AppReceiptOffline&&typeof window.AppReceiptOffline.stage==='function')
    window.AppReceiptOffline.stage(item).catch(e=>console.warn('[ReceiptOffline] stage failed',e));
}
async function wsFlushPendingReceipts(){
  const list=(window.AppReceiptOffline&&typeof window.AppReceiptOffline.pending==='function')?await window.AppReceiptOffline.pending():[];
  if(!list.length||(typeof getCurrentUserUid==='function'&&!getCurrentUserUid()))return;
  for(const item of list){
    try{
      await fsSet('payments',item.payEntry.id,item.payEntry);
      if(Array.isArray(item.sales)) await Promise.all(item.sales.filter(s=>s&&s.id).map(s=>fsUpdate('sales',s.id,{paid:s.paid,netDebt:s.netDebt,customerPhone:s.customerPhone||''})));
      if(item.creditAdded>0&&item.customerName&&typeof syncCreditBalance==='function')await syncCreditBalance(item.customerName);
      if(window.AppReceiptOffline&&typeof window.AppReceiptOffline.remove==='function')await window.AppReceiptOffline.remove(item.id);
      if(window.AppOutbox&&typeof window.AppOutbox.remove==='function')window.AppOutbox.remove(item.payEntry.clientOperationId||item.id);
      if(window.AppAudit&&typeof window.AppAudit.record==='function')await window.AppAudit.record('receipt:synced',{id:item.id});
    }catch(e){ console.warn('[ReceiptSync] pending item retained',item&&item.id,e); }
  }
}
window.addEventListener('online',()=>{setTimeout(()=>wsFlushPendingReceipts().catch(()=>{}),800);});

/* ═══════════════════════════════════════════════════════════════════════
   واصل السداد — مسار واحد للحفظ، مع خيار الطباعة.
   الحفظ لا يعتمد على الطباعة أو الشبكة، والطباعة اختيارية بالكامل.
   لكل نافذة سداد رمز عملية مستقل يمنع إنشاء نفس الواصل مرتين حتى بعد
   بطء الهاتف أو النقر المتكرر.
   ═══════════════════════════════════════════════════════════════════════ */
function wsReceiptOperationKey() {
  const el = document.getElementById('receipt-modal');
  if (!el) return '';
  let key = el.dataset.receiptOpKey || '';
  if (!key) {
    key = wsUid('RO-');
    el.dataset.receiptOpKey = key;
  }
  return key;
}

function wsReceiptOperationUsed(key) {
  if (!key) return false;
  try { return localStorage.getItem('ws_receipt_used_' + key) === '1'; } catch (e) { return false; }
}
function wsMarkReceiptOperationUsed(key) {
  if (!key) return;
  try { localStorage.setItem('ws_receipt_used_' + key, '1'); } catch (e) {}
}

function _setReceiptButtonBusy(btn, busy, label, icon) {
  if (!btn) return;
  if (busy) {
    if (!btn.dataset.originalHtml) btn.dataset.originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.setAttribute('aria-busy', 'true');
    btn.classList.add('opacity-70', 'cursor-wait');
    btn.innerHTML = '<i data-lucide="loader-circle" class="w-5 h-5 animate-spin"></i><span>' + label + '</span>';
  } else {
    btn.disabled = false;
    btn.removeAttribute('aria-busy');
    btn.classList.remove('opacity-70', 'cursor-wait');
    if (btn.dataset.originalHtml) btn.innerHTML = btn.dataset.originalHtml;
  }
  try { refreshIcons(); } catch (e) {}
}

function savePaymentReceipt() {
  return _savePaymentReceiptCore(false);
}
function savePaymentReceiptAndPrint() {
  return _savePaymentReceiptCore(true);
}

function _savePaymentReceiptCore(shouldPrint) {
  const saveBtn = document.getElementById('btn-save-payment-receipt');
  const printBtn = document.getElementById('btn-save-print-payment-receipt');
  const nameEl = document.getElementById('receipt-cust-name');
  const phoneEl = document.getElementById('receipt-cust-phone');
  const amountEl = document.getElementById('receipt-amount');
  const typeEl = document.getElementById('receipt-pay-type');
  const notesEl = document.getElementById('receipt-notes');

  if (!nameEl || !amountEl || !typeEl) {
    alert('⚠️ تعذّر فتح نموذج واصل السداد بشكل صحيح. أعد فتح نافذة السداد وحاول مرة أخرى.');
    return false;
  }

  const name = nameEl.value.trim();
  const phone = phoneEl ? phoneEl.value.trim() : '';
  const amount = r2(amountEl.value);
  const payType = typeEl.value;
  const notes = notesEl ? notesEl.value.trim() : '';
  if (!name) { alert('يرجى إدخال اسم العميل.'); nameEl.focus(); return false; }
  if (!isFinite(amount) || amount <= 0) { alert('يرجى إدخال مبلغ صحيح أكبر من صفر.'); amountEl.focus(); return false; }

  const opKey = wsReceiptOperationKey();
  if (wsReceiptOperationUsed(opKey)) {
    showSuccessToast('ℹ️ تم حفظ هذا الواصل بالفعل — لن يتم تسجيله مرة ثانية.');
    return false;
  }

  const guardKey = 'receipt-' + (typeof wsNormName === 'function' ? wsNormName(name) : name) + '-' + amount + '-' + payType;
  if (!guardOnce(guardKey, 5000)) {
    showSuccessToast('⏳ العملية قيد التنفيذ — لا تضغط مرة أخرى.');
    return false;
  }

  /* للطباعة فقط: فتح النافذة هنا، مباشرة من نقرة المستخدم، قبل أي عمل
     ثقيل أو عملية حفظ؛ هكذا لا تعتبرها المتصفحات نافذة منبثقة آلية. */
  let pw = null;
  if (shouldPrint) {
    try { pw = window.open('', '_blank', 'width=480,height=520,noopener,noreferrer'); } catch (e) { pw = null; }
  }

  _setReceiptButtonBusy(saveBtn, true, 'جاري حفظ الواصل...', 'save');
  _setReceiptButtonBusy(printBtn, true, shouldPrint ? 'جاري الحفظ والطباعة...' : 'جاري الحفظ...', 'printer');

  try {
    /* فحص تكرار سابق: تحذير فقط، ولا نحذف أي حركة. */
    const recentTwin = (DB.payments || []).find(p => {
      if (!p || p.isRefund || p.customerName !== name || Math.abs(r2(p.amount) - amount) > 0.001) return false;
      const t = Number(p.timestamp || 0);
      return t > 0 && Math.abs(Date.now() - t) <= 15 * 60 * 1000;
    });
    if (recentTwin) {
      const ok = confirm('⚠️ تنبيه سلامة الحسابات\n\nيوجد واصل سابق لنفس العميل وبنفس المبلغ خلال آخر 15 دقيقة:\n' +
        'المبلغ: ' + fmt(amount) + '\n' +
        'رقم الحركة: ' + (recentTwin.id || '—') + '\n' +
        'التاريخ: ' + (recentTwin.date || '—') + '\n\nهل هذا سداد جديد فعلاً؟');
      if (!ok) {
        try { if (pw) pw.close(); } catch (e) {}
        return false;
      }
    }

    const receiptId = wsUid('REC-');
    let rem = amount;
    const touchedSales = [];
    const debtDistribution = [];

    for (let i = 0; i < DB.sales.length; i++) {
      const sale = DB.sales[i];
      if (sale.customerName !== name || !(sale.netDebt > 0)) continue;
      const applied = r2(Math.min(rem, sale.netDebt));
      if (applied <= 0) continue;
      sale.paid = r2((sale.paid || 0) + applied);
      sale.netDebt = r2(sale.netDebt - applied);
      rem = r2(rem - applied);
      touchedSales.push(sale);
      debtDistribution.push({ saleId: sale.id, amountApplied: applied });
      if (rem <= 0.001) break;
    }

    const creditAdded = rem > 0.001 ? r2(rem) : 0;
    if (creditAdded > 0) addCustomerCredit(name, creditAdded);

    const payEntry = {
      id: receiptId,
      customerName: name,
      amount,
      type: payType,
      reason: notes || `واصل سداد ${receiptId}`,
      date: new Date().toLocaleString('ar-EG'),
      timestamp: Date.now(),
      receiptId,
      clientOperationId: opKey,
      signedBy: (typeof getCurrentUserName === 'function' ? (getCurrentUserName() || 'مستخدم النظام') : 'مستخدم النظام'),
      signedByUid: (typeof getCurrentUserUid === 'function' ? (getCurrentUserUid() || '') : ''),
      receiverRole: (typeof getCurrentUserRole === 'function' ? (getCurrentUserRole() || 'employee') : 'employee'),
      debtDistribution,
      creditAdded
    };

    /* تحقق نهائي قبل الإضافة: يمنع أي مسار آخر من تسجيل نفس العملية. */
    const alreadyStored = (DB.payments || []).some(p => p && p.clientOperationId === opKey);
    if (alreadyStored) {
      wsMarkReceiptOperationUsed(opKey);
      try { if (pw) pw.close(); } catch (e) {}
      showSuccessToast('ℹ️ الواصل مسجل مسبقاً — لم تتم إضافة نسخة أخرى.');
      return false;
    }

    DB.payments.push(payEntry);

    const phoneTouched = [];
    if (phone) {
      DB.sales.filter(s => s.customerName === name && !s.customerPhone).forEach(s => {
        s.customerPhone = phone;
        phoneTouched.push(s);
      });
    }

    /* علامة الاستخدام تُكتب قبل أي رسم أو مزامنة: إعادة النقر أو إعادة الرسم
       لا يمكن أن تنشئ حركة ثانية. */
    wsMarkReceiptOperationUsed(opKey);
    saveDB();
    reconcileAndSync(name, { silent: true });
    renderAllSections();
    updatePaymentDuplicateAlert();
    closeReceiptModal();

    wsQueuePendingReceipt(payEntry, touchedSales, phoneTouched, creditAdded);
    Promise.resolve().then(() => wsFlushPendingReceipts().catch(() => {}));

    if (shouldPrint) {
      try {
        if (pw) {
          printPaymentReceipt(pw, receiptId, name, phone, amount, payType, notes, creditAdded);
        } else {
          showSuccessToast('✅ تم حفظ الواصل. اسمح بالنوافذ المنبثقة إذا أردت الطباعة.');
        }
      } catch (e) {
        console.warn('تعذرت طباعة واصل السداد بعد نجاح الحفظ:', e);
        try { if (pw) pw.close(); } catch (e2) {}
      }
    }

    const creditMsg = creditAdded > 0 ? `\nالفائض (${fmt(creditAdded)}) أُضيف كرصيد للعميل.` : '';
    showSuccessToast(`✅ تم حفظ واصل السداد ${receiptId} بنجاح.`);
    if (!shouldPrint) {
      alert(`✅ تم حفظ واصل السداد ${receiptId} بنجاح!\nالمبلغ: ${fmt(amount)}${creditMsg}` + wsSaveNote());
    }
    return true;
  } catch (err) {
    console.error('فشل حفظ واصل السداد:', err);
    try { if (pw) pw.close(); } catch (e2) {}
    alert('❌ تعذّر حفظ واصل السداد.\n\n' + (err && err.message ? err.message : String(err)) + '\n\nلم تُحذف البيانات من الشاشة. أعد المحاولة بعد التأكد من الحقول.');
    return false;
  } finally {
    _setReceiptButtonBusy(saveBtn, false);
    _setReceiptButtonBusy(printBtn, false);
  }
}

function printPaymentReceipt(pw, id, name, phone, amount, payType, notes, creditAdded) {
  if (!pw) { alert('يرجى السماح بالنوافذ المنبثقة في المتصفح لإتمام الطباعة.\
(الإعدادات ← الخصوصية ← النوافذ المنبثقة)'); return; }
  /* ⚠️ إصلاح 8.8 — تهريب النصوص:
     كانت هذه الدالة تحقن اسم العميل والهاتف والبيان واسم المحل في HTML
     خاماً عبر document.write بلا أي تهريب — وهي الموضع الوحيد في الملف
     الذي فاته ذلك، فبقية الصفحة تستخدم escapeHtml بانتظام.
     الأثر: اسم عميل فيه علامة اقتباس أو وسم يكسر الإيصال فلا يُطبع، أو
     يُنفَّذ كوداً في نافذة من **نفس المصدر** — بصلاحية كاملة على الجلسة.
     والنافذة تُفتح بعد حفظ العملية مباشرةً، فالكسر يقع والمستخدم يظنّ
     أن السداد لم يُسجَّل فيعيده مرة أخرى. */
  const E   = (v) => escapeHtml(v == null ? '' : v);
  /* ⚠️ إصلاح 8.8.3 — عطل مؤكَّد في كل مرة، بلا استثناء:
     السطر التالي كان يقرأ `_ps` — **وهو غير معرَّف في الملف كله**.
     لا `const _ps` ولا `let` ولا وسيط بهذا الاسم؛ بحثٌ في 9,000 سطر
     لا يجد له تعريفاً واحداً. فالدالة ترمي ReferenceError عند أول
     سطر يلمسه، فلا يُكتب في نافذة الطباعة حرف واحد.

     ولماذا لم يشتكِ أحد؟ لأن المُستدعي يلفّها في try/catch يكتفي بـ
     console.error ثم يُغلق النافذة:

         try { printPaymentReceipt(...); }
         catch (e) { console.error(...); try { pw.close(); } catch {} }

     فالسلوك الظاهر: يُطلب الإذن بالنوافذ المنبثقة، تُفتح نافذة بيضاء،
     تُغلق فوراً، ثم تظهر رسالة «✅ تم تسجيل واصل السداد بنجاح».
     العملية محفوظة فعلاً — لكن **إيصال السداد لم يُطبع ولا مرة واحدة
     منذ إضافة هذه الدالة**، ولا شيء في الواجهة يقول ذلك.

     الصواب `getSettings()`: هي مصدر إعدادات المحل في بقية الملف،
     وتدمج `DEFAULT_SETTINGS` مع `DB.settings` — فلا تنكسر لو لم تصل
     الإعدادات من السيرفر بعد (فتح أول، أو عمل دون اتصال). */
  const _ps = getSettings();
  const _id = E(id), _n = E(name), _ph = E(phone), _pt = E(payType), _nt = E(notes);
  const _shopName   = E(_ps.name),        _shopTag    = E(_ps.tagline);
  const _shopPhone  = E(_ps.phone || ''), _shopFooter = E(_ps.footer || '');
  const _amt = Number(amount) || 0, _cr = Number(creditAdded) || 0;
  const _by  = E(getCurrentUserName());
  pw.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<title>واصل سداد ${_id}</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&amp;family=Tajawal:wght@400;500;700;800;900&amp;family=JetBrains+Mono:wght@500;600;700&amp;display=swap" rel="stylesheet">
<style>
  *{font-family:'Cairo',sans-serif;box-sizing:border-box;margin:0;padding:0;}
  body{background:#fbfaf8;display:flex;justify-content:center;align-items:flex-start;padding:20px;min-height:100vh;font-weight:700;}
  .receipt{width:320px;background:white;border:2px solid #3d423f;border-radius:16px;overflow:hidden;}
  .rec-header{background:linear-gradient(135deg,#272928,#3d423f);color:white;text-align:center;padding:18px 12px;}
  .rec-title{font-size:25px;font-weight:900;letter-spacing:normal;}
  .rec-sub{font-size:13px;font-weight:700;opacity:0.85;margin-top:2px;}
  .rec-badge{display:inline-block;background:rgba(255, 255, 255, 0.15);border:1px solid rgba(255, 255, 255, 0.3);border-radius:6px;padding:3px 10px;font-size:13px;font-weight:900;margin-top:6px;}
  .rec-body{padding:16px;}
  .rec-row{display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid #f1f6f3;font-size:15px;font-weight:700;color:#3d423f;}
  .rec-row span:last-child{font-weight:900;color:#161817;}
  .rec-amount{text-align:center;padding:14px;background:#f1fcfd;border-radius:12px;margin:12px 0;}
  .rec-amount .val{font-size:40px;font-weight:900;color:#179baa;}
  .rec-amount .lbl{font-size:13px;font-weight:700;color:#505552;margin-bottom:4px;}
  .rec-credit{background:#eef7f3;border-radius:10px;padding:10px;text-align:center;font-size:14px;color:#147d49;font-weight:900;margin-bottom:10px;}
  .rec-footer{background:#fbfaf8;text-align:center;padding:12px;font-size:13px;font-weight:700;color:#6e7471;border-top:1px dashed #e2e9e6;}
  @media print{body{background:white;padding:0;}@page{size:80mm auto;margin:4mm;}.receipt{border:none;border-radius:0;}}
</style>
</head>
<body>
<div class="receipt">
  <div class="rec-header">
    <div class="rec-title">${_shopName}</div>
    <div class="rec-sub">${_shopTag}</div>
    <div class="rec-badge">واصل سداد</div>
  </div>
  <div class="rec-body">
    <div class="rec-row"><span>رقم الواصل</span><span>${_id}</span></div>
    <div class="rec-row"><span>التاريخ</span><span>${new Date().toLocaleString('ar-EG')}</span></div>
    <div class="rec-row"><span>العميل</span><span>${_n}</span></div>
    ${_ph?`<div class="rec-row"><span>الهاتف</span><span>${_ph}</span></div>`:''}
    <div class="rec-row"><span>طريقة الدفع</span><span>${_pt}</span></div>
    ${_nt?`<div class="rec-row"><span>البيان</span><span>${_nt}</span></div>`:''}
    <div class="rec-row" style="border-bottom:none;"><span>المستلم</span><span>${_by}</span></div>
    <div class="rec-amount">
      <div class="lbl">المبلغ المستلم</div>
      <div class="val">${_amt.toLocaleString('ar-EG', {minimumFractionDigits:0,maximumFractionDigits:2})}</div>
    </div>
    ${_cr>0?`<div class="rec-credit">💰 رصيد مضاف للعميل: ${_cr.toLocaleString('ar-EG',{minimumFractionDigits:0,maximumFractionDigits:2})}</div>`:''}
  </div>
  <div class="rec-footer">شكراً لثقتكم بنا • ${_shopPhone}${_shopFooter?"  •  "+_shopFooter:""}</div>
</div>
<script>
  if(document.fonts&&document.fonts.ready){document.fonts.ready.then(()=>setTimeout(()=>window.print(),600));}
  else{setTimeout(()=>window.print(),1800);}
${'<\/scr'+'ipt>'}

</body>
</html>`);
  pw.document.close();
}

// ============================================================
// اختيار طريقة الإرجاع (3 بطاقات)
// ============================================================
function selectRetMethod(method) {
  selectedRetMethod = method;
  const ids = { 'استرداد نقدي':'ret-card-cash', 'رصيد للعميل':'ret-card-credit', 'تسديد دين':'ret-card-debt' };
  document.querySelectorAll('.ret-method-card').forEach(el => {
    el.classList.remove('border-blue-500','bg-blue-50/60');
    el.classList.add('border-slate-200');
  });
  const sel = document.getElementById(ids[method]);
  if (sel) { sel.classList.add('border-blue-500','bg-blue-50/60'); sel.classList.remove('border-slate-200'); }
}

function updateRetDebtHint() {
  if (!returnSource) return;
  const debt = getCustomerNetDebt(returnSource.customerName);
  const hint = document.getElementById('ret-debt-card-hint');
  if (!hint) return;
  if (debt > 0) {
    hint.innerText = `دين: ${fmt(debt)}`;
    document.getElementById('ret-card-debt').classList.remove('opacity-50');
  } else {
    hint.innerText = 'لا ديون مسجلة';
    document.getElementById('ret-card-debt').classList.add('opacity-50');
  }
}

// ============================================================
// BOOT
// ============================================================
function renderEditedInvoicesLog() {
  const box = document.getElementById('edited-inv-log-list');
  if (!box) return;
  const log = (DB.editedInvoicesLog || []).slice().reverse(); // الأحدث أولاً
  if (!log.length) {
    box.innerHTML = `<div class="text-center text-slate-400 text-sm py-10">لا توجد فواتير معدّلة حتى الآن.</div>`;
    return;
  }
  box.innerHTML = log.map(entry => {
    const o = entry.original || {};
    const stillExists = DB.sales.some(s => s.id === entry.originalId);
    const itemsHtml = (o.items || []).map(it => `
      <div class="flex justify-between text-xs py-1 border-b border-slate-50">
        <span>${escapeHtml(it.name)}</span><span class="text-slate-500">${fmt(it.qty)} × ${fmt(it.price)} = <b>${fmt(it.total)}</b></span>
      </div>`).join('');
    return `
    <div class="border border-pink-100 bg-pink-50/50 rounded-xl p-4">
      <div class="flex flex-wrap justify-between items-center gap-2 mb-2">
        <div class="font-bold text-slate-800 flex items-center gap-2 text-sm">
          <i data-lucide="file-clock" class="w-4 h-4 text-pink-600"></i>
          فاتورة ${stillExists ? invLinkHtml(entry.originalId, {small:true}) : escapeHtml(entry.originalId)}
          ${stillExists ? '' : '<span class="text-[10px] bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full">محذوفة حالياً</span>'}
        </div>
        <span class="text-[11px] bg-pink-100 text-pink-700 px-2 py-1 rounded-full font-bold">عُدّلت ${entry.editCount || 1} ${((entry.editCount||1)===1) ? 'مرة' : 'مرات'}</span>
      </div>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs mb-2">
        <div><span class="text-slate-400">العميل الأصلي:</span> <b>${escapeHtml(o.customerName || '-')}</b></div>
        <div><span class="text-slate-400">تاريخ الفاتورة:</span> <b>${escapeHtml(o.date || '-')}</b></div>
        <div><span class="text-slate-400">أول تعديل:</span> <b>${escapeHtml(entry.firstEditedAt || '-')}</b>${entry.firstEditedBy ? ` بواسطة ${escapeHtml(entry.firstEditedBy)}` : ''}</div>
        <div><span class="text-slate-400">آخر تعديل:</span> <b>${escapeHtml(entry.lastEditedAt || '-')}</b>${entry.lastEditedBy ? ` بواسطة ${escapeHtml(entry.lastEditedBy)}` : ''}</div>
      </div>
      <details class="text-xs">
        <summary class="cursor-pointer font-bold text-pink-700">عرض أصناف الفاتورة الأصلية (${(o.items||[]).length})</summary>
        <div class="mt-2">${itemsHtml}</div>
        <div class="flex justify-between text-xs font-bold pt-2 mt-1 border-t border-pink-100">
          <span>الإجمالي الأصلي:</span><span>${fmt(o.subtotal||0)}</span>
        </div>
        <div class="flex justify-between text-xs"><span>المدفوع أصلاً:</span><span>${fmt(o.paid||0)}</span></div>
        <div class="flex justify-between text-xs"><span>الدين وقتها:</span><span>${fmt(o.netDebt||0)}</span></div>
      </details>
      ${stillExists ? `<button onclick="quickViewInvoice('${escapeAttr(entry.originalId)}')" class="mt-2 text-[11px] text-blue-600 font-bold hover:underline">👁️ عرض الفاتورة الحالية بعد التعديل</button>` : ''}
    </div>`;
  }).join('');
  refreshIcons();
}

/* تجميع إعادة الرسم: عشرة مستمعين لحظيين كانوا يستدعون هذه الدالة مباشرة،
   فتُعاد الصفحة كلها عشر مرات في جزء من الثانية عند كل فتح أو تحديث.
   الآن تُنفَّذ مرة واحدة في إطار العرض التالي — هذا وحده يزيل معظم التقطيع. */
let _renderScheduled = false;
/* إصلاح 8.8: يمنع إعادة التحميل التلقائي عند وصول تحديث للتطبيق أثناء
   تحرير فاتورة. الحارس القديم كان ينتظر الكتابات المرسَلة إلى Firestore
   فقط، وفاتورة فيها اثنا عشر صنفاً لم تُحفظ ليست كتابة معلّقة. */
window.wsHasUnsavedWork = function () {
  try {
    if (Array.isArray(window.currentInvoiceItems) && currentInvoiceItems.length > 0) return true;
    const nm = document.getElementById('pos-customer-name');
    if (nm && nm.value && nm.value.trim()) return true;
  } catch (e) {}
  return false;
};

function renderAllSections() {
  if (_renderScheduled) return;
  _renderScheduled = true;
  requestAnimationFrame(() => {
    _renderScheduled = false;
    try { _renderAllSectionsNow(); } catch (e) { console.error('renderAllSections:', e); }
  });
}

/* ═══════════════════════════════════════════════════════════════════════
   إصلاح البطء 8.9.1 — كان النظام يرسم أحد عشر قسماً ليُظهر واحداً.

   ما كان يجري عند حفظ فاتورة واحدة:

     ١) تُكتب الفاتورة، فيطلق Firestore لقطة محلية فورية ثم لقطة أخرى
        بعد تأكيد السيرفر — لقطتان لمجموعة sales وحدها.
     ٢) ومعها: payments (الدفعة)، store (خصم المخزون)، creditBalances
        (الرصيد)، وربما sales مرة أخرى (توزيع الدين على فواتير أخرى).
        فالمجموع بين ست وعشر لقطات للعملية الواحدة.
     ٣) وكل لقطة كانت تستدعي renderAllSections، وهذه تستدعي **أحد عشر
        دالة رسم** تبني innerHTML من **كل** السجلات: كل الفواتير، وكل
        المقبوضات، وكل المصروفات، وكل أصناف المخزن…

   وعشرة من تلك الأقسام الأحد عشر **مخفيّة على الشاشة** (`.tab-content`
   مع `hidden`) — لا يراها المستخدم أصلاً. أي أن أغلى ما في العملية كان
   بناء جداول لا ينظر إليها أحد.

   والأثر يكبر طردياً مع نموّ المحل: مئة فاتورة لا تُلاحَظ، وخمسة آلاف
   تجعل كل حفظ يجمّد الشاشة ثوانيَ — فيظنّ المستخدم أن «الرفع بطيء»
   بينما الرفع نفسه لم يبدأ؛ الجهاز مشغول برسم ما لا يُرى.

   الآن: يُرسم القسم المفتوح وحده. والبقية تُعلَّم «متّسخة» وتُرسم لحظة
   فتحها. والنتيجة على الشاشة واحدة تماماً — لأن ما لا يُعرض لا فرق
   بين رسمه وتركه. */
const SECTION_RENDERERS = {
  sales:      renderSalesArchive,
  debts:      renderDebtsSection,
  credits:    renderCreditsSection,
  expenses:   renderExpenses,
  store:      renderStoreItems,
  inventory:  renderInventoryDashboard,
  payments:   renderPaymentsLedger,
  trash:      renderTrashSection,
  returns:    renderReturnsArchive,
  editedinv:  renderEditedInvoicesLog
};
let _sectionDirty = {};

function renderSection(id) {
  const fn = SECTION_RENDERERS[id];
  if (!fn) return;
  try { fn(); } catch (e) { console.error('render ' + id + ':', e); }
  _sectionDirty[id] = false;
}


/* ⚠️ إصلاح البطء 8.9.1 — إعادة بناء الأيقونات كانت تقع 19 مرة.
   lucide.createIcons() تمسح **المستند كله** بحثاً عن [data-lucide] وتستبدل
   كل واحدة بعنصر SVG جديد. وكانت تُستدعى بعد كل رسم وكل فتح قسم وكل
   تحديث جدول — أي عشرات المرات في الدقيقة أثناء العمل العادي، وكل مرة
   تُلقي 39 عنصراً وتبني غيرها.
   الآن: نداء واحد مؤجَّل إلى إطار الرسم التالي مهما تكرّر الطلب. النتيجة
   على الشاشة واحدة، والعمل يقع مرة واحدة. */
/* refreshIcons انتقلت إلى shared.js في 8.9.3 — انظر سبب النقل هناك */

function _renderAllSectionsNow() {
  applySettings();
  try { updatePaymentDuplicateAlert(); } catch (e) { console.warn('duplicate payment alert:', e); }
  updateUserBadge();

  /* نافذة تسليم المبالغ ليست قسماً في اللوحة، وتظهر فوق كل شيء —
     فتُرسم دائماً، وهي خفيفة (سجلّات اليوم فقط). */
  try { renderReceivedAmountsList(); } catch (e) { console.error(e); }

  // كل الأقسام صارت بحاجة تحديث، لكن لا نرسم إلا المفتوح
  Object.keys(SECTION_RENDERERS).forEach(k => { _sectionDirty[k] = true; });
  if (_activeSection) renderSection(_activeSection);

  _gdriveLoadInit();
  _gdriveUpdateUI(!!_gdriveToken);
}

// ============================================================
// 11. SEARCH — البحث الشامل
// ============================================================

function setSearchPeriod(period) {
  const now = new Date();
  let from;
  if (period === 'today') {
    from = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  } else if (period === 'week') {
    from = new Date(now); from.setDate(from.getDate() - 7);
  } else if (period === 'month') {
    from = new Date(now.getFullYear(), now.getMonth(), 1);
  }
  const fmt2 = d => d.toISOString().split('T')[0];
  document.getElementById('search-date-from').value = fmt2(from);
  document.getElementById('search-date-to').value = fmt2(new Date(now));
  runSearch();
}

function clearSearchFilters() {
  document.getElementById('search-text').value = '';
  document.getElementById('search-date-from').value = '';
  document.getElementById('search-date-to').value = '';
  document.getElementById('search-type').value = 'all';
  document.getElementById('search-results-body').innerHTML = '<tr><td colspan="7" class="p-10 text-center text-slate-400 text-sm">ابدأ البحث أو استعرض كل السجلات بالضغط على "عرض الكل"</td></tr>';
  document.getElementById('search-summary').classList.add('hidden');
  document.getElementById('search-count').innerText = '';
  document.getElementById('search-customer-card').classList.add('hidden');
}

function showAllRecords() {
  document.getElementById('search-text').value = '';
  document.getElementById('search-date-from').value = '';
  document.getElementById('search-date-to').value = '';
  document.getElementById('search-type').value = 'all';
  runSearch(true);
}

function getDateRange() {
  const fromVal = document.getElementById('search-date-from').value;
  const toVal   = document.getElementById('search-date-to').value;
  const fromTs  = fromVal ? dayStartTs(fromVal) : 0;
  const toTs    = toVal   ? dayEndTs(toVal) : Infinity;
  return { fromTs, toTs };
}

function tsInRange(ts, fromTs, toTs) {
  if (!ts) return true;
  return ts >= fromTs && ts <= toTs;
}

function runSearch(showAll) {
  showAll = showAll === true;
  const query      = (document.getElementById('search-text').value || '').trim().toLowerCase();
  const typeFilter = document.getElementById('search-type').value;
  const { fromTs, toTs } = getDateRange();
  const hasDateFilter = fromTs > 0 || toTs < Infinity;
  const hasQuery = query.length > 0;
  const hasFilter = hasQuery || hasDateFilter || typeFilter !== 'all';

  if (!showAll && !hasFilter) {
    document.getElementById('search-results-body').innerHTML = '<tr><td colspan="7" class="p-10 text-center text-slate-400 text-sm">ابدأ البحث أو استعرض كل السجلات بالضغط على "عرض الكل"</td></tr>';
    document.getElementById('search-summary').classList.add('hidden');
    document.getElementById('search-count').innerText = '';
    return;
  }

  let rows = [];

  // ===== فواتير المبيعات =====
  if (typeFilter === 'all' || typeFilter === 'sales') {
    DB.sales.forEach(inv => {
      if (!tsInRange(inv.timestamp, fromTs, toTs)) return;
      const itemNames = (inv.items || []).map(i => i.name).join(' ');
      const haystack  = [inv.id, inv.customerName, inv.customerPhone||'', String(inv.subtotal), String(inv.paid), String(inv.netDebt), itemNames].join(' ').toLowerCase();
      if (!showAll && hasQuery && !haystack.includes(query)) return;
      const itemsSummary = (inv.items||[]).slice(0,3).map(i=>`${escapeHtml(i.name)} ×${fmt(i.qty)}`).join('، ') + ((inv.items||[]).length>3?` +${(inv.items||[]).length-3} أصناف`:'');
      rows.push({
        type:'sales', typeLabel:'فاتورة مبيعات', id:inv.id, date:inv.date, timestamp:inv.timestamp||0,
        entity:inv.customerName, detail:itemsSummary,
        amount:inv.subtotal, amtColor:'text-slate-800',
        subAmounts:[{l:'مدفوع',v:inv.paid,c:'text-emerald-600'},{l:'دين',v:inv.netDebt,c:'text-rose-600'}],
        invId:inv.id
      });
    });
  }

  // ===== المدفوعات =====
  if (typeFilter === 'all' || typeFilter === 'payments') {
    DB.payments.forEach(p => {
      if (!tsInRange(p.timestamp, fromTs, toTs)) return;
      const haystack = [p.customerName, p.reason||'', p.type||'', String(p.amount), p.receiptId||''].join(' ').toLowerCase();
      if (!showAll && hasQuery && !haystack.includes(query)) return;
      rows.push({
        type:'payments', typeLabel:(p.isRefund?'استرداد نقدي':'واصل سداد'), isRefund:!!p.isRefund, id:p.receiptId||'—', date:p.date, timestamp:p.timestamp||0,
        entity:p.customerName, detail:(p.reason||'') + (p.type?` • ${p.type}`:''),
        amount:p.amount, amtColor:p.isRefund?'text-rose-600':'text-emerald-600',
        invId:null
      });
    });
  }

  // ===== المرتجعات =====
  if (typeFilter === 'all' || typeFilter === 'returns') {
    DB.returns.forEach(r => {
      if (!tsInRange(r.timestamp, fromTs, toTs)) return;
      const itemNames = (r.items||[]).map(i=>i.name).join(' ');
      const haystack  = [r.id, r.customerName, r.originalInvId, String(r.total), itemNames, r.method||'', r.reason||''].join(' ').toLowerCase();
      if (!showAll && hasQuery && !haystack.includes(query)) return;
      const itemsSummary = (r.items||[]).slice(0,3).map(i=>`${escapeHtml(i.name)} ×${fmt(i.qty)}`).join('، ');
      rows.push({
        type:'returns', typeLabel:'مرتجع', id:r.id, date:r.date, timestamp:r.timestamp||0,
        entity:r.customerName, detail:`${itemsSummary} • ${r.method} • الفاتورة: ${r.originalInvId}`,
        amount:r.total, amtColor:'text-amber-600',
        invId:r.originalInvId
      });
    });
  }

  // ===== المصروفات =====
  if (typeFilter === 'all' || typeFilter === 'expenses') {
    DB.expenses.forEach(e => {
      if (!tsInRange(e.timestamp, fromTs, toTs)) return;
      const haystack = [e.title, String(e.amount), e.id].join(' ').toLowerCase();
      if (!showAll && hasQuery && !haystack.includes(query)) return;
      rows.push({
        type:'expenses', typeLabel:'مصروف', id:e.id, date:e.date, timestamp:e.timestamp||0,
        entity:'—', detail:e.title,
        amount:e.amount, amtColor:'text-rose-600',
        invId:null
      });
    });
  }

  rows.sort((a,b) => (b.timestamp||0) - (a.timestamp||0));

  // ملخص مالي للنتائج
  const sumSales    = r2(rows.filter(r=>r.type==='sales').reduce((a,r)=>a+(r.amount||0),0));
  /* الترشيح بالعلامة لا بنص التسمية: كان يستثني الاسترداد بمقارنة نصية
     (typeLabel !== 'استرداد نقدي'). صحيح اليوم لأن التسمية تُشتق من العلامة،
     لكن أي تغيير في صياغة النص مستقبلاً كان سيُدخل المستردات ضمن «المحصّل»
     بلا أن يلاحظ أحد. نعتمد isRefund مباشرةً كما في بقية التقارير. */
  const sumPayments = r2(rows.filter(r=>r.type==='payments'&&!r.isRefund).reduce((a,r)=>a+(r.amount||0),0));
  const sumRefunds  = r2(rows.filter(r=>r.type==='payments'&& r.isRefund).reduce((a,r)=>a+(r.amount||0),0));
  const sumReturns  = r2(rows.filter(r=>r.type==='returns').reduce((a,r)=>a+(r.amount||0),0));
  const sumExpenses = r2(rows.filter(r=>r.type==='expenses').reduce((a,r)=>a+(r.amount||0),0));

  const sumEl = document.getElementById('search-summary');
  sumEl.className = 'grid grid-cols-2 md:grid-cols-5 gap-3';
  sumEl.innerHTML = `
    <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center"><div class="text-xs text-blue-500 font-bold">مبيعات</div><div class="text-lg font-black text-blue-700">${fmt(sumSales)}</div></div>
    <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center"><div class="text-xs text-emerald-500 font-bold">محصّل</div><div class="text-lg font-black text-emerald-700">${fmt(sumPayments)}</div></div>
    <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 text-center"><div class="text-xs text-amber-500 font-bold">مرتجعات</div><div class="text-lg font-black text-amber-700">${fmt(sumReturns)}</div></div>
    <div class="bg-rose-50 border border-rose-200 rounded-xl p-3 text-center"><div class="text-xs text-rose-500 font-bold">مصروفات</div><div class="text-lg font-black text-rose-700">${fmt(sumExpenses)}</div></div>
    <div class="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center"><div class="text-xs text-slate-500 font-bold">مستردات نقدية</div><div class="text-lg font-black text-slate-700">${fmt(sumRefunds)}</div></div>
  `;

  // جدول النتائج التفصيلي
  const body = document.getElementById('search-results-body');
  if (rows.length === 0) {
    body.innerHTML = '<tr><td colspan="7" class="p-10 text-center text-slate-400 text-sm">لا توجد نتائج مطابقة لبحثك</td></tr>';
  } else {
    body.innerHTML = rows.map(r => {
      const subLine = (r.subAmounts || []).map(s => `<span class="block text-xs ${escapeHtml(s.c)}">${escapeHtml(s.l)}: ${fmt(s.v)}</span>`).join('');
      const actionBtn = r.invId
        ? `<button onclick="quickViewInvoice('${escapeAttr(r.invId)}')" style="padding:5px 10px;border-radius:8px;background:#eef7f3;color:#14693e;border:none;font-size:11px;font-weight:800;font-family:Cairo,sans-serif;cursor:pointer;">عرض الفاتورة</button>`
        : '<span class="text-slate-300">—</span>';
      return `<tr class="text-sm text-slate-700 hover:bg-blue-50/40 transition-colors">
        <td class="p-3 font-bold text-xs whitespace-nowrap">${escapeHtml(r.typeLabel)}</td>
        <td class="p-3 text-xs" style="font-family:monospace;">${escapeHtml(r.id)}</td>
        <td class="p-3 text-xs text-slate-500 whitespace-nowrap">${escapeHtml(r.date)}</td>
        <td class="p-3 font-medium">${escapeHtml(r.entity)}</td>
        <td class="p-3 text-xs text-slate-500">${escapeHtml(r.detail)}</td>
        <td class="p-3 text-left font-bold ${escapeHtml(r.amtColor)} whitespace-nowrap">${fmt(r.amount)}${subLine}</td>
        <td class="p-3 text-center">${actionBtn}</td>
      </tr>`;
    }).join('');
  }
  document.getElementById('search-count').innerText = rows.length ? `${rows.length} سجل` : '';
}
