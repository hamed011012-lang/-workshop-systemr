const {JSDOM}=require('jsdom');const fs=require('fs'),assert=require('assert');const base='app/src/main/assets/www/';
const html=fs.readFileSync(base+'cutting.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
const dom=new JSDOM(html,{url:'https://test.local/cutting.html',runScripts:'outside-only'}),w=dom.window;
w.guardPage=()=>{};w.auth={onAuthStateChanged(){}};w.alert=console.log;w.confirm=()=>true;w.escHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));w.wsNum=(v,f=0)=>{let n=parseFloat(v);return Number.isFinite(n)?n:f;};w.safeSetItem=(k,v)=>w.localStorage.setItem(k,v);w.showToast=()=>{};w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};
for(const f of ['app/opening-symbols.js','app/default-cutting-data.js','app/symbol-formulas.js','app/calculation-systems.js','app/full-system-file.js','app/system-studio.js','app/engineering.js','app/cut-optimizer.js','app/materials-easy.js','app/pages/cutting.js'])w.eval(fs.readFileSync(base+f,'utf8'));
w.eval('initProfiles();');
for(const type of ['door_single','aluminum_door','window_single','window_double','door_double','aluminum_door_double']){
 const single=type==='door_single'||type==='aluminum_door';
 w.eval(`document.getElementById('measurements-container').innerHTML='<div class="measurement-item">'+createMeasurementHTML(1,100,210,'${type}',50,'','الافتراضي')+'</div>';calculateAll();`);
 assert.equal(w._lastCutResults.pending.length,0,type);
 const plans=[...w._lastPhysicalCutPlans.values()];
 const frame=plans.find(p=>/^(شمبرلي|حلق)/.test(p.name));assert(frame,type);
 assert.equal(frame.pieces.filter(p=>p.axis==='عرض').length,single?1:2,type+' frame width');
 assert.equal(frame.pieces.filter(p=>p.axis==='ارتفاع').length,2,type+' frame height');
 const leaf=plans.find(p=>/^ضلفة/.test(p.name));assert(leaf,type);assert.equal(leaf.pieces.length,type.includes('double')?8:4,type+' sash unchanged');
 if(single){
  const r=w._lastCutResults.rows[0];const material=r.materialRows.find(r=>r.name===frame.name);assert(Math.abs(material.amount-frame.pieces.reduce((n,p)=>n+p.length,0))<1e-6,type+' preview/raw parity');
  const physical=w.document.querySelector('.totals-section .total-row');
  const labels=[...physical.querySelectorAll('tbody tr')].map(row=>({code:row.cells[0].textContent,qty:Number(row.cells[2].querySelector('bdi').textContent.split('×')[1])}));
  assert.equal(labels.filter(x=>x.code==='L1').reduce((n,x)=>n+x.qty,0),1);
  assert.equal(labels.filter(x=>x.code==='H1').reduce((n,x)=>n+x.qty,0),2);
  if(type==='door_single'){assert.equal(frame.rods.length,1);assert(Math.abs(material.amount-556.9)<1e-6);assert.equal(r.materialRows.find(r=>r.name==='حديد شمبرلي').amount,665);}
  w.eval('calculateAll();');const frozen=[...w._lastPhysicalCutPlans.values()].find(p=>p.name===frame.name);assert.equal(frozen.pieces.length,3,'frozen snapshot');
  const materials=w.WSMaterials;w.WSMaterials=null;w.eval('calculateAll();');const fallback=[...w._lastPhysicalCutPlans.values()].find(p=>p.name===frame.name);assert.equal(fallback.pieces.length,3,'fallback');w.WSMaterials=materials;
 }
}
console.log('PASS v358: single door frame 1 width + 2 heights, +12 per piece; preview/plan parity, L1/H1 quantities, frozen/fallback paths; sash, steel, windows and double doors unchanged.');dom.window.close();
