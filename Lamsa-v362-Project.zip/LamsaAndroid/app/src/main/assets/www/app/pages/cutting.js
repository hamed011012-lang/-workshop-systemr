
    /* لا يُسمح في المعادلة إلا بالمتغيّرات والأرقام والعمليات الحسابية
       ودوال Math المعروفة. أي شيء آخر (استدعاء fetch، الوصول لـ window،
       نص برمجي كامل…) يُرفض قبل التنفيذ. */
    /* ══ قائمة سماح صارمة لا قائمة منع ══
       لا يمرّ إلا ما هو مذكور صراحةً — المتغيّرات الخمسة ودوال Math
       الثمانية. وأي اسم آخر، معروفاً كان أو مجهولاً، يُرفض.

       ⚠️ إصلاح 8.8 — الموضع نفسه كان جزءاً من المشكلة:
       كان هذا التعريف أسفل الملف (بعد السطر 2950) بينما initProfiles()
       تُستدعى في أول سطر من الكتلة. وهو `const`، أي في منطقة الموت
       المؤقّت (TDZ) وقت الاستدعاء — فلم يكن مجرّد "غير مستعمل" في مسار
       الترحيل، بل كان استعماله هناك سيرمي ReferenceError. نُقل إلى أعلى
       الكتلة ليكون جاهزاً قبل أي تنفيذ لمعادلة. */
    const FORMULA_ALLOWED = /^[\s0-9+\-*/().,%<>=?:&|!]*(?:(?:w|h|manualLeafW|flipH|largeW|Math\.(?:ceil|floor|round|abs|min|max|sqrt|pow))[\s0-9+\-*/().,%<>=?:&|!]*)*$/;
    const FORMULA_BANNED = /\b(?:function|=>|new|this|window|document|globalThis|eval|Function|import|require|fetch|localStorage|constructor|prototype|__proto__|setTimeout|setInterval)\b|[`$;\[\]{}"']/;

    /* ══ تصحيح 8.8.3 — escAttr كانت تُستعمل في المكان الخطأ ══
       escAttr مصمَّمة لقيمة تُوضع داخل **نص جافاسكريبت** في خاصية، مثل
       onclick="fn('...')" — فهي تسبق علامة الاقتباس المفردة بشرطة مائلة.
       وحين تُستعمل في خاصية HTML عادية (value / data-*) تبقى تلك الشرطة
       جزءاً من القيمة بعد أن يفكّ المتصفح الترميز.

       الأثر عملياً: نظام تشغيل اسمه «مقاس 5" الجديد» أو اسم فيه علامة
       اقتباس مفردة كان يخرج من <option value=...> بشرطة زائدة، ثم
       loadProfileToEditor(this.value) تبحث عن appProfiles["...\'..."]
       فلا تجده — فيُفتح المحرّر فارغاً بلا رسالة، ويظن المستخدم أن
       النظام ضاع. نفس العلة في data-group و data-profile و data-name.

       الصحيح للخصائص العادية هو escHtml وحدها: المتصفح يفكّ &quot; و&#39;
       إلى المحرف الأصلي، فتصل القيمة كما كُتبت تماماً. (13 موضعاً) */
    /* ═══════════════════════════════════════════════════════════════
       ثغرة 8.8.5 — الأخطر في النظام كله: تنفيذ كود في جلسة المدير
       ═══════════════════════════════════════════════════════════════
       `resultsHTML` نصّ HTML يُلتقط من الشاشة ويُخزَّن في مجموعة
       cuttingArchive، وقاعدتها `allow create, update: if isMember()` —
       أي أن **أي عضو يستطيع كتابة ما شاء فيه**. ثم يُعاد حقنه خاماً:

           document.getElementById('results').innerHTML = entry.resultsHTML;

       على جهاز كل من يفتح تلك العملية من الأرشيف.

       وسياسة CSP في هذا الملف تسمح بـ 'unsafe-inline' (وهي ضرورية،
       فالصفحات مليئة بـ onclick). ومعنى ذلك أن وسماً مثل
       <img src=x onerror="…"> المحقون عبر innerHTML **يُنفَّذ فعلاً**.
       (وسم <script> وحده لا يعمل عبر innerHTML — لكن معالج الحدث يعمل.)

       سلسلة الاستغلال كاملة:
         ١) عضو عادي — أو حساب مسروق — يكتب الحمولة في cuttingArchive.
         ٢) المدير يفتح أرشيف القص وينقر تلك العملية.
         ٣) يُنفَّذ الكود **بصلاحيات المدير**، لا بصلاحيات كاتبه.
         ٤) وبصلاحية المدير يستطيع الكود:
              db.collection('members').doc(<uid المهاجم>).set({role:'manager'})
            فترتقي رتبته دائماً، أو يحذف كل الفواتير، أو يسحب بيانات
            العملاء كلها إلى خادم خارجي.

       أي أن الفصل بين «عضو» و«مدير» — وهو أساس كل قواعد السيرفر —
       كان قابلاً للتجاوز بنقرة واحدة من المدير على سجل أرشيف.

       المعالجة: لا نثق بهذا النص أبداً. يُحلَّل في مستند خامل
       (DOMParser لا ينفّذ سكربتاً ولا يحمّل صورة)، ثم يُعاد بناؤه من
       قائمة سماح ضيّقة: الوسوم التي ينتجها التطبيق فعلاً، وخاصّتا
       class و style فقط. وكل معالج حدث وكل وسم آخر يسقط.

       و style نفسها مفلترة: url() و expression() ممنوعتان — الأولى
       تسرّب البيانات إلى خادم خارجي بمجرد العرض، ولا تحتاج جافاسكربت.
       ═══════════════════════════════════════════════════════════════ */
    const CUT_HTML_TAGS = ['IMG','DIV','SPAN','UL','OL','LI','H3','H4','H5','P','B','STRONG',
                           'EM','I','SMALL','BDI','DETAILS','SUMMARY','BR','HR','TABLE','THEAD','TBODY','TR','TD','TH'];
    function safeCssText(v) {
      const s = String(v == null ? '' : v);
      if (/url\s*\(|expression\s*\(|@import|javascript:|behavior\s*:|-moz-binding/i.test(s)) return '';
      return s.length > 400 ? '' : s;
    }
    function sanitizeResultsHTML(html) {
      const src = String(html == null ? '' : html);
      if (!src) return '';
      let doc;
      try { doc = new DOMParser().parseFromString('<body>' + src + '</body>', 'text/html'); }
      catch (e) { return ''; }
      const walk = (node) => {
        // نسخة ثابتة من الأبناء: الحذف أثناء المرور يُخطّي عناصر
        Array.prototype.slice.call(node.childNodes).forEach(ch => {
          if (ch.nodeType === 3) return;                       // نص: يبقى كما هو
          if (ch.nodeType !== 1) { ch.remove(); return; }       // تعليق أو غيره: يسقط
          if (CUT_HTML_TAGS.indexOf(ch.tagName) === -1) { ch.remove(); return; }
          if(ch.tagName==='IMG' && !window.WSOpeningSymbols.trustedSrc(ch.getAttribute('src')||'')){ch.remove();return;}
          Array.prototype.slice.call(ch.attributes).forEach(at => {
            const n = at.name.toLowerCase();
            if (ch.tagName==='IMG' && (n==='src'||n==='alt')) return;
            if (n === 'class') return;
            if(n==='dir'&&['rtl','ltr','auto'].includes(at.value))return;
            if (n === 'style') { const v = safeCssText(at.value); if (v) ch.setAttribute('style', v); else ch.removeAttribute('style'); return; }
            ch.removeAttribute(at.name);                        // on*, src, href, data-*, كلها تسقط
          });
          walk(ch);
        });
      };
      walk(doc.body);
      return doc.body.innerHTML;
    }

    function isSafeFormula(src) {
      if (typeof src !== 'string' || !src.trim() || src.length > 300) return false;
      if (FORMULA_BANNED.test(src)) return false;
      return FORMULA_ALLOWED.test(src);
    }

    /* إصلاح 8.8: لا إعادة تحميل تلقائية وقائمة القص فيها مقاسات. */
    window.wsHasUnsavedWork = function () {
      try { return document.querySelectorAll('.measurement-item').length > 0; }
      catch (e) { return false; }
    };

    function initCuttingApp() {
      initProfiles();
      refreshGlobalProfileOptions();   // القائمة الواحدة فوق الجدول
      restoreDraft();
      attachDraftAutoSave();
      applyPendingCuttingHandoffIfAny();
      if(new URLSearchParams(location.search).get('manageProfiles')==='1')toggleEditor();
    }

    // يتحقق إن جاء المستخدم للتو من صفحة القياسات بزر "إرسال للقص"، ويملأ قائمة القياسات تلقائياً
    function applyPendingCuttingHandoffIfAny() {
      const raw = localStorage.getItem('handoff_to_cutting');
      if(!raw) return;
      try {
        const h = JSON.parse(raw);
        localStorage.removeItem('handoff_to_cutting');
        if(!h.lines || !h.lines.trim()) return;

        /* ══ صفحة نظيفة قبل استقبال مقاسات الزبون الجديد ══
           restoreDraft يعمل قبل هذه الدالة فيُعيد جلسة القص السابقة:
           اسم زبونها ونتائجها المحسوبة. و prepareMeasurements يمسح صفوف
           المقاسات وحدها — فتبقى **نتائج الزبون السابق معروضة أسفل مقاسات
           الجديد**، ويبقى اسمه في الخانة إن لم يحمل التحويل اسماً.

           والنتيجة في الورشة: ورقة قص تحمل اسم زبون وأرقام زبون آخر —
           ويُقصّ الألمنيوم على مقاس ليس مقاسه. لذلك نمسح كل أثر للجلسة
           السابقة أولاً: المقاسات، والنتائج، والاسم. */
        document.getElementById('measurements-container').innerHTML = '';
        document.getElementById('results').innerHTML = '';
        const custEl = document.getElementById('cut-customer');
        if (custEl) custEl.value = h.customerName || '';
        cutContact = { phone: h.customerPhone || '', loc: h.customerLocation || null };
        renderCutContact();
        // الرسوم تصل مع البنود، فنحفظها لتُعرض في بطاقة كل مقاس
        cutSketches = Array.isArray(h.items) ? h.items.map(x => (x && x.img) || '') : [];
        try { refreshApplyAllBar(); } catch (e) {}

        document.getElementById('bulk-input').value = h.lines;
      loadedArchiveFingerprint = '';   // عمل جديد: لا صلة بما استُرجع سابقاً
        const banner = document.getElementById('handoff-banner');
        banner.style.display = 'block';
        // textContent بدل innerHTML: اسم العميل نص لا HTML، وكان يُحقن كما هو
        banner.textContent = '📥 تم استيراد قياسات' + (h.customerName ? (' «' + h.customerName + '»') : '')
          + ' من صفحة القياسات — تم اختيار المعادلات المحفوظة تلقائياً. راجع الأنواع والحقول الإضافية ثم اضغط «حساب النتائج»';
        prepareMeasurements(h.items);
        // مسودة الزبون السابق ما زالت محفوظة — نستبدلها بالحالة الجديدة فوراً
        try { scheduleDraftSave(); } catch (e) {}
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } catch(e) { console.error('applyPendingCuttingHandoffIfAny:', e); }
    }

    /* ⚠️ 9.8.1 — أسماء الأنواع تُربط بالتوازي لا بالتسلسل.

       نفس علّة صفحة القياسات: كان الربط داخل guardPage، أي **بعد** أن
       تكتمل قراءة مستند العضوية من Firestore. فرحلةُ شبكة كاملة تسبق
       بدء الاستماع، ثم رحلةٌ ثانية حتى تصل أول لقطة.

       وأثره هنا أوضح منه في الكراسة: هذه شاشة القصّاص. فالنوع الذي
       أضافه زميله قبل دقائق يصله بمعرّفه الخام — `xtype_1735…` — حتى
       تكتمل الرحلتان. فيقرأ رمزاً لا معنى له ولا يعرف أي شغل هو.

       وقراءة الأنواع لا تعتمد على الرتبة: القاعدة تشترط العضوية وحدها،
       وهي معروفة لحظةَ يعرف Firebase مَن أنت. */
    try {
      auth.onAuthStateChanged(function (u) {
        if (u && !typesUnsub) { try { attachTypeNamesSync(); } catch (e) {} }
      });
    } catch (e) {}

    // ===== حارس الدخول: يشغّل التطبيق فقط بعد تأكيد جلسة Firebase صالحة =====
    guardPage(function(shopUser) {
      document.getElementById('auth-gate').style.display = 'none';
      /* 9.5.0 — رابط الفواتير يُكشف للمدير وحده (مخفيّ في الوسم) */
      try {
        const _inv = document.getElementById('nav-invoices');
        const _mgr = (shopUser && shopUser.role === 'manager');
        window.WSCanManageSystems=!!_mgr;
        const materialEditor=document.getElementById('easy-materials-button');if(materialEditor)materialEditor.hidden=!_mgr;
        if (_inv) { if (_mgr) _inv.removeAttribute('hidden'); else _inv.setAttribute('hidden',''); }
      } catch (e) {}
      document.getElementById('app-nav').style.display = 'flex';
      // الاسم وحده فقط — بلا أي كلمة صفة بجانبه
      document.getElementById('nav-user-badge').textContent = shopUser.name;
      attachCuttingArchiveSync();
      attachJobsSync();          // كراسات الزبائن — قراءة مباشرة من قاعدة البيانات
      attachTypeNamesSync();     // أسماء الأنواع المشتركة — تظهر كما كتبها من أضافها
      migrateLocalCuttingArchiveToFirestore();
      initCuttingApp();
        }, 'cutting');

    // ===== كل معادلة أدناه مرتبطة مباشرة بالعرض (w) والارتفاع (h) اللذين تُدخلهما =====
    // ===== لا يوجد أي تخصيم متسلسل: تعديل رقم أي بند لا يغيّر أي بند آخر إطلاقاً =====
    const defaultFormulas = {
      window_double: [
        {label: "عرض الضلفة", calc: "(w - 7.4) / 2", editNum: "7.4"},
        {label: "ارتفاع الضلفة", calc: "h - 5.6", editNum: "5.6"},
        {label: "T", calc: "h - 8", editNum: "8"},
        {label: "عرض الباكيتة", calc: "(w - 31.8) / 2", editNum: "31.8"},
        {label: "ارتفاع الباكيتة", calc: "h - 17.8", editNum: "17.8"},
        {label: "عرض الزجاج", calc: "(w - 32.4) / 2", editNum: "32.4"},
        {label: "ارتفاع الزجاج", calc: "h - 18.1", editNum: "18.1"},
        {label: "مواد الإطار", calc: "(w + h) * 2 + 60", editNum: "60"},
        {label: "مواد الضلفة", calc: "(w / 2 + h - 9.3) * 4.03", editNum: "4.03"},
        {label: "مواد الباكيتة", calc: "2 * w + 4 * h - 134.8", editNum: "134.8"}
      ],
      window_single: [
        {label: "عرض الضلفة", calc: "w - 5.6", editNum: "5.6"},
        {label: "ارتفاع الضلفة", calc: "h - 5.6", editNum: "5.6"},
        {label: "عرض الباكيتة", calc: "w - 17.8", editNum: "17.8"},
        {label: "ارتفاع الباكيتة", calc: "h - 17.8", editNum: "17.8"},
        {label: "عرض الزجاج", calc: "w - 18.1", editNum: "18.1"},
        {label: "ارتفاع الزجاج", calc: "h - 18.1", editNum: "18.1"},
        {label: "مواد الإطار", calc: "(w + h) * 2 + 60", editNum: "60"},
        {label: "مواد الضلفة", calc: "(w + h - 11.2) * 2.02", editNum: "2.02"},
        {label: "مواد الباكيتة", calc: "2 * w + 2 * h - 71.2", editNum: "71.2"}
      ],
      window_double_top: [
        {label: "عرض الضلفة", calc: "manualLeafW", editNum: ""},
        {label: "عرض التابت", calc: "w - (manualLeafW * 2) - 11", editNum: "11"},
        {label: "ارتفاع الضلفة", calc: "h - 5.6", editNum: "5.6"},
        {label: "T", calc: "h - 8.1", editNum: "8.1"},
        {label: "عرض الباكيتة", calc: "manualLeafW - 12.2", editNum: "12.2"},
        {label: "ارتفاع الباكيتة", calc: "h - 17.8", editNum: "17.8"},
        {label: "عرض باكيتة التابت", calc: "w - (manualLeafW * 2) - 11", editNum: "11"},
        {label: "ارتفاع باكيتة التابت", calc: "h - 8.1", editNum: "8.1"},
        {label: "عرض الزجاج", calc: "manualLeafW - 12.5", editNum: "12.5"},
        {label: "ارتفاع الزجاج", calc: "h - 18.1", editNum: "18.1"},
        {label: "زجاج التابت (عرض)", calc: "w - (manualLeafW * 2) - 11.5", editNum: "11.5"},
        {label: "زجاج التابت (ارتفاع)", calc: "h - 8.8", editNum: "8.8"},
        {label: "مواد الإطار", calc: "(w + h) * 2 + 60", editNum: "60"},
        {label: "مواد الضلفة", calc: "(manualLeafW + (h - 5.6)) * 4", editNum: "4"},
        {label: "مواد الباكيتة", calc: "2 * w + 6 * h - 158.2", editNum: "158.2"}
      ],
      window_flipper: [
        {label: "عرض الضلفة", calc: "w - 5.6", editNum: "5.6"},
        {label: "ارتفاع الضلفة", calc: "flipH", editNum: ""},
        {label: "T", calc: "w - 7.9", editNum: "7.9"},
        {label: "عرض باكيتة الضلفة", calc: "w - 17.8", editNum: "17.8"},
        {label: "ارتفاع باكيتة الضلفة", calc: "flipH - 12.2", editNum: "12.2"},
        {label: "عرض باكيتة التابت", calc: "w - 7.9", editNum: "7.9"},
        {label: "ارتفاع باكيتة التابت", calc: "h - flipH - 9.5", editNum: "9.5"},
        {label: "عرض زجاج الضلفة", calc: "w - 18.1", editNum: "18.1"},
        {label: "ارتفاع زجاج الضلفة", calc: "flipH - 12.5", editNum: "12.5"},
        {label: "عرض زجاج التابت", calc: "w - 8.4", editNum: "8.4"},
        {label: "ارتفاع زجاج التابت", calc: "h - flipH - 10", editNum: "10"},
        {label: "مواد الإطار", calc: "(w + h) * 2 + 60", editNum: "60"},
        {label: "مواد الضلفة", calc: "((w - 5.6) + flipH) * 2", editNum: "2"},
        {label: "مواد الباكيتة", calc: "4 * w + 2 * h - 94.8", editNum: "94.8"}
      ],
      window_leaf_fixed: [
        {label: "عرض الضلفة", calc: "manualLeafW", editNum: ""},
        {label: "ارتفاع الضلفة", calc: "h - 5.6", editNum: "5.6"},
        {label: "T", calc: "h - 8.1", editNum: "8.1"},
        {label: "عرض الباكيتة", calc: "manualLeafW - 12.2", editNum: "12.2"},
        {label: "ارتفاع الباكيتة", calc: "h - 17.8", editNum: "17.8"},
        {label: "عرض باكيتة التابت", calc: "w - manualLeafW - 7.9", editNum: "7.9"},
        {label: "ارتفاع باكيتة التابت", calc: "h - 8.1", editNum: "8.1"},
        {label: "عرض الزجاج", calc: "manualLeafW - 12.5", editNum: "12.5"},
        {label: "ارتفاع الزجاج", calc: "h - 18.1", editNum: "18.1"},
        {label: "عرض زجاج التابت", calc: "w - manualLeafW - 8.4", editNum: "8.4"},
        {label: "ارتفاع زجاج التابت", calc: "h - 8.6", editNum: "8.6"},
        {label: "مواد الإطار", calc: "(w + h) * 2 + 60", editNum: "60"},
        {label: "مواد الضلفة", calc: "(manualLeafW + (h - 5.6)) * 2", editNum: "2"},
        {label: "مواد الباكيتة", calc: "2 * w + 4 * h - 92", editNum: "92"}
      ],
      aluminum_sliding_normal: [
        {label: "عرض الحلق", calc: "w - 0.3", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "h - 0.3", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "(w + 1) / 2", editNum: "1"},
        {label: "ارتفاع الضلفة", calc: "h - 6", editNum: "6"},
        {label: "عرض الزجاج", calc: "(w - 21) / 2", editNum: "21"},
        {label: "ارتفاع الزجاج", calc: "h - 17", editNum: "17"}
      ],
      aluminum_67: [
        {label: "قص الحلق", calc: "(w * 10 - 3) / 10", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "(h * 10 - 3) / 10", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "(w - 15) / 2", editNum: "15"},
        {label: "ارتفاع الضلفة", calc: "h - 6.7", editNum: "6.7"},
        {label: "عرض مخفض الباكيتة", calc: "(w / 2) - 10", editNum: "10"},
        {label: "ارتفاع مخفض الباكيتة", calc: "h - 16.4", editNum: "16.4"},
        {label: "عرض الزجاج", calc: "(w - 16) / 2", editNum: "16"},
        {label: "ارتفاع الزجاج", calc: "h - 14.7", editNum: "14.7"}
      ],
      door_single: [
        {label: "عرض ضلفة الباب", calc: "w - 5.7", editNum: "5.7"},
        {label: "ارتفاع ضلفة الباب", calc: "h - 2.1", editNum: "2.1"},
        {label: "عرض الباكيتة", calc: "w - 23.7", editNum: "23.7"},
        {label: "ارتفاع الباكيتة", calc: "h - 20.1", editNum: "20.1"},
        {label: "مسطح الباب (عرض)", calc: "w - 24.2", editNum: "24.2"},
        {label: "عدد مسطح الباب", calc: "Math.ceil((h - 19) / 10)", editNum: "19"},
        {label: "مواد الإطار", calc: "w + h*2 + 30", editNum: "30"},
        {label: "مواد الضلفة", calc: "2 * w + 2 * h - 15.6", editNum: "15.6"},
        {label: "مواد الباكيتة", calc: "4 * w + 2 * h - 135", editNum: "135"}
      ],
      door_double: [
        {label: "عرض الضلفة الكبيرة", calc: "largeW", editNum: ""},
        {label: "عرض الضلفة الصغيرة", calc: "w - 6 - largeW", editNum: "6"},
        {label: "ارتفاع الضلفة", calc: "h - 2.2", editNum: "2.2"},
        {label: "عرض باكيتة كبيرة", calc: "largeW - 18", editNum: "18"},
        {label: "عرض باكيتة صغيرة", calc: "w - largeW - 24", editNum: "24"},
        {label: "ارتفاع الباكيتة", calc: "h - 20.2", editNum: "20.2"},
        {label: "مواد الإطار", calc: "w + h*2 + 30", editNum: "30"},
        {label: "مواد الضلفة الكبيرة", calc: "2 * h + 2 * largeW - 4.4", editNum: "4.4"},
        {label: "مواد الضلفة الصغيرة", calc: "2 * w + 2 * h - 2 * largeW - 16.4", editNum: "16.4"},
        {label: "مواد الباكيتة", calc: "4 * w + 4 * h - 248.8", editNum: "248.8"}
      ],
      sliding_poly_one: [
        {label: "عرض الضلفة", calc: "w / 2", editNum: ""},
        {label: "ارتفاع الضلفة", calc: "h - 8.8", editNum: "8.8"},
        {label: "عرض الباكيتة", calc: "(w - 27) / 2", editNum: "27"},
        {label: "ارتفاع الباكيتة", calc: "h - 22.3", editNum: "22.3"},
        {label: "عرض الزجاج", calc: "(w - 28) / 2", editNum: "28"},
        {label: "ارتفاع الزجاج", calc: "h - 22.8", editNum: "22.8"},
        {label: "مواد الإطار", calc: "(w + h)*2 + 60", editNum: "60"},
        {label: "مواد الضلفة", calc: "(w / 2 + (h - 8.8)) * 4", editNum: "4"},
        {label: "مواد الباكيتة", calc: "2 * w + 4 * h - 143.2", editNum: "143.2"}
      ],
      sliding_poplist: [
        {label: "عرض الضلفة", calc: "(w - 0.5)/2", editNum: "0.5"},
        {label: "ارتفاع الضلفة", calc: "h - 7.6", editNum: "7.6"},
        {label: "عرض الباكيتة", calc: "(w - 25.7) / 2", editNum: "25.7"},
        {label: "ارتفاع الباكيتة", calc: "h - 20.2", editNum: "20.2"},
        {label: "عرض الزجاج", calc: "(w - 26.5) / 2", editNum: "26.5"},
        {label: "ارتفاع الزجاج", calc: "h - 20.6", editNum: "20.6"},
        {label: "مواد الإطار", calc: "(w + h)*2 + 60", editNum: "60"},
        {label: "مواد الضلفة", calc: "(w / 2 + h - 7.85) * 4", editNum: "4"},
        {label: "مواد الباكيتة", calc: "2 * w + 4 * h - 132.2", editNum: "132.2"}
      ],
      sranti_external_large: [
        {label: "عرض الصندوق", calc: "w - 1.4", editNum: "1.4"},
        {label: "ارتفاع السكة", calc: "h - 17", editNum: "17"},
        {label: "تشفير السكة", calc: "h - 21", editNum: "21"},
        {label: "عرض الحصيرة", calc: "w - 8", editNum: "8"},
        {label: "عدد شرايح الحصيرة", calc: "Math.ceil((h - 10) / 5.5)", editNum: "10"},
        {label: "مواد خام الحصيرة", calc: "((w - 8) * Math.ceil((h - 10) / 5.5)) / 550", editNum: "550"},
        {label: "الطوبو", calc: "w - 10", editNum: "10"}
      ],
      sranti_external_small: [
        {label: "عرض الصندوق", calc: "w - 1.4", editNum: "1.4"},
        {label: "ارتفاع السكة", calc: "h - 13", editNum: "13"},
        {label: "تشفير السكة", calc: "h - 17", editNum: "17"},
        {label: "عرض الحصيرة", calc: "w - 8", editNum: "8"},
        {label: "عدد شرايح الحصيرة", calc: "Math.ceil((h - 10) / 5.5)", editNum: "10"},
        {label: "مواد خام الحصيرة", calc: "((w - 8) * Math.ceil((h - 10) / 5.5)) / 550", editNum: "550"},
        {label: "الطوبو", calc: "w - 10", editNum: "10"}
      ],
      sranti_normal: [
        {label: "عرض الحصيرة", calc: "w - 1", editNum: "1"},
        {label: "عدد شرايح الحصيرة", calc: "Math.ceil(h / 5.5)", editNum: "5.5"},
        {label: "المواد الخام", calc: "((w - 1) * Math.ceil(h / 5.5)) / 560", editNum: "560"}
      ],
      aluminum_door: [
        {label: "قص الحلق", calc: "(w * 10 - 3) / 10", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "(h * 10 - 3) / 10", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "w - 4.6", editNum: "4.6"},
        {label: "ارتفاع الباب", calc: "h - 3", editNum: "3"}
      ],
      aluminum_door_double: [
        {label: "قص الحلق", calc: "w - 0.3", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "h - 0.3", editNum: "0.3"},
        {label: "عرض الضلفة الكبيرة", calc: "manualLeafW", editNum: ""},
        {label: "عرض الضلفة الصغيرة", calc: "w - 5.5 - manualLeafW", editNum: "5.5"},
        {label: "ارتفاع الضلفة", calc: "h - 3", editNum: "3"}
      ],
      aluminum_window_double: [
        {label: "قص الحلق", calc: "(w * 10 - 3) / 10", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "(h * 10 - 3) / 10", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "(w - 7.7) / 2", editNum: "7.7"},
        {label: "ارتفاع الضلفة", calc: "h - 3.8", editNum: "3.8"},
        {label: "عرض الزجاج", calc: "((w - 7.7) / 2) - 10.4", editNum: "10.4"},
        {label: "ارتفاع الزجاج", calc: "(h - 3.8) - 10.4", editNum: "10.4"}
      ],
      aluminum_window_single: [
        {label: "قص الحلق", calc: "(w * 10 - 3) / 10", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "(h * 10 - 3) / 10", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "w - 4.4", editNum: "4.4"},
        {label: "ارتفاع الضلفة", calc: "h - 3.8", editNum: "3.8"},
        {label: "عرض الزجاج", calc: "(w - 4.4) - 10.4", editNum: "10.4"},
        {label: "ارتفاع الزجاج", calc: "(h - 3.8) - 10.4", editNum: "10.4"}
      ],
      aluminum_window_flipper: [
        {label: "قص الحلق", calc: "(w * 10 - 3) / 10", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "(h * 10 - 3) / 10", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "w - 3.8", editNum: "3.8"},
        {label: "ارتفاع الضلفة", calc: "h - 4.4", editNum: "4.4"},
        {label: "عرض الزجاج", calc: "(w - 3.8) - 10.4", editNum: "10.4"},
        {label: "ارتفاع الزجاج", calc: "(h - 4.4) - 10.4", editNum: "10.4"}
      ],
      aluminum_window_leaf_fixed: [
        {label: "قص الحلق", calc: "(w * 10 - 3) / 10", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "(h * 10 - 3) / 10", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "manualLeafW", editNum: ""},
        {label: "ارتفاع الضلفة", calc: "h - 3.8", editNum: "3.8"},
        {label: "عرض الثابت", calc: "w - manualLeafW - 8.8", editNum: "8.8"},
        {label: "ارتفاع الثابت", calc: "h - 5.8", editNum: "5.8"},
        {label: "زجاج الضلفة (عرض)", calc: "manualLeafW - 10.4", editNum: "10.4"},
        {label: "زجاج الضلفة (ارتفاع)", calc: "(h - 3.8) - 10.4", editNum: "10.4"},
        {label: "عرض زجاج الثابت", calc: "(w - manualLeafW - 8.8) - 0.8", editNum: "0.8"},
        {label: "ارتفاع زجاج الثابت", calc: "h - 0.8", editNum: "0.8"}
      ],
      aluminum_window_flipper_fixed: [
        // معكوسة فعلياً: بدّلنا w/h في كل معادلة مقابلة للأصلية.
        // الحلق يبقى محسوباً من مقاس فتحة الإدخال؛ بقية النتائج تتبادل العرض والارتفاع.
        {label: "قص الحلق", calc: "(w * 10 - 3) / 10", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "(h * 10 - 3) / 10", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "w - 3.8", editNum: "3.8"},
        {label: "ارتفاع الضلفة", calc: "manualLeafW", editNum: ""},
        {label: "عرض الثابت", calc: "w - 5.8", editNum: "5.8"},
        {label: "ارتفاع الثابت", calc: "h - manualLeafW - 8.8", editNum: "8.8"},
        {label: "عرض زجاج الضلفة", calc: "(w - 3.8) - 10.4", editNum: "10.4"},
        {label: "ارتفاع زجاج الضلفة", calc: "manualLeafW - 10.4", editNum: "10.4"},
        {label: "عرض زجاج الثابت", calc: "h - manualLeafW - 8.8 - 0.8", editNum: "0.8"},
        {label: "ارتفاع زجاج الثابت", calc: "w - 0.8", editNum: "0.8"}
      ],
      aluminum_sliding_67: [
        {label: "قص الحلق", calc: "(w * 10 - 3) / 10", editNum: "0.3"},
        {label: "ارتفاع الحلق", calc: "(h * 10 - 3) / 10", editNum: "0.3"},
        {label: "عرض الضلفة", calc: "(w - 15) / 2", editNum: "15"},
        {label: "ارتفاع الضلفة", calc: "h - 6.7", editNum: "6.7"},
        {label: "عرض مخفض الباكيتة", calc: "(w / 2) - 10", editNum: "10"},
        {label: "ارتفاع مخفض الباكيتة", calc: "h - 16.4", editNum: "16.4"},
        {label: "عرض الزجاج", calc: "(w - 16) / 2", editNum: "16"},
        {label: "ارتفاع الزجاج", calc: "h - 14.7", editNum: "14.7"}
      ]
    };

    const typeNames = {
      'window_double': 'نافذة ضلفتين',
      'window_single': 'نافذة ضلفة واحدة',
      'window_double_top': 'نافذة ضلفتين مع تابت',
      'window_flipper': 'نافذة قلاب وتابت',
      'window_leaf_fixed': 'نافذة ضلفة وتابت',
      'aluminum_sliding_normal': 'نافذة المونيوم سحاب عادي',
      'aluminum_67': 'نافذة المونيوم سحاب ضلفتين نظام 67',
      'aluminum_door': 'باب المونيوم',
      'aluminum_door_double': 'باب المونيوم ضلفتين',
      'aluminum_window_double': 'نافذة المونيوم ضلفتين',
      'aluminum_window_single': 'نافذة المونيوم ضلفة واحدة',
      'aluminum_window_flipper': 'نافذة المونيوم قلاب',
      'aluminum_window_leaf_fixed': 'نافذة المونيوم ضلفة وثابت',
      'aluminum_window_flipper_fixed': 'نافذة المونيوم قلاب وثابت (معكوسة)',
      'aluminum_sliding_67': 'نافذة المونيوم سحاب ضلفتين نظام 67',
      'door_single': 'باب ضلفة واحدة',
      'door_double': 'باب ضلفتين',
      'sliding_poly_one': 'سحاب بولي ون',
      'sliding_poplist': 'سحاب بوبلست',
      'sranti_external_large': 'سرانتي خارجي كبير',
      'sranti_external_small': 'سرانتي خارجي صغير',
      'sranti_normal': 'سرانتي عادي'
    };

    // أسماء واضحة ومصنفة: PVC أولاً، ثم السرانتي، ثم الألمنيوم.
    function operationDisplayName(type) {
      const name = typeNames[type] || customTypeRegistry[type] || type || 'عملية قص';
      if (String(type).startsWith('sranti_')) return '🪟 ' + name;
      if (String(type).startsWith('aluminum_') || type === 'aluminum_67') return '🔩 ' + name;
      const icon = getTypeIcon(type) || '⚙️';
      return '🟦 PVC · ' + icon + ' ' + name;
    }

    /* ============================================================
       الإطار (الشمبرلي): زيادة ثابتة على العرض والارتفاع.
       تظهر أول نتيجة في كل الأنواع عدا السرانتي والمونيوم 67.
       القيمة قابلة للتعديل من لوحة الأنظمة والبروفيلات.
       ============================================================ */
    const SHAMBERLY_DEFAULT = 0.3;

    function getShamberlyOffset() {
      const v = wsNum(localStorage.getItem('shamberly_offset'), NaN);
      return isNaN(v) ? SHAMBERLY_DEFAULT : v;
    }

    function setShamberlyOffset(v) {
      const n = wsNum(v, NaN);   // إصلاح 8.8: يقبل الأرقام العربية
      if (isNaN(n) || n < 0) { showToast('أدخل رقماً صحيحاً موجباً', 'error'); return; }
      try { localStorage.setItem('shamberly_offset', String(n)); } catch (e) { console.error('تعذّر حفظ الشمبرلي:', e); }
      showToast('تم حفظ زيادة الإطار (الشمبرلي): ' + n, 'success');
      const ex = document.getElementById('shamberly-example');
      if (ex) ex.textContent = `مثال: 100 × 90 ← ${trimNum(100 + n)} × ${trimNum(90 + n)}`;
    }

    // الأنواع المستثناة: السرانتي بكل أشكاله والمونيوم 67
    function hasShamberly(type) {
      if(window.WSSymbolFormulas?.find(type))return false;
      if (!type) return false;
      if (String(type).indexOf('aluminum_') === 0) return false;
      if (String(type).indexOf('sranti') === 0) return false;
      return true;
    }

    // يحذف الأصفار الزائدة: 100.30 ← 100.3 و 100.00 ← 100
    function trimNum(n) {
      return String(Math.round(n * 100) / 100);
    }

    let appProfiles = {
      "الافتراضي": JSON.parse(JSON.stringify(defaultFormulas))
    };
    let currentProfileName = "الافتراضي";

    // ===== سجلّ أنواع العمليات المخصّصة كليّاً (يُضاف إليه عبر «إضافة معادلة جديدة») =====
    let customTypeRegistry = {}; // { typeKey: 'الاسم المعروض' }

    function loadCustomTypesRegistry() {
      try {
        const stored = JSON.parse(localStorage.getItem('app_custom_types') || '{}');
        customTypeRegistry = stored;
        Object.entries(customTypeRegistry).forEach(([key, name]) => { typeNames[key] = name; });
      } catch(e) { customTypeRegistry = {}; }
    }
    function saveCustomTypesRegistry() {
      // إصلاح 8.8: امتلاء حصة التخزين كان يرمي ويوقف الدالة المستدعية
      try { localStorage.setItem('app_custom_types', JSON.stringify(customTypeRegistry)); }
      catch (e) { console.error('تعذّر حفظ الأنواع المخصّصة محلياً:', e); }
    }

    // ===== تقييم متسلسل عام (يُستخدم فقط أثناء الترحيل، ليقرأ أي صيغة قديمة كما كانت تُحسب) =====
    function evaluateRowsAt(rows, extraVars) {
      const vars = Object.assign({}, extraVars);
      const values = {};
      (rows || []).forEach((item, idx) => {
        let value;
        try {
          /* ⚠️ إصلاح 8.8: هذا المسار كان ينفّذ الصيغة **بلا أي تحقق**.
             وهو المسار الذي يقرأ من app_custom_profiles في localStorage
             عند كل إقلاع — أي أن نصاً مدسوساً في التخزين المحلي كان
             يُنفَّذ تلقائياً عند فتح الصفحة، بينما مسار الحساب العادي
             محميّ بـ isSafeFormula. الحماية الآن على المسارين. */
          if (!isSafeFormula(item.calc)) { value = null; }
          else {
            const keys = Object.keys(vars);
            const vals = Object.values(vars);
            value = new Function(...keys, `"use strict"; return (${item.calc});`)(...vals);
            if (typeof value !== 'number' || !isFinite(value)) value = null;
          }
        } catch(e) { value = null; }
        if (item.saveAs && value !== null) vars[item.saveAs] = value;
        values[idx] = value;
      });
      return values;
    }

    // ===== يحوّل بنداً واحداً مخزّناً (قديم التسلسل أو مُخصَّص سابقاً) إلى الصيغة المباشرة الجديدة،
    // مع الحفاظ حسابياً على نفس النتيجة التي كان يعطيها — عبر حل عكسي لرقم واحد مجهول =====
    function migrateRowToDirectFormula(storedRow, newDefaultRow, rowIndex, probedValues, probeVars) {
      if (!newDefaultRow.editNum) {
        return { label: newDefaultRow.label, calc: newDefaultRow.calc, editNum: newDefaultRow.editNum };
      }
      if (!storedRow || storedRow.calc === newDefaultRow.calc) {
        return { label: newDefaultRow.label, calc: newDefaultRow.calc, editNum: newDefaultRow.editNum };
      }
      const probedValue = probedValues[rowIndex];
      if (probedValue === null || probedValue === undefined) {
        return { label: newDefaultRow.label, calc: newDefaultRow.calc, editNum: newDefaultRow.editNum };
      }
      const template = newDefaultRow.calc;
      const oldNum = newDefaultRow.editNum;
      const regex = new RegExp('\\b' + oldNum.replace('.', '\\.') + '\\b', 'g');
      const calcWithX = (xVal) => {
        const testCalc = template.replace(regex, '(' + xVal + ')');
        // إصلاح 8.8: نفس الحماية — لا تنفيذ لصيغة لم تجتَز الفحص
        if (!isSafeFormula(testCalc)) throw new Error('صيغة غير آمنة أثناء الترحيل');
        const keys = Object.keys(probeVars);
        const vals = Object.values(probeVars);
        return new Function(...keys, `"use strict"; return (${testCalc});`)(...vals);
      };
      try {
        const v0 = calcWithX(0);
        const v1 = calcWithX(1);
        const slope = v1 - v0;
        if (!isFinite(slope) || Math.abs(slope) < 1e-9) {
          return { label: newDefaultRow.label, calc: newDefaultRow.calc, editNum: newDefaultRow.editNum };
        }
        let X = Math.round(((probedValue - v0) / slope) * 1000) / 1000;
        const xStr = String(X);
        return { label: newDefaultRow.label, calc: template.replace(regex, xStr), editNum: xStr };
      } catch(e) {
        return { label: newDefaultRow.label, calc: newDefaultRow.calc, editNum: newDefaultRow.editNum };
      }
    }

    // بعض بنود "مواد الضلفة" تعرض معامل ضرب (وليس رقم طرح) كخانة قابلة للتعديل.
    // إن كان تخصيم عرض/ارتفاع الضلفة (الأعلى منها) قد خُصِّص سابقاً، يُعاد بناء الجزء
    // الداخلي من معادلة المواد باستخدام القيم المُرحَّلة فعلياً بدل الافتراضي المجمّد،
    // لضمان صحة الترحيل مهما كانت التركيبة السابقة.
    const materialLeafRecipe = {
      window_double: { leafWIdx: 0, leafHIdx: 1, matIdx: 8 },
      window_single: { leafWIdx: 0, leafHIdx: 1, matIdx: 7 },
      window_double_top: { leafWIdx: 0, leafHIdx: 2, matIdx: 13 },
      window_flipper: { leafWIdx: 0, leafHIdx: 1, matIdx: 12 },
      window_leaf_fixed: { leafWIdx: 0, leafHIdx: 1, matIdx: 12 },
      sliding_poly_one: { leafWIdx: 0, leafHIdx: 1, matIdx: 7 },
      sliding_poplist: { leafWIdx: 0, leafHIdx: 1, matIdx: 7 }
    };

    function migrateProfileTypeToDirectFormulas(storedRows, newDefaultRows, extraVarsForProbe, typeKey) {
      const probeVars = Object.assign({ w: 200, h: 200 }, extraVarsForProbe);
      const probedValues = evaluateRowsAt(storedRows, probeVars);
      const migratedRows = newDefaultRows.map((newRow, idx) => migrateRowToDirectFormula(storedRows[idx], newRow, idx, probedValues, probeVars));

      const recipe = materialLeafRecipe[typeKey];
      if (recipe && storedRows[recipe.matIdx] && newDefaultRows[recipe.matIdx]) {
        const matNewDefault = newDefaultRows[recipe.matIdx];
        const matStored = storedRows[recipe.matIdx];
        const leafWChanged = migratedRows[recipe.leafWIdx].calc !== newDefaultRows[recipe.leafWIdx].calc;
        const leafHChanged = migratedRows[recipe.leafHIdx].calc !== newDefaultRows[recipe.leafHIdx].calc;
        if (matStored.calc !== matNewDefault.calc && matNewDefault.editNum && (leafWChanged || leafHChanged)) {
          const leafWCalc = migratedRows[recipe.leafWIdx].calc;
          const leafHCalc = migratedRows[recipe.leafHIdx].calc;
          const correctedTemplate = `((${leafWCalc}) + (${leafHCalc})) * ${matNewDefault.editNum}`;
          const correctedDefaultRow = { label: matNewDefault.label, calc: correctedTemplate, editNum: matNewDefault.editNum };
          migratedRows[recipe.matIdx] = migrateRowToDirectFormula(matStored, correctedDefaultRow, recipe.matIdx, probedValues, probeVars);
        }
      }
      return migratedRows;
    }

    // تحميل الأنظمة المحفوظة، مع ترحيل تلقائي لأي أنواع جديدة أو معادلات قديمة الطراز
    // (تخصيم متسلسل) إلى الصيغة المباشرة — مع الحفاظ على أي تخصيص رقمي أجراه المستخدم سابقاً
    function initProfiles() {
      const stored = localStorage.getItem('app_custom_profiles');
      if (stored) {
        try {
          appProfiles = JSON.parse(stored);
        } catch(e) {
          console.error("فشل تحميل الأنظمة المخصصة");
        }
      }
      let directProfiles={};try{directProfiles=JSON.parse(localStorage.getItem('ws_profile_direct_v1')||'{}')||{};}catch(e){}
      let migrated = false;
      const probeExtraByType = {
        window_double_top: { manualLeafW: 80 },
        window_flipper: { flipH: 80 },
        door_double: { largeW: 80 },
        window_leaf_fixed: { manualLeafW: 80 }
      };
      Object.keys(appProfiles).forEach(pName => {
        if(directProfiles[pName])return;
        Object.keys(defaultFormulas).forEach(typeKey => {
          const newRows = defaultFormulas[typeKey];
          if (!appProfiles[pName][typeKey]) {
            appProfiles[pName][typeKey] = JSON.parse(JSON.stringify(newRows));
            migrated = true;
            return;
          }
          const storedRows = appProfiles[pName][typeKey];
          const needsMigration = newRows.some((r, i) => !storedRows[i] || storedRows[i].calc !== r.calc);
          if (needsMigration) {
            appProfiles[pName][typeKey] = migrateProfileTypeToDirectFormulas(storedRows, newRows, probeExtraByType[typeKey] || {}, typeKey);
            migrated = true;
          }
        });
      });
      if (migrated) {
        try { localStorage.setItem('app_custom_profiles', JSON.stringify(appProfiles)); } catch (e) { console.error('تعذّر حفظ الأنظمة محلياً:', e); }
      }
      loadCustomTypesRegistry();
      window.WSSymbolFormulas?.install(appProfiles,customTypeRegistry,typeNames);
    }

    /* ===== دقة حسابية بدون أخطاء الفاصلة العائمة =====
       الطريقة السابقة كانت تبني نصاً بصيغة أُسّية (num + 'e' + decimals).
       وهذا ينهار متى جاء الرقم نفسه بصيغة أُسّية: 1e-7 يصير النص "1e-7e2"
       وهو ليس رقماً، فتُعيد الدالة NaN بدل صفر — ويظهر «NaN» في نتائج
       القص أمام المستخدم. يحدث ذلك مع أي ناتج أصغر من 0.0000001، مثل
       قسمة فرق ضئيل بين مقاسين على 550. */
    function preciseRound(num, decimals = 2) {
      if (typeof num !== 'number' || !isFinite(num)) return num;
      // أرقام بهذه الضخامة لا كسور فيها أصلاً، والإزاحة التصحيحية تُفسدها
      if (Math.abs(num) >= 1e15) return num;
      const f = Math.pow(10, decimals);
      // إزاحة صغيرة تُصحّح حالات مثل 1.005 و2.675 التي يخزّنها الحاسوب أقل بقليل
      const eps = num >= 0 ? Number.EPSILON * Math.abs(num) : -Number.EPSILON * Math.abs(num);
      const rounded = Math.round((num + eps) * f) / f;
      if (!isFinite(rounded)) return num;   // أرقام ضخمة جداً تُترك كما هي
      return Object.is(rounded, -0) ? 0 : rounded;
    }

    // ===== تنبيهات لطيفة بدل نوافذ alert المزعجة =====
    function showToast(message, type = 'info') {
      const container = document.getElementById('toast-container');
      if (!container) { return; }
      const toast = document.createElement('div');
      toast.className = 'toast toast-' + type;
      toast.textContent = message;
      container.appendChild(toast);
      requestAnimationFrame(() => toast.classList.add('toast-show'));
      setTimeout(() => {
        toast.classList.remove('toast-show');
        setTimeout(() => toast.remove(), 350);
      }, 2700);
    }

    // ===== تجميع الحالة الحالية الظاهرة على الشاشة (القياسات والنتائج) =====
    function collectCurrentState() {
      const customerName = document.getElementById('cut-customer')?.value.trim() || '';
      const bulkInput = document.getElementById('bulk-input')?.value || '';
      const measurements = [];
      document.querySelectorAll('.measurement-item').forEach(item => {
        const w = item.querySelector('.width-input')?.value || '';
        const h = item.querySelector('.height-input')?.value || '';
        const type = item.querySelector('.type-select')?.value || '';
        const profile = item.querySelector('.profile-select')?.value || '';
        let manualValue = '';
        if (type === 'window_double_top') {
          manualValue = item.querySelector('.manual-leaf-width')?.value || '';
        } else if (type === 'window_flipper') {
          manualValue = item.querySelector('.manual-flipper-height')?.value || '';
        } else if (['door_double','aluminum_door_double'].includes(type)) {
          manualValue = item.querySelector('.equal-door-leaves')?.checked ? '__equal__' : (item.querySelector('.manual-large-leaf')?.value || '');
        } else if (['window_leaf_fixed','aluminum_window_leaf_fixed','aluminum_window_flipper_fixed'].includes(type)) {
          manualValue = item.querySelector('.manual-leaf-fixed-width')?.value || '';
        }
        const message = item.querySelector('.message-input')?.value || '';
        measurements.push({ w, h, type, profile, manualValue, message, formulaSnapshot:item.wsFormulaSnapshot||null,openingLayout:item.wsOpeningLayout||null,accessoryExceptions:item.wsAccessoryExceptions||{}, ...window.WSOpeningSymbols.metadata(item.wsOpening) });
      });
      const resultsHTML = document.getElementById('results')?.innerHTML || '';
      return { customerName, bulkInput, measurements, resultsHTML, cutContact, cutSketches };
    }

    function rebuildMeasurementsFromState(measurements, state = {}) {
      const container = document.getElementById('measurements-container');
      container.innerHTML = '';
      (measurements || []).forEach((item, idx) => {
        const div = document.createElement('div');
        div.className = 'measurement-item';
        div.wsOpening=window.WSOpeningSymbols.metadata(item);
        div.wsFormulaSnapshot=item.formulaSnapshot||null;div.wsOpeningLayout=item.openingLayout||null;div.wsAccessoryExceptions=item.accessoryExceptions||{};
        div.innerHTML = createMeasurementHTML(idx + 1, item.w, item.h, item.type, item.manualValue, item.message, item.profile, div.wsOpening);
        container.appendChild(div);
        const select = div.querySelector('.type-select');
        if (select) toggleExtraInputs(select);
      });
      const custEl = document.getElementById('cut-customer');
      if (custEl) custEl.value = state.customerName || '';
      // بيانات الزبون والرسوم جزء من الجلسة، وإلا ضاعت بإعادة فتح الصفحة
      cutContact = state.cutContact || { phone: '', loc: null };
      cutSketches = Array.isArray(state.cutSketches) ? state.cutSketches : [];
      try { renderCutContact(); } catch (e) {}
      refreshApplyAllBar();   // الشريط يظهر أيضاً بعد استعادة مسودة أو فتح عملية من الأرشيف
    }

    // ===== حفظ تلقائي مستمر للمسودة الحالية (تبقى موجودة حتى عند الخروج الخاطئ) =====
    let draftSaveTimer = null;
    function scheduleDraftSave() {
      clearTimeout(draftSaveTimer);
      draftSaveTimer = setTimeout(saveDraft, 500);
    }

    function saveDraft() {
      const state = collectCurrentState();
      // الاسم وحده ليس عملاً: مسودة فيها اسم بلا أي مقاس تُحذف كالفارغة
      if (!state.bulkInput.trim() && state.measurements.length === 0 && !state.resultsHTML) {
        localStorage.removeItem('app_current_draft');
        return;
      }
      state.savedAt = new Date().toISOString();
      try {
        state.savedAt = Date.now();   // لنعرف عمر المسودة عند الفتح التالي
        localStorage.setItem('app_current_draft', JSON.stringify(state));
      } catch(e) { /* التخزين ممتلئ، نتجاهل بصمت دون تعطيل التطبيق */ }
    }

    /* ══ متى تُستعاد جلسة القص؟ ══
       كانت تُستعاد دائماً، فيفتح القصّاص الصفحة صباحاً فيجد مقاسات
       زبون الأمس في مربع الإدخال وأمثلته المحسوبة أسفلها. فيضيف عليها
       أو يقصّ منها ظنّاً أنها شغله — **عمل فوق عمل آخر**.

       والحاجة الحقيقية للاستعادة ضيّقة: إغلاق بالخطأ أو انقطاع كهرباء
       أثناء العمل. فنقيّدها بها: أقل من عشر دقائق تُستعاد، وأكثر تُؤرشف
       وتُترك الصفحة نظيفة — نفس قاعدة كراسة القياسات، فلا يتعلّم
       المستخدم نظامين لنفس الفكرة. */
    const CUT_DRAFT_TTL = 10 * 60 * 1000;

    function restoreDraft() {
      let raw = localStorage.getItem('app_current_draft');

      if (raw) {
        try {
          const peek = JSON.parse(raw);
          const age = peek.savedAt ? (Date.now() - peek.savedAt) : Infinity;
          const hasWork = (peek.bulkInput || '').trim() ||
                          (Array.isArray(peek.measurements) && peek.measurements.length);
          if (hasWork && age >= CUT_DRAFT_TTL) {
            /* جلسة قديمة: تُحفظ في الأرشيف — لا تُمحى — ثم تبدأ الصفحة
               نظيفة. فلا يضيع عمل ولا يُبنى فوقه. */
            try { archiveCurrentFromState(peek); } catch (e) { console.error('أرشفة الجلسة القديمة:', e); }
            localStorage.removeItem('app_current_draft');
            showToast('حُفظت جلسة القص السابقة في الأرشيف — الصفحة جاهزة لعمل جديد', 'success');
            return;
          }
        } catch (e) { /* مسودة تالفة: نُكمل بالمسار المعتاد */ }
      }

      if (!raw) {
        // ترحيل بيانات "حفظ/تحميل" القديمة (إن وُجدت) حتى لا يفقد المستخدم عمله السابق
        const legacy = localStorage.getItem('savedMeasurements_v2');
        if (legacy) {
          try {
            raw = JSON.stringify({ bulkInput: '', measurements: JSON.parse(legacy), resultsHTML: '' });
          } catch(e) {}
        }
      }
      if (!raw) return;
      try {
        const state = JSON.parse(raw);
        document.getElementById('bulk-input').value = state.bulkInput || '';
        rebuildMeasurementsFromState(state.measurements, state);
        window._lastCutResults=null;
        if (state.resultsHTML) document.getElementById('results').innerHTML = sanitizeResultsHTML(state.resultsHTML);   // تنقية 8.8.5
      } catch(e) {
        console.error('تعذرت استعادة العمل السابق', e);
      }
    }

    function attachDraftAutoSave() {
      const container = document.getElementById('measurements-container');
      container.addEventListener('input', scheduleDraftSave);
      container.addEventListener('change', scheduleDraftSave);
      const bulk = document.getElementById('bulk-input');
      if (bulk) bulk.addEventListener('input', scheduleDraftSave);
      window.addEventListener('beforeunload', saveDraft);
    }

    /* ════════════════════════════════════════════════════════════
       كراسات الزبائن — قراءة مباشرة من قاعدة البيانات
       ------------------------------------------------------------
       نفس مجموعة measurementJobs التي تكتبها كراسة القياسات. الغرض أن
       يبدأ القصّاص عمله من هنا بلا فتح الكراسة إطلاقاً.

       ما يُستورَد: المقاسات وأنواعها وملاحظاتها واسم الزبون.
       ما لا يُستورَد: البنود المالية وحسابات الأمتار — هذه شاشة قص لا
       شاشة محاسبة، ومن يقصّ يحتاج أرقاماً وأنواعاً لا أسعاراً. وإخفاؤها
       يمنع كذلك وصول أسعار الزبائن إلى من لا شأن له بها.

       القراءة من قاعدة البيانات مباشرةً — لا عبر الكراسة — فتصلح هذه
       الشاشة أن تُفصَل تطبيقاً مستقلاً لاحقاً بلا تغيير في منطقها.
       ════════════════════════════════════════════════════════════ */
    /* ترتيب القوائم — يُحفظ محلياً فيبقى بين الجلسات */
    let jobsSort = (localStorage.getItem('cut_jobs_sort') === 'date') ? 'date' : 'name';
    function setJobsSort(m) {
      jobsSort = (m === 'date') ? 'date' : 'name';
      try { localStorage.setItem('cut_jobs_sort', jobsSort); } catch (e) {}
      renderJobsArchive();
    }

    let arcSort = (localStorage.getItem('cut_arc_sort') === 'date') ? 'date' : 'name';
    function setArcSort(m) {
      arcSort = (m === 'date') ? 'date' : 'name';
      try { localStorage.setItem('cut_arc_sort', arcSort); } catch (e) {}
      renderArchiveList();
    }

    let jobsSheets = [];
    let jobsUnsub = null;
    let jobsCursor = null;
    let jobsHasMore = true;
    let jobsLoading = false;
    let jobsSearchSeq = 0;
    let jobsSearchTimer = null;
    const CUT_JOBS_PAGE_SIZE = 100;
    const CUT_JOBS_SEARCH_PAGE_SIZE = 100;

    function mapCuttingJobDoc(d) {
      const v = d.data || {}, st = v.state || {};
      return { id:d.id, label:v.label||'بدون اسم', customer:(st.custName||'').trim(), phone:(st.custPhone||'').trim(), loc:st.custLocation||null,
        items:Array.isArray(st.jobList)?st.jobList:[], updatedAt:v.updatedAt||v.createdAt||0, approved:v.approved===true,
        approvedInvId:v.approvedInvId||'', workStarted:v.workStarted===true, workDone:v.workDone===true, deleted:v.deleted===true };
    }

    async function searchCuttingJobsServer(term) {
      const q = String(term || '').trim();
      const seq = ++jobsSearchSeq;
      if (jobsSearchTimer) clearTimeout(jobsSearchTimer);
      if (q.length < 2 || typeof FirestorePager?.fetchPrefix !== 'function') { renderJobsArchive(true); return; }
      jobsSearchTimer = setTimeout(async () => {
        try {
          const [byName, byPhone, byLabel] = await Promise.all([
            FirestorePager.fetchPrefix(db, 'measurementJobs', 'state.custName', q, { pageSize: CUT_JOBS_SEARCH_PAGE_SIZE }),
            FirestorePager.fetchPrefixVariants(db, 'measurementJobs', 'state.custPhone', q, { pageSize: CUT_JOBS_SEARCH_PAGE_SIZE }),
            FirestorePager.fetchPrefix(db, 'measurementJobs', 'label', q, { pageSize: CUT_JOBS_SEARCH_PAGE_SIZE })
          ]);
          if (seq !== jobsSearchSeq) return;
          const byId = new Map(jobsSheets.map(x => [x.id, x]));
          [...byName.docs, ...byPhone.docs, ...byLabel.docs].map(mapCuttingJobDoc).forEach(x => {
            if (!x.deleted && x.items.length && !byId.has(x.id)) { byId.set(x.id, x); jobsSheets.push(x); }
          });
        } catch (e) { if (seq === jobsSearchSeq) console.warn('البحث الموجّه في كراسات القص:', e && e.code || e); }
        if (seq === jobsSearchSeq) renderJobsArchive(true);
      }, 220);
    }

    function renderJobsPager() {
      const list = document.getElementById('jobs-list');
      if (!list) return;
      let box = document.getElementById('cut-jobs-pager');
      if (!box) {
        box = document.createElement('div');
        box.id = 'cut-jobs-pager';
        box.style.cssText = 'text-align:center;padding:10px;';
        list.parentNode.insertBefore(box, list.nextSibling);
      }
      if (jobsLoading) box.innerHTML = '<div style="color:#717375;font-size:12px;font-weight:700;">⏳ جاري تحميل المزيد...</div>';
      else if (jobsHasMore) box.innerHTML = '<button type="button" onclick="loadMoreCuttingJobs()" style="width:100%;padding:10px;border:1px solid #d4e2ef;border-radius:12px;background:#f6faff;color:#315f8c;font-family:inherit;font-weight:800;">⬇️ تحميل المزيد من الكراسات</button>';
      else box.innerHTML = jobsSheets.length ? '<div style="color:#85878a;font-size:11px;">تم تحميل كل الكراسات</div>' : '';
    }

    async function loadMoreCuttingJobs(reset) {
      if (jobsLoading) return;
      if (reset) { jobsCursor = null; jobsHasMore = true; jobsSheets = []; }
      if (!jobsHasMore) return;
      jobsLoading = true; renderJobsPager();
      try {
        const page = await FirestorePager.fetchPage(db, 'measurementJobs', { pageSize: CUT_JOBS_PAGE_SIZE, cursor: jobsCursor });
        const rows = page.docs.map(mapCuttingJobDoc).filter(x => !x.deleted && x.items.length);
        jobsSheets.push(...rows);
        jobsCursor = page.lastDoc; jobsHasMore = page.hasMore;
        if (document.getElementById('jobs-overlay')?.classList.contains('open')) renderJobsArchive();
      } catch(e) { console.warn('قراءة كراسات القص:', e && e.code || e); }
      finally { jobsLoading = false; renderJobsPager(); }
    }

    function attachJobsSync() {
      if (jobsUnsub) return;
      jobsUnsub = { paged: true };
      loadMoreCuttingJobs(true);
    }

    /* بيانات الزبون: تُعرض إن وصلت مع التحويل، وتُحفظ مع الجلسة فتبقى
       بعد إعادة فتح الصفحة. الأزرار تعمل ولا تكتفي بالعرض. */
    let cutContact = { phone: '', loc: null };
    let cutSketches = [];   // رسم كل مقاس بالترتيب نفسه

    function renderCutContact() {
      const el = document.getElementById('cut-contact');
      if (!el) return;
      const p = (cutContact.phone || '').trim();
      const L = cutContact.loc;
      const hasLoc = !!(L && typeof L.lat === 'number');
      if (!p && !hasLoc) { el.style.display = 'none'; el.innerHTML = ''; return; }

      let html = '';
      if (p) {
        html += '<span>📞</span><span class="cc-txt">' + escHtml(p) + '</span>' +
                '<button type="button" onclick="cutCall()">اتصال</button>' +
                '<button type="button" onclick="cutCopy(\'phone\')">نسخ</button>';
      }
      if (p && hasLoc) html += '<span class="cc-sep"></span>';
      if (hasLoc) {
        html += '<span>📍</span><span class="cc-txt">' +
                escHtml(L.lat.toFixed(6) + ', ' + L.lng.toFixed(6)) + '</span>' +
                '<button type="button" onclick="cutOpenLoc()">فتح</button>' +
                '<button type="button" onclick="cutCopy(\'loc\')">نسخ</button>';
      }
      el.innerHTML = html;
      el.style.display = 'flex';
    }

    function cutCall() {
      const p = (cutContact.phone || '').trim();
      if (!p) return;
      window.location.href = 'tel:' + encodeURIComponent(p.replace(/\s+/g, ''));
    }
    function cutOpenLoc() {
      const L = cutContact.loc;
      if (!L || typeof L.lat !== 'number') return;
      window.open('https://www.google.com/maps?q=' + L.lat + ',' + L.lng, '_blank', 'noopener');
    }
    async function cutCopy(what) {
      const L = cutContact.loc;
      const txt = what === 'phone'
        ? (cutContact.phone || '').replace(/\s+/g, '')
        : (L ? (L.lat + ',' + L.lng) : '');
      if (!txt) return;
      /* نفس احتياط الكراسة: clipboard الحديثة تحتاج https وقد تُرفض،
         فبديل قديم يمنع الفشل الصامت. */
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(txt);
          showToast('نُسخ ✅', 'success'); return;
        }
      } catch (e) {}
      try {
        const ta = document.createElement('textarea');
        ta.value = txt; ta.style.cssText = 'position:fixed;top:-1000px;opacity:0;';
        document.body.appendChild(ta); ta.select();
        const ok = document.execCommand('copy'); ta.remove();
        showToast(ok ? 'نُسخ ✅' : 'تعذّر النسخ', ok ? 'success' : 'error');
      } catch (e) { showToast('تعذّر النسخ', 'error'); }
    }

    /* ══ حذف كراسة زبون من هنا ══
       الكراسة نفسها التي تكتبها صفحة القياسات (مجموعة measurementJobs)،
       فالحذف من هنا يجب أن يتبع **قواعدها هي** لا قواعد أخف. وإلا صار
       هذا الباب طريقاً جانبياً يتجاوز حماية بُنيت هناك عمداً:

         • للمدير وحده.
         • ينقل للسلة (deleted:true) ولا يمحو — تبقى قابلة للاسترجاع من
           صفحة القياسات.
         • الخدمة المعتمدة لا تُحذف قبل إلغاء اعتمادها: لها فاتورة قائمة
           في الفواتير، وحذف الكراسة يترك تلك الفاتورة بلا مصدر.
           وإلغاء الاعتماد يقع في صفحة القياسات لأنه يعكس الفاتورة
           ومقبوضاتها ورصيدها — عملية مالية لا مكان لها في شاشة قص. */
    function deleteJobSheet(id, ev) {
      if (ev) ev.stopPropagation();
      if (!isCutManager()) { alert('⛔ حذف كراسة زبون متاح للمدير فقط.'); return; }

      const j = jobsSheets.find(x => x.id === id);
      if (!j) return;

      if (j.approved) {
        alert('⛔ لا يمكن حذف خدمة معتمدة.\n\n' +
              'لها فاتورة قائمة في الفواتير' + (j.approvedInvId ? (' برقم ' + j.approvedInvId) : '') + '.\n\n' +
              'افتح صفحة القياسات ← الأرشيف، وألغِ الاعتماد أولاً (ضغطة مطوّلة على زر «ابدأ في العمل»)، ثم احذفها.');
        return;
      }

      const who = j.customer || j.label || 'كراسة بلا اسم';
      if (!confirm('نقل مقاسات «' + who + '» إلى سلة المهملات؟\n\n' +
                   j.items.length + ' مقاساً.\n\n' +
                   'لن تُفقد — تبقى في سلة صفحة القياسات ويمكن استرجاعها في أي وقت.')) return;

      fsUpdate('measurementJobs', id, {
        deleted: true,
        deletedAt: Date.now(),
        deletedBy: (window.currentShopUser && window.currentShopUser.name) || ''
      });
      showToast('نُقلت إلى سلة المهملات', 'success');
    }

    function openJobsArchive() {
      document.getElementById('jobs-overlay').classList.add('open');
      renderJobsArchive();
    }
    function closeJobsArchive() {
      document.getElementById('jobs-overlay').classList.remove('open');
    }

    function renderJobsArchive(suppressServerSearch) {
      const list = document.getElementById('jobs-list');
      if (!list) return;
      const rawQ = (document.getElementById('jobs-search')?.value || '').trim();
      const q = rawQ.toLowerCase();
      if (!suppressServerSearch && rawQ.length >= 2) searchCuttingJobsServer(rawQ);
      const mode = (document.querySelector('input[name="jobsFilter"]:checked') || {}).value || 'all';

      let rows = jobsSheets.filter(x => {
        if (mode === 'approved' && !x.approved) return false;
        if (mode === 'pending'  &&  x.approved) return false;
        if (!q) return true;
        return (x.customer + ' ' + x.label).toLowerCase().includes(q);
      });

      rows = rows.slice().sort((a, b) => {
        const na = a.customer || a.label || '', nb = b.customer || b.label || '';
        const ta = a.updatedAt || 0, tb = b.updatedAt || 0;
        return jobsSort === 'date'
          ? (tb - ta) || na.localeCompare(nb, 'ar')
          : na.localeCompare(nb, 'ar') || (tb - ta);
      });
      try {
        document.querySelectorAll('#jobs-overlay .sort-btn').forEach(b =>
          b.classList.toggle('active', b.dataset.sort === jobsSort));
      } catch (e) {}

      if (!rows.length) {
        list.innerHTML = '<div style="text-align:center;color:#717375;padding:26px 10px;font-weight:700;">لا توجد كراسات مطابقة.</div>';
        return;
      }

      list.innerHTML = rows.map((x, i) => {
        // ملخّص الأنواع: كم مقاساً من كل نوع — يعرف القصّاص ما ينتظره قبل الفتح
        const byType = {};
        x.items.forEach(it => {
          const k = it.type || 'غير محدد';
          byType[k] = (byType[k] || 0) + 1;
        });
        const typesTxt = Object.keys(byType)
          .map(k => escHtml(jobTypeLabel(k)) + ' ×' + byType[k]).join(' · ');

        const state = x.workDone ? { t: '✔ انتهى العمل', c: '#057195', b: '#f2fbfe' }
                    : x.workStarted ? { t: '▶ جارٍ العمل', c: '#1f6fc9', b: '#fffbf0' }
                    : x.approved ? { t: '✓ معتمدة', c: '#057195', b: '#f2fbfe' }
                    : { t: '✗ غير معتمدة', c: '#b12c1b', b: '#fef2f1' };

        const when = x.updatedAt ? new Date(x.updatedAt).toLocaleDateString('ar-EG') : '—';
        return `
          <div class="job-card" onclick="loadJobIntoCutting('${escAttr(x.id)}')">
            <div class="job-top">
              <div class="job-name">${escHtml(x.customer || x.label)}</div>
              <span class="job-state" style="color:${escHtml(state.c)};background:${escHtml(state.b)};">${escHtml(state.t)}</span>
              ${isCutManager()
                ? `<button class="job-del" title="نقل إلى سلة المهملات"
                       onclick="deleteJobSheet('${escAttr(x.id)}', event)">🗑️</button>`
                : ''}
            </div>
            <div class="job-meta">${x.items.length} مقاساً · ${escHtml(when)}</div>
            <div class="job-types">${typesTxt}</div>
          </div>`;
      }).join('');
    }

    // اسم النوع كما يعرفه القصّاص. الأنواع المخصّصة تصل بمعرّفها فنعرضه كما هو.
    /* ══ أسماء الأنواع تُقرأ من المصدر المشترك ══
       كانت خريطة ثابتة مكتوبة هنا. فأي نوع يضيفه عضو من الكراسة («شبك
       حماية» مثلاً) يصل إلى هذه الشاشة بمعرّفه الخام — `xtype_1735…` —
       فيقرؤه القصّاص رمزاً لا معنى له، ولا يعرف أي شغل هو.

       الآن تُقرأ من مجموعة measurementTypes نفسها التي تكتبها الكراسة،
       فيظهر الاسم كما كُتب تماماً وعلى كل الأجهزة لحظياً.

       والخريطة الثابتة تبقى **بديلاً** لا مصدراً: تعمل قبل وصول أول
       لقطة، ودون اتصال على جهاز جديد. */
    const FALLBACK_TYPE_NAMES = {
      pvc: 'PVC', seranati: 'سرانتي', xtype_ser_normal: 'سرانتي عادي',
      xtype_alum: 'ألمونيوم', xtype_ser_out: 'سرانتي خارجي',
      xtype_net_move: 'ناموسية متحركة', xtype_net_fix: 'ناموسية ثابتة'
    };
    let sharedTypeNames = {};      // معرّف → اسم، من قاعدة البيانات
    let typesUnsub = null;

    function attachTypeNamesSync() {
      if (typesUnsub) return;          // 9.8.1 — قد تُستدعى مبكراً ومن guardPage
      if (typesUnsub) return;

      // نبدأ بآخر نسخة محفوظة محلياً حتى تعمل الأسماء دون اتصال
      try {
        const cached = JSON.parse(localStorage.getItem('ws_type_names') || '{}');
        if (cached && typeof cached === 'object') sharedTypeNames = cached;
      } catch (e) {}

      typesUnsub = db.collection('measurementTypes').doc('list')
        .onSnapshot(doc => {
          if (!doc.exists) return;
          const v = doc.data() || {};
          if (!Array.isArray(v.types)) return;
          const map = {};
          v.types.forEach(t => { if (t && t.id && t.name) map[t.id] = t.name; });
          sharedTypeNames = map;
          try { localStorage.setItem('ws_type_names', JSON.stringify(map)); } catch (e) {}
          /* ⚠️ 9.8.1 — يُعاد رسم **كل** ما يحمل اسم نوع، لا الكراسات وحدها.

             كان الشرط مقصوراً على نافذة الكراسات المفتوحة. وjobTypeLabel
             تُستعمل في أرشيف القص أيضاً (ملخّص الأنواع في البطاقة، وسطور
             التفاصيل). فمن كان ينظر إلى الأرشيف حين وصل الاسم الجديد
             يبقى أمام المعرّف الخام حتى يُعيد فتح الشاشة — وهو لا يعرف
             أن عليه إعادة فتحها، فيقرأ رمزاً ويحسبه عطلاً.

             والرسم هنا رخيص: قائمتان على الشاشة لا أكثر. */
          try {
            const jo = document.getElementById('jobs-overlay');
            if (jo && jo.classList.contains('open')) renderJobsArchive();
          } catch (e) {}
          try { renderArchiveList(); } catch (e) {}
        }, err => console.warn('مزامنة أسماء الأنواع:', err && err.code));
    }

    function jobTypeLabel(id) {
      return sharedTypeNames[id] || FALLBACK_TYPE_NAMES[id] || id;
    }

    /* فتح كراسة زبون في الحاسبة: تُبنى الأسطر من مقاساتها ويُمسح كل أثر
       للجلسة السابقة أولاً — نفس ما يفعله التحويل القادم من الكراسة، فلا
       تختلط ورقة زبون بورقة آخر. */
    /* فتح كراسة زبون: تُعرض مقاساتها للاختيار قبل الإدخال.
       الكراسة الواحدة قد تحمل عشرين مقاساً من أنواع مختلفة، والقصّاص
       يأخذ نوعاً واحداً في يومه — فإدخالها كلها يعني حذف ما لا يعنيه
       يدوياً، أو حسابها معاً فيطلب مواداً لا يحتاجها اليوم. */
    let jobPickerId = null;

    function loadJobIntoCutting(id) {
      const job = jobsSheets.find(x => x.id === id);
      if (!job) return;
      if (!job.items.length) { showToast('لا مقاسات في هذه الكراسة', 'error'); return; }

      jobPickerId = id;
      const byType = {};
      job.items.forEach((it, i) => {
        const k = jobTypeLabel(it.type);
        (byType[k] = byType[k] || []).push({ it, i });
      });

      const body = Object.keys(byType).map(k => `
        <div class="jp-group">
          <label class="jp-ghead">
            <input type="checkbox" class="jp-gcb" data-group="${escHtml(k)}" checked
                   onchange="toggleJobGroup(this)">
            <span>${escHtml(k)}</span>
            <span class="jp-count">${byType[k].length}</span>
          </label>
          ${byType[k].map(({ it, i }) => {
            const extra = [it.sk, it.itemColor, it.note].filter(Boolean).join(' · ');
            return `<label class="jp-row">
              <input type="checkbox" class="jp-cb" data-group="${escHtml(k)}" value="${i}" checked
                     onchange="syncJobGroupBoxes()">
              <span class="jp-dim">${wsDimensionPair(it.w,it.h)}</span>
              ${extra ? `<span class="jp-note">${escHtml(extra)}</span>` : ''}
            </label>`;
          }).join('')}
        </div>`).join('');

      const ov = document.createElement('div');
      ov.id = 'jobPickerOverlay';
      ov.className = 'archive-overlay open';
      ov.onclick = e => { if (e.target === ov) closeJobPicker(); };
      ov.innerHTML = `
        <div class="archive-panel">
          <div class="archive-panel-header">
            <h2>📐 ${escHtml(job.customer || job.label)}</h2>
            <button class="close-archive-btn" onclick="closeJobPicker()" aria-label="إغلاق">✕</button>
          </div>
          <div class="jp-tools">
            <button type="button" class="jp-tbtn" onclick="setAllJobRows(true)">تحديد الكل</button>
            <button type="button" class="jp-tbtn" onclick="setAllJobRows(false)">إلغاء الكل</button>
            <span class="jp-sel" id="jp-selcount"></span>
          </div>
          <div class="jp-list">${body}</div>
          <button type="button" class="btn jp-go" onclick="confirmJobPicker()">إدخال المحدَّد للقص</button>
        </div>`;
      document.body.appendChild(ov);
      updateJobSelCount();
    }

    function closeJobPicker() {
      const ov = document.getElementById('jobPickerOverlay');
      if (ov) ov.remove();
      jobPickerId = null;
    }

    // تحديد نوع كامل بضغطة — القصّاص يعمل بالنوع لا بالمقاس المفرد
    function toggleJobGroup(cb) {
      const ov = document.getElementById('jobPickerOverlay');
      if (!ov) return;
      ov.querySelectorAll('.jp-cb[data-group="' + CSS.escape(cb.dataset.group) + '"]')
        .forEach(x => { x.checked = cb.checked; });
      updateJobSelCount();
    }

    // مربّع النوع يعكس حالة صفوفه: مؤشَّر إن أُشّرت كلها
    function syncJobGroupBoxes() {
      const ov = document.getElementById('jobPickerOverlay');
      if (!ov) return;
      ov.querySelectorAll('.jp-gcb').forEach(g => {
        const rows = ov.querySelectorAll('.jp-cb[data-group="' + CSS.escape(g.dataset.group) + '"]');
        const on = Array.from(rows).filter(r => r.checked).length;
        g.checked = on === rows.length;
        g.indeterminate = on > 0 && on < rows.length;
      });
      updateJobSelCount();
    }

    function setAllJobRows(on) {
      const ov = document.getElementById('jobPickerOverlay');
      if (!ov) return;
      ov.querySelectorAll('.jp-cb, .jp-gcb').forEach(x => { x.checked = on; x.indeterminate = false; });
      updateJobSelCount();
    }

    function updateJobSelCount() {
      const ov = document.getElementById('jobPickerOverlay');
      if (!ov) return;
      const n = ov.querySelectorAll('.jp-cb:checked').length;
      const el = ov.querySelector('#jp-selcount');
      if (el) el.textContent = n ? ('محدَّد: ' + n) : 'لم تحدّد شيئاً';
    }

    function confirmJobPicker() {
      const ov = document.getElementById('jobPickerOverlay');
      const job = jobsSheets.find(x => x.id === jobPickerId);
      if (!ov || !job) return;
      const idx = Array.from(ov.querySelectorAll('.jp-cb:checked')).map(c => +c.value);
      if (!idx.length) { showToast('حدّد مقاساً واحداً على الأقل', 'error'); return; }

      const cur = (document.getElementById('bulk-input')?.value || '').trim();
      if (cur && !confirm('ستُستبدل القياسات الحالية بـ' + idx.length + ' مقاساً من «' +
                          (job.customer || job.label) + '».\n\nمتابعة؟')) return;

      const lines = idx.map(i => {
        const it = job.items[i];
        const parts = [jobTypeLabel(it.type), it.sk, it.itemColor, it.note].filter(Boolean);
        const note = parts.join(' - ');
        return it.w + ' × ' + it.h + (note ? ' ' + note : '');
      }).join('\n');

      document.getElementById('measurements-container').innerHTML = '';
      document.getElementById('results').innerHTML = '';
      const custEl = document.getElementById('cut-customer');
      if (custEl) custEl.value = job.customer || job.label || '';
      cutContact = { phone: job.phone || '', loc: job.loc || null };
      renderCutContact();
      cutSketches = idx.map(i => (job.items[i] && job.items[i].img) || '');
      document.getElementById('bulk-input').value = lines;

      closeJobPicker();
      closeJobsArchive();
      prepareMeasurements(idx.map(i => { const it = job.items[i]; return {...it, note:[jobTypeLabel(it.type), it.sk, it.itemColor, it.note].filter(Boolean).join(' - ')}; }));
      try { scheduleDraftSave(); } catch (e) {}
      showToast('أُدخل ' + idx.length + ' مقاساً من «' + (job.customer || job.label) + '»', 'success');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function getArchive() { return archives; }

    // ===== الأرشيف التدريجي v223: لا نحمّل cuttingArchive بالكامل عند فتح الصفحة =====
    let archives = [];
    let archivesUnsub = null;
    let cuttingArchiveCursor = null;
    let cuttingArchiveHasMore = true;
    let cuttingArchiveLoading = false;
    const CUT_ARCHIVE_PAGE_SIZE = 100;

    function renderCuttingArchivePager() {
      const list = document.getElementById('archive-list');
      if (!list) return;
      let box = document.getElementById('cut-archive-pager');
      if (!box) {
        box = document.createElement('div'); box.id='cut-archive-pager';
        box.style.cssText='text-align:center;padding:10px;'; list.parentNode.insertBefore(box,list.nextSibling);
      }
      if (cuttingArchiveLoading) box.innerHTML='<div style="color:#85878a;font-size:12px;font-weight:700;">⏳ جاري تحميل المزيد...</div>';
      else if (cuttingArchiveHasMore) box.innerHTML='<button type="button" onclick="loadMoreCuttingArchive()" style="width:100%;padding:10px;border:1px solid #d7eee2;border-radius:12px;background:#f6fff9;color:#157f4a;font-family:inherit;font-weight:800;">⬇️ تحميل المزيد من أرشيف القص</button>';
      else box.innerHTML=archives.length?'<div style="color:#85878a;font-size:11px;">تم تحميل كل عمليات القص</div>':'';
    }

    async function loadMoreCuttingArchive(reset) {
      if (cuttingArchiveLoading) return;
      if (reset) { cuttingArchiveCursor=null; cuttingArchiveHasMore=true; archives=[]; archivesTrash=[]; }
      if (!cuttingArchiveHasMore) return;
      cuttingArchiveLoading=true; renderCuttingArchivePager();
      try {
        const page=await FirestorePager.fetchPage(db,'cuttingArchive',{pageSize:CUT_ARCHIVE_PAGE_SIZE,cursor:cuttingArchiveCursor});
        const all=page.docs.map(d=>({id:d.id,...(d.data||{})}));
        archives.push(...all.filter(e=>e.deleted!==true));
        archivesTrash.push(...all.filter(e=>e.deleted===true).sort((a,b)=>(b.deletedAt||0)-(a.deletedAt||0)));
        cuttingArchiveCursor=page.lastDoc; cuttingArchiveHasMore=page.hasMore;
        const overlay=document.getElementById('archive-overlay'); if(overlay&&overlay.classList.contains('open')) renderArchiveList();
      } catch(e) { console.error('تعذّرت قراءة أرشيف القص:',e); showFsErrorToast(fsErrorMessage(e,'أرشيف القص')); }
      finally { cuttingArchiveLoading=false; renderCuttingArchivePager(); }
    }

    function attachCuttingArchiveSync() {
      if(archivesUnsub) return;
      archivesUnsub={paged:true};
      loadMoreCuttingArchive(true);
    }

    // ترحيل تلقائي لمرة واحدة: أي عمليات قص كانت محفوظة سابقاً على هذا الجهاز فقط تُرفع للأرشيف السحابي المشترك
    async function migrateLocalCuttingArchiveToFirestore() {
      if(localStorage.getItem('cutting_archive_migrated_to_cloud')) return;
      try {
        const old = JSON.parse(localStorage.getItem('app_archive') || '[]');
        /* ══ ترحيل حيادي ══
           علامة «تم الترحيل» تُوضع بعد الحلقة. فلو انقطع الاتصال في
           منتصفها لم تُوضع، وأُعيد الترحيل عند الفتح التالي بمعرّفات
           جديدة — فتظهر كل عملية مرحَّلة مرتين.
           المعرّف الآن مشتق من العملية نفسها، فإعادة الترحيل تكتب فوق
           نفس المستندات. تشغيله عشر مرات يعطي النتيجة نفسها. */
        let _ci = 0;
        for(const e of old) {
          const { id, ...rest } = e;
          const migId = 'MIGC-' + (_ci++) + '_' +
            String(e.customerName || '').replace(/[^\w\u0600-\u06FF]/g, '').slice(0, 20) + '_' +
            String(e.savedAt || '').replace(/\D/g, '').slice(0, 14);
          await fsSet('cuttingArchive', migId, {
            ...rest,
            savedAtMs: e.savedAt ? new Date(e.savedAt).getTime() : Date.now(),
            createdBy: (window.currentShopUser && window.currentShopUser.name) || '',
            migratedFromDevice: true
          });
        }
        localStorage.setItem('cutting_archive_migrated_to_cloud', '1');
      } catch(e) { console.error('migrateLocalCuttingArchiveToFirestore:', e); }
    }

    /* أرشفة جلسة من حالة محفوظة (لا من الشاشة). تُستعمل عند الفتح حين
       تكون المسودة قديمة: نحفظها قبل أن نُخلي الصفحة، فلا يضيع عمل. */
    function archiveCurrentFromState(state) {
      if (!state) return false;
      const hasWork = (Array.isArray(state.measurements) && state.measurements.length) ||
                      state.resultsHTML || (state.bulkInput || '').trim();
      if (!hasWork) return false;
      fsAdd('cuttingArchive', {
        savedAt: new Date().toISOString(),
        savedAtMs: Date.now(),
        createdBy: (window.currentShopUser && window.currentShopUser.name) || '',
        customerName: state.customerName || '',
        bulkInput: state.bulkInput || '',
        measurements: state.measurements || [],
        resultsHTML: state.resultsHTML || '',
        cutContact: state.cutContact || null,
        cutSketches: state.cutSketches || []
      });
      return true;
    }

    /* ══ منع تكرار العملية في أرشيف القص ══
       المسار الذي كان يُنتج نسخاً:
         ١) يسترجع المستخدم عملية من الأرشيف — restoreArchiveEntry تؤرشف
            ما كان على الشاشة أولاً (سليم) ثم تُحمّل العملية المسترجَعة.
         ٢) يضغط «جديد» — فتؤرشف archiveCurrentIfAny **العملية المسترجَعة
            نفسها** من جديد. فتصير نسختان منها في الأرشيف.
       وكل استرجاع ثم «جديد» يضيف نسخة، فتتضخّم القائمة بنسخ متطابقة.

       الحل: نتذكّر بصمة ما حُمّل من الأرشيف. وإن لم يتغيّر شيء بعده فلا
       داعي لأرشفته ثانيةً — هو محفوظ أصلاً. وأي تعديل يغيّر البصمة
       فيُؤرشَف كعملية جديدة كما ينبغي. */
    let loadedArchiveFingerprint = '';

    function cutStateFingerprint(st) {
      try {
        return JSON.stringify([
          (st.customerName || '').trim(),
          (st.bulkInput || '').trim(),
          (st.measurements || []).map(m => [m.w,m.h,m.type,m.profile,m.manualValue,m.message,m.formulaSnapshot||null,window.WSOpeningSymbols.resolve(m)]),
          st.cutContact || null
        ]);
      } catch (e) { return ''; }
    }

    function archiveCurrentIfAny(silent) {
      const state = collectCurrentState();
      if (state.measurements.length === 0 && !state.resultsHTML && !state.bulkInput.trim()) return false;

      // نسخة طبق الأصل مما استُرجع للتو: موجودة في الأرشيف، فلا تُكرَّر
      if (loadedArchiveFingerprint &&
          cutStateFingerprint(state) === loadedArchiveFingerprint) return false;
      fsAdd('cuttingArchive', {
        savedAt: new Date().toISOString(),
        savedAtMs: Date.now(),
        createdBy: (window.currentShopUser && window.currentShopUser.name) || '',
        ...state
      });
      if (!silent) showToast('تم حفظ العملية في الأرشيف', 'success');
      return true;
    }

    function openArchive() {
      renderArchiveList();
      document.getElementById('archive-overlay').classList.add('open');
      document.body.style.overflow = 'hidden';
    }

    function closeArchive() {
      document.getElementById('archive-overlay').classList.remove('open');
      document.body.style.overflow = '';
    }

    function formatArchiveDate(iso) {
      try {
        return new Date(iso).toLocaleString('ar', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
      } catch(e) { return iso; }
    }

    function renderArchiveList() {
      /* ترتيب أبجدي باسم الزبون، والأحدث أولاً عند تطابق الاسم.
         الترتيب الزمني وحده يجعل البحث عن عملية بعد أسبوع تصفّحاً أعمى. */
      // بحث باسم الزبون — الأرشيف يطول بسرعة فالتصفّح وحده لا يكفي
      const q = (document.getElementById('arc-search')?.value || '').trim().toLowerCase();
      const archive = getArchive()
        .filter(e => !q || ((e.customerName || '') + ' ' + (e.bulkInput || '')).toLowerCase().includes(q))
        .slice().sort((a, b) => {
        const na = a.customerName || '', nb = b.customerName || '';
        const ta = a.savedAtMs || 0, tb = b.savedAtMs || 0;
        return arcSort === 'date'
          ? (tb - ta) || na.localeCompare(nb, 'ar')
          : na.localeCompare(nb, 'ar') || (tb - ta);
      });
      try {
        document.querySelectorAll('#archive-overlay .sort-btn').forEach(b =>
          b.classList.toggle('active', b.dataset.sort === arcSort));
      } catch (e) {}
      const listEl = document.getElementById('archive-list');
      if (archive.length === 0) {
        listEl.innerHTML = '<div class="archive-empty">لا توجد عمليات محفوظة في الأرشيف بعد.<br>عند الضغط على زر «جديد» سيُحفظ عملك الحالي هنا تلقائياً.</div>';
        return;
      }
      let html = '';
      archive.forEach(entry => {
        const count = entry.measurements ? entry.measurements.length : 0;
        let preview = '';
        if (entry.measurements && entry.measurements[0] && entry.measurements[0].w && entry.measurements[0].h) {
          preview = `${entry.measurements[0].w} × ${entry.measurements[0].h}` + (count > 1 ? ` و${count - 1} غيرها` : '');
        }
        const starters = cutStartersOf(entry);
        const workLbl = starters.map(x => escHtml(x.name || '؟')).join('، ');
        const stateCls = entry.approved ? 'is-approved' : 'not-approved';
        html += `
        <div class="archive-entry ${stateCls}">
          <div class="archive-entry-info">
            <!-- الاسم هو العنوان، والتاريخ سطر ثانوي تحته.
                 كان التاريخ هو العنوان، فقائمة الأرشيف تبدو صفاً من تواريخ
                 متشابهة لا يُميَّز بينها إلا بفتح كل واحدة. -->
            <div style="font-weight:900; color:#171818; font-size:15px; line-height:1.4;">
              ${entry.customerName ? escHtml(entry.customerName) : 'عملية بلا اسم'}
            </div>
            <div class="archive-entry-date">${formatArchiveDate(entry.savedAt)}</div>
            <div class="archive-entry-preview">${count} قياس${preview ? ' — ' + wsFormatDimensions(preview) : ''}</div>
            <!-- الحالة مكتوبة بجانب اللون، فمن لا يميّز الألوان يقرؤها -->
            <div class="cut-state ${stateCls}">
              ${entry.approved
                ? ('✓ قص معتمد — الأرقام مثبَّتة' + (entry.approvedBy ? (' · ' + escHtml(entry.approvedBy)) : ''))
                : '✗ لم يُعتمد بعد'}
            </div>
            ${workLbl ? `<div class="cut-workers">${entry.workDone ? ('✔ انتهى' + (entry.workDoneBy ? (' — ' + escHtml(entry.workDoneBy)) : '') + ' · بدأه: ') : '▶ جارٍ القص: '}${workLbl}</div>` : ''}
          </div>
          <div class="archive-entry-actions">
            ${entry.approved
              ? `<button class="cut-work-btn${entry.workDone ? ' done' : (entry.workStarted ? ' started' : '')}"
                     title="حالة العمل"
                     onclick="event.stopPropagation(); cutWorkTap('${escAttr(entry.id)}');">
                   ${entry.workDone ? 'تم الانتهاء' : (entry.workStarted ? 'جارٍ القص' : 'ابدأ القص')}
                 </button>
                 ${isCutManager()
                   ? `<button class="cut-unapprove-btn" title="إلغاء الاعتماد"
                          onclick="event.stopPropagation(); cancelCutApproval('${escAttr(entry.id)}');">↩︎ إلغاء الاعتماد</button>`
                   : ''}`
              : (isCutManager()
                  ? `<button class="cut-approve-btn" onclick="event.stopPropagation(); approveCutJob('${escAttr(entry.id)}');">اعتماد القص</button>`
                  : `<button class="cut-approve-btn" disabled title="الاعتماد للمدير فقط" style="opacity:.5;cursor:not-allowed;">🔒 بانتظار الاعتماد</button>`)}
            <button class="archive-btn-restore" onclick="restoreArchiveEntry('${escAttr(entry.id)}')">استعادة</button>
            ${isCutManager() ? `<button class="archive-btn-delete" onclick="deleteArchiveEntry('${escAttr(entry.id)}')" aria-label="حذف">🗑️</button>` : ''}
          </div>
        </div>`;
      });

      // سلة المهملات — للمدير وحدها، ولا تظهر وهي فارغة
      if (isCutManager() && archivesTrash.length) {
        html += `<div class="cut-trash-head">🗑️ سلة المهملات (${archivesTrash.length})</div>`;
        archivesTrash.forEach(t => {
          const when = t.deletedAt ? new Date(t.deletedAt).toLocaleDateString('ar-EG') : '—';
          html += `
          <div class="archive-entry cut-trashed">
            <div class="archive-entry-info">
              <div style="font-weight:800; color:#535455; font-size:14px;">${t.customerName ? escHtml(t.customerName) : 'عملية بلا اسم'}</div>
              <div class="archive-entry-date">حُذفت في ${escHtml(when)}${t.deletedBy ? (' — ' + escHtml(t.deletedBy)) : ''}</div>
            </div>
            <div class="archive-entry-actions">
              <button class="archive-btn-restore" onclick="restoreFromCutTrash('${escAttr(t.id)}')">استرجاع</button>
              <button class="archive-btn-delete" onclick="purgeFromCutTrash('${escAttr(t.id)}')" aria-label="محو نهائي">✕</button>
            </div>
          </div>`;
        });
      }

      if (isCutManager()) html += `<button class="archive-clear-all" onclick="clearArchiveAll()">نقل الأرشيف كله للسلة</button>`;
      listEl.innerHTML = html;
    }

    function restoreArchiveEntry(id) {
      const archive = getArchive();
      const entry = archive.find(e => e.id === id);
      if (!entry) return;
      archiveCurrentIfAny(true); // احفظ العمل الحالي أولاً حتى لا يضيع
      document.getElementById('bulk-input').value = entry.bulkInput || '';
      const _c = document.getElementById('cut-customer');
      if (_c) _c.value = entry.customerName || '';
      setTimeout(refreshApplyAllBar, 0);
      rebuildMeasurementsFromState(entry.measurements, entry);
      window._lastCutResults=null;
      document.getElementById('results').innerHTML = sanitizeResultsHTML(entry.resultsHTML || '');   // تنقية 8.8.5 — المصدر مجموعة مشتركة يكتبها أي عضو
      /* البصمة تُؤخذ من **الحالة المحمّلة فعلاً** لا من سجل الأرشيف.
         الفرق مهم: rebuildMeasurementsFromState تبني الحقول من السجل وقد
         تُطبّع قيمها (رقم يُكتب 100 يعود 100.0، حقل فارغ يصير سلسلة
         فارغة). فبصمةٌ مأخوذة من السجل لا تطابق ما تحسبه
         collectCurrentState لاحقاً — فيسقط الحارس وتُؤرشَف نسخة ثانية.
         أخذها من نفس المصدر يضمن التطابق. */
      loadedArchiveFingerprint = cutStateFingerprint(collectCurrentState());
      saveDraft();
      closeArchive();
      showToast('تم استعادة العملية من الأرشيف', 'success');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    let archivesTrash = [];

    /* ════════════════════════════════════════════════════════════
       اعتماد القص = تثبيت الأرقام
       ------------------------------------------------------------
       اخترتُ هذا المعنى للاعتماد هنا — لا «طلب مواد» ولا وسم «تم» فارغ —
       لأنه الوحيد الذي يحمي من خطأ لا يُصلَّح: بمجرد نزول المقصّ على
       العود، أي تعديل لاحق في الأرقام يجعل ما في الشاشة مخالفاً لما في
       الورشة. فالاعتماد يثبّت الأرقام ويمنع تغييرها.

       ولا أثر مالي له إطلاقاً — بخلاف اعتماد الكراسة الذي يكتب فاتورة.
       الشغل هنا معتمد أصلاً ومفوتَر من الكراسة، فإنشاء فاتورة ثانية
       يعني مطالبة الزبون بالضعف.

       إن كان مقصودك بالاعتماد شيئاً آخر (طلب مواد من مورّد مثلاً) فهذا
       تغيير في هذه الدالة وحدها.
       ════════════════════════════════════════════════════════════ */
    function approveCutJob(id) {
      /* ⚠️ إصلاح 8.8.3 — الاعتماد كان يقع على الجهاز ويرفضه السيرفر.

         قاعدة cuttingArchive تمنع غير المدير من لمس
         approved/approvedBy/approvedAt/approvedInvId، والتعليق في ملف
         القواعد يقول صراحةً «الاعتماد والإلغاء للمدير في الواجهة».
         لكن هذه الدالة وحدها من بين أخواتها كانت بلا حارس:
         cancelCutApproval و deleteArchiveEntry و restoreFromCutTrash
         و purgeFromCutTrash و clearArchiveAll كلها تفحص isCutManager().

         فما كان يقع: يضغط العضو «اعتماد القص»، فتقول الرسالة «اعتُمد
         القص — الأرقام مثبَّتة ✅»، ويتغيّر الزر أمامه إلى «ابدأ القص».
         ثم يرفض السيرفر الكتابة، فتعود الحالة إلى «غير معتمد» عند أول
         لقطة — على جهازه وعند الجميع.

         وأثره ليس تجميلياً: الاعتماد هو ما يُثبّت الأرقام حتى لا يُقصّ
         في الورشة على رقم غير الذي يراه المشغّل. فمن ظنّ أنه اعتمد يترك
         الكراسة مفتوحة للتعديل وهو يحسبها مقفلة. */
      if (!isCutManager()) {
        alert('⛔ اعتماد القص متاح للمدير فقط.\n\nاطلب من المدير اعتمادها لتُثبَّت أرقامها.');
        return;
      }
      const e = archives.find(x => x.id === id);
      if (!e) return;
      if (e.approved) return;
      const n = (e.measurements || []).length;
      if (!confirm('اعتماد قص «' + (e.customerName || 'عملية بلا اسم') + '»؟\n\n' +
                   'ستُثبَّت أرقامها (' + n + ' مقاساً) فلا تُعدَّل بعدها.\n' +
                   'هذا لتفادي أن يُقصّ في الورشة على رقم غير الذي تراه هنا.\n\n' +
                   'لا أثر مالي — الفاتورة صدرت من الكراسة.')) return;
      fsUpdate('cuttingArchive', id, {
        approved: true,
        approvedAt: Date.now(),
        approvedBy: (window.currentShopUser && window.currentShopUser.name) || ''
      });
      showToast('اعتُمد القص — الأرقام مثبَّتة ✅', 'success');
    }

    function cancelCutApproval(id) {
      if (!isCutManager()) { alert('⛔ إلغاء الاعتماد متاح للمدير وحده.'); return; }
      const e = archives.find(x => x.id === id);
      if (!e || !e.approved) return;
      if (!confirm('إلغاء اعتماد «' + (e.customerName || 'عملية بلا اسم') + '»؟\n\n' +
                   'تعود أرقامها قابلة للتعديل.')) return;
      fsUpdate('cuttingArchive', id, {
        approved: false, approvedAt: 0, approvedBy: '',
        workStartedBy: [], workStarted: false, workDone: false, workDoneAt: 0, workDoneBy: ''
      });
      showToast('أُلغي الاعتماد', 'success');
    }

    // من بدأ العمل — قائمة لا اسماً واحداً: أنواع مختلفة قد يأخذها أكثر من عضو
    function cutStartersOf(e) {
      const raw = e && e.workStartedBy;
      if (Array.isArray(raw)) return raw.filter(Boolean);
      if (typeof raw === 'string' && raw.trim()) return [{ name: raw.trim(), at: e.workStartedAt || 0 }];
      return [];
    }

    /* دورة العمل: ابدأ → جارٍ العمل → تم الانتهاء. نفس دورة الكراسة تماماً
       فلا يتعلّم المستخدم نظامين مختلفين لنفس الفكرة. */
    function cutWorkTap(id) {
      const e = archives.find(x => x.id === id);
      if (!e || !e.approved) return;
      const me = (window.currentShopUser && window.currentShopUser.name) || '';
      const uid = (window.currentShopUser && window.currentShopUser.uid) || '';

      if (e.workDone) {
        const w = e.workDoneAt ? new Date(e.workDoneAt).toLocaleString('ar-EG') : '—';
        if (confirm('هذا القص منتهٍ.\n\nأنهاه: ' + (e.workDoneBy || '—') + '\nفي: ' + w +
                    '\n\nهل تريد إعادة فتحه؟')) {
          fsUpdate('cuttingArchive', id, { workDone: false, workDoneAt: 0, workDoneBy: '' });
          showToast('أُعيد فتح العمل', 'success');
        }
        return;
      }

      if (e.workStarted) {
        const who = cutStartersOf(e).map(x => x.name || '؟').join('، ');
        if (confirm('العمل جارٍ' + (who ? ('\nبدأه: ' + who) : '') + '\n\nهل انتهى القص؟')) {
          fsUpdate('cuttingArchive', id, { workDone: true, workDoneAt: Date.now(), workDoneBy: me });
          showToast('✅ انتهى القص', 'success');
        }
        return;
      }

      const already = cutStartersOf(e).some(x => x && (x.uid ? x.uid === uid : x.name === me));
      if (!confirm('بدء القص في «' + (e.customerName || '') + '»؟')) return;
      if (!already) {
        // إضافة ذرّية: عضوان يبدآن معاً يُسجَّلان معاً ولا يكتب أحدهما فوق الآخر
        fsArrayUnion('cuttingArchive', id, 'workStartedBy',
          { uid: uid, name: me, at: Date.now() },
          { workStarted: true, workStartedAt: e.workStartedAt || Date.now() });
      } else {
        fsUpdate('cuttingArchive', id, { workStarted: true });
      }
      showToast('▶️ بدأ القص', 'success');
    }

    // ضغطة مطوّلة على زر الحالة = إلغاء الاعتماد (للمدير)
    /* حُذف من هنا في 9.6.0: cutLpStart و cutLpEnd — إلغاء الاعتماد
       بالضغط المطوّل. استُبدل بزرّ «↩︎ إلغاء الاعتماد» صريح.

       والضغط المطوّل أسوأ من السحب: لا يُرى، ولا يُخمَّن، ويقع بالخطأ حين
       يُمسك الهاتف بيد فيها قفّاز. وكان يُلغي **اعتماد قصّ** — أي يفتح
       أرقاماً ثُبِّتت للورشة. فعلٌ بهذا الأثر لا يجوز أن يقع بحركة لا
       يعرفها أحد. */

    function isCutManager() {
      return !!(window.currentShopUser && window.currentShopUser.role === 'manager');
    }

    /* الحذف من الأرشيف ينقل للسلة ولا يمحو — كأرشيف الكراسة تماماً.
       العملية المعتمدة لا تُحذف قبل إلغاء اعتمادها، فأرقامها مثبَّتة
       ويُقصّ عليها في الورشة. */
    function deleteArchiveEntry(id) {
      if (!isCutManager()) { alert('⛔ حذف عملية من الأرشيف متاح للمدير فقط.'); return; }
      const e = archives.find(x => x.id === id);
      if (!e) return;
      if (e.approved) {
        alert('⛔ لا يمكن حذف عملية معتمدة.\n\nألغِ اعتمادها أولاً (ضغطة مطوّلة على زر الحالة)، ثم احذفها.');
        return;
      }
      if (!confirm('نقل «' + (e.customerName || 'عملية بلا اسم') + '» إلى سلة المهملات؟\n\nلن تُفقد — يمكن استرجاعها في أي وقت.')) return;
      fsUpdate('cuttingArchive', id, {
        deleted: true, deletedAt: Date.now(),
        deletedBy: (window.currentShopUser && window.currentShopUser.name) || ''
      });
      showToast('نُقلت إلى سلة المهملات', 'success');
    }

    function restoreFromCutTrash(id) {
      if (!isCutManager()) { alert('⛔ متاح للمدير فقط.'); return; }
      fsUpdate('cuttingArchive', id, { deleted: false, deletedAt: 0, deletedBy: '' });
      showToast('عادت إلى الأرشيف ✅', 'success');
    }

    function purgeFromCutTrash(id) {
      if (!isCutManager()) { alert('⛔ متاح للمدير فقط.'); return; }
      const t = archivesTrash.find(x => x.id === id);
      if (!t) return;
      if (!confirm('⚠️ محو «' + (t.customerName || 'عملية بلا اسم') + '» نهائياً؟\n\nلا رجعة في هذا.')) return;
      if (!confirm('تأكيد أخير: امحُ العملية نهائياً؟')) return;
      fsDelete('cuttingArchive', id);
      showToast('تم المحو النهائي', 'success');
    }

    function clearArchiveAll() {
      if (!isCutManager()) { alert('⛔ متاح للمدير فقط.'); return; }
      if (!archives.length) { showToast('الأرشيف فارغ', 'error'); return; }
      const approved = archives.filter(e => e.approved).length;
      if (approved) {
        alert('⛔ لا يمكن إفراغ الأرشيف: فيه ' + approved + ' عملية معتمدة.\n\nألغِ اعتمادها أولاً.');
        return;
      }
      if (!confirm('نقل كل عناصر الأرشيف (' + archives.length + ') إلى سلة المهملات؟')) return;
      archives.forEach(e => fsUpdate('cuttingArchive', e.id, {
        deleted: true, deletedAt: Date.now(),
        deletedBy: (window.currentShopUser && window.currentShopUser.name) || ''
      }));
      showToast('نُقل الأرشيف إلى السلة', 'success');
    }

    // ===== زر «جديد»: يحفظ العمل السابق في الأرشيف تلقائياً ثم ينظف الشاشة =====
    function startNewSession() {
      const _c = document.getElementById('cut-customer'); if (_c) _c.value = '';
      cutContact = { phone: '', loc: null }; cutSketches = [];
      try { renderCutContact(); } catch (e) {}
      const hadContent = archiveCurrentIfAny(true);
      loadedArchiveFingerprint = '';   // عمل جديد: لا صلة بما استُرجع سابقاً
      clearWorkspace();
      localStorage.removeItem('app_current_draft');
      showToast(hadContent ? 'تم حفظ العملية السابقة في الأرشيف، وبدأت صفحة جديدة' : 'بدأت صفحة جديدة', 'success');
    }

    function clearWorkspace() {
      document.getElementById('bulk-input').value = '';
      document.getElementById('measurements-container').innerHTML = '';
      document.getElementById('results').innerHTML = '';
    }

    function createMeasurementHTML(index, w = '', h = '', type = '', manualValue = '', message = '', selectedProfile = '', opening = {}) {
      let profileOptions = '';
      if(selectedProfile&&!Object.hasOwn(appProfiles,selectedProfile))profileOptions='<option selected value="'+escHtml(selectedProfile)+'">'+escHtml(selectedProfile)+'</option>';
      Object.keys(appProfiles).forEach(pName => {
        profileOptions += `<option value="${escHtml(pName)}" ${selectedProfile === pName ? 'selected' : ''}>${escHtml(pName)}</option>`;
      });

      return `
        <div class="measurement-header">
          <span class="measurement-badge">${index}</span>
          <span class="measurement-type-icon" id="type-icon-${index}">${escHtml(getTypeIcon(type))}</span>
          <span>القياس</span><button type="button" onclick="wsRefreshRowFormula(this)" title="استخدام المعادلة الحالية بدل النسخة المثبتة عند الاختيار أو أول حساب">تحديث معادلة المقاس</button>${window.WSOpeningSymbols.html(opening)}<small>${escHtml(window.WSOpeningSymbols.metadata(opening).symbolLabel||'')}</small>
        </div>
        
        <!-- البروفايل صار واحداً فوق الجدول. نُبقي حقلاً مخفياً بنفس الصنف
             لأن القراءة تتم منه في مواضع عدة (الحساب، حفظ المسودة،
             الأرشيف) — فتغييره في مكان واحد أسلم من تتبّعه في كلها. -->
        <select class="profile-select" hidden aria-hidden="true">${profileOptions}</select>

        <div class="dimensions-row" dir="rtl">
          <div><label>العرض (سم):</label><input type="number" step="0.01" value="${w}" class="width-input"></div>
          <div><label>الارتفاع (سم):</label><input type="number" step="0.01" value="${h}" class="height-input"></div>
        </div>
        <label>نوع العملية:</label>
        <select class="type-select" onchange="toggleExtraInputs(this)">
          ${type&&!Object.hasOwn(typeNames,type)?'<option selected value="'+escHtml(type)+'">معادلة محفوظة مع الطلب</option>':''}${buildTypeSelectOptions(type)}
        </select>

        <div class="extra-double-top extra-field-group" style="display:${type==='window_double_top'?'block':'none'};">
          <label>عرض الضلفة (لضلفتين مع تابت):</label>
          <input type="number" step="0.1" value="${manualValue}" placeholder="مثال: 50" class="manual-leaf-width">
        </div>        
        <div class="extra-flipper extra-field-group" style="display:${type==='window_flipper'?'block':'none'};">
          <label>ارتفاع الضلفة (القلاب):</label>
          <input type="number" step="0.1" value="${manualValue}" placeholder="مثال: 50" class="manual-flipper-height">
        </div>
        <div class="extra-door-double extra-field-group" style="display:${['door_double','aluminum_door_double'].includes(type)?'block':'none'};">
          <label><input type="checkbox" class="equal-door-leaves" onchange="toggleEqualDoorLeaves(this)" ${manualValue === "__equal__" ? "checked" : ""}> تساوي الضلفتين (حساب تلقائي)</label>
          <label>عرض الضلفة يدوياً (والثانية تُحسب تلقائياً):</label>
          <input type="number" step="0.1" value="${manualValue === "__equal__" ? "" : manualValue}" placeholder="مثال: 80" class="manual-large-leaf" ${manualValue === "__equal__" ? "disabled" : ""}>
        </div>
        <div class="extra-leaf-fixed extra-field-group" style="display:${['window_leaf_fixed','aluminum_window_leaf_fixed','aluminum_window_flipper_fixed'].includes(type)?'block':'none'};">
          <label>عرض الضلفة (للنافذة ذات الضلفة والثابت):</label>
          <input type="number" step="0.1" value="${manualValue}" placeholder="مثال: 50" class="manual-leaf-fixed-width">
        </div>

        <label>ملاحظة (اختياري):</label>
        <textarea class="message-input" placeholder="أدخل ملاحظة لهذا القياس">${String(message == null ? '' : message).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}</textarea>
      `;
    }

    function getTypeIcon(type) {
      if (!type) return '';
      if (customTypeRegistry[type]) return '🧩';
      if (type.startsWith('window_') || type.startsWith('aluminum_window_') || type === 'aluminum_67' || type === 'aluminum_sliding_67' || type === 'aluminum_sliding_normal') return '🪟';
      if (type.startsWith('aluminum_door')) return '🚪';
      if (type.startsWith('door_')) return '🚪';
      if (type.startsWith('sliding_')) return '↔️';
      if (type.startsWith('sranti_')) return '🪟';
      return '⚙️';
    }

    function buildTypeSelectOptions(selectedType = '') {
      let html = `<option value="">-- اختر --</option>
          <optgroup label="🟦 PVC — العمليات العادية" style="background:#f0f7ff;color:#234d70">
            <option value="window_double" ${selectedType==='window_double'?'selected':''}>🪟 نافذة ضلفتين</option>
            <option value="window_single" ${selectedType==='window_single'?'selected':''}>🪟 نافذة ضلفة واحدة</option>
            <option value="window_double_top" ${selectedType==='window_double_top'?'selected':''}>🪟 نافذة ضلفتين مع تابت</option>
            <option value="window_flipper" ${selectedType==='window_flipper'?'selected':''}>🪟 نافذة قلاب وتابت</option>
            <option value="window_leaf_fixed" ${selectedType==='window_leaf_fixed'?'selected':''}>🪟 نافذة ضلفة وتابت</option>
            <option value="door_single" ${selectedType==='door_single'?'selected':''}>🚪 باب ضلفة واحدة</option>
            <option value="door_double" ${selectedType==='door_double'?'selected':''}>🚪 باب ضلفتين</option>
            <option value="sliding_poly_one" ${selectedType==='sliding_poly_one'?'selected':''}>↔️ سحاب بولي ون</option>
            <option value="sliding_poplist" ${selectedType==='sliding_poplist'?'selected':''}>↔️ سحاب بوبلست</option>
          </optgroup>
          <optgroup label="🪟 عمليات السرانتي" style="background:#f3f8ed;color:#45652e">
            <option value="sranti_external_large" ${selectedType==='sranti_external_large'?'selected':''}>🪟 سرانتي خارجي كبير</option>
            <option value="sranti_external_small" ${selectedType==='sranti_external_small'?'selected':''}>🪟 سرانتي خارجي صغير</option>
            <option value="sranti_normal" ${selectedType==='sranti_normal'?'selected':''}>🪟 سرانتي عادي</option>
          </optgroup>
          <optgroup label="🔩 عمليات الألمنيوم — أخيراً" style="background:#f5f2f8;color:#624b75">
            <option value="aluminum_window_double" ${selectedType==='aluminum_window_double'?'selected':''}>🪟 نافذة ألمنيوم ضلفتين</option>
            <option value="aluminum_window_single" ${selectedType==='aluminum_window_single'?'selected':''}>🪟 نافذة ألمنيوم ضلفة واحدة</option>
            <option value="aluminum_window_flipper" ${selectedType==='aluminum_window_flipper'?'selected':''}>🪟 نافذة ألمنيوم قلاب</option>
            <option value="aluminum_window_leaf_fixed" ${selectedType==='aluminum_window_leaf_fixed'?'selected':''}>🪟 نافذة ألمنيوم ضلفة وثابت</option>
            <option value="aluminum_window_flipper_fixed" ${selectedType==='aluminum_window_flipper_fixed'?'selected':''}>🪟 نافذة ألمنيوم قلاب وثابت (معكوسة)</option>
            <option value="aluminum_sliding_67" ${selectedType==='aluminum_sliding_67'?'selected':''}>↔️ نافذة ألمنيوم سحاب ضلفتين نظام 67</option>
            <option value="aluminum_sliding_normal" ${selectedType==='aluminum_sliding_normal'?'selected':''}>↔️ نافذة المونيوم سحاب عادي (غير 67)</option>
            <option value="aluminum_67" ${selectedType==='aluminum_67'?'selected':''}>↔️ ألمنيوم سحاب نظام 67</option>
            <option value="aluminum_door" ${selectedType==='aluminum_door'?'selected':''}>🚪 باب ألمنيوم</option>
            <option value="aluminum_door_double" ${selectedType==='aluminum_door_double'?'selected':''}>🚪 باب ألمنيوم ضلفتين</option>
          </optgroup>`;
      const customKeys = Object.keys(customTypeRegistry);
      if (customKeys.length > 0) {
        html += `<optgroup label="🧩 أنواع مخصصة">`;
        customKeys.forEach(key => {
          html += `<option value="${escHtml(key)}" ${selectedType===key?'selected':''}>${escHtml(customTypeRegistry[key])}</option>`;
        });
        html += `</optgroup>`;
      }
      return html;
    }

    // يُحدّث كل قوائم "نوع العملية" الظاهرة حالياً على الشاشة لتشمل أي نوع مخصص أُضيف أو حُذف
    function refreshAllTypeSelects() {
      document.querySelectorAll('.type-select').forEach(sel => {
        const current = sel.value;
        sel.innerHTML = buildTypeSelectOptions(current);
        if (sel.value !== current) sel.value = ''; // النوع المحذوف يعود لغير مُحدَّد
      });
    }

    // ميزة التغيير التلقائي للنوع مثل العنصر الأول
    /* الاختيار الواحد يُطبَّق على كل الحقول المخفية.
       يُستدعى عند تغييره وبعد كل بناء لجدول القياسات، فأي صف يُضاف لاحقاً
       يرث النظام المختار ولا يبقى على الافتراضي. */
    function onGlobalProfileChanged() {
      const g = document.getElementById('global-profile');
      if (!g || !g.value) return;
      document.querySelectorAll('.profile-select').forEach(sel => { sel.value = g.value; });
      try { scheduleDraftSave(); } catch (e) {}
    }

    // يملأ القائمة الواحدة بالأنظمة المتاحة ويحافظ على المختار إن بقي موجوداً
    function refreshGlobalProfileOptions() {
      const g = document.getElementById('global-profile');
      if (!g) return;
      const prev = g.value;
      const names = Object.keys(appProfiles);
      g.innerHTML = names.map(n => `<option value="${escHtml(n)}">${escHtml(n)}</option>`).join('');
      if (prev && names.indexOf(prev) > -1) g.value = prev;
      onGlobalProfileChanged();
    }

    // اسم قديم محفوظ للتوافق مع أي نداء متبقٍ
    function onFirstProfileChanged() { onGlobalProfileChanged(); }

    /* ════════════════════════════════════════════════════════════
       عرض النتائج كجدول — خيار ثانٍ لا يُلغي البطاقات
       ------------------------------------------------------------
       البطاقات تعرض كل مقاس على حدة، وهي أوضح لمن يقصّ مقاساً واحداً.
       أما من يقارن عشرة مقاسات ببعضها — أو ينقل الأرقام إلى ورقة — فيريد
       صفّاً لكل بند وعموداً لكل مقاس، كجدول إكسل.

       الاثنان يقرآن **نفس النتائج المحسوبة** (_lastCutResults) فلا يختلف
       رقم بين العرضين، ولا يُعاد الحساب عند التبديل.
       ════════════════════════════════════════════════════════════ */
    let resultsAsTable = false;

    /* الجدول مقسَّم صفحات — إضافة 8.8
       ------------------------------------------------------------
       أعمدة الجدول هي المقاسات، فكراسة فيها عشرون مقاساً كانت تبني
       عشرين عموداً دفعة واحدة: صفّ يمتدّ عرضاً بلا نهاية، وعلى الهاتف
       لا يظهر منه إلا عمود ونصف، والقارئ يفقد موضعه بين الأعمدة.

       الآن ثلاثة مقاسات في الصفحة، والصفحة التالية تعرض **الثلاثة
       التالية وحدها** — لا تتراكم ولا تتكرر الأولى معها. فمن يقرأ
       الصفحة الثانية يرى المقاسات 4 و5 و6 فقط، كورقة تُقلب.

       التنقّل بزرّين، وبالسحب أيضاً حين لا يفيض الجدول عن عرض الشاشة
       (وإلا تعارض السحب مع تمرير الجدول نفسه فضاع الاثنان). */
    /* ⚠️ 9.2.0 — عدد الأعمدة صار يتبع عرض الشاشة بدل ثلاثة ثابتة.

       كان ثابتاً عند ٣. فكراسة فيها عشرون مقاساً تصير سبع صفحات يقلبها
       المشغّل واحدةً واحدةً وهو واقف عند المنشار — ولا يستطيع مقارنة
       مقاسين في صفحتين مختلفتين إطلاقاً، وهو أكثر ما يُحتاج إليه في
       القص (تشابُه المقاسات هو مصدر الخطأ الأشيع).

       الآن: يُحسب كم عموداً يسع عرضَ الشاشة فعلياً (٩٠ بكسل للعمود،
       و١١٠ لعمود البند)، بحدّ أدنى ٣ وأقصى ٨. فالهاتف العريض والجهاز
       اللوحي يعرضان أكثر، والصغير لا ينكسر. */
    function rtPerPage() {
      const w = (document.getElementById('results') || document.body).clientWidth || 360;
      return Math.max(3, Math.min(8, Math.floor((w - 96) / 72)));
    }
    let rtPage = 0;                 // رقم الصفحة، يبدأ من صفر

    function rtPageCount() {
      const d = window._lastCutResults;
      const n = (d && Array.isArray(d.rows)) ? d.rows.length : 0;
      return Math.max(1, Math.ceil(n / rtPerPage()));
    }

    function toggleResultsView() {
      resultsAsTable = !resultsAsTable;
      rtPage = 0;                   // نبدأ من الصفحة الأولى في كل مرة
      renderResultsTable();
    }

    function rtGoTo(page) {
      const last = rtPageCount() - 1;
      const next = Math.min(Math.max(0, page), last);
      if (next === rtPage) return;
      rtPage = next;
      renderResultsTable();
    }
    function rtNext() { rtGoTo(rtPage + 1); }
    function rtPrev() { rtGoTo(rtPage - 1); }

    function renderResultsTable() {
      const data = window._lastCutResults;
      const host = document.getElementById('results');
      if (!data || !Array.isArray(data.rows) || !data.rows.length) return;

      if (!resultsAsTable) { calculateAll(); return; }   // العودة لعرض البطاقات

      const total  = data.rows.length;
      const pages  = rtPageCount();
      if (rtPage > pages - 1) rtPage = pages - 1;
      if (rtPage < 0) rtPage = 0;
      const from  = rtPage * rtPerPage();
      const shown = data.rows.slice(from, from + rtPerPage());   // هذه الصفحة وحدها

      /* البنود تُجمع من **كل** المقاسات لا من الظاهر منها فقط، وإلا
         تغيّرت صفوف الجدول كلما حُمّل عمود جديد — فيقفز ما يقرؤه
         المستخدم تحت عينه. */
      const labels = [];
      data.rows.forEach(r => Object.keys(r.res || {}).forEach(k => {
        if (labels.indexOf(k) === -1) labels.push(k);
      }));

      const head = shown.map(r =>
        /* ⚠️ 9.2.0 — الأبعاد كانت تُقرأ مقلوبة.
           النص «120×210» داخل صفحة dir="rtl" يُعاد ترتيبه بصرياً فيظهر
           «210×120»، لأن × محرف محايد الاتجاه يتبع سياقه. فيقرأ المشغّل
           العرض ارتفاعاً والارتفاع عرضاً — وهو خطأ لا يُكتشف إلا بعد
           القصّ. dir="ltr" يثبّت الترتيب كما كُتب. */
        `<th>المثال ${r.index}<br>${window.WSOpeningSymbols.html(r,52)}<br>${escHtml(r.symbolLabel||'')}<br><span class="rt-sub" dir="rtl">${wsDimensionPair(r.w,r.h)}</span></th>`).join('');

      const body = labels.map(lab => `
        <tr>
          <th class="rt-lab">${escHtml(lab)}</th>
          ${shown.map(r => {
            const v = (r.res || {})[lab];
            /* ⚠️ 9.2.0 — توحيد الدقّة.
               كانت القيم تُعرض كما خرجت من الحساب: 46.3 بجوار 970.02
               بجوار 1111.07. والاختلاف ليس تجميلياً — المشغّل يقرأ عموداً
               رأسياً بسرعة، واختلافُ عدد الخانات بعد الفاصلة يُبطئ القراءة
               ويُغري بالخلط بين 970.02 و 97.002.
               خانة واحدة تكفي للقص (دقّة المليمتر)، والصحيح يُعرض بلا
               فاصلة أصلاً. */
            const shown = (typeof v === 'number' && isFinite(v))
              ? (Number.isInteger(v) ? String(v) : v.toFixed(1))
              : v;
            return `<td dir="ltr">${shown === undefined || shown === null || shown === '' ? '—' : escHtml(shown)}</td>`;
          }).join('')}
        </tr>`).join('');

      const first = from + 1, lastIdx = from + shown.length;

      host.innerHTML = `
        <div class="results-actions">
          <button type="button" class="share-inline-btn" onclick="shareResults()">📤 مشاركة النتائج</button>
          <button type="button" class="view-toggle-btn" onclick="toggleResultsView()">🗂️ عرض كبطاقات</button>
        </div>
        ${data.customer ? `<div class="rt-title">${escHtml(data.customer)}</div>` : ''}
        ${wsCutSymbolSummary([],data.pending||[])}
        <div class="rt-wrap" id="rt-wrap">
          <table class="rt">
            <thead><tr><th class="rt-corner">البند</th>${head}</tr></thead>
            <tbody>${body}</tbody>
          </table>
        </div>
        <div class="rt-nav">
          <button type="button" class="rt-btn" onclick="rtPrev()" ${rtPage === 0 ? 'disabled' : ''}>
            ⟶ السابق
          </button>
          <div class="rt-pos">
            <div class="rt-pos-main">صفحة ${rtPage + 1} من ${pages}</div>
            <div class="rt-pos-sub">المقاسات ${first}${lastIdx > first ? '–' + lastIdx : ''} من ${total}</div>
          </div>
          <button type="button" class="rt-btn" onclick="rtNext()" ${rtPage >= pages - 1 ? 'disabled' : ''}>
            التالي ⟵
          </button>
        </div>
        ${pages > 1 ? `<div class="rt-hint">اسحب الجدول يميناً أو يساراً لقلب الصفحة.</div>` : ''}`;

      if(data.rawReport)host.insertAdjacentHTML('beforeend',data.rawReport);
      const wrap = document.getElementById('rt-wrap');
      if (!wrap || pages <= 1) return;

      /* ⚠️ 9.6.0 — أُلغي السحب لقلب صفحة الجدول.

         كان يشترط ألّا يفيض الجدول وأن تغلب السحبة أفقياً — شرطان
         يفشلان كثيراً في الاستعمال: الإصبع نادراً ما يسحب أفقياً محضاً،
         فتُلتقط سحبة أرادها المستخدم تمريراً للصفحة فتقلب الجدول تحت
         عينه، أو يسحب ليقلب فلا يقع شيء لأن الميل رأسي قليلاً.

         وحركةٌ تعمل أحياناً أسوأ من حركة لا تعمل: الأولى تُفقد الثقة
         بالواجهة كلها. وزرّا «السابق/التالي» يفعلان الشيء نفسه بيقين
         وهما ظاهران دائماً. */

    }

    function shareResults() {
      const resultsDiv = document.getElementById('results');
      if (!resultsDiv.innerHTML.trim()) {
        showToast('لا توجد نتائج للمشاركة', 'error');
        return;
      }

      /* ⚠️ إصلاح 8.8 — خطر أحدثه تقسيم الجدول صفحات:
         الدالة كانت تقرأ نصّ #results من الشاشة. وفي وضع الجدول لم يعد
         على الشاشة إلا **صفحة واحدة**، أي ثلاثة مقاسات. فمن يشارك وهو
         في الصفحة الثانية يُرسل ثلاثة مقاسات من عشرين — والمستلم في
         الورشة لا شيء يدلّه على أن البقية ناقصة، فيقصّ على ما وصله.

         الآن في وضع الجدول نبني النصّ من النتائج المحفوظة كلها
         (_lastCutResults) لا من المعروض. وفي وضع البطاقات نُبقي قراءة
         الشاشة (فهي تعرض كل شيء) بعد نزع أزرار الواجهة وشريط التنقّل،
         وكانت نصوصها تُرسَل ضمن الرسالة. */
      let text;
      const data = window._lastCutResults;
      if (resultsAsTable && data && Array.isArray(data.rows) && data.rows.length) {
        const parts = data.rows.map(r => {
          const lines = Object.keys(r.res || {})
            .map(k => {
              const v = r.res[k];
              return (v === undefined || v === null || v === '') ? null : `${k}: ${v}`;
            })
            .filter(Boolean);
          return `— المثال ${r.index} (عرض ${r.w} — ارتفاع ${r.h}) ${r.symbolLabel||''}:\n` + lines.map(l => '   ' + l).join('\n');
        });
        text = parts.join('\n\n');
        if(data.pending?.length)text+='\n\nلم تُحسب بعد:\n'+data.pending.map(r=>'المقاس '+r.index+' — '+(r.symbolLabel||'')+' — '+r.pending).join('\n');
      } else {
        const temp = document.createElement('div');
        temp.innerHTML = resultsDiv.innerHTML;
        temp.querySelectorAll('.results-actions, .rt-nav, .rt-hint').forEach(el => el.remove());
        text = temp.innerText || temp.textContent;
      }
      // الاسم يتصدّر النص المُشارك أيضاً، لا صورة النتائج وحدها
      const who = (document.getElementById('cut-customer')?.value || '').trim();
      const head = who ? `نتائج القص — ${who}` : 'نتائج الحاسبة';
      const shareText = `${head}:\n\n${text}\n\n---\nحاسبة أبواب ونوافذ`;

      if (navigator.share) {
        navigator.share({ title: head, text: shareText }).catch(err => copyToClipboard(shareText));
      } else {
        copyToClipboard(shareText);
      }
    }

    function copyToClipboard(text) {
      navigator.clipboard.writeText(text).then(() => {
        showToast('تم نسخ النتائج إلى الحافظة', 'success');
      }).catch(err => {
        showToast('فشل النسخ إلى الحافظة', 'error');
      });
    }

    /* يقرأ السطر: العرض ثم الارتفاع، وأي كلام بعدهما يُعتبر ملاحظة لهذا القياس.
       بهذا تصل ملاحظة الكراسة ونوعها إلى خانة ملاحظات القياس في صفحة القص،
       وتبقى محفوظة حتى لو أُعيد الضغط على «تحضير القياسات». */
    function parseLine(line) {
      line = String(line == null ? '' : line)
        // محارف اتجاه غير مرئية تأتي مع النسخ من التطبيقات العربية
        .replace(/[\u200E\u200F\u061C\u202A-\u202E\u2066-\u2069\uFEFF]/g, '')
        .replace(/\u00A0/g, ' ')
        .trim();
      /* ⚠️ إصلاح 8.8 — أخطر خلل حسابي في هذه الصفحة:
         لم يكن فيها أي تحويل للأرقام العربية إطلاقاً (بخلاف الفواتير
         والقياسات). والنمط أدناه يستعمل [\d.] و\d لا تطابق إلا 0-9
         اللاتينية — فسطر «١٢٠ × ٢١٠» لا يطابق شيئاً، ويسقط إلى
         الاحتياطي فلا يجد أرقاماً، فيُعاد null: المقاس يُهمَل بصمت.
         وإن مرّ نصفه تُقرأ NaN فتُحسب أطوال قصّ خاطئة — ويُقصّ
         الألمنيوم عليها. خسارة مادة لا تُسترجع.
         التحويل يقع هنا قبل أي مطابقة، على كل مسارات التحليل. */
      line = (typeof wsToLatinDigits === 'function') ? wsToLatinDigits(line).trim() : line;
      if (!line) return null;

      const m = line.match(/^\s*([\d.]+)\s*(?:[x*\u00D7X\-]|\s)\s*([\d.]+)\s*(.*)$/);
      if (m) {
        const w = parseFloat(m[1]), h = parseFloat(m[2]);
        if (!isNaN(w) && !isNaN(h)) {
          const note = (m[3] || '').replace(/^[\s\-\u2013\u2014:,\u060C|]+/, '').trim();
          return { w: w, h: h, note: note };
        }
      }

      // احتياطي: السلوك القديم لأي صيغة غير متوقعة
      const cleaned = line.replace(/x|\*|-/g, ' ');
      const numbers = cleaned.match(/[\d.]+/g);
      if (!numbers || numbers.length < 2) return null;
      return { w: parseFloat(numbers[0]), h: parseFloat(numbers[1]), note: '' };
    }

    function toggleEqualDoorLeaves(box) {
      const field=box.closest(".extra-door-double").querySelector(".manual-large-leaf");
      field.disabled=box.checked; if(box.checked) field.value="";
    }
    function toggleExtraInputs(selectElement) {
      const type = selectElement.value;
      const container = selectElement.closest('.measurement-item');
      const doubleTopGroup = container.querySelector('.extra-double-top');
      const flipperGroup = container.querySelector('.extra-flipper');
      const doorDoubleGroup = container.querySelector('.extra-door-double');
      const leafFixedGroup = container.querySelector('.extra-leaf-fixed');
      const iconSpan = container.querySelector('.measurement-type-icon');
      if (iconSpan) iconSpan.textContent = getTypeIcon(type);

      if (doubleTopGroup) doubleTopGroup.style.display = 'none';
      if (flipperGroup) flipperGroup.style.display = 'none';
      if (doorDoubleGroup) doorDoubleGroup.style.display = 'none';
      if (leafFixedGroup) leafFixedGroup.style.display = 'none';

      if (type === 'window_double_top') {
        if (doubleTopGroup) doubleTopGroup.style.display = 'block';
      } else if (type === 'window_flipper') {
        if (flipperGroup) flipperGroup.style.display = 'block';
      } else if (['door_double','aluminum_door_double'].includes(type)) {
        if (doorDoubleGroup) doorDoubleGroup.style.display = 'block';
      } else if (['window_leaf_fixed','aluminum_window_leaf_fixed','aluminum_window_flipper_fixed'].includes(type)) {
        if (leafFixedGroup) leafFixedGroup.style.display = 'block';
      }
    }

    // v331: resolve only explicit operation IDs, never guess from free-text notes.
    function wsResolveMeasurementFormula(item) {
      const key = item && typeof item.cuttingFormula === 'string' ? item.cuttingFormula : '';
      if (!key) return '';
      if(window.WSStudio?.validSnapshot(item.formulaSnapshot,key,item.cuttingProfile||'الافتراضي'))return key;
      const known = Object.prototype.hasOwnProperty.call(typeNames, key) ||
        Object.prototype.hasOwnProperty.call(customTypeRegistry, key);
      return known && Object.values(appProfiles).some(profile =>
        profile && Object.prototype.hasOwnProperty.call(profile, key) && Array.isArray(profile[key]) && profile[key].length > 0
      ) ? key : '';
    }

    function prepareMeasurements(sourceItems) {
      const bulkInput = document.getElementById('bulk-input').value;
      const lines = bulkInput.split('\n');
      const container = document.getElementById('measurements-container');
      container.innerHTML = '';

      /* ══ متى نعرض الرسوم؟ ══
         الرسوم تصل مصفوفةً بترتيب المقاسات، فالربط بينها وبين الصفوف
         بالفهرس. وهذا يصحّ ما دام النص لم يُمسّ — فإن حذف المستخدم سطراً
         أو أعاد ترتيبها اختلّت المطابقة، فيظهر رسم شبّاك بجانب مقاس باب.
         ورسمٌ خطأ أسوأ من لا رسم: يُقصّ عليه ولا يُراجَع.

         فنعرضها فقط حين يطابق عدد المقاسات المقروءة عدد الرسوم. */
      // Structured rows keep notes with newlines from shifting formula-to-row matching.
      window._lastCutResults=null;
      const imported = Array.isArray(sourceItems) ? sourceItems : null;
      const parsed = imported ? imported.filter(it => it && wsNum(it.w, NaN) > 0 && wsNum(it.h, NaN) > 0)
        .map(it => ({w:wsNum(it.w), h:wsNum(it.h), note:it.note || '', source:it}))
        : lines.map(parseLine).filter(Boolean);
      let missingFormulas = 0;
      const showSketches = Array.isArray(cutSketches) &&
                           cutSketches.length === parsed.length &&
                           cutSketches.some(x => !!x);

      let index = 1;
      parsed.forEach(dim => {

        const div = document.createElement('div');
        div.className = 'measurement-item';
        // dim.note يحمل نوع المقاس وملاحظته القادمين من كراسة القياسات
        const formula = wsResolveMeasurementFormula(dim.source);
        if (dim.source && dim.source.cuttingFormula && !formula) missingFormulas++;
        div.wsOpening=window.WSOpeningSymbols.metadata(dim.source);
        div.wsRequestedProfile=dim.source?.cuttingProfile||'';
        div.wsFormulaSnapshot=dim.source?.formulaSnapshot||null;div.wsOpeningLayout=dim.source?.openingLayout||null;div.wsAccessoryExceptions=dim.source?.accessoryExceptions||{};
        const equalDoor=div.wsOpening.leafLayout==='equal' && ['door_double','aluminum_door_double'].includes(formula);
        div.innerHTML = createMeasurementHTML(index, dim.w, dim.h, formula, equalDoor?'__equal__':'', dim.note || '', '', div.wsOpening);

        // رسم المقاس داخل بطاقته: القصّاص يرى الشكل أمام أرقامه بلا فتح الكراسة
        const sk = dim.source ? (dim.source.img || '') : (showSketches ? cutSketches[index - 1] : '');
        if (sk) {
          const box = document.createElement('div');
          box.className = 'm-sketch';
          const im = document.createElement('img');
          /* إصلاح 8.8.5 — مصدر الصورة يأتي من measurementJobs التي يكتبها أي
             عضو. المتصفح لا ينفّذ javascript: في src، لكن رابطاً خارجياً
             يكفي لتتبّع من فتح أي كراسة ومتى، ويُسرّب ذلك بمجرد العرض.
             نقصره على الصور المضمّنة (data:) أو https. */
          im.src = /^(data:image\/(png|jpe?g|gif|webp|svg\+xml);|https:\/\/)/i.test(String(sk)) ? sk : '';
          im.alt = 'رسم المقاس ' + index;
          im.loading = 'lazy';
          box.appendChild(im);
          const cap = document.createElement('div');
          cap.className = 'm-sketch-cap';
          cap.textContent = 'رسم المقاس ' + index;
          box.appendChild(cap);
          div.appendChild(box);
        }

        container.appendChild(div);
        index++;
      });

      if (index === 1) {
        container.innerHTML = '<div style="color:red;text-align:center;">لم يتم العثور على قياسات صالحة.</div>';
      }
      if (missingFormulas) showToast('بعض المعادلات المحفوظة غير متوفرة على هذا الجهاز. ارفع نظامها أو اختر العملية يدوياً للصفوف الفارغة.', 'error');
      onGlobalProfileChanged();
      Array.from(container.children).forEach(div=>{
        if(!div.wsRequestedProfile)return;
        const select=div.querySelector('.profile-select');if(!select)return;
        const name=div.wsRequestedProfile;
        if(!Array.from(select.options).some(o=>o.value===name))select.add(new Option('نظام غير موجود: '+name,name));
        select.value=name;
        const label=document.createElement('small');label.textContent='نظام المعادلات: '+name;div.appendChild(label);
      });
      // الصفوف المبنيّة للتو ترث النظام المختار
      refreshApplyAllBar();
      saveDraft();
    }

    /* ============================================================
       تحديد نوع عملية واحد لكل القياسات دفعة واحدة
       حين تأتي مقاسات كثيرة من نفس النوع، بدل اختيار النوع في كل
       قياس على حدة. ويبقى بالإمكان تغيير أي قياس منفرد بعدها.
       ============================================================ */
    function refreshApplyAllBar() {
      const bar = document.getElementById('apply-all-bar');
      const sel = document.getElementById('apply-all-type');
      const cnt = document.getElementById('aab-count');
      if (!bar || !sel) return;

      const items = document.querySelectorAll('#measurements-container .measurement-item');
      if (!items.length) { bar.style.display = 'none'; return; }

      // نحافظ على اختيار المستخدم السابق عند إعادة البناء
      const prev = sel.value;
      sel.innerHTML = buildTypeSelectOptions(prev || '');
      if (prev) sel.value = prev;

      cnt.textContent = items.length + (items.length === 1 ? ' قياس' : ' قياسات');
      bar.style.display = 'block';
    }

    function applyTypeToAll() {
      const sel = document.getElementById('apply-all-type');
      const type = sel ? sel.value : '';
      if (!type) { alert('اختر نوع العملية أولاً.'); return; }

      const items = document.querySelectorAll('#measurements-container .measurement-item');
      if (!items.length) { alert('لا توجد قياسات محضّرة.'); return; }

      const name = operationDisplayName(type);
      if (!confirm('سيتم تعيين «' + name + '» لكل القياسات وعددها ' + items.length + '.\n\nهل تريد المتابعة؟')) return;

      items.forEach(item => {
        const ts = item.querySelector('.type-select');
        if (!ts) return;
        ts.value = type;
        toggleExtraInputs(ts);      // يُظهر الحقول الإضافية الخاصة بالنوع (عرض الضلفة... إلخ)
      });

      saveDraft();

      // تنبيه بالحقول الإضافية التي تحتاج تعبئة يدوية
      const needsManual = ['window_double_top', 'window_flipper', 'door_double', 'aluminum_door_double', 'window_leaf_fixed', 'aluminum_window_leaf_fixed', 'aluminum_window_flipper_fixed'];
      if (needsManual.indexOf(type) !== -1) {
        alert('✅ تم تعيين «' + name + '» لكل القياسات.\n\nتنبيه: هذا النوع يحتاج قيمة إضافية في كل قياس (عرض/ارتفاع الضلفة)، فاملأها قبل الحساب.');
      } else {
        alert('✅ تم تعيين «' + name + '» لكل القياسات وعددها ' + items.length + '.');
      }
    }

    /* عُقلت قواعد التحقق من الصيغ إلى أعلى الملف — انظر isSafeFormula هناك. */

    function calculateItem(w, h, type, manualValue = 0, profileName = "الافتراضي", frozen = null, layout = null) {
      const engFile={cutProfiles:appProfiles,workshopOptions:window.WSStudio?.options()};
      const activeFormulas = frozen ? {[type]:frozen} : window.WSEngine?window.WSEngine.resolveProfile(engFile,profileName):appProfiles[profileName] || appProfiles["الافتراضي"];
      const namedParams=frozen?{}:{...(window.WSEngine?.params(engFile,profileName)||{}),...(window.WSEngine?.counts(type,layout,w,h)||{})};
      if (!activeFormulas[type]) return {};

      const vars = { w, h };
      if (type === 'window_double_top') vars.manualLeafW = manualValue;
      else if (type === 'window_flipper') vars.flipH = manualValue;
      else if (type === 'door_double') vars.largeW = manualValue;
      else if (type === 'aluminum_door_double') vars.manualLeafW = manualValue;
      else if (['window_leaf_fixed','aluminum_window_leaf_fixed','aluminum_window_flipper_fixed'].includes(type)) vars.manualLeafW = manualValue;

      const items = activeFormulas[type];
      const results = {};

      items.forEach(item => {
        let value;
        try {
          const keys = Object.keys(vars);
          const values = Object.values(vars);
          /* المعادلات تُنفَّذ بـ new Function، وهي محفوظة محلياً ويحرّرها
             المستخدم. نتحقق من صيغتها أولاً حتى لا يُنفَّذ نص تالف أو
             مدسوس لو وصل إلى التخزين المحلي بأي طريق. */
          const expression=(!frozen&&window.WSEngine)?window.WSEngine.compile(item.calc,namedParams):item.calc;
          if (!isSafeFormula(expression)) { results[item.label] = 'صيغة غير صالحة'; return; }
          const func = new Function(...keys, `"use strict"; return (${expression});`);
          value = func(...values);
          if (typeof value === 'number' && isFinite(value)) {
            value = preciseRound(value, 2);
          } else {
            value = 'خطأ';
          }
        } catch (e) {
          value = 'خطأ';
        }
        if (item.saveAs && value !== 'خطأ' && typeof value === 'number') {
          vars[item.saveAs] = value;
        }
        results[item.label] = value;
      });

      return results;
    }

    // ===== قوالب بناء البنود لصفحة "إضافة معادلة جديدة كليًا" — بلا كتابة أكواد، فقط اختيارات =====
    const CUSTOM_ROW_TEMPLATES = {
      w_minus:       { label: 'العرض − رقم',                              build: n => `w - ${n}`,            needsNum: true },
      w_minus_half:  { label: '(العرض − رقم) ÷ 2  (لضلفتين متماثلتين)',    build: n => `(w - ${n}) / 2`,      needsNum: true },
      w_plus:        { label: 'العرض + رقم',                              build: n => `w + ${n}`,            needsNum: true },
      w_copy:        { label: 'نسخ العرض كما هو (بدون تعديل)',             build: () => `w`,                  needsNum: false },
      h_minus:       { label: 'الارتفاع − رقم',                           build: n => `h - ${n}`,            needsNum: true },
      h_minus_half:  { label: '(الارتفاع − رقم) ÷ 2',                     build: n => `(h - ${n}) / 2`,      needsNum: true },
      h_plus:        { label: 'الارتفاع + رقم',                           build: n => `h + ${n}`,            needsNum: true },
      h_copy:        { label: 'نسخ الارتفاع كما هو (بدون تعديل)',          build: () => `h`,                  needsNum: false },
      perimeter_plus:{ label: 'محيط الإطار: (العرض + الارتفاع) × 2 + رقم', build: n => `(w + h) * 2 + ${n}`,  needsNum: true }
    };
    let customRowIdCounter = 0;

    function customRowCardHTML(rowId) {
      let options = '';
      Object.entries(CUSTOM_ROW_TEMPLATES).forEach(([key, t]) => {
        options += `<option value="${escHtml(key)}">${escHtml(t.label)}</option>`;
      });
      return `
        <div class="custom-row-card" id="custom-row-${rowId}">
          <button type="button" class="remove-row-btn" onclick="removeCustomFormulaRowUI(${rowId})" title="حذف هذا البند">✕</button>
          <div class="row-grid">
            <div class="row-label-field">
              <label>تسمية النتيجة</label>
              <input type="text" id="custom-row-label-${rowId}" placeholder="مثال: عرض القص">
            </div>
            <div>
              <label>نوع الحساب</label>
              <select id="custom-row-calctype-${rowId}" onchange="updateCustomRowNumVisibility(${rowId})">
                ${options}
              </select>
            </div>
            <div id="custom-row-num-wrap-${rowId}">
              <label>الرقم</label>
              <input type="number" step="0.01" id="custom-row-num-${rowId}" placeholder="مثال: 12.2">
            </div>
          </div>
        </div>
      `;
    }
    function addCustomFormulaRowUI() {
      customRowIdCounter++;
      const container = document.getElementById('custom-type-rows');
      if (!container) return;
      const wrap = document.createElement('div');
      wrap.innerHTML = customRowCardHTML(customRowIdCounter);
      container.appendChild(wrap.firstElementChild);
    }
    function removeCustomFormulaRowUI(rowId) {
      const el = document.getElementById('custom-row-' + rowId);
      if (el) el.remove();
    }
    function updateCustomRowNumVisibility(rowId) {
      const select = document.getElementById('custom-row-calctype-' + rowId);
      const wrap = document.getElementById('custom-row-num-wrap-' + rowId);
      const t = CUSTOM_ROW_TEMPLATES[select.value];
      if (wrap) wrap.style.display = t.needsNum ? 'block' : 'none';
    }

    function saveNewCustomType() {
      const nameInp = document.getElementById('new-type-name');
      const name = nameInp.value.trim();
      if (!name) { showToast('من فضلك اكتب اسماً لنوع العملية الجديد', 'error'); return; }

      const rowCards = document.querySelectorAll('#custom-type-rows .custom-row-card');
      if (rowCards.length === 0) { showToast('أضف بند نتيجة واحداً على الأقل', 'error'); return; }

      const rows = [];
      for (const card of rowCards) {
        const id = card.id.replace('custom-row-', '');
        const label = document.getElementById('custom-row-label-' + id).value.trim();
        const calcType = document.getElementById('custom-row-calctype-' + id).value;
        const numInp = document.getElementById('custom-row-num-' + id);
        const template = CUSTOM_ROW_TEMPLATES[calcType];
        if (!label) { showToast('يرجى كتابة تسمية لكل بند نتيجة', 'error'); return; }
        let numVal = '';
        if (template.needsNum) {
          numVal = (numInp.value || '').trim();
          // إصلاح 8.8: كان الإدخال بالأرقام العربية يُرفض برسالة «أدخل رقماً صحيحاً»
          const _nv = wsNum(numVal, NaN);
          if (numVal === '' || isNaN(_nv)) { showToast(`يرجى إدخال رقم صحيح لبند «${label}»`, 'error'); return; }
          numVal = String(_nv);
        }
        rows.push({ label, calc: template.build(numVal), editNum: template.needsNum ? numVal : '' });
      }

      const labels = rows.map(r => r.label);
      if (new Set(labels).size !== labels.length) {
        showToast('لا يمكن تكرار نفس تسمية النتيجة أكثر من مرة في النوع نفسه', 'error');
        return;
      }

      const key = 'custom_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
      customTypeRegistry[key] = name;
      typeNames[key] = name;
      saveCustomTypesRegistry();

      Object.keys(appProfiles).forEach(pName => {
        appProfiles[pName][key] = JSON.parse(JSON.stringify(rows));
      });
      try { localStorage.setItem('app_custom_profiles', JSON.stringify(appProfiles)); } catch (e) { console.error('تعذّر حفظ الأنظمة محلياً:', e); }

      nameInp.value = '';
      document.getElementById('custom-type-rows').innerHTML = '';
      addCustomFormulaRowUI();

      refreshAllTypeSelects();
      renderCustomTypesList();
      showToast(`تمت إضافة «${name}» بنجاح، وأصبح متاحاً الآن ضمن قائمة "نوع العملية"`, 'success');
    }

    function renderCustomTypesList() {
      const container = document.getElementById('custom-types-list');
      if (!container) return;
      const keys = Object.keys(customTypeRegistry);
      if (keys.length === 0) {
        container.innerHTML = '<div style="font-size:13px;color:#939597;">لا توجد أنواع عمليات مخصصة بعد.</div>';
        return;
      }
      container.innerHTML = keys.map(key => `
        <div class="custom-type-chip">
          <span>🧩 ${escHtml(customTypeRegistry[key])}</span>
          <button type="button" onclick="deleteCustomType('${escAttr(key)}')" title="حذف هذا النوع نهائياً">🗑️</button>
        </div>
      `).join('');
    }

    function deleteCustomType(key) {
      const name = customTypeRegistry[key] || key;
      if (!confirm(`هل تريد حذف نوع العملية «${name}» نهائياً من كل الأنظمة؟ لا يمكن التراجع عن هذا الإجراء.`)) return;
      window.WSSymbolFormulas?.remove(key);
      delete customTypeRegistry[key];
      delete typeNames[key];
      Object.keys(appProfiles).forEach(pName => { delete appProfiles[pName][key]; });
      saveCustomTypesRegistry();
      try { localStorage.setItem('app_custom_profiles', JSON.stringify(appProfiles)); } catch (e) { console.error('تعذّر حفظ الأنظمة محلياً:', e); }
      refreshAllTypeSelects();
      renderCustomTypesList();
      loadProfileToEditor(currentProfileName);
      showToast('تم حذف النوع المخصص', 'success');
    }

    function toggleEditor() {
      const div = document.getElementById('formulas-content');
      div.style.display = div.style.display === 'block' ? 'none' : 'block';
      if (div.style.display === 'block') buildSimpleNumberEditor();
    }

    function buildSimpleNumberEditor() {
      const div = document.getElementById('formulas-content');
      div.innerHTML = '<h3 class="editor-title">لوحة إنشاء وإدارة أنظمة التخصيص</h3>';

      let managerHtml = `
        <div class="profile-manager-box">
          <label>ملفات أنظمة المعادلات</label>
          <div class="clone-hint">نزّل النظام الحالي كملف مستقل لتعديله خارج التطبيق، ثم ارفعه هنا لإضافته كنظام جديد. <strong>لن يتم استبدال النظام الافتراضي أو أي نظام موجود.</strong></div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
            <button type="button" class="save-btn" style="margin:0;flex:1;min-width:180px;background:#147f8a;" onclick="downloadFormulaProfile('الافتراضي')">⬇️ تنزيل المعادلات الأصلية</button>
            <button type="button" class="save-btn" style="margin:0;flex:1;min-width:180px;background:#4c718a;" onclick="downloadFormulaProfile()">⬇️ تنزيل النظام الحالي</button>
            <button type="button" class="save-btn" style="margin:0;flex:1;min-width:180px;background:#365b78;" onclick="document.getElementById('formula-profile-file').click()">⬆️ رفع نظام معادلات جديد</button>
          </div>
          <input id="formula-profile-file" type="file" accept=".json,application/json" style="display:none" onchange="importFormulaProfileFile(this)">
          <div class="clone-hint" style="margin-top:8px;">الملف بصيغة JSON نصية قابلة للتعديل. يمكنك إنشاء النظام الثاني والثالث والرابع بنفس الطريقة.</div>
        </div>

        <div class="profile-manager-box">
          <label>اسم نظام التشغيل الجديد (مثل: بروفيل تركي خاص):</label>
          <input type="text" id="new-profile-name" placeholder="أدخل اسماً فريداً للنظام">
          <div class="clone-hint">سيتم نسخ كل الأرقام الحالية من نظام «<strong id="clone-source-name">${escHtml(currentProfileName)}</strong>» كنقطة بداية، ويمكنك تعديل أي رقم فيه بعد الإنشاء مباشرة.</div>
          <button class="save-btn" style="margin:0; background:linear-gradient(135deg,#96cee1,#499dba);" onclick="createNewProfile()">➕ إضافة هذا النظام كنسخة جديدة</button>
        </div>

        <div class="profile-manager-box">
          <label>زيادة الإطار (الشمبرلي) على العرض والارتفاع:</label>
          <input type="number" step="0.01" min="0" id="shamberly-offset-input" value="${getShamberlyOffset()}">
          <div class="clone-hint" id="shamberly-example">مثال: 100 × 90 ← ${trimNum(100 + getShamberlyOffset())} × ${trimNum(90 + getShamberlyOffset())}</div>
          <div class="clone-hint" style="margin-top:-4px;">تُطبَّق على كل الأنواع عدا السرانتي والمونيوم 67.</div>
          <button class="save-btn" style="margin:0; background:linear-gradient(135deg,#96cee1,#499dba);" onclick="setShamberlyOffset(document.getElementById('shamberly-offset-input').value)">💾 حفظ زيادة الإطار</button>
        </div>

        <div class="new-type-box">
          <h3 class="editor-title">🧩 إضافة معادلة (نوع عملية) جديدة كليًا</h3>
          <div class="clone-hint" style="margin-top:-4px;">
            أنشئ نوع عملية جديداً تماماً غير موجود في القائمة، ببنود نتائج خاصة بك. كل بند يُحسب مباشرة من العرض أو الارتفاع الذي تُدخله — بلا أي تسلسل بين البنود.
          </div>
          <label>اسم نوع العملية الجديد:</label>
          <input type="text" id="new-type-name" placeholder="مثال: نافذة خاصة بمقاس معين">
          <div id="custom-type-rows"></div>
          <button type="button" class="add-row-btn" onclick="addCustomFormulaRowUI()">➕ إضافة بند نتيجة</button>
          <button type="button" class="btn save-new-type-btn" onclick="saveNewCustomType()">✅ حفظ نوع العملية الجديد</button>
          <div style="margin-top:16px;">
            <label style="margin-bottom:8px;">الأنواع المخصصة الحالية:</label>
            <div class="custom-types-list" id="custom-types-list"></div>
          </div>
        </div>

        <hr style="border:none;border-top:1px dashed var(--border-color);margin:20px 0;">
        <div class="editor-toolbar">
          <div>
            <label>اختر نظام التشغيل لتعديل أرقامه التخصيصية الحالية:</label>
            <select id="editor-profile-select" onchange="loadProfileToEditor(this.value)">
      `;

      Object.keys(appProfiles).forEach(pName => {
        managerHtml += `<option value="${escHtml(pName)}" ${currentProfileName === pName ? 'selected' : ''}>${escHtml(pName)}</option>`;
      });
      managerHtml += `
            </select>
          </div>
          <button class="delete-profile-btn" id="delete-profile-btn" onclick="deleteCurrentProfile()">🗑️ حذف هذا النظام</button>
        </div>
        <div id="profile-inputs-container"></div>
      `;

      div.innerHTML += managerHtml;
      addCustomFormulaRowUI();
      renderCustomTypesList();
      loadProfileToEditor(currentProfileName);
    }

    function downloadFormulaProfile(profileName) {
      const sourceName = profileName || currentProfileName || 'الافتراضي';
      const formulas = appProfiles[sourceName];
      if (!formulas || typeof formulas !== 'object') {
        showToast('تعذّر تجهيز ملف المعادلات لهذا النظام', 'error');
        return;
      }
      const payload = {
        format: 'al-lamsa-formula-profile',
        version: 1,
        exportedAt: new Date().toISOString(),
        profileName: sourceName,
        customTypeNames: Object.fromEntries(Object.entries(customTypeRegistry).filter(([key]) => Object.prototype.hasOwnProperty.call(formulas, key))),
        formulas: JSON.parse(JSON.stringify(formulas))
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const safe = sourceName.replace(/[\\/:*?"<>|]+/g, '-').trim() || 'المعادلات';
      a.href = url;
      a.download = `نظام-المعادلات-${safe}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast(`تم تنزيل معادلات نظام «${sourceName}»`, 'success');
    }

    function wsValidateImportedFormulaMap(formulas) {
      if (!formulas || typeof formulas !== 'object' || Array.isArray(formulas)) throw new Error('بنية ملف المعادلات غير صحيحة');
      const out = {};
      for (const [type, rows] of Object.entries(formulas)) {
        if (!type || !Array.isArray(rows)) throw new Error(`البند «${type || 'غير معروف'}» غير صالح`);
        out[type] = rows.map((row, i) => {
          if (!row || typeof row !== 'object') throw new Error(`صف ${i + 1} في «${type}» غير صالح`);
          const label = String(row.label || '').trim();
          const calc = String(row.calc || '').trim();
          if (!label || !calc || !isSafeFormula(calc)) throw new Error(`المعادلة غير صالحة في «${type}» — ${label || 'صف بلا اسم'}`);
          return { label, calc, editNum: row.editNum == null ? '' : String(row.editNum) };
        });
      }
      if (!Object.keys(out).length) throw new Error('ملف المعادلات فارغ');
      return out;
    }

    function wsUniqueImportedProfileName(base) {
      let name = String(base || 'نظام مستورد').trim() || 'نظام مستورد';
      if (name === 'الافتراضي') name = 'نظام مستورد';
      if (!appProfiles[name]) return name;
      let i = 2;
      while (appProfiles[`${name} ${i}`]) i++;
      return `${name} ${i}`;
    }

    async function importFormulaProfileFile(input) {
      const file = input && input.files && input.files[0];
      if (!file) return;
      try {
        if (file.size > 2 * 1024 * 1024) throw new Error('الملف كبير جداً');
        const raw = await file.text();
        const payload = JSON.parse(raw);
        const formulas = wsValidateImportedFormulaMap(payload.formulas || payload);
        const baseName = String(payload.profileName || file.name.replace(/\.json$/i, '') || 'نظام مستورد').trim();
        const finalName = wsUniqueImportedProfileName(baseName);
        if (!confirm(`سيتم إضافة نظام جديد باسم «${finalName}».\n\nلن يتم تعديل أو استبدال «الافتراضي» أو أي نظام موجود.\n\nمتابعة؟`)) return;
        // أسماء المعادلات المخصصة يجب أن ترافق ملفها، وإلا تُستورد
        // معادلات صحيحة لكنها تختفي من قائمة أنواع العمليات.
        const names = payload.customTypeNames && typeof payload.customTypeNames === 'object' && !Array.isArray(payload.customTypeNames)
          ? payload.customTypeNames : {};
        for (const key of Object.keys(formulas)) {
          if (!key.startsWith('custom_')) continue;
          const label = String(names[key] || '').trim();
          if (!label || label.length > 120) throw new Error('اسم المعادلة المخصصة مفقود أو طويل: ' + key);
          if (customTypeRegistry[key] && customTypeRegistry[key] !== label) throw new Error('تعارض اسم معادلة موجودة: ' + key);
        }
        appProfiles[finalName] = formulas;
        Object.keys(formulas).forEach(key => {
          if (key.startsWith('custom_')) { customTypeRegistry[key] = String(names[key]).trim(); typeNames[key] = customTypeRegistry[key]; }
        });
        saveCustomTypesRegistry();
        currentProfileName = finalName;
        localStorage.setItem('app_custom_profiles', JSON.stringify(appProfiles));
        refreshAllProfileSelects();
        buildSimpleNumberEditor();
        showToast(`تمت إضافة نظام «${finalName}» بنجاح`, 'success');
      } catch (e) {
        console.error('استيراد نظام المعادلات:', e);
        showToast('تعذّر استيراد الملف: ' + (e.message || 'ملف غير صالح'), 'error');
      } finally {
        try { input.value = ''; } catch (e) {}
      }
    }

    function createNewProfile() {
      const nameInp = document.getElementById('new-profile-name');
      const name = nameInp.value.trim();
      if (!name) { showToast('من فضلك اكتب اسماً للنظام', 'error'); return; }
      if (appProfiles[name]) { showToast('هذا الاسم موجود مسبقاً، اختر اسماً آخر', 'error'); return; }

      appProfiles[name] = JSON.parse(JSON.stringify(appProfiles[currentProfileName]));
      currentProfileName = name;
      try { localStorage.setItem('app_custom_profiles', JSON.stringify(appProfiles)); } catch (e) { console.error('تعذّر حفظ الأنظمة محلياً:', e); }
      refreshAllProfileSelects();
      showToast(`تم إنشاء النظام الجديد «${name}» بنجاح`, 'success');
      buildSimpleNumberEditor();
    }

    function deleteCurrentProfile() {
      if (currentProfileName === 'الافتراضي') {
        showToast('لا يمكن حذف النظام الافتراضي', 'error');
        return;
      }
      if (!confirm(`هل أنت متأكد من حذف نظام «${currentProfileName}» نهائياً؟ لا يمكن التراجع عن هذا الإجراء.`)) return;

      delete appProfiles[currentProfileName];
      try { localStorage.setItem('app_custom_profiles', JSON.stringify(appProfiles)); } catch (e) { console.error('تعذّر حفظ الأنظمة محلياً:', e); }
      currentProfileName = 'الافتراضي';
      refreshAllProfileSelects();
      showToast('تم حذف النظام بنجاح', 'success');
      buildSimpleNumberEditor();
    }

    // تحديث قوائم البروفايل فوراً بعد إضافة نظام أو حذفه
    function refreshAllProfileSelects() {
      refreshGlobalProfileOptions();   // القائمة الواحدة فوق الجدول أولاً
      document.querySelectorAll('.profile-select').forEach(sel => {
        const currentVal = sel.value;
        let optionsHtml = '';
        Object.keys(appProfiles).forEach(pName => {
          optionsHtml += `<option value="${escHtml(pName)}" ${currentVal === pName ? 'selected' : ''}>${escHtml(pName)}</option>`;
        });
        sel.innerHTML = optionsHtml;
        if (![...sel.options].some(o => o.value === currentVal)) {
          sel.value = 'الافتراضي';
        }
      });
      saveDraft();
    }

    function loadProfileToEditor(pName) {
      currentProfileName = pName;
      const container = document.getElementById('profile-inputs-container');
      container.innerHTML = '';

      const cloneNameEl = document.getElementById('clone-source-name');
      if (cloneNameEl) cloneNameEl.textContent = pName;
      const deleteBtn = document.getElementById('delete-profile-btn');
      if (deleteBtn) deleteBtn.style.display = (pName === 'الافتراضي') ? 'none' : 'inline-block';

      let html = `<div class="editor-current-label">أنت تعدّل الآن أرقام النظام: <strong>${escHtml(pName)}</strong> — يتم الحفظ تلقائياً فور تغيير أي رقم، بلا أزرار إضافية.</div>`;
      const targetFormulas = appProfiles[pName];

      Object.keys(targetFormulas).forEach(key => {
        const name = typeNames[key] || key;
        let sectionHtml = '';
        let hasEdits = false;

        targetFormulas[key].forEach((item, i) => {
          if (item.editNum !== undefined && item.editNum !== "") {
            hasEdits = true;
            sectionHtml += `
              <div class="formula-item">
                <label>${escHtml(item.label)}</label>
                <!-- المعادلة كاملة أمام العين: تعديل رقم بلا رؤية موضعه من
                     المعادلة تخمينٌ محض — لا يُعرف أهو طرحٌ من العرض أم
                     من الارتفاع، ولا أثره على الناتج. -->
                <div class="formula-full" dir="ltr" title="المعادلة كاملة">${escHtml(item.calc)}</div>
                <div class="formula-input-row">
                  <input type="text" inputmode="decimal" value="${escHtml(item.editNum)}" data-profile="${escHtml(pName)}" data-type="${escHtml(key)}" data-index="${i}" class="profile-calc-input" onchange="handleProfileNumberChange(this)">
                  <span class="save-indicator" aria-hidden="true">✓</span>
                  <button type="button" class="formula-edit-btn" title="تحرير المعادلة كاملة"
                          onclick="editFullFormula('${escAttr(pName)}','${escAttr(key)}',${i})">✎ المعادلة</button>
                </div>
              </div>
            `;
          }
        });

        if (hasEdits) {
          html += `
            <details class="type-details">
              <summary><span class="chevron">◂</span> ${escHtml(name)}</summary>
              <div class="type-details-body">${sectionHtml}</div>
            </details>
          `;
        }
      });

      container.innerHTML = html;
    }

    /* ══ تحرير المعادلة كاملة ══
       تعديل الرقم وحده يعمل بالاستبدال النصي داخل المعادلة، وله حدّ:
       لو تكرّر الرقم نفسه في موضعين (مثل 2 في `2*w + 2*h`) استُبدلا معاً.
       فمن أراد ضبطاً دقيقاً يحرّر المعادلة نفسها من هنا.

       والمُدخَل يمرّ على isSafeFormula قبل الحفظ: لا يُقبل إلا المتغيّرات
       والأرقام والعمليات ودوال Math — فلا يُحفظ نص يعطب الحاسبة كلها،
       ولا يُنفَّذ شيء خارج الحساب. */
    function editFullFormula(pName, type, idx) {
      const bound=window.WSSymbolFormulas?.find(type);if(bound){window.WSSymbolFormulas.open(bound.material,bound.symbol,()=>{initProfiles();loadProfileToEditor(pName);});return;}
      const item = appProfiles[pName] && appProfiles[pName][type] && appProfiles[pName][type][idx];
      if (!item) return;

      const help = 'المتغيّرات المتاحة: w (العرض) · h (الارتفاع)' +
                   (type.includes('door') ? ' · largeW (عرض الضلفة الكبيرة)' : '') +
                   '\nمسموح: + − × ÷ ( ) وأرقام و Math.ceil / Math.floor / Math.round';

      const next = prompt('تحرير معادلة «' + item.label + '»\n' + help + '\n\nالمعادلة الحالية:', item.calc);
      if (next === null) return;
      const clean = next.trim();
      if (!clean) { showToast('المعادلة فارغة', 'error'); return; }
      if (clean === item.calc) return;

      if (!isSafeFormula(clean)) {
        alert('⛔ صيغة غير مقبولة.\n\n' + help +
              '\n\nلا يُسمح بنصوص برمجية ولا بأقواس معقوفة ولا بفواصل منقوطة.');
        return;
      }

      // تجربة فعلية قبل الحفظ: معادلة تنهار على مقاس عادي لا تُحفظ
      try {
        const test = new Function('w', 'h', 'largeW', 'manualLeafW', 'flipH',
                                  '"use strict"; return (' + clean + ');')(120, 210, 60, 40, 0);
        if (typeof test !== 'number' || !isFinite(test)) {
          alert('⛔ المعادلة لا تُنتج رقماً صالحاً على مقاس تجريبي (120 × 210).\n\nراجع صيغتها.');
          return;
        }
      } catch (e) {
        alert('⛔ خطأ في المعادلة: ' + (e && e.message ? e.message : e));
        return;
      }

      item.calc = clean;
      /* editNum يُعاد استخراجه: هو آخر رقم عشري في المعادلة — وهو ما
         يعدّله الحقل السريع. بلا تحديثه يبقى الحقل يعرض رقماً لم يعد
         موجوداً، فيستبدل شيئاً غير موجود ويُفسد المعادلة. */
      const nums = clean.match(/\d+\.\d+|\d+/g);
      item.editNum = nums && nums.length ? nums[nums.length - 1] : '';

      try { localStorage.setItem('app_custom_profiles', JSON.stringify(appProfiles)); } catch (e) { console.error('تعذّر حفظ الأنظمة محلياً:', e); }
      showToast('حُفظت المعادلة ✅', 'success');
      try { loadProfileToEditor(pName); } catch (e) { console.error('إعادة رسم المحرر:', e); }
      // النتائج المعروضة تعتمد المعادلة القديمة، فتُعاد الحسبة فوراً
      try { if (typeof calculateAll === 'function') calculateAll(); } catch (e) {}
    }

    // حفظ تلقائي فوري لكل رقم عند تعديله — بدون الحاجة لأي زر حفظ جماعي
    function handleProfileNumberChange(inp) {
      const pName = inp.dataset.profile;
      const type = inp.dataset.type;
      const idx = parseInt(inp.dataset.index, 10);   // الأساس صراحةً
      const newNumStr = inp.value.trim().replace(',', '.');

      if (!newNumStr || isNaN(newNumStr)) {
        showToast('الرجاء إدخال رقم صحيح', 'error');
        return;
      }

      const item = appProfiles[pName][type][idx];
      const oldNum = item.editNum;
      if (newNumStr !== oldNum) {
        const regex = new RegExp('\\b' + oldNum.replace('.', '\\.') + '\\b', 'g');
        item.calc = item.calc.replace(regex, newNumStr);
        item.editNum = newNumStr;
        try { localStorage.setItem('app_custom_profiles', JSON.stringify(appProfiles)); } catch (e) { console.error('تعذّر حفظ الأنظمة محلياً:', e); }

        const indicator = inp.parentElement.querySelector('.save-indicator');
        if (indicator) {
          indicator.classList.add('show');
          setTimeout(() => indicator.classList.remove('show'), 1200);
        }
      }
    }

    // رموز صغيرة بجوار النتائج فقط، بلا لوحة حالة حساب مستقلة.
    function wsCutSymbolSummary(rows,pending=[]){return pending.length?'<p class="ws-pending">لم تُحسب المقاسات: '+pending.map(r=>escHtml(r.index)+' — '+escHtml(r.pending)).join('؛ ')+'</p>':'';}
    function wsDimensionPair(w,h){return '<span class="ws-dim-pair"><bdi>'+escHtml(w)+'</bdi><span>×</span><bdi>'+escHtml(h)+'</bdi></span>';}
    function wsFormatDimensions(text){return escHtml(text).replace(/([0-9]+(?:\.[0-9]+)?)\s*×\s*([0-9]+(?:\.[0-9]+)?)/g,(_,w,h)=>wsDimensionPair(w,h));}
    function wsSmallSymbol(rows,index){const r=rows.find(r=>r.index===index);return r?'<span class="ws-result-symbol">'+window.WSOpeningSymbols.html(r,26)+'</span>':'';}

    // تخطيط أعواد منفصلة حسب النظام والقطاع وطول العود، وليس قسمة الأطوال.
    function wsStockLength(alu){
      const key=alu?'ws_alu_stock_cm':'ws_pvc_stock_cm';
      const fallback=alu?650:580;
      const n=Number(localStorage.getItem(key));
      return Number.isFinite(n)&&n>0?n:fallback;
    }
    window.wsSaveStockLengths=function(){
      const kerf=Number(document.getElementById('ws-saw-kerf')?.value);if(!Number.isFinite(kerf)||kerf<0){alert('راجع سماكة سلاح القص');return;}localStorage.setItem('ws_saw_kerf_cm',String(kerf));
      const pairs=[['ws-pvc-stock','ws_pvc_stock_cm'],['ws-alu-stock','ws_alu_stock_cm']];
      for(const [id,key] of pairs){const n=Number(document.getElementById(id)?.value);if(!Number.isFinite(n)||n<=0){alert('طول العود يجب أن يكون رقماً موجباً');return;}localStorage.setItem(key,String(n));}
      calculateAll();
    };
    setTimeout(()=>{const kerf=document.getElementById('ws-saw-kerf');if(kerf)kerf.value=localStorage.getItem('ws_saw_kerf_cm')||'0';for(const [id,alu] of [['ws-pvc-stock',false],['ws-alu-stock',true]]){const el=document.getElementById(id);if(el)el.value=wsStockLength(alu);}},0);
    function wsBuildCutPlan(results, offset){
      const groups=new Map(),blocked=new Set();
      let activeProfile='', activeResult=null;
      const add=(family,name,length,qty,source,stock,axis)=>{
        const edit=activeResult?.rawEdits?.find(e=>e.name===name&&e.unit==='عود');
        const changed=edit && (edit.base!=='original'||Number(edit.factor??1)!==1||Number(edit.offset||0)!==0||Number(edit.waste||0)!==0);
        if(edit?.rod>0)stock=Number(edit.rod);
        family += activeProfile ? ' — '+activeProfile : '';
        length=Number(length); qty=Math.round(Number(qty)); stock=Number(stock);
        if(!(length>0&&qty>0&&stock>0))return;
        const key=[family,name,stock].join('|');
        if(changed){blocked.add(key);return;}
        if(!groups.has(key))groups.set(key,{family,name,stock,pieces:[]});
        for(let i=0;i<qty;i++)groups.get(key).pieces.push({length,source,axis});
      };
      for(const r of results){
        if(r.customMaterials||r.frozenBinding||r.type.startsWith('custom_'))continue; // لا نفترض تفاصيل قص لنظام مخصص
        activeProfile=r.profileName||'';activeResult=r;
        const {type,res,index,w,h}=r;
        if(type.startsWith('sranti_'))continue;
        const alu=type.startsWith('aluminum_');
        const sliding=type.startsWith('sliding_')||['aluminum_67','aluminum_sliding_67','aluminum_sliding_normal'].includes(type);
        const family=type==='sliding_poly_one'?'pvc سحاب بولي ون':type==='sliding_poplist'?'pvc سحاب بوبلست':alu?(sliding?'سحاب المونيوم':'المونيوم مفصلي'):'pvc مفصلي';
        const stock=wsStockLength(alu);
        const frame=alu?(sliding?'حلق سحاب المونيوم':'حلق المونيوم'):(sliding?'حلق السحاب':'شمبرلي');
        // نستخدم أبعاد نتائج الحلق إن وُجدت؛ وإلا أبعاد الشمبرلي الظاهرة.
        const fw=alu?Number(res['قص الحلق']??res['عرض الحلق']??w):Number(w)+offset;
        const fh=alu?Number(res['ارتفاع الحلق']??h):Number(h)+offset;
        const singleDoorFrame=type==='door_single'||type==='aluminum_door';
        add(family,frame,fw+12,singleDoorFrame?1:2,index,stock,'عرض'); add(family,frame,fh+12,2,index,stock,'ارتفاع');
        const door=type.includes('door');
        const leafName=door?'ضلفة الباب':sliding?'ضلفة السحاب':'ضلفة النافذة';
        const leafStock=wsStockLength(alu);
        const big=Number(res['عرض الضلفة الكبيرة']),small=Number(res['عرض الضلفة الصغيرة']),leafH=Number(res['ارتفاع الضلفة']);
        if(big>0&&small>0&&leafH>0){
          add(family,leafName,big,2,index,leafStock,'عرض الكبيرة');add(family,leafName,small,2,index,leafStock,'عرض الصغيرة');add(family,leafName,leafH,4,index,leafStock,'ارتفاع');
        }else{
          const lw=Number(res['عرض الضلفة']??res['عرض ضلفة الباب']),lh=Number(res['ارتفاع الضلفة']??res['ارتفاع ضلفة الباب']??res['ارتفاع الباب']);
          if(lw>0&&lh>0){
            const double=/double|sliding|aluminum_67|poplist/.test(type)&&!/single|leaf_fixed|flipper/.test(type);
            const count=double?4:2;
            add(family,leafName,lw,count,index,leafStock,'عرض');add(family,leafName,lh,count,index,leafStock,'ارتفاع');
          }
        }
      }
      const plans=new Map();
      for(const [key,g] of groups){
        if(blocked.has(key))continue;
        plans.set(key,{...g,...window.WSCutOptimizer.solve(g.pieces,g.stock,Number(localStorage.getItem('ws_saw_kerf_cm'))||0)});
      }
      return plans;
    }
    function wsMaterialOrder(name){
      if(/^(شمبرلي|حلق)/.test(name))return 0;
      if(/^ضلف/.test(name))return 1;
      if(/^(T|تي)(?:\s|$)/i.test(name))return 2;
      if(/مسطح/.test(name))return 3;
      if(/باكيت/.test(name))return 4;
      return 5;
    }
    function wsExecutionCutReport(plan,resultColors=["#e1eee9","#e1eaf5","#faecd7","#ede4f6","#f8e3e5"]){
      const pieceCode=piece=>(/ارتفاع/.test(piece.axis||'')?'H':/عرض/.test(piece.axis||'')?'L':'')+piece.source;
      return `<div class="ws-execution-report" dir="rtl"><h4>تقرير ترتيب القص لتقليل الهدر</h4>
        <p class="ws-cut-start">ابدأ بالعود 1، واقرأ صفوفه من أعلى إلى أسفل ثم انتقل للعود التالي. L = العرض، H = الارتفاع. الرقم بجوار الحرف هو رقم المقاس. مثال: H1 مع 150 × 2 يعني قطعتين بطول 150 سم لارتفاع المقاس الأول داخل هذا العود فقط.</p>
        <p class="ws-cut-scope">${escHtml(plan.name)} · ${escHtml(plan.family)} · طول العود ${trimNum(plan.stock)} سم</p>
        <p class="ws-cut-proof">${plan.optimal?'أقل عدد أعواد مؤكد لهذه القطع':'أفضل توزيع عُثر عليه؛ الحد الأدنى غير مثبت'} · سماكة سلاح القص ${trimNum(plan.kerf)} سم</p>
        ${plan.rods.map((rod,rodIndex)=>{
          const refs=[...new Set(rod.pieces.map(p=>p.source))];
          const grouped=new Map();
          for(const piece of rod.pieces){
            const key=JSON.stringify([piece.source,piece.axis,piece.length]);
            if(!grouped.has(key))grouped.set(key,{...piece,quantity:0});
            grouped.get(key).quantity++;
          }
          const groups=[...grouped.values()];
          const steps=groups.map(piece=>`<tr><td class="ws-cut-code"><bdi dir="ltr">${escHtml(pieceCode(piece))}</bdi></td><td><strong>${escHtml(piece.axis||'قطعة')}</strong></td><td class="ws-length"><bdi dir="ltr">${trimNum(piece.length)} × ${piece.quantity}</bdi><small>سم × قطعة</small></td></tr>`).join('');
          const remaining=trimNum(plan.stock-rod.used);
          return `<div class="ws-rod-card"><h5>${rodIndex===0?'ابدأ هنا — ':''}العود ${rodIndex+1}</h5><p>المقاسات التي ستُقص من هذا العود: ${refs.map(n=>'رقم '+escHtml(n)).join('، ')}</p>
          <table class="ws-cut-steps"><thead><tr><th>رقم المقاس</th><th>القطعة</th><th>الطول × العدد</th></tr></thead><tbody>${steps}</tbody></table>
          <div class="ws-cut-bar">${groups.map(piece=>`<span style="flex:${(piece.length+plan.kerf)*piece.quantity};background:${resultColors[(piece.source-1)%resultColors.length]}" title="${escHtml(pieceCode(piece))} · ${trimNum(piece.length)} × ${piece.quantity}"><bdi dir="ltr">${escHtml(pieceCode(piece))}</bdi></span>`).join('')}<span class="ws-cut-offcut" style="flex:${Math.max(0,plan.stock-rod.used)}">باقي</span></div>
          <div class="ws-rod-end"><span>المستهلك مع سلاح القص: <bdi>${trimNum(rod.used)}</bdi> سم</span><strong class="ws-remainder">المتبقي: <bdi>${remaining}</bdi> سم</strong></div>
          <p class="ws-next-rod">${rodIndex+1<plan.rods.length?'بعد هذه الخطوات انتقل إلى العود '+(rodIndex+2):'انتهى قص هذا القطاع.'}</p></div>`;
        }).join('')}</div>`;
    }
    function wsRefreshRowFormula(button){const item=button.closest('.measurement-item');if(!confirm('استخدام المعادلة والمواد الحالية لهذا المقاس بدل النسخة المثبتة؟'))return;item.wsFormulaSnapshot=null;calculateAll();}
    function calculateAll() {
      window.WSSymbolFormulas?.install(appProfiles,customTypeRegistry,typeNames);
      const items = document.querySelectorAll('.measurement-item');
      if (items.length === 0) {
        showToast('لا توجد قياسات', 'error');
        return;
      }

      const messages = {};
      items.forEach((item, idx) => {
        const msg = item.querySelector('.message-input')?.value.trim();
        if (msg) messages[idx + 1] = msg;
      });

      const allResults = [];
      const pending = [];
      let hasValid = false;
      const negativeWarnings = [];   // قياسات نتجت عنها أرقام قص سالبة

      items.forEach((item, idx) => {
        const wInput = item.querySelector('.width-input');
        const hInput = item.querySelector('.height-input');
        const typeSelect = item.querySelector('.type-select');
        const profileSelect = item.querySelector('.profile-select');
        
        const type = typeSelect.value;
        const profileName = profileSelect.value;
        const frozen=window.WSStudio?.validSnapshot(item.wsFormulaSnapshot,type,profileName)?item.wsFormulaSnapshot:null;

        // إصلاح 8.8: قراءة موحّدة تقبل الأرقام العربية
        const w = wsNum(wInput.value, NaN);
        const h = wsNum(hInput.value, NaN);

        const opening=window.WSOpeningSymbols.metadata(item.wsOpening);
        const defer=(reason)=>pending.push({index:idx+1,w:isNaN(w)?'':w,h:isNaN(h)?'':h,...opening,pending:reason});
        if (!type) { defer('لم تُختر معادلة — المقاس محفوظ'); return; }
        if(item.wsFormulaSnapshot&&item.wsFormulaSnapshot.type===type&&item.wsFormulaSnapshot.profile===profileName&&!frozen){defer('نسخة المعادلة المحفوظة غير صالحة؛ راجعها أو حدّث معادلة المقاس صراحة');return;}
        if(!frozen&&type.startsWith('custom_symbol_')&&!window.WSSymbolFormulas?.find(type)){defer('تعريف معادلة الرمز غير موجود — استورد ملف الأنظمة ومعادلات الرموز');return;}
        if (!(w>0) || !(h>0)) { defer('راجع العرض والارتفاع'); return; }
        let available=appProfiles[profileName];try{if(window.WSEngine)available=window.WSEngine.resolveProfile({cutProfiles:appProfiles,workshopOptions:window.WSStudio.options()},profileName);}catch(e){if(!frozen){defer(e.message);return;}}
        if(!frozen&&(!available || !Array.isArray(available[type]) || !available[type].length)) {
          defer('المعادلة غير موجودة في النظام المحدد'); return;
        }

        let manualValue = 0;
        let needsManual = false;
        let fieldName = "";
        if (type === 'window_double_top') {
          manualValue = wsNum(item.querySelector('.manual-leaf-width').value);
          needsManual = true;
          fieldName = "عرض الضلفة";
        } else if (type === 'window_flipper') {
          manualValue = wsNum(item.querySelector('.manual-flipper-height').value);
          needsManual = true;
          fieldName = "ارتفاع الضلفة (القلاب)";
        } else if (['door_double','aluminum_door_double'].includes(type)) {
          manualValue = item.querySelector('.equal-door-leaves')?.checked ? (type==='door_double' ? (w-6)/2 : (w-5.5)/2) : wsNum(item.querySelector('.manual-large-leaf').value);
          needsManual = true;
          fieldName = "عرض الضلفة الكبيرة";
        } else if (['window_leaf_fixed','aluminum_window_leaf_fixed','aluminum_window_flipper_fixed'].includes(type)) {
          manualValue = wsNum(item.querySelector('.manual-leaf-fixed-width').value);
          needsManual = true;
          fieldName = "عرض الضلفة (لنافذة ضلفة وتابت)";
        }

        if (needsManual && !manualValue) {
          defer('أكمل '+fieldName);
          showToast(`القياس ${idx + 1}: يرجى إدخال ${fieldName}`, 'error');
          return;
        }

        let res;try{res=calculateItem(w,h,type,manualValue,profileName,frozen?.formulas,item.wsOpeningLayout);}catch(e){defer('تعذر الحساب: '+e.message);return;}
        if(Object.values(res).some(v=>typeof v!=='number'||!Number.isFinite(v)||v<0)){defer('نتيجة قص غير صالحة؛ راجع المعادلة والمقاس');return;}
        const rules=frozen?frozen.materials:window.WSStudio?.rawRules(profileName,type,item.wsOpeningLayout,w,h);
        let customMaterials=null;try{if(rules)customMaterials=window.WSStudio.raw(rules,w,h,manualValue);}catch(e){defer('راجع قواعد المواد: '+e.message);return;}
        let accessoryOverrides={},cutItems=null;
        try{if(window.WSEngine){const file=frozen?{cutProfiles:{},workshopOptions:{}}:window.WSFullSystemFile.exportFile(),ps={...window.WSEngine.params(file,profileName),...window.WSEngine.counts(type,item.wsOpeningLayout,w,h)};const accRules=frozen?frozen.accessories:window.WSEngine.mapped(file,'accessories',profileName,type);accessoryOverrides=window.WSEngine.accessoryValues(accRules,w,h,manualValue,ps);cutItems=frozen?frozen.cutItems:window.WSEngine.mapped(file,'cutItems',profileName,type)?.map(r=>({...r,quantity:window.WSEngine.compile(r.quantity,ps)}));for(const [name,e] of Object.entries(item.wsAccessoryExceptions||{})){if(!e.reason||!Number.isInteger(e.count)||e.count<0||['__proto__','constructor','prototype'].includes(name))throw Error('استثناء إكسسوار غير صالح');accessoryOverrides[name]=e.count;}}}catch(e){defer(e.message);return;}
        let materialRows=null,rawEdits=[];
        try{if(window.WSMaterials){
          rawEdits=frozen?(frozen.rawEdits||[]):window.WSEngine.mapped(window.WSFullSystemFile.exportFile(),'rawEdits',profileName,type)||[];
          const original=window.WSMaterials.collect({type,w,h,res,cuttingSymbol:opening.cuttingSymbol,customMaterials,binding:frozen?frozen.binding:window.WSSymbolFormulas?.find(type),accessoryOverrides,operationName:typeNames[type]||type});
          const changed=window.WSMaterials.apply(original,rawEdits,{type,w,h,res});
          if(changed.warnings.length)throw Error(changed.warnings.join('؛ '));materialRows=changed.rows;for(const r of materialRows)if(r.unit==='قطعة'&&Object.hasOwn(item.wsAccessoryExceptions||{},r.name))r.amount=item.wsAccessoryExceptions[r.name].count;
        }}catch(e){defer('راجع المواد: '+e.message);return;}
        /* نتيجة سالبة = المقاس المُدخل أصغر من أن يستوعب خصومات هذا النظام،
           وغالباً خطأ كتابة (130 كُتبت 30). كانت تُعرض كرقم عادي بلا أي تنبيه،
           فيقرأها العامل على أنها مقاس قص — «عرض الزجاج ‎-1.2» مثلاً.
           نجمعها هنا لتُميَّز بالأحمر ويُنبَّه عليها صراحةً. */
        const negs = Object.entries(res).filter(([k, v]) => typeof v === 'number' && v < 0);
        if (negs.length) {
          negativeWarnings.push({ num: idx + 1, w, h, fields: negs.map(([k]) => k) });
        }
        hasValid=true;
        if(!frozen&&window.WSStudio)item.wsFormulaSnapshot=window.WSStudio.snapshot({cuttingFormula:type,cuttingProfile:profileName,w,h,openingLayout:item.wsOpeningLayout});
        // w و h محفوظان لأن الإطار (الشمبرلي) يُحسب من المدخلات مباشرة
        allResults.push({ index: idx + 1, res, type, profileName, w, h, manualValue, accessoryOverrides,cutItems,customMaterials,materialRows,rawEdits, frozenBinding:frozen?.binding||null, ...opening });
      });

      if (!hasValid) {
        window._lastCutResults={rows:[],pending,customer:(document.getElementById('cut-customer')?.value||'').trim()};
        document.getElementById('results').innerHTML = wsCutSymbolSummary([],pending);
        saveDraft();
        return;
      }

      /* اسم العمل في رأس النتائج — قبل أي رقم.
         ورقة القص تُطبع أو تُشارك وتصل للمنجرة وحدها، فبلا اسم في رأسها
         تصير قصاصة أرقام مجهولة الصاحب: تُخلط بورقة زبون آخر ويُقصّ
         الألمونيوم على مقاس غير مقاسه — وهو خطأ لا يُصلَّح بعد القص. */
      const cutCustomer = (document.getElementById('cut-customer')?.value || '').trim();
      /* نحتفظ بالنتائج كما هي ليُعاد رسمها بأي عرض بلا إعادة حساب —
         فتبديل العرض لا يُغيّر رقماً واحداً. */
      window._lastCutResults = { rows: allResults, pending, customer: cutCustomer };

      let html = `<div class="results-actions">
          <button type="button" class="share-inline-btn" onclick="shareResults()">📤 مشاركة النتائج</button>
          <button type="button" class="view-toggle-btn" onclick="toggleResultsView()">🧮 عرض كجدول</button>
        </div>`;
      if (cutCustomer) {
        html += `<div style="background:linear-gradient(135deg,#127291,#145b73);color:#ffffff;border-radius:14px;
                     padding:14px 16px;margin-bottom:14px;text-align:center;box-shadow:0 4px 14px -4px rgba(18, 114, 145, .5);">
          <div style="font-size:11px;opacity:.85;font-weight:700;letter-spacing:.5px;">اسم العمل</div>
          <div style="font-size:19px;font-weight:900;margin-top:2px;">${escHtml(cutCustomer)}</div>
          <div style="font-size:11px;opacity:.85;font-weight:600;margin-top:3px;">${escHtml(new Date().toLocaleDateString('ar-EG'))}</div>
        </div>`;
      }
      html += wsCutSymbolSummary(allResults,pending);
      if(pending.length)html+='<p style="color:#a54c13">المواد الخام والنتائج أدناه تخص المقاسات المحسوبة فقط؛ '+pending.length+' مقاس يحتاج استكمال الاختيار أو المدخلات.</p>';
      html += `<div class="section-title">النتائج الفنية للحسابات</div>`;
      // لافتة صريحة قبل أي نتيجة، فالأرقام السالبة لا يصح أن تُقرأ كمقاسات قص
      if (negativeWarnings.length) {
        html += `<div style="background:#78261b;color:#ffffff;border-radius:12px;padding:14px 16px;margin-bottom:14px;font-weight:800;line-height:1.9;">
          ⚠️ نتائج سالبة — راجع هذه المقاسات قبل القص
          <div style="font-weight:600;font-size:13px;opacity:.95;margin-top:6px;">
            ${negativeWarnings.map(n => `القياس ${n.num} (${escHtml(n.w)}×${escHtml(n.h)}): ${escHtml(n.fields.slice(0,4).join('، '))}`).join('<br>')}
          </div>
          <div style="font-weight:600;font-size:12px;opacity:.85;margin-top:6px;">
            المقاس المُدخل أصغر من خصومات هذا النظام — غالباً خطأ في كتابة الرقم.
          </div>
        </div>`;
        showToast(`⚠️ ${negativeWarnings.length} قياساً نتجت عنه أرقام سالبة — راجعها`, 'error');
      }

      const resultColors = ['#ebf0f6', '#e5eaef', '#eaf3f7', '#fff4d6', '#ffece9', '#f0f3f7', '#f9f5eb'];

      // ===== الحلق: أول نتيجة لأنظمة الألمنيوم الجديدة =====
      const throatLines = [];
      allResults.forEach(({ index, res, profileName }) => {
        const wVal = res["قص الحلق"]; const hVal = res["ارتفاع الحلق"];
        if (wVal !== undefined && hVal !== undefined && wVal !== '—' && hVal !== '—' && wVal !== 'خطأ' && hVal !== 'خطأ') {
          throatLines.push({ num: index, operation: typeNames[(allResults.find(r=>r.index===index)||{}).type] || 'عملية الألمنيوم', text: `حلق المونيوم: ${wVal} × ${hVal}` });
        }
      });
      if (throatLines.length > 0) {
        html += `<div class="result-section"><ul class="results-list">`;
        throatLines.forEach((item, i) => {
          html += `<li style="background-color:${resultColors[i % resultColors.length]};"><small class="operation-label">${escHtml(item.operation)}</small><span class="cut-result-value">${wsSmallSymbol(allResults,item.num)}${escHtml(item.num)}- ${wsFormatDimensions(item.text)}</span>`;
          // الملاحظة تظهر في قسم الإطار فقط
          html += `</li>`;
        });
        html += `</ul></div>`;
      }


      // ===== الإطار (الشمبرلي): أول نتيجة على الإطلاق =====
      // الملاحظات تُعرض هنا فقط — أسفل المقاس بخط صغير — ولا تتكرر في بقية الأقسام
      const shOffset = getShamberlyOffset();
      const shLines = [];
      allResults.forEach(({ index, type, w, h }) => {
        if (!hasShamberly(type)) return;
        const W = wsNum(w, NaN), H = wsNum(h, NaN);   // إصلاح 8.8
        if (isNaN(W) || isNaN(H)) return;
        shLines.push({ num: index, w: trimNum(W + shOffset), h: trimNum(H + shOffset) });
      });
      if (shLines.length > 0) {
        html += `<div class="result-section"><div class="section-subtitle">شمبرلي pvc</div><ul class="results-list">`;
        shLines.forEach((item, i) => {
          html += `<li style="background-color:${resultColors[i % resultColors.length]};">`;
          html += `<small class="operation-label">${escHtml(operationDisplayName((allResults.find(r=>r.index===item.num)||{}).type))}</small><span class="sh-main cut-result-value" dir="rtl" style="display:inline-block;text-align:right;direction:rtl">${wsSmallSymbol(allResults,item.num)}${escHtml(item.num)}- شمبرلي pvc: <span class="sh-pair" dir="rtl"><span class="sh-width">${escHtml(item.w)}</span><span class="sh-multiply">×</span><span class="sh-height">${escHtml(item.h)}</span></span></span>`;
          if (messages[item.num]) html += `<span class="sh-note">${escHtml(messages[item.num])}</span>`;
          html += `</li>`;
        });
        html += `</ul></div>`;
      }

      const leafLines = [];
      allResults.forEach(({ index, res, type, profileName }) => {
        let tag = '';   // اسم النظام لا يُكتب أمام كل مقاس
        if (['door_double','aluminum_door_double'].includes(type)) {
          const largeW = res["عرض الضلفة الكبيرة"];
          const smallW = res["عرض الضلفة الصغيرة"];
          const H = res["ارتفاع الضلفة"];
          if (largeW !== undefined && H !== undefined && largeW !== 'خطأ' && H !== 'خطأ') {
            leafLines.push({index, operation:operationDisplayName(type), result:`ضلفة كبيرة: ${largeW} × ${H}`});
          }
          if (smallW !== undefined && H !== undefined && smallW !== 'خطأ' && H !== 'خطأ') {
            leafLines.push({index, operation:operationDisplayName(type), result:`ضلفة صغيرة: ${smallW} × ${H}`});
          }
        } else {
          let wKey = "", hKey = "";
          if (res["عرض الضلفة"] !== undefined) {
            wKey = "عرض الضلفة";
            hKey = res["ارتفاع الضلفة"] !== undefined ? "ارتفاع الضلفة" : (['aluminum_door','aluminum_door_double'].includes(type) && res['ارتفاع الباب'] !== undefined ? "ارتفاع الباب" : "ارتفاع الضلفة");
          }
          else if (res["عرض ضلفة الباب"] !== undefined) { wKey = "عرض ضلفة الباب"; hKey = "ارتفاع ضلفة الباب"; }

          if (wKey && res[wKey] !== 'خطأ' && res[hKey] !== 'خطأ') {
            leafLines.push({index, operation:operationDisplayName(type), result:`ضلفة: ${res[wKey]} × ${res[hKey]}`});
          }
        }
      });

      if (leafLines.length > 0) {
        html += `<div class="result-section"><h3 style="text-align:center;color:var(--header-color);">الضلفات</h3><ul class="results-list">`;
        leafLines.forEach((line, i) => {
          html += `<li style="background-color:${resultColors[i % resultColors.length]};"><small class="operation-label">${escHtml(line.operation)}</small><span class="cut-result-value">${wsSmallSymbol(allResults,line.index)}${escHtml(line.index)}- ${wsFormatDimensions(line.result)}</span>`;
            // الملاحظة تظهر في قسم الإطار فقط
          html += `</li>`;
        });
        html += `</ul></div>`;
      }

      const categories = {
        "الثابت": [ { w: "عرض الثابت", h: "ارتفاع الثابت" } ],
        "باكيتة": [
          { w: "عرض الباكيتة", h: "ارتفاع الباكيتة" },
          { w: "عرض باكيتة كبيرة", h: "ارتفاع الباكيتة" },
          { w: "عرض باكيتة صغيرة", h: "ارتفاع الباكيتة" },
          { w: "عرض باكيتة الضلفة", h: "ارتفاع باكيتة الضلفة" }
        ],
        "باكيتة تابت": [ { w: "عرض باكيتة التابت", h: "ارتفاع باكيتة التابت" } ],
        "مخفض الباكيتة": [ { w: "عرض مخفض الباكيتة", h: "ارتفاع مخفض الباكيتة" } ],
        "زجاج ضلفة": [
          { w: "عرض زجاج الضلفة", h: "ارتفاع زجاج الضلفة" },
          { w: "عرض الزجاج", h: "ارتفاع الزجاج" },
          { w: "زجاج الضلفة (عرض)", h: "زجاج الضلفة (ارتفاع)" },
          { w: "عرض زجاج الضلفة", h: "ارتفاع زجاج الضلفة" }
        ],
        "زجاج تابت": [
          { w: "زجاج التابت (عرض)", h: "زجاج التابت (ارتفاع)" },
          { w: "عرض زجاج التابت", h: "ارتفاع زجاج التابت" },
          { w: "عرض زجاج الثابت", h: "ارتفاع زجاج الثابت" }
        ]
      };

      for (const [categoryName, pairs] of Object.entries(categories)) {
        const listItems = [];
        allResults.forEach(({ index, res, profileName }) => {
          const seenPairs = new Set();
          for (const pair of pairs) {
            const pairKey = `${pair.w}|${pair.h}`;
            if (seenPairs.has(pairKey)) continue;
            seenPairs.add(pairKey);
            const wVal = res[pair.w]; const hVal = res[pair.h];
            if (wVal !== undefined && hVal !== undefined && wVal !== '—' && hVal !== '—' && wVal !== 'خطأ' && hVal !== 'خطأ') {
              // عرض عدد قطع الزجاج بوضوح دون مضاعفة أبعاد القطعة نفسها.
              // الأنواع ذات الضلفتين تحتاج قطعتين من الزجاج بالمقاس المحسوب.
              const doubleLeafGlassTypes = new Set([
                'window_double', 'window_double_top', 'aluminum_67',
                'aluminum_window_double', 'aluminum_sliding_67', 'door_double',
                'sliding_poly_two', 'sliding_poplist_two'
              ]);
              const glassCount = doubleLeafGlassTypes.has(allResults.find(r => r.index === index)?.type) ? ' × 2' : '';
              listItems.push({ num: index, operation: typeNames[allResults.find(r => r.index === index)?.type] || 'عملية القص', text: `${categoryName}: ${wVal} × ${hVal}${glassCount}` });
              break;
            }
          }
        });
        if (listItems.length > 0) {
          html += `<div class="result-section"><ul class="results-list">`;
          listItems.forEach((item, i) => {
            const operationLabel = categoryName.startsWith('زجاج') ? '' : wsSmallSymbol(allResults,item.num)+ `<small class="operation-label">${escHtml(item.operation)}</small>`;
            html += `<li style="background-color:${resultColors[i % resultColors.length]};">${operationLabel}<span class="cut-result-value">${escHtml(item.num)}- ${wsFormatDimensions(item.text)}</span>`;
            // الملاحظة تظهر في قسم الإطار فقط
            html += `</li>`;
          });
          html += `</ul></div>`;
        }
      }

      // لا نعرض قسم زجاج إضافياً؛ أبعاد الزجاج تظهر مرة واحدة ضمن فئات «زجاج ضلفة» و«زجاج تابت».

      const singleValueCategories = {
        "T": ["T"],
        "مسطح الباب (عرض)": ["مسطح الباب (عرض)"], "عدد مسطح الباب": ["عدد مسطح الباب"]
      };

      for (const [label, keys] of Object.entries(singleValueCategories)) {
        const values = [];
        allResults.forEach(({ index, res, type, profileName }) => {
          if (label === 'T' && (String(type).startsWith('sliding_') || ['aluminum_67','aluminum_sliding_67'].includes(type))) return;
          for (const key of keys) {
            const val = res[key];
            if (val !== undefined && val !== '—' && val !== 'خطأ') {
              values.push({ num: index, val: `${val}` });
              break;
            }
          }
        });
        if (values.length > 0) {
          html += `<div class="result-section"><h3 style="text-align:center;color:var(--header-color);">${escHtml(label)}</h3><ul class="results-list">`;
          values.forEach((v, i) => {
            html += `<li style="background-color:${resultColors[i % resultColors.length]};">${escHtml(v.num)}- ${escHtml(v.val)}`;
            // الملاحظة تظهر في قسم الإطار فقط
            html += `</li>`;
          });
          html += `</ul></div>`;
        }
      }

      // حسابات السرانتي
      // «الحصيرة» تُعرض كزوج واحد: العرض × عدد الشرايح (مثل 140 × 20)
      // بدل قسمين منفصلين، لأنهما يُقرآن معاً عند القص.
      const srantiOrder = [
        { label: "عرض الصندوق", key: "عرض الصندوق" }, { label: "ارتفاع السكة", key: "ارتفاع السكة" },
        { label: "تشفير السكة", key: "تشفير السكة" },
        { label: "الحصيرة (عرض × عدد الشرايح)", key: "عرض الحصيرة", pairKey: "عدد شرايح الحصيرة" },
        { label: "الطوبو", key: "الطوبو" },
        { label: "مواد خام الحصيرة", key: "مواد خام الحصيرة" }
      ];

      srantiOrder.forEach((item, catIndex) => {
        const values = [];
        allResults.forEach(({ index, res, type, profileName }) => {
          if (type === 'sranti_external_large' || type === 'sranti_external_small' || type === 'sranti_normal') {
            const val = res[item.key];
            if (val === undefined || val === '—' || val === 'خطأ') return;
            if (item.pairKey) {
              // زوج مدمج: العرض × العدد
              const pv = res[item.pairKey];
              if (pv === undefined || pv === '—' || pv === 'خطأ') return;
              values.push({ num: index, val: `${val} × ${pv}` });
            } else {
              values.push({ num: index, val: `${val}` });
            }
          }
        });
        if (values.length > 0) {
          html += `<div class="result-section"><h3 style="text-align:center;color:var(--header-color);">${escHtml(item.label)}</h3><ul class="results-list">`;
          values.forEach((v, i) => {
            html += `<li style="background-color:${resultColors[(catIndex + i) % resultColors.length]};">${escHtml(v.num)}- ${escHtml(v.val)}`;
            // الملاحظة تظهر في قسم الإطار فقط
            html += `</li>`;
          });
          html += `</ul></div>`;
        }
      });

      // ===== نتائج أنواع العمليات المخصصة كليًا (تُعرض ببنودها كما أُنشئت تماماً) =====
      const customResultsByType = {};
      allResults.forEach(entry => {
        if (customTypeRegistry[entry.type]) {
          if (!customResultsByType[entry.type]) customResultsByType[entry.type] = [];
          customResultsByType[entry.type].push(entry);
        }
      });
      Object.entries(customResultsByType).forEach(([type, entries]) => {
        html += `<div class="result-section"><h3 style="text-align:center;color:var(--header-color);">🧩 ${escHtml(operationDisplayName(type))}</h3><ul class="results-list">`;
        let li = 0;
        entries.forEach(({ index, res, profileName }) => {
          Object.entries(res).forEach(([label, val]) => {
            if (val === undefined || val === '—') return;
            html += `<li style="background-color:${resultColors[li % resultColors.length]};">${index}- ${escHtml(label)}: ${escHtml(val)}`;
            // الملاحظة تظهر في قسم الإطار فقط
            html += `</li>`;
            li++;
          });
        });
        html += `</ul></div>`;
      });

      // Material totals are calculated independently; cutting results above are unchanged.
      const rawTotals = new Map();
      let activeAcc={},usedAcc=new Set(),rawProfile='';
      function rawAdd(family, name, amount, unit='عود', rodLength=580) {
        if(rawProfile)family+=' — '+rawProfile;
        if(unit==='قطعة'&&Object.hasOwn(activeAcc,name)){amount=activeAcc[name];usedAcc.add(name);}
        if (!Number.isFinite(amount) || amount <= 0) return;
        const key = family + '|' + name + '|' + unit + '|' + (unit==='عود'?rodLength:'');
        const row = rawTotals.get(key) || {family,name,amount:0,unit,rodLength};
        row.amount += amount;
        // طول العود جزء من مفتاح التجميع، فلا تختلط أطوال القطاعات المختلفة.
        if (unit === 'عود') row.rodLength = Number(rodLength)||580;
        rawTotals.set(key,row);
      }
      allResults.forEach(({type,w,h,res,cuttingSymbol,customMaterials,frozenBinding,accessoryOverrides,materialRows,profileName}) => {
        rawProfile=profileName||'';
        if(materialRows){activeAcc={};materialRows.forEach(r=>rawAdd(r.family,r.name,r.amount,r.unit,r.rodLength));return;}
        activeAcc=accessoryOverrides||{};usedAcc=new Set();
        try{
        if(customMaterials){customMaterials.forEach(r=>rawAdd(typeNames[type]||type,r.name,r.amount,r.unit,r.rodLength));return;}
        const linked=frozenBinding||window.WSSymbolFormulas?.find(type);
        if(linked){
          const materials=window.WSSymbolFormulas.materials(linked,res);
          materials.forEach(r=>rawAdd(linked.name,r.name,r.amount,r.unit,r.rodLength));
          const four=['two-center-fixed','two-side-fixed','two-three-fixed','two-top-fixed-bottom','fixed-top-two-bottom','double-fixed-left','double-fixed-right','double-fixed-top','double-four-fixed'];
          const two=['window-double','leaf-fixed','single-fixed-left','single-fixed-right','single-fixed-top','single-fixed-bottom'];
          const kafloti=four.includes(cuttingSymbol)?4:two.includes(cuttingSymbol)?2:0;
          if(kafloti&&!materials.some(r=>/كافلوت/.test(r.name)))rawAdd(linked.name,'كافلوتي',kafloti,'قطعة');
          return;
        }

        const alu=type.startsWith('aluminum_');
        const family = type === 'sliding_poly_one' ? 'pvc سحاب بولي ون' : type === 'sliding_poplist' ? 'pvc سحاب بوبلست' : alu ? (['aluminum_67','aluminum_sliding_67','aluminum_sliding_normal'].includes(type) ? 'سحاب المونيوم' : 'المونيوم مفصلي') : 'pvc مفصلي';
        if(type.startsWith('sranti_')) {
          ['مواد خام الحصيرة','المواد الخام'].forEach(k=>{const n=Number(res[k]);if(Number.isFinite(n))rawAdd('سرانتي',k,n,'كمية');});return;
        }
        const sliding67=['aluminum_67','aluminum_sliding_67'].includes(type);
        const sliding=sliding67||type==='aluminum_sliding_normal'||type.startsWith('sliding_');
        const door=type.includes('door');
        const double=/double|sliding|aluminum_67|poplist/.test(type)&&!/single|leaf_fixed|flipper/.test(type);
        const leaves=double?2:1;
        rawAdd(family,alu ? (sliding ? 'حلق سحاب المونيوم' : 'حلق المونيوم') : (sliding ? 'حلق السحاب' : 'شمبرلي'), (type==='door_single'||type==='aluminum_door') ? (alu?Number(res['قص الحلق']??res['عرض الحلق']??w):Number(w)+getShamberlyOffset())+12+2*((alu?Number(res['ارتفاع الحلق']??h):Number(h)+getShamberlyOffset())+12) : 2*(alu ? (Number(res['قص الحلق']??res['عرض الحلق']??w)+Number(res['ارتفاع الحلق']??h)) : (Number(w)+Number(h)+2*getShamberlyOffset()))+48);
        if(!alu)rawAdd(family,'حديد شمبرلي',2*w+2*h+45);
        if(sliding67){
          rawAdd(family,'سكار نظام 67',2*(Number(res['ارتفاع الضلفة'])||h));
          rawAdd(family,'شنكل نظام 67',2*h);
          rawAdd(family,'عجل نظام 67',2*w);
          rawAdd(family,'مخفض نظام 67',4*(Number(res['عرض مخفض الباكيتة'])||0)+4*(Number(res['ارتفاع مخفض الباكيتة'])||0));
        }else if(type==='aluminum_sliding_normal') {
          rawAdd(family,'ضلفة السحاب',(Number(res['عرض الضلفة'])+Number(res['ارتفاع الضلفة']))*4,'عود',650);
        }else if(type==='aluminum_door_double') { const first=Number(res['عرض الضلفة الكبيرة'])||0; const second=Number(res['عرض الضلفة الصغيرة'])||0; const height=Number(res['ارتفاع الضلفة'])||0; rawAdd(family,'ضلفة الباب',2*(first+second)+4*height,'عود',650); }
        else if (!door && double) {
          // ضلف النوافذ ذات الضلفتين: الاعتماد على أبعاد الضلفة الظاهرة في النتائج
          // PVC = (عرض الضلفة + ارتفاع الضلفة) × 4 ÷ 560
          // Aluminium = (عرض الضلفة + ارتفاع الضلفة) × 4 ÷ 640
          const leafW = Number(res['عرض الضلفة']);
          const leafH = Number(res['ارتفاع الضلفة']);
          if (Number.isFinite(leafW) && Number.isFinite(leafH) && leafW > 0 && leafH > 0) {
            rawAdd(family, 'ضلفة النافذة', (leafW + leafH) * 4, 'عود', alu ? 650 : 580);
          }
        } else rawAdd(family,door?'ضلفة الباب':sliding?'ضلفة السحاب':'ضلفة النافذة',leaves*(2*w+2*h),'عود',alu?650:580);
        if(door){if(double)rawAdd(family,'تي صداد',h);}
        else if(!sliding)rawAdd(family,'تي T',(/flipper/.test(type)?w:h)*(/double_top/.test(type)?2:1));
        const pack=Number(res['مواد الباكيتة']);
        // خام الباكيتة يُحسب مثل خام الضلفة: PVC ÷ 560، ألمنيوم ÷ 640.
        // نخزن الطول الإجمالي بالسنتيمتر/وحدة النتائج، ثم نحسب عدد الأعواد بالمقسوم الخاص بالمادة.
        if(Number.isFinite(pack))rawAdd(family,'الباكيتة',pack,'عود',alu?650:580);
        // السكة قطعة بمقاس تجاري ثابت؛ الفرق المستهدف بين بُعد النافذة والسكة 6–26 سم.
        // القلاب يعتمد العرض، وبقية النوافذ تعتمد الارتفاع. الأبواب مستثناة تماماً.
        if(!door) {
          const reference = /flipper/.test(type) ? w : h;
          const sizes=[40,60,80,100,120,140,160,180];
          const suitable=sizes.filter(size=>reference-size>=6-1e-9 && reference-size<=26+1e-9);
          let selected = suitable.length ? suitable[suitable.length-1] : null;
          // لا نُسقط أي نافذة من مجموع المواد: للمقاسات الأصغر/الأكبر من المجال
          // نستخدم أقرب مقاس متاح من القائمة بدلاً من ترك بند السكة فارغاً.
          if(selected===null) selected = reference < sizes[0]+6 ? sizes[0] : sizes[sizes.length-1];
          const railName = sliding ? (alu ? 'سكة سحاب المونيوم' : 'سكة سحاب pvc') : 'سكة مفصلي';
          rawAdd(family,`${railName} ${selected} سم`,leaves,'قطعة');
        }
        const accFamily = alu ? 'اكسسوار حديد' : family;
        const acc=(name,n)=>rawAdd(accFamily, name,n,'قطعة');
        if(alu) {
          if(sliding67) acc('زاوية تجميع حلق سحاب',4);
          else if(type==='aluminum_sliding_normal') acc('زاوية تجميع ضلفة سحاب',8);
          else if(type==='aluminum_door') acc('زاوية تجميع مفصلي',6);
          else if(type==='aluminum_door_double') acc('زاوية تجميع مفصلي',10);
          else if(type==='aluminum_window_double') acc('زاوية تجميع مفصلي',12);
          else if(type.startsWith('aluminum_window_')) acc('زاوية تجميع مفصلي',8);
        }
        if(sliding){acc('عجلات',4);acc('مقبض',2);acc('مثبت',4);}
        else {
          // نافذة ضلفتين = 4 مفصلات، وضلفة واحدة = نصفها؛ كل غير السحاب يعتمد المفصلات.
          const hingeCount = door ? (double ? 8 : 4) : (double ? 4 : 2);
          acc('مفصلات',hingeCount);
          if(door){acc('قفل باب كامل',1);if(double){acc('طابات',2);acc('سكارة',2);acc('رزات',8);acc('مقبض باب كامل',1);}}
          else if(/flipper/.test(type))acc('قلاب',1);
          else {acc('مثبت',double?4:2);acc('مقبض نافذة',double?2:1);acc('كافلوتي',type==='window_double_top'?4:(double||/leaf_fixed/.test(type))?2:1);/* الزرات محسوبة ضمن المفصلات؛ لا تُعرض كبند مستقل. */}
        }
        }finally{for(const [name,n] of Object.entries(activeAcc))if(!usedAcc.has(name))rawAdd(typeNames[type]||type,name,n,'قطعة');activeAcc={};}
      });
      const wsCutPlans=wsBuildCutPlan(allResults,getShamberlyOffset());
      window._lastPhysicalCutPlans=wsCutPlans;
      // يستبدل تقدير الجمع فقط عندما تتوفر كل القطع من نتائج معادلة قياسية.
      const wsPlanForRow=r=>wsCutPlans.get([r.family,r.name,Number(r.rodLength)].join('|'));
      // The actual frame pieces determine required stock; use their exact grouping even if
      // legacy totals specified a different default commercial stock length.
      const wsFrameNames=new Set(['شمبرلي','حلق السحاب','حلق المونيوم','حلق سحاب المونيوم']);
      for(const [key,plan] of wsCutPlans){
        // Apply physical cutting plans to frames AND leaves, including saved formula results.
        const matching=[...rawTotals.values()].filter(r=>r.family===plan.family&&r.name===plan.name&&r.unit==='عود'&&Number(r.rodLength)===plan.stock);
        for(const row of matching){
          rawTotals.delete([row.family,row.name,row.unit,row.rodLength].join('|'));
        }
        const amount=plan.pieces.reduce((sum,p)=>sum+p.length,0);
        rawTotals.set([plan.family,plan.name,'عود',plan.stock].join('|'),{family:plan.family,name:plan.name,unit:'عود',rodLength:plan.stock,amount});
      }
      if(rawTotals.size){
        const familyOrder = family => family.startsWith('pvc') ? 0 : family === 'سرانتي' ? 1 : family.includes('المونيوم') || family.includes('سحاب المونيوم') ? 2 : 3;
        const rawRows=[...rawTotals.values()].sort((a,b)=>wsMaterialOrder(a.name)-wsMaterialOrder(b.name) || familyOrder(a.family)-familyOrder(b.family) || a.family.localeCompare(b.family,'ar') || a.name.localeCompare(b.name,'ar') || a.rodLength-b.rodLength);
        const materialRows=rawRows.filter(r=>r.unit!=='قطعة');
        const accessoryRows=rawRows.filter(r=>r.unit==='قطعة');
        const renderRawRows=(rows,offset=0)=>rows.forEach((r,i)=>{
          const value=r.unit==='عود'?r.amount/(Number(r.rodLength)||580):r.amount;
          // عدد الأعواد يُقرّب دائماً للأعلى: أي كسر فوق عود كامل يحتاج عوداً إضافياً.
          const plan=r.unit==='عود'?wsPlanForRow(r):null;
          const rounded = plan?.invalid?'غير قابل للقص':plan?plan.rods.length:r.unit === 'عود' ? Math.ceil(value) : r.unit==='م²'?Math.round(value*100)/100:Math.round(value);
          const trueValue = Math.round(value*1000)/1000;
          const cmHint = r.unit === 'عود' ? `<small class="raw-cm">مجموع الأطوال: ${Math.round(r.amount*100)/100} سم — طول العود: ${r.rodLength} سم</small>` : '';
          const remain=plan&&!plan.invalid?`<small class="raw-cm">المتبقي الإجمالي: ${trimNum(plan.rods.reduce((n,rod)=>n+plan.stock-rod.used,0))} سم</small>`:'';
          const planReport=plan&&!plan.invalid?wsExecutionCutReport(plan):plan?.invalid?'<p class="ws-cut-warning">توجد قطعة مع سماكة السلاح أطول من العود التجاري؛ لا تبدأ القص قبل مراجعتها.</p>':r.unit==='عود'?'<p>تقدير أطوال فقط؛ يلزم تعريف قطع هذا القطاع لتأكيد عدد الأعواد.</p>':'';
          const details=r.unit==='عود'?`<details class="ws-material-details"><summary>التفاصيل</summary><div class="ws-material-numbers">${cmHint}<small class="raw-exact">مكافئ مجموع الأطوال: ${trueValue} عود — ليس عدد أعواد الشراء</small>${remain}</div>${planReport}</details>`:'';
          html+=`<li class="total-row" style="background-color:${resultColors[(i+offset)%resultColors.length]};display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px"><span class="ws-material-name">${escHtml(r.name)}<small class="raw-family">${escHtml(r.family)}</small></span><span class="raw-amounts"><b class="raw-rounded">${rounded} ${r.unit}${r.unit==='عود'?' كامل':''}</b>${!plan&&r.unit==='عود'?'<small>تقديري</small>':''}</span>${details}</li>`;
        });
        html+='<div class="result-section totals-section"><h3>📦 مجموع المواد الخام فقط</h3><ul class="results-list totals-list">';
        renderRawRows(materialRows);
        html+='</ul>';
        if(accessoryRows.length){
          html+='<div class="section-subtitle" style="margin-top:12px">اكسسوارات</div><ul class="results-list totals-list">';
          renderRawRows(accessoryRows,materialRows.length);
          html+='</ul>';
        }
        html+='</div>';
      }

      document.getElementById('results').innerHTML = html;
      if(window._lastCutResults)window._lastCutResults.rawReport=document.querySelector('#results .totals-section')?.outerHTML||'';
      saveDraft();
      /* ⚠️ إصلاح 8.8: كانت calculateAll تكتب البطاقات دائماً وتتجاهل
         resultsAsTable. فمن يضغط «احسب» وهو في وضع الجدول يعود إلى
         البطاقات بلا سبب ظاهر، والمتغيّر يبقى true — فضغطته التالية
         على «عرض كجدول» تقلبه إلى false فيرى البطاقات مرة أخرى.
         أي أن الزر كان يحتاج ضغطتين ليعمل بعد كل حساب. */
      if (resultsAsTable) { rtPage = 0; renderResultsTable(); }
    }
  