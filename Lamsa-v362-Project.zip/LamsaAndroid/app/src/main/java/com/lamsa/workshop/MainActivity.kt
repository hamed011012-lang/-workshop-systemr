package com.lamsa.workshop

import android.Manifest
import android.content.pm.PackageManager
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.view.View
import android.webkit.*
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var loader: WebViewAssetLoader
    private lateinit var vendors: JSONObject
    private var chooser: ValueCallback<Array<Uri>>? = null
    private data class PendingSave(val bytes: ByteArray, val id: String, val reply: JavaScriptReplyProxy)
    private var pendingSave: PendingSave? = null
    private var printView: WebView? = null
    private var locationRequest: Pair<String, GeolocationPermissions.Callback>? = null
    private val home = "https://appassets.androidplatform.net/assets/www/index.html"
    private val origin = "https://appassets.androidplatform.net"
    private val fileLimit = 16 * 1024 * 1024

    private fun isLocal(uri: Uri): Boolean = uri.scheme == "https" && uri.host == "appassets.androidplatform.net" && (uri.port == -1 || uri.port == 443) && uri.path?.startsWith("/assets/www/") == true
    private fun message(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun reply(proxy: JavaScriptReplyProxy, id: String, error: String? = null) {
        proxy.postMessage(JSONObject().put("id", id).put("ok", error == null).put("error", error ?: "").toString())
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vendors = JSONObject(assets.open("vendor-map.json").bufferedReader().use { it.readText() })
        loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        setContentView(web)
        ViewCompat.setOnApplyWindowInsetsListener(web) { view, insets ->
            val edges = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            view.setPadding(edges.left, edges.top, edges.right, edges.bottom)
            insets
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            builtInZoomControls = false
            textZoom = 100
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                loader.shouldInterceptRequest(request.url)?.let { return it }
                val item = vendors.optJSONObject(request.url.toString()) ?: return null
                return try { WebResourceResponse(item.getString("mime"), "UTF-8", 200, "OK", mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "public, max-age=31536000"), assets.open(item.getString("path"))) }
                catch (_: Exception) { WebResourceResponse("text/plain", "UTF-8", 404, "Missing bundled dependency", emptyMap(), ByteArrayInputStream(ByteArray(0))) }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (isLocal(request.url)) return false
                if (request.isForMainFrame) external(request.url)
                return request.isForMainFrame
            }
            override fun onPageFinished(view: WebView, url: String) { CookieManager.getInstance().flush() }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) message("تعذر فتح الصفحة. يمكنك الرجوع ثم المحاولة مجددًا.")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(requestOrigin: String, callback: GeolocationPermissions.Callback) {
                if (requestOrigin.trimEnd('/') != origin) { callback.invoke(requestOrigin, false, false); return }
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) callback.invoke(requestOrigin, true, false)
                else { locationRequest?.let { it.second.invoke(it.first, false, false) }; locationRequest = requestOrigin to callback; requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 703) }
            }
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = callback
                return try { startActivityForResult(params.createIntent(), 701); true }
                catch (_: Exception) { chooser = null; callback.onReceiveValue(null); message("لا يوجد تطبيق لاختيار الملفات"); true }
            }
            override fun onJsAlert(view: WebView, url: String, text: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(text).setPositiveButton("حسنًا") { _, _ -> result.confirm() }.setOnCancelListener { result.cancel() }.show(); return true
            }
            override fun onJsConfirm(view: WebView, url: String, text: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(text).setPositiveButton("نعم") { _, _ -> result.confirm() }.setNegativeButton("إلغاء") { _, _ -> result.cancel() }.setOnCancelListener { result.cancel() }.show(); return true
            }
            override fun onJsPrompt(view: WebView, url: String, text: String, defaultValue: String?, result: JsPromptResult): Boolean {
                val input = EditText(this@MainActivity); input.setText(defaultValue.orEmpty())
                AlertDialog.Builder(this@MainActivity).setMessage(text).setView(input).setPositiveButton("حفظ") { _, _ -> result.confirm(input.text.toString()) }.setNegativeButton("إلغاء") { _, _ -> result.cancel() }.setOnCancelListener { result.cancel() }.show(); return true
            }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "LamsaNative", setOf(origin)) { _, msg, source, main, proxy ->
                if (!main || source.toString().trimEnd('/') != origin || !isLocal(Uri.parse(web.url ?: ""))) return@addWebMessageListener
                var id = ""
                try {
                    val raw = msg.data ?: throw IllegalArgumentException("طلب فارغ")
                    require(raw.length <= 48 * 1024 * 1024) { "حجم الملف كبير جدًا" }
                    val data = JSONObject(raw); id = data.getString("id")
                    when (data.getString("action")) {
                        "share" -> { share(data); reply(proxy, id) }
                        "save" -> save(data, id, proxy)
                        "copy" -> { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("اللمسة الأخيرة", data.optString("text"))); reply(proxy, id) }
                        "print" -> { printDocument(data.optString("html")); reply(proxy, id) }
                        else -> reply(proxy, id, "طلب غير معروف")
                    }
                } catch (e: Exception) { reply(proxy, id, e.message ?: "تعذرت العملية") }
            }
        } else message("حدّث Android System WebView لتفعيل مشاركة الملفات وحفظها")
        web.setDownloadListener { url, _, _, _, _ ->
            if (url.startsWith("https://") && !isLocal(Uri.parse(url))) external(Uri.parse(url))
            else web.evaluateJavascript("window.LamsaDownload && window.LamsaDownload(${JSONObject.quote(url)}, 'download')", null)
        }
        if (savedInstanceState == null || web.restoreState(savedInstanceState) == null) web.loadUrl(home)
        File(cacheDir, "shared").listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 7L * 86400000 }?.forEach { it.deleteRecursively() }
    }

    private fun printDocument(html: String) {
        val manager = getSystemService(PRINT_SERVICE) as PrintManager
        if (html.isBlank()) { manager.print("اللمسة الأخيرة", web.createPrintDocumentAdapter("اللمسة الأخيرة"), PrintAttributes.Builder().build()); return }
        require(html.length <= 8 * 1024 * 1024) { "مستند الطباعة كبير جدًا" }
        printView?.destroy()
        val view = WebView(this); printView = view
        view.settings.javaScriptEnabled = false; view.settings.allowFileAccess = false; view.settings.allowContentAccess = false
        view.webViewClient = object : WebViewClient() {
            private var started = false
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                loader.shouldInterceptRequest(r.url)?.let { return it }
                val item = vendors.optJSONObject(r.url.toString()) ?: return null
                return WebResourceResponse(item.getString("mime"), "UTF-8", assets.open(item.getString("path")))
            }
            override fun onPageFinished(v: WebView, url: String) {
                if (!started) { started = true; manager.print("اللمسة الأخيرة", v.createPrintDocumentAdapter("اللمسة الأخيرة"), PrintAttributes.Builder().build()) }
            }
        }
        view.loadDataWithBaseURL(home, html, "text/html", "UTF-8", null)
    }
    private fun bytes(file: JSONObject): ByteArray {
        val encoded = file.getString("base64")
        require(encoded.length <= (fileLimit * 4L / 3 + 8)) { "أقصى حجم للملف 16 ميجابايت" }
        return Base64.decode(encoded, Base64.DEFAULT).also { require(it.size <= fileLimit) }
    }
    private fun fileName(value: String): String = value.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").take(120).ifBlank { "lamsa-file" }
    private fun mime(value: String): String = if (value.matches(Regex("[a-zA-Z0-9.+-]+/[a-zA-Z0-9.+-]+"))) value else "application/octet-stream"
    private fun save(data: JSONObject, id: String, proxy: JavaScriptReplyProxy) {
        check(pendingSave == null) { "أكمل حفظ الملف السابق أولًا" }
        val file = data.getJSONObject("file")
        pendingSave = PendingSave(bytes(file), id, proxy)
        try { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime(file.optString("type"))).putExtra(Intent.EXTRA_TITLE, fileName(file.optString("name"))), 702) }
        catch (e: Exception) { pendingSave = null; throw e }
    }
    private fun share(data: JSONObject) {
        val files = data.optJSONArray("files")
        require((files?.length() ?: 0) <= 8) { "أقصى عدد للمشاركة 8 ملفات" }
        val uris = arrayListOf<Uri>(); var total = 0; var sharedMime: String? = null
        for (i in 0 until (files?.length() ?: 0)) {
            val item = files!!.getJSONObject(i); val content = bytes(item); total += content.size
            require(total <= 24 * 1024 * 1024) { "حجم المشاركة كبير جدًا" }
            val folder = File(cacheDir, "shared/" + UUID.randomUUID()); folder.mkdirs()
            val file = File(folder, fileName(item.optString("name"))); file.writeBytes(content)
            uris.add(FileProvider.getUriForFile(this, "$packageName.files", file))
            val current = mime(item.optString("type")); sharedMime = if (sharedMime == null) current else if (sharedMime == current) current else "*/*"
        }
        val intent = Intent(if (uris.size > 1) Intent.ACTION_SEND_MULTIPLE else Intent.ACTION_SEND)
        intent.type = sharedMime ?: "text/plain"
        intent.putExtra(Intent.EXTRA_SUBJECT, data.optString("title"))
        intent.putExtra(Intent.EXTRA_TEXT, listOf(data.optString("text"), data.optString("url")).filter { it.isNotBlank() }.joinToString("\n"))
        if (uris.size == 1) intent.putExtra(Intent.EXTRA_STREAM, uris[0])
        else if (uris.size > 1) intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        if (uris.isNotEmpty()) { intent.clipData = ClipData.newUri(contentResolver, "ملفات", uris[0]).apply { uris.drop(1).forEach { addItem(ClipData.Item(it)) } }; intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "مشاركة"))
    }
    private fun external(uri: Uri) {
        if (uri.scheme !in setOf("https", "http", "tel", "mailto", "whatsapp", "geo")) return
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { message("لا يوجد تطبيق لفتح الرابط") }
    }
    @Deprecated("Activity result compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 701) { chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); chooser = null }
        if (requestCode == 702) {
            val job = pendingSave ?: return; pendingSave = null
            val uri = data?.data
            if (resultCode != RESULT_OK || uri == null) { reply(job.reply, job.id, "تم إلغاء الحفظ"); return }
            try { contentResolver.openOutputStream(uri)?.use { it.write(job.bytes) } ?: throw IllegalStateException("تعذر فتح الملف"); reply(job.reply, job.id); message("تم حفظ الملف") }
            catch (e: Exception) { reply(job.reply, job.id, e.message ?: "تعذر الحفظ") }
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 703) { locationRequest?.let { it.second.invoke(it.first, grantResults.any { result -> result == PackageManager.PERMISSION_GRANTED }, false) }; locationRequest = null }
    }
    @Deprecated("Back compatibility")
    override fun onBackPressed() {
        web.evaluateJavascript("Boolean(window.LamsaBack && window.LamsaBack())") { handled ->
            if (handled != "true") {
                if (web.canGoBack()) web.goBack()
                else AlertDialog.Builder(this).setMessage("إغلاق التطبيق؟").setPositiveButton("إغلاق") { _, _ -> finish() }.setNegativeButton("إلغاء", null).show()
            }
        }
    }
    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    override fun onPause() { web.evaluateJavascript("window.wsSaveBeforeExit && window.wsSaveBeforeExit()", null); web.onPause(); CookieManager.getInstance().flush(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { chooser?.onReceiveValue(null); printView?.destroy(); web.destroy(); super.onDestroy() }
}
