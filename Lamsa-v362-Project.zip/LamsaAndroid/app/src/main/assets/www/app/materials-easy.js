(function(g){'use strict';
const clone=x=>JSON.parse(JSON.stringify(x));
function collect({type,w,h,res,cuttingSymbol,customMaterials,binding,accessoryOverrides={},operationName}){
 cuttingSymbol=cuttingSymbol||binding?.symbol;
 const rows=[],usedAcc=new Set(),activeAcc=accessoryOverrides;
 function rawAdd(family,name,amount,unit='عود',rodLength=580){
  if(unit==='عود'&&!customMaterials&&!binding){const alu=type.startsWith('aluminum_');rodLength=Number(localStorage.getItem(alu?'ws_alu_stock_cm':'ws_pvc_stock_cm'))||(alu?650:580);}
  if(unit==='قطعة'&&Object.hasOwn(activeAcc,name)){amount=activeAcc[name];usedAcc.add(name);}
  if(!Number.isFinite(amount)||amount<0)throw Error('كمية مادة غير صالحة: '+name);
  rows.push({family,name,amount,unit,rodLength});
 }
 function original(){
        if(customMaterials){customMaterials.forEach(r=>rawAdd(operationName||type,r.name,r.amount,r.unit,r.rodLength));return;}
        const linked=binding;
        if(linked){
          const materials=window.WSSymbolFormulas.materials(linked,res);
          materials.forEach(r=>rawAdd(linked.name,r.name,r.amount,r.unit,r.rodLength));
          const four=['two-center-fixed','two-side-fixed','two-three-fixed','two-top-fixed-bottom','fixed-top-two-bottom','double-fixed-left','double-fixed-right','double-fixed-top','double-four-fixed'];
          const two=['window-double','leaf-fixed','single-fixed-left','single-fixed-right','single-fixed-top','single-fixed-bottom'];
          const kafloti=four.includes(cuttingSymbol)?4:two.includes(cuttingSymbol)?2:0;
          if(kafloti&&!materials.some(r=>/كافلوت/.test(r.name)))rawAdd(linked.name,'كافلوتي',kafloti,'قطعة');
          return;
        }

        const alu=type.startsWith('aluminum_');
        const family = type === 'sliding_poly_one' ? 'pvc سحاب بولي ون' : type === 'sliding_poplist' ? 'pvc سحاب بوبلست' : alu ? (['aluminum_67','aluminum_sliding_67','aluminum_sliding_normal'].includes(type) ? 'سحاب المونيوم' : 'المونيوم مفصلي') : 'pvc مفصلي';
        if(type.startsWith('sranti_')) {
          ['مواد خام الحصيرة','المواد الخام'].forEach(k=>{const n=Number(res[k]);if(Number.isFinite(n))rawAdd('سرانتي',k,n,'كمية');});return;
        }
        const sliding67=['aluminum_67','aluminum_sliding_67'].includes(type);
        const sliding=sliding67||type==='aluminum_sliding_normal'||type.startsWith('sliding_');
        const door=type.includes('door');
        const double=/double|sliding|aluminum_67|poplist/.test(type)&&!/single|leaf_fixed|flipper/.test(type);
        const leaves=double?2:1;
        const savedFrameOffset=parseFloat(localStorage.getItem('shamberly_offset'));
        const frameOffset=Number.isFinite(savedFrameOffset)?savedFrameOffset:0.3;
        rawAdd(family,alu ? (sliding ? 'حلق سحاب المونيوم' : 'حلق المونيوم') : (sliding ? 'حلق السحاب' : 'شمبرلي'), (type==='door_single'||type==='aluminum_door') ? (alu?Number(res['قص الحلق']??res['عرض الحلق']??w):Number(w)+frameOffset)+12+2*((alu?Number(res['ارتفاع الحلق']??h):Number(h)+frameOffset)+12) : type==='aluminum_door_double' ? 2*((Number(res['عرض الحلق'])||0)+(Number(res['ارتفاع الحلق'])||0)) : 2*w+2*h+45);
        if(!alu)rawAdd(family,'حديد شمبرلي',2*w+2*h+45);
        if(sliding67){
          rawAdd(family,'سكار نظام 67',2*(Number(res['ارتفاع الضلفة'])||h));
          rawAdd(family,'شنكل نظام 67',2*h);
          rawAdd(family,'عجل نظام 67',2*w);
          rawAdd(family,'مخفض نظام 67',4*(Number(res['عرض مخفض الباكيتة'])||0)+4*(Number(res['ارتفاع مخفض الباكيتة'])||0));
        }else if(type==='aluminum_sliding_normal') {
          rawAdd(family,'ضلفة السحاب',(Number(res['عرض الضلفة'])+Number(res['ارتفاع الضلفة']))*4,'عود',650);
        }else if(type==='aluminum_door_double') { const first=Number(res['عرض الضلفة الكبيرة'])||0; const second=Number(res['عرض الضلفة الصغيرة'])||0; const height=Number(res['ارتفاع الضلفة'])||0; rawAdd(family,'ضلفة الباب',2*(first+second)+4*height,'عود',650); }
        else if (!door && double) {
          // ضلف النوافذ ذات الضلفتين: الاعتماد على أبعاد الضلفة الظاهرة في النتائج
          // PVC = (عرض الضلفة + ارتفاع الضلفة) × 4 ÷ 560
          // Aluminium = (عرض الضلفة + ارتفاع الضلفة) × 4 ÷ 640
          const leafW = Number(res['عرض الضلفة']);
          const leafH = Number(res['ارتفاع الضلفة']);
          if (Number.isFinite(leafW) && Number.isFinite(leafH) && leafW > 0 && leafH > 0) {
            rawAdd(family, sliding?'ضلفة السحاب':'ضلفة النافذة', (leafW + leafH) * 4, 'عود', alu ? 650 : 580);
          }
        } else rawAdd(family,door?'ضلفة الباب':sliding?'ضلفة السحاب':'ضلفة النافذة',leaves*(2*w+2*h),'عود',alu?650:580);
        if(door){if(double)rawAdd(family,'تي صداد',h);}
        else if(!sliding)rawAdd(family,'تي T',(/flipper/.test(type)?w:h)*(/double_top/.test(type)?2:1));
        const pack=Number(res['مواد الباكيتة']);
        // خام الباكيتة يُحسب مثل خام الضلفة: PVC ÷ 560، ألمنيوم ÷ 640.
        // نخزن الطول الإجمالي بالسنتيمتر/وحدة النتائج، ثم نحسب عدد الأعواد بالمقسوم الخاص بالمادة.
        if(Number.isFinite(pack))rawAdd(family,'الباكيتة',pack,'عود',alu?650:580);
        // السكة قطعة بمقاس تجاري ثابت؛ الفرق المستهدف بين بُعد النافذة والسكة 6–26 سم.
        // القلاب يعتمد العرض، وبقية النوافذ تعتمد الارتفاع. الأبواب مستثناة تماماً.
        if(!door) {
          const reference = /flipper/.test(type) ? w : h;
          const sizes=[40,60,80,100,120,140,160,180];
          const suitable=sizes.filter(size=>reference-size>=6-1e-9 && reference-size<=26+1e-9);
          let selected = suitable.length ? suitable[suitable.length-1] : null;
          // لا نُسقط أي نافذة من مجموع المواد: للمقاسات الأصغر/الأكبر من المجال
          // نستخدم أقرب مقاس متاح من القائمة بدلاً من ترك بند السكة فارغاً.
          if(selected===null) selected = reference < sizes[0]+6 ? sizes[0] : sizes[sizes.length-1];
          const railName = sliding ? (alu ? 'سكة سحاب المونيوم' : 'سكة سحاب pvc') : 'سكة مفصلي';
          rawAdd(family,`${railName} ${selected} سم`,leaves,'قطعة');
        }
        const accFamily = alu ? 'اكسسوار حديد' : family;
        const acc=(name,n)=>rawAdd(accFamily, name,n,'قطعة');
        if(alu) {
          if(sliding67) acc('زاوية تجميع حلق سحاب',4);
          else if(type==='aluminum_sliding_normal') acc('زاوية تجميع ضلفة سحاب',8);
          else if(type==='aluminum_door') acc('زاوية تجميع مفصلي',6);
          else if(type==='aluminum_door_double') acc('زاوية تجميع مفصلي',10);
          else if(type==='aluminum_window_double') acc('زاوية تجميع مفصلي',12);
          else if(type.startsWith('aluminum_window_')) acc('زاوية تجميع مفصلي',8);
        }
        if(sliding){acc('عجلات',4);acc('مقبض',2);acc('مثبت',4);}
        else {
          // نافذة ضلفتين = 4 مفصلات، وضلفة واحدة = نصفها؛ كل غير السحاب يعتمد المفصلات.
          const hingeCount = door ? (double ? 8 : 4) : (double ? 4 : 2);
          acc('مفصلات',hingeCount);
          if(door){acc('قفل باب كامل',1);if(double){acc('طابات',2);acc('سكارة',2);acc('رزات',8);acc('مقبض باب كامل',1);}}
          else if(/flipper/.test(type))acc('قلاب',1);
          else {acc('مثبت',double?4:2);acc('مقبض نافذة',double?2:1);acc('كافلوتي',type==='window_double_top'?4:(double||/leaf_fixed/.test(type))?2:1);/* الزرات محسوبة ضمن المفصلات؛ لا تُعرض كبند مستقل. */}
        }
 }
 original();for(const [name,n] of Object.entries(activeAcc))if(!usedAcc.has(name))rawAdd(operationName||type,name,n,'قطعة');
 return rows;
}
function apply(rows,edits,context){
 const result=clone(rows),warnings=[];
 for(const rule of edits||[]){
  let matches=result.filter(r=>r.name===rule.name&&r.unit===rule.unit);
  if(rule.add){if(matches.length)throw Error('المادة المضافة موجودة بالفعل: '+rule.name);const row={family:context.operationName||context.type,name:rule.name,unit:rule.unit,amount:0,rodLength:rule.rod||580};result.push(row);matches=[row];}
  if(!matches.length){warnings.push('لم توجد مادة مطابقة: '+rule.name);continue;}
  for(const row of matches){
   let base=rule.base==='original'?row.amount:rule.base==='w'?context.w:rule.base==='h'?context.h:rule.base==='perimeter'?2*(context.w+context.h):rule.base==='area'?context.w*context.h/10000:rule.base==='result'?context.res[rule.result]:1;
   if(['w','h','perimeter','result'].includes(rule.base)&&rule.unit==='متر')base/=100;
   const amount=(base+rule.offset)*rule.factor*(1+rule.waste/100);
   if(!Number.isFinite(amount)||amount<0)throw Error('نتيجة مادة سالبة أو غير صالحة: '+rule.name);
   if(rule.unit==='قطعة'&&!Number.isInteger(Math.round(amount*1e8)/1e8))throw Error('عدد القطع يجب أن يكون عددًا صحيحًا: '+rule.name);
   row.amount=Math.round(amount*1e8)/1e8;if(rule.unit==='عود'&&rule.rod)row.rodLength=rule.rod;
  }
 }
 return {rows:result,warnings};
}
function preview(file,systemId,type,w,h,manual){
 const sys=g.WSEngine.systemFromList(systemId,file.systems),trial=g.WSStudio.trial(file,systemId,type,w,h,manual,true),binding=file.symbolFormulas.find(b=>b.key===type)||null;
 const rows=collect({type,w,h,res:trial.cut,cuttingSymbol:binding?.symbol,customMaterials:g.WSEngine.mapped(file,'materials',sys.cutProfile,type)?trial.materials:null,binding,accessoryOverrides:trial.accessories,operationName:file.customTypeNames[type]||g.WSCuttingDefaults.names[type]||type});
 return {...apply(rows,g.WSEngine.mapped(file,'rawEdits',sys.cutProfile,type),{type,w,h,res:trial.cut}),original:rows,cut:trial.cut};
}
g.WSMaterials=Object.freeze({collect,apply,preview});
})(window);
