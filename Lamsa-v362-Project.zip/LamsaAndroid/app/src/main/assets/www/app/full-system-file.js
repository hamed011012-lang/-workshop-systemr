(function(g){'use strict';
const FORMAT='workshop-full-systems-v2';
const names={pvc:'PVC',xtype_alum:'الألمنيوم',xtype_pvc_slide:'PVC سحاب',xtype_ser_normal:'سرانتي عادي',xtype_ser_out:'سرانتي خارجي',xtype_net_move:'ناموسية متحركة',xtype_net_fix:'ناموسية ثابتة',xtype_box_pvc:'صندوق PVC',xtype_box_light:'صندوق خفاف',xtype_kitchen_skirt:'سكارات مطبخ'};
const keys={systems:'ws_calculation_systems_v1',bindings:'ws_symbol_formulas_v1',profiles:'app_custom_profiles',customTypeNames:'app_custom_types',direct:'ws_profile_direct_v1',options:'ws_workshop_options_v1'};
const copy=x=>JSON.parse(JSON.stringify(x));
function object(x){return x&&typeof x==='object'&&!Array.isArray(x);}
function safeKey(x){return typeof x==='string'&&x.length<=160&&!['__proto__','constructor','prototype'].includes(x);}
function read(k,fallback){const text=localStorage.getItem(k);if(!text)return copy(fallback);try{return JSON.parse(text);}catch(e){throw Error('بيانات محلية غير صالحة: '+k+'؛ لم تُكتب فوقها أي بيانات');}}
function profiles(raw){
 if(!object(raw)||!Object.keys(raw).length||Object.keys(raw).length>100)throw Error('ملف أنظمة القص فارغ أو غير صالح');
 const out={};for(const [name,types] of Object.entries(raw)){
  if(!safeKey(name)||!name.trim()||!object(types))throw Error('اسم أو محتوى نظام القص غير صالح');
  out[name]={};for(const [type,rows] of Object.entries(types)){
   if(!safeKey(type)||!/^\w+$/.test(type)||!Array.isArray(rows)||!rows.length||rows.length>100)throw Error('نوع معادلة غير صالح: '+type);
   if(type.startsWith('custom_symbol_'))throw Error('معادلات الرموز تُعدل في symbolFormulas فقط لمنع تعارض تعريفين');
   const seen=new Set();out[name][type]=rows.map(r=>{
    if(!r||!String(r.label||'').trim()||String(r.label).length>120||seen.has(r.label)||!(g.WSEngine?g.WSEngine.safe(r.calc):g.WSCuttingDefaults.isSafeFormula(r.calc)))throw Error('معادلة غير صالحة في '+name+' / '+type);
    seen.add(r.label);return {label:String(r.label),calc:r.calc,editNum:String(r.editNum??'')};
   });
  }
  if(!Object.keys(out[name]).length)throw Error('نظام قص بلا معادلات: '+name);
 }
 return out;
}
function exportFile(){
 const stored=read(keys.profiles,{});if(!object(stored))throw Error('أنظمة القص المحلية غير صالحة');
 const cutProfiles={...stored};if(!cutProfiles['الافتراضي'])cutProfiles['الافتراضي']=copy(g.WSCuttingDefaults.formulas);
 for(const [name,types] of Object.entries(cutProfiles)){if(!object(types))throw Error('نظام قص محلي غير صالح');cutProfiles[name]=Object.fromEntries(Object.entries(types).filter(([key])=>!key.startsWith('custom_symbol_')));}
 const local=g.WSSystems.all(),customTypes=read('ws_custom_types',[]),extraTypes=read('ws_extra_types',[]),types=[...(Array.isArray(customTypes)?customTypes:[]),...(Array.isArray(extraTypes)?extraTypes:[])],systemNames={...names};
 if(Array.isArray(types))types.forEach(t=>{if(t?.id&&safeKey(t.id))systemNames[t.id]=String(t.name||t.id);});
 const systems=Object.entries(systemNames).map(([id,name])=>{
  const d=local.find(x=>x.id===id);const custom=Array.isArray(types)&&types.find(x=>x.id===id);
  return d||{id,name,enabled:true,rules:g.WSSystems.defaults(custom?.calc==='ser'?'xtype_ser_normal':id),baseMaterial:Object.hasOwn(names,id)?id:custom?.calc==='ser'?'xtype_ser_normal':'pvc',cutProfile:'الافتراضي'};
 });
 local.forEach(d=>{if(!systems.some(x=>x.id===d.id))systems.push(d);});
 const symbolFormulas=g.WSSymbolFormulas.all();
 symbolFormulas.forEach(d=>{if(!systems.some(x=>x.id===d.material))systems.push({id:d.material,name:d.material,enabled:true,rules:g.WSSystems.defaults(d.material),baseMaterial:Object.hasOwn(names,d.material)?d.material:'pvc',cutProfile:'الافتراضي'});});
 systems.forEach(d=>{d.cutProfile=d.cutProfile||'الافتراضي';d.baseMaterial=d.baseMaterial||(Object.hasOwn(names,d.id)?d.id:'pvc');});
 return {format:FORMAT,version:2,exportedAt:new Date().toISOString(),instructions:[
  'systems: جميع قواعد حساب الأمتار. كل نظام مرتبط بنظام قص عبر cutProfile. غيّر enabled إلى true لتفعيل قواعده.',
  'cutProfiles: جميع المعادلات الأصلية والمخصصة. label اسم الناتج، calc التعبير، editNum معامل المحرر. w العرض وh الارتفاع بالسنتيمتر.',
  'symbolFormulas: معادلات الرموز والمواد. عدّل base وoffset وdivisor وquantity وunit وrod؛ لا تكرر معادلاتها داخل cutProfiles.',
  'يمكن حذف الأنظمة غير المطلوبة من الملف قبل الاستيراد؛ الاستبدال يحدث للمعرّفات الموجودة في الملف فقط ولا يحذف بقية الأنظمة.',
  'اختيار نظام جديد ينسخ القواعد والمعادلات بأسماء جديدة؛ اختيار استبدال يحدث الأنظمة القائمة. ملف JSON قابل للتحرير بأي محرر نصوص.'
 ],systems,cutProfiles:profiles(cutProfiles),customTypeNames:Object.fromEntries(Object.entries(read(keys.customTypeNames,{})).filter(([key])=>Object.values(cutProfiles).some(types=>Object.hasOwn(types,key)))),symbolFormulas,workshopOptions:g.WSStudio?.options()||{learning:{enabled:true,tolerance:10,limit:6},materials:{}}};
}
function validate(data){
 if(!data||data.format!==FORMAT||data.version!==2||!Array.isArray(data.systems)||!data.systems.length||data.systems.length>1000||!Array.isArray(data.symbolFormulas)||data.symbolFormulas.length>2000)throw Error('ملف النظام الكامل غير صالح أو إصداره غير مدعوم');
 const systems=data.systems.map(g.WSSystems.normalize),bindings=data.symbolFormulas.map(g.WSSymbolFormulas.normalize),cutProfiles=profiles(data.cutProfiles),custom=Object.assign({},data.customTypeNames||{});
 if(new Set(systems.map(d=>d.id)).size!==systems.length||new Set(bindings.map(d=>d.key)).size!==bindings.length)throw Error('معرّفات أنظمة أو رموز مكررة');
 for(const [k,v] of Object.entries(custom)){if(!safeKey(k)||!/^custom_\w+$/.test(k)||typeof v!=='string'||!v.trim()||v.length>120)throw Error('اسم نوع قص مخصص غير صالح');}
 systems.forEach(d=>{if(!cutProfiles[d.cutProfile||'الافتراضي'])throw Error('نظام القص المرتبط غير موجود في الملف: '+d.name);});
 bindings.forEach(d=>{if(!systems.some(x=>x.id===d.material))throw Error('نظام أمتار الرمز غير موجود في الملف: '+d.name);});
 for(const formulas of Object.values(cutProfiles))for(const type of Object.keys(formulas)){
  if(!Object.hasOwn(g.WSCuttingDefaults.names,type)&&!custom[type])throw Error('اسم نوع المعادلة غير موجود: '+type);
 }
 if(g.WSEngine)g.WSEngine.validateFile(data);
 const workshopOptions=g.WSStudio?g.WSStudio.validateOptions(data.workshopOptions||{learning:{enabled:true,tolerance:10,limit:6},materials:{}}):data.workshopOptions;
 return {systems,bindings,cutProfiles,custom,workshopOptions};
}
function unique(base,taken){let name=base,i=2;while(Object.hasOwn(taken,name))name=base+' '+i++;return name;}
function importFile(data,mode='new',name='نسخة مستوردة',dryRun=false){
 if(!['new','replace'].includes(mode))throw Error('اختر إضافة نظام جديد أو استبدال الحالي');
 const parsed=validate(data);if(g.WSEngine){const failures=g.WSEngine.runTests(data).filter(t=>!t.passed);if(failures.length)throw Error('فشل '+failures.length+' اختبار محفوظ؛ راجع نتائج النظام قبل الاستيراد');}const stamp=Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);name=String(name||'نسخة مستوردة').trim().slice(0,60);
 const oldSystems=g.WSSystems.all(),oldBindings=g.WSSymbolFormulas.all(),oldProfiles=read(keys.profiles,{}),oldCustom=read(keys.customTypeNames,{}),direct=read(keys.direct,{});
 if(!object(oldProfiles)||!object(oldCustom)||!object(direct))throw Error('إعدادات محلية غير صالحة؛ تعذر الاستيراد');
 if(!oldProfiles['الافتراضي'])oldProfiles['الافتراضي']=copy(g.WSCuttingDefaults.formulas);
 const materialMap={},profileMap={},typeMap={};
 parsed.systems.forEach((d,i)=>materialMap[d.id]=mode==='new'?'sys_'+stamp+'_'+i:d.id);
 let serial=0;Object.keys(parsed.custom).forEach(k=>typeMap[k]=mode==='new'?'custom_import_'+stamp+'_'+serial++:k);
 for(const oldName of Object.keys(parsed.cutProfiles)){
  const next=mode==='new'?unique(name+' — '+oldName,oldProfiles):oldName;profileMap[oldName]=next;
  oldProfiles[next]=Object.fromEntries(Object.entries(parsed.cutProfiles[oldName]).map(([k,v])=>[typeMap[k]||k,v]));direct[next]=true;
 }
 for(const [k,v] of Object.entries(parsed.custom))oldCustom[typeMap[k]]=v;
 const importedSystems=parsed.systems.map(d=>({...d,id:materialMap[d.id],name:mode==='new'?d.name+' — '+name:d.name,baseMaterial:d.baseMaterial||(Object.hasOwn(names,d.id)?d.id:'pvc'),cutProfile:profileMap[d.cutProfile||'الافتراضي'],...(d.parentSystem?{parentSystem:materialMap[d.parentSystem]}:{})}));
 const importedBindings=parsed.bindings.map(d=>g.WSSymbolFormulas.normalize({...d,material:materialMap[d.material],name:mode==='new'?d.name+' — '+name:d.name}));
 const options=g.WSStudio?.options()||{learning:{enabled:true,tolerance:10,limit:6},materials:{}};
 if(parsed.workshopOptions){if(mode==='replace')for(const k of Object.keys(options.materials)){if(Object.hasOwn(parsed.cutProfiles,k.slice(0,k.lastIndexOf('::'))))delete options.materials[k];}options.learning=parsed.workshopOptions.learning;if(parsed.workshopOptions.advice)options.advice=parsed.workshopOptions.advice;for(const [k,v] of Object.entries(parsed.workshopOptions.materials)){const at=k.lastIndexOf('::'),profile=k.slice(0,at),type=k.slice(at+2);if(at<0||!profileMap[profile])throw Error('بروفايل قواعد المواد غير موجود');options.materials[profileMap[profile]+'::'+(typeMap[type]||type)]=v;}}
 if(g.WSEngine&&parsed.workshopOptions?.engineering){const e=g.WSEngine.rebaseEngineering(parsed.workshopOptions.engineering,profileMap,materialMap,typeMap);const old=g.WSEngine.validate(options.engineering);for(const k of ['parameters','links','accessories','cutItems','rawEdits']){const retained=Object.fromEntries(Object.entries(old[k]).filter(([key])=>mode==='new'||!Object.values(profileMap).includes(['parameters','links'].includes(k)?key:key.slice(0,key.lastIndexOf('::')))));e[k]={...retained,...e[k]};}e.tests=old.tests.filter(t=>mode==='new'||!Object.values(materialMap).includes(t.system)).concat(e.tests);options.engineering=e;}
 const next={options,systems:oldSystems.filter(x=>!importedSystems.some(d=>d.id===x.id)).concat(importedSystems),bindings:oldBindings.filter(x=>!importedBindings.some(d=>d.key===x.key)).concat(importedBindings),profiles:oldProfiles,customTypeNames:oldCustom,direct};
 const result={systems:importedSystems.length,profiles:Object.keys(parsed.cutProfiles).length,bindings:importedBindings.length,mode,systemIds:importedSystems.map(d=>d.id),profileNames:Object.values(profileMap)};
 if(dryRun)return result;
 const previous=Object.fromEntries(Object.entries(keys).map(([k,v])=>[v,localStorage.getItem(v)]));
 localStorage.setItem('ws_full_system_import_backup_v2',JSON.stringify(previous));
 try{for(const [part,key] of Object.entries(keys))localStorage.setItem(key,JSON.stringify(next[part]));}
 catch(e){let failed=false;for(const [key,value] of Object.entries(previous)){try{if(value===null)localStorage.removeItem(key);else localStorage.setItem(key,value);}catch(_){failed=true;}}
  throw Error(failed?'تعذر إكمال الاستيراد والاسترجاع المحلي؛ احتفظ بلقطة ws_full_system_import_backup_v2 للمراجعة':'تعذر الحفظ؛ أُعيدت الإعدادات السابقة');}
 return result;
}
g.WSFullSystemFile=Object.freeze({exportFile,validate,importFile});
})(window);
