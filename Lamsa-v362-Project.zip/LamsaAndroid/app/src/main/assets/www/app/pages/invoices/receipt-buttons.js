/*
 * Receipt UI Controller — v140
 * Event delegation: the buttons may be re-rendered without losing their handler.
 * The controller never owns the financial transaction; it only routes the click
 * to the single transaction functions defined by app.js.
 */
(function () {
  'use strict';
  const SAVE_ID = 'btn-save-payment-receipt';
  const PRINT_ID = 'btn-save-print-payment-receipt';
  let installed = false;

  function install() {
    if (installed) return;
    installed = true;
    document.addEventListener('click', function (event) {
      const btn = event.target && event.target.closest ? event.target.closest('#' + SAVE_ID + ', #' + PRINT_ID) : null;
      if (!btn) return;
      event.preventDefault();
      event.stopPropagation();
      if (btn.disabled || btn.getAttribute('aria-busy') === 'true') return;

      try {
        const mode = btn.id === SAVE_ID ? 'save' : 'print';
        if (window.AppReceiptCommand && typeof window.AppReceiptCommand.run === 'function') {
          Promise.resolve(window.AppReceiptCommand.run(mode)).catch(function (error) {
            console.error('[ReceiptController]', error);
            const msg = error && error.message ? error.message : 'تعذّر تنفيذ العملية.';
            if (typeof window.showSuccessToast === 'function') window.showSuccessToast('⚠️ ' + msg);
            else alert('⚠️ ' + msg);
          });
        } else if (mode === 'save' && typeof window.savePaymentReceipt === 'function') {
          Promise.resolve(window.savePaymentReceipt()).catch(function (error) { throw error; });
        } else if (mode === 'print' && typeof window.savePaymentReceiptAndPrint === 'function') {
          Promise.resolve(window.savePaymentReceiptAndPrint()).catch(function (error) { throw error; });
        } else {
          throw new Error('وظيفة الواصل لم تُحمّل بعد. أعد فتح نافذة الواصل.');
        }
      } catch (error) {
        console.error('[ReceiptController]', error);
        if (typeof window.showSuccessToast === 'function') {
          window.showSuccessToast('⚠️ ' + (error && error.message ? error.message : 'تعذّر تنفيذ العملية.'));
        } else {
          alert('⚠️ ' + (error && error.message ? error.message : 'تعذّر تنفيذ العملية.'));
        }
      }
    }, { passive: false });
  }

  if (window.AppRuntime && typeof window.AppRuntime.ready === 'function') window.AppRuntime.ready(install);
  else if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, { once: true });
  else install();
})();
