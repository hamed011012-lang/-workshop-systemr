(function(){'use strict';
window.WS_ANDROID=true;
if(window.top!==window)return;
const pending=new Map();let seq=0;
function native(action,data={}){return new Promise((resolve,reject)=>{if(!window.LamsaNative){reject(new Error('حدّث Android System WebView'));return;}const id=String(++seq);pending.set(id,{resolve,reject});try{LamsaNative.postMessage(JSON.stringify({id,action,...data}));}catch(e){pending.delete(id);reject(e);}});}
if(window.LamsaNative)LamsaNative.onmessage=event=>{try{const m=JSON.parse(event.data),p=pending.get(m.id);if(!p)return;pending.delete(m.id);m.ok?p.resolve():p.reject(new Error(m.error||'تعذرت العملية'));}catch(e){console.error(e);}};
async function encode(file){if(file.size>16*1024*1024)throw Error('أقصى حجم للملف 16 ميجابايت');const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(new Error('تعذرت قراءة الملف'));reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.readAsDataURL(file);});return {name:file.name||'lamsa-file',type:file.type||'application/octet-stream',base64};}
Object.defineProperty(navigator,'share',{configurable:true,value:async data=>{if((data.files||[]).length>8)throw Error('أقصى عدد للمشاركة 8 ملفات');return native('share',{title:data.title||'',text:data.text||'',url:data.url||'',files:await Promise.all((data.files||[]).map(encode))});}});
Object.defineProperty(navigator,'canShare',{configurable:true,value:data=>(data?.files||[]).length<=8&&(data?.files||[]).every(f=>f.size<=16*1024*1024)});
window.LamsaDownload=async function(url,name){try{const blob=await (await fetch(url)).blob();const file=await encode(blob);file.name=name||'lamsa-file';await native('save',{file});}catch(e){alert(e.message);}};
document.addEventListener('click',event=>{const a=event.target.closest?.('a[download]');if(!a)return;event.preventDefault();window.LamsaDownload(a.href,a.download);},true);
window.LamsaBack=function(){
 const visible=e=>e&&!e.hidden&&getComputedStyle(e).display!=='none'&&getComputedStyle(e).visibility!=='hidden';
 const dialogs=[...document.querySelectorAll('dialog[open]')];if(dialogs.length){const d=dialogs.at(-1);const event=new Event('cancel',{cancelable:true});if(d.dispatchEvent(event))d.close();return true;}
 const overlays=[...document.querySelectorAll('.tp-overlay,.archive-overlay.open,[role="dialog"]')].filter(visible);
 if(overlays.length){const d=overlays.at(-1);const close=d.querySelector('[aria-label="إغلاق"],.close-archive-btn,.tp-cancel');if(close)close.click();else if(d.id==='typePickerOverlay'&&typeof closeTypePicker==='function')closeTypePicker();else d.remove();return true;}
 const settings=document.getElementById('ws-settings-panel');if(visible(settings)){settings.hidden=true;return true;}
 const formulas=document.getElementById('formulas-content');if(visible(formulas)&&formulas.getBoundingClientRect().height>0&&typeof toggleEditor==='function'){toggleEditor();return true;}
 return false;
};
const originalClick=HTMLAnchorElement.prototype.click;
HTMLAnchorElement.prototype.click=function(){if(this.hasAttribute('download')){window.LamsaDownload(this.href,this.download);return;}return originalClick.call(this);};
window.LamsaPrintHtml=html=>native('print',{html:String(html)}).catch(e=>alert(e.message));
const browserOpen=window.open.bind(window);
window.open=function(url,...args){if(url && url!=='about:blank')return browserOpen(url,...args);let html='';const popup={closed:false,opener:null,focus(){},close(){this.closed=true;},print(){window.LamsaPrintHtml(html);},document:{open(){html='';},write(value){html+=String(value);},close(){window.LamsaPrintHtml(html);}}};return popup;};
window.print=()=>native('print').catch(e=>alert(e.message));
try{Object.defineProperty(navigator.clipboard,'writeText',{configurable:true,value:text=>native('copy',{text:String(text)})});}catch(_){}
})();
