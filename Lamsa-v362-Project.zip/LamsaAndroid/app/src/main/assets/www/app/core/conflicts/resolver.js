/* Workshop Conflict Resolver v153.
 * Presents local/remote snapshots when available and only applies an explicit
 * resolver registered for the entity. Never overwrites data implicitly.
 */
(function(g){'use strict'; if(g.AppConflictResolver)return;
  const now=()=>Date.now();
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const pretty=v=>{try{return JSON.stringify(v,null,2)}catch(_){return String(v)} };
  function resolverFor(c){
    const r=g.AppConflictResolvers||{};
    return r[String(c.entity)]||r['*']||null;
  }
  async function snapshot(c){
    let local=c&&c.localSnapshot!=null?c.localSnapshot:c&&c.payload;
    let remote=c&&c.remoteSnapshot!=null?c.remoteSnapshot:(c&&c.error&&c.error.remoteSnapshot);
    if(remote==null && g.AppVersioning && g.AppVersioning.list && c){
      try{const revs=await g.AppVersioning.list(c.entity,c.entityId,50); if(revs.length) local=revs[revs.length-1].data;}catch(_){ }
    }
    return {local,remote,hasRemote:remote!=null};
  }
  async function inspect(c){
    const s=await snapshot(c); return Object.assign({},c,{localSnapshot:s.local,remoteSnapshot:s.remote,hasRemote:s.hasRemote,canApply:!!resolverFor(c)});
  }
  async function decide(c,decision){
    const d=String(decision||'reviewed');
    const resolver=resolverFor(c);
    if((d==='keep-local'||d==='keep-remote') && typeof resolver!=='function')
      throw new Error('لا يوجد معالج آمن لتطبيق هذا القرار على هذا النوع من البيانات');
    let result=null;
    if(typeof resolver==='function') result=await resolver({conflict:c,decision:d,snapshots:await snapshot(c)});
    if(g.AppConflictCenter&&g.AppConflictCenter.resolve) return g.AppConflictCenter.resolve(c.id,d,{result,at:now()});
    return {id:c.id,decision:d,result};
  }
  function modal(){
    let el=document.getElementById('app-conflict-modal');
    if(el)return el;
    el=document.createElement('div'); el.id='app-conflict-modal'; el.className='fixed inset-0 z-[9999] hidden';
    el.innerHTML=`<div class="absolute inset-0 bg-black/40" data-conflict-close></div><div class="absolute inset-x-3 top-8 bottom-8 mx-auto max-w-5xl rounded-2xl bg-white shadow-2xl overflow-hidden flex flex-col"><div class="p-4 border-b flex items-center justify-between gap-3"><div><div class="font-black text-lg">مركز التعارضات</div><div id="app-conflict-sub" class="text-xs text-slate-500"></div></div><button type="button" data-conflict-close class="px-3 py-1.5 rounded-xl border font-bold">إغلاق</button></div><div class="flex-1 overflow-auto p-4"><div id="app-conflict-list" class="space-y-2"></div><div id="app-conflict-detail" class="hidden mt-4"><div class="grid md:grid-cols-2 gap-3"><section class="border rounded-xl overflow-hidden"><div class="px-3 py-2 bg-slate-50 font-black">النسخة المحلية</div><pre id="conflict-local" class="p-3 text-[11px] overflow-auto max-h-80 whitespace-pre-wrap"></pre></section><section class="border rounded-xl overflow-hidden"><div class="px-3 py-2 bg-slate-50 font-black">النسخة البعيدة</div><pre id="conflict-remote" class="p-3 text-[11px] overflow-auto max-h-80 whitespace-pre-wrap"></pre></section></div><div id="conflict-actions" class="flex flex-wrap gap-2 mt-3"></div><div id="conflict-changes" class="mt-4 hidden"></div></div></div></div>`;
    document.body.appendChild(el); el.addEventListener('click',e=>{if(e.target.hasAttribute('data-conflict-close'))el.classList.add('hidden');}); return el;
  }
  async function show(){
    const el=modal(), list=el.querySelector('#app-conflict-list'), detail=el.querySelector('#app-conflict-detail'), sub=el.querySelector('#app-conflict-sub');
    const rows=await (g.AppConflictCenter?g.AppConflictCenter.list(100):[]); sub.textContent=`${rows.length} تعارض مفتوح`;
    detail.classList.add('hidden'); list.innerHTML=rows.length?rows.map((c,i)=>`<button type="button" data-conflict-id="${esc(c.id)}" class="w-full text-right border rounded-xl p-3 hover:bg-slate-50"><div class="font-black">${esc(c.entity)} — ${esc(c.entityId)}</div><div class="text-xs text-slate-500 mt-1">${esc(c.error&&c.error.message||'تعارض')} · الإصدار ${Number(c.version||0)}</div></button>`).join(''):'<div class="p-6 text-center text-emerald-700 font-black">لا توجد تعارضات مفتوحة.</div>';
    list.querySelectorAll('[data-conflict-id]').forEach(b=>b.addEventListener('click',async()=>{
      const c=rows.find(x=>String(x.id)===String(b.dataset.conflictId)); if(!c)return; const x=await inspect(c);
      detail.classList.remove('hidden'); el.querySelector('#conflict-local').textContent=pretty(x.localSnapshot); el.querySelector('#conflict-remote').textContent=x.hasRemote?pretty(x.remoteSnapshot):'لا توجد نسخة بعيدة محفوظة في سجل التعارض.\nلم يتم تطبيق أي قرار تلقائي.'; const changesEl=el.querySelector('#conflict-changes'); if(g.AppFieldRevisions&&g.AppFieldRevisions.diff){const ch=g.AppFieldRevisions.diff(x.localSnapshot,x.remoteSnapshot); changesEl.classList.toggle('hidden',!x.hasRemote||!ch.length); changesEl.innerHTML=x.hasRemote&&ch.length?'<div class="font-black mb-2">التغييرات على مستوى الحقول</div>'+ch.slice(0,40).map(c=>`<div class="border rounded-xl p-2 mb-1 text-xs"><b>${esc(c.path)}</b><div class="text-slate-500">${esc(JSON.stringify(c.before))} → ${esc(JSON.stringify(c.after))}</div></div>`).join(''):'';}
      const actions=el.querySelector('#conflict-actions'); actions.innerHTML='';
      const add=(label,decision,disabled)=>{const q=document.createElement('button');q.type='button';q.textContent=label;q.disabled=!!disabled;q.className='px-3 py-2 rounded-xl border font-black disabled:opacity-40';q.onclick=async()=>{try{await decide(x,decision);await show();}catch(err){alert(String(err.message||err));}};actions.appendChild(q)};
      add('اعتماد المحلية','keep-local',!x.canApply); add('اعتماد البعيدة','keep-remote',!x.canApply||!x.hasRemote); add('تسجيل كمراجعته','reviewed',false);
    }));
    el.classList.remove('hidden');
  }
  g.AppConflictResolver=Object.freeze({inspect,decide,show});
})(window);
