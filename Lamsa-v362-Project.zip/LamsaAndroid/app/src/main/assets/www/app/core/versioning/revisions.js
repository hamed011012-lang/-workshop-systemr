/* Workshop Field Revision Engine v154.
 * Records field-level changes without changing business data. Additive and safe.
 */
(function(g){'use strict'; if(g.AppFieldRevisions)return;
  const STORE='revisions'; const now=()=>Date.now();
  const primitive=v=>v===null||v===undefined||typeof v!=='object';
  const clone=v=>{try{return JSON.parse(JSON.stringify(v));}catch(_){return v;}};
  function flatten(v,p,out){out=out||{}; if(primitive(v)){out[p||'$']=v;return out;} if(Array.isArray(v)){v.forEach((x,i)=>flatten(x,(p?p+'.':'')+i,out)); if(!v.length)out[p||'$']=[]; return out;} const ks=Object.keys(v).sort(); if(!ks.length)out[p||'$']={}; ks.forEach(k=>flatten(v[k],p?p+'.'+k:k,out)); return out;}
  function diff(before,after){
    const a=flatten(before||{}),b=flatten(after||{}),keys=new Set([...Object.keys(a),...Object.keys(b)]),changes=[];
    keys.forEach(path=>{const av=a[path],bv=b[path]; let same=false; try{same=JSON.stringify(av)===JSON.stringify(bv);}catch(_){same=av===bv;} if(!same)changes.push({path,before:clone(av),after:clone(bv)});});
    return changes.sort((x,y)=>x.path.localeCompare(y.path));
  }
  async function record(meta){
    if(!g.AppDB||!g.AppDB.put)return null;
    const changes=Array.isArray(meta&&meta.changes)?meta.changes:diff(meta&&meta.before,meta&&meta.after);
    const id=String(meta&&meta.revisionId||`fieldrev:${meta&&meta.entity||'unknown'}:${meta&&meta.entityId||''}:${meta&&meta.version||0}:${meta&&meta.operationId||now()}`);
    const row={key:id,id,collection:'fieldRevisions',entity:String(meta&&meta.entity||'unknown'),entityId:String(meta&&meta.entityId||''),version:Number(meta&&meta.version||0),operationId:String(meta&&meta.operationId||''),changes,changeCount:changes.length,createdAt:now()};
    await g.AppDB.put(STORE,row); return row;
  }
  async function list(entity,id,limit){
    if(!g.AppDB||!g.AppDB.list)return [];
    const rows=await g.AppDB.list(STORE,Math.max(1,Number(limit)||500));
    return rows.filter(x=>x&&x.collection==='fieldRevisions'&&(!entity||x.entity===String(entity))&&(!id||x.entityId===String(id)));
  }
  function summarize(changes,limit){return (changes||[]).slice(0,Math.max(1,Number(limit)||8)).map(c=>c.path).join('، ');}
  g.AppFieldRevisions=Object.freeze({diff,record,list,summarize,flatten});
})(window);
