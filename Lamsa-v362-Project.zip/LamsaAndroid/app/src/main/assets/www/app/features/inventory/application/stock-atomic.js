/* Workshop Inventory v148 — atomic stock movement bridge.
 * Phase 8: records stock deltas produced by invoice mutations with a stable
 * operation identity. The legacy stock engine remains authoritative; this
 * bridge creates a durable ledger for idempotent reconciliation.
 */
(function(g){'use strict'; if(g.StockAtomic)return;
  const wrapped=new Set();
  const num=v=>Number.isFinite(Number(v))?Number(v):0;
  function snapshot(){
    const map=new Map();
    const items=Array.isArray(g.DB&&g.DB.store)?g.DB.store:[];
    for(const x of items){ if(!x||x.id==null)continue; map.set(String(x.id),num(x.qty)); }
    return map;
  }
  function diff(before,after){
    const ids=new Set([...before.keys(),...after.keys()]), out=[];
    for(const id of ids){ const d=num(after.get(id))-num(before.get(id)); if(d!==0) out.push({itemId:id,delta:d}); }
    return out;
  }
  function invoiceFor(identity){
    const sales=Array.isArray(g.DB&&g.DB.sales)?g.DB.sales:[];
    if(identity&&identity!=='new') return sales.find(x=>x&&String(x.id)===String(identity))||null;
    return sales.length?sales[sales.length-1]:null;
  }
  async function record(kind,identity,before){
    try{
      if(!g.StockCommand||!g.InventoryRepository)return;
      const after=snapshot(), deltas=diff(before,after); if(!deltas.length)return;
      const inv=invoiceFor(identity);
      const stable=inv&&inv.id?String(inv.id):String(identity||'unknown');
      const rev=inv&&(inv.editedAtMs||inv.createdAtMs||inv.timestamp||inv.date)?String(inv.editedAtMs||inv.createdAtMs||inv.timestamp||inv.date):String(Date.now());
      const operationId='stock:'+kind+':'+stable+':'+rev;
      for(const d of deltas){
        await g.StockCommand.movement({operationId,itemId:d.itemId,delta:d.delta,reason:'invoice-'+kind,invoiceId:inv&&inv.id||stable,at:Date.now()});
      }
      if(g.AppAudit) await g.AppAudit.record('stock-atomic',{kind,invoiceId:inv&&inv.id||stable,movements:deltas.length});
      if(g.StockLedger) await g.StockLedger.reconcile(Array.isArray(g.DB&&g.DB.store)?g.DB.store:[]);
    }catch(e){ if(g.wsSilent)g.wsSilent('stock:atomic',e); }
  }
  function wrap(name,kind,identityFn){
    if(wrapped.has(name))return;
    const original=g[name]; if(typeof original!=='function'||original.__wsStockAtomic)return;
    function fn(){
      const before=snapshot(); let identity=''; try{identity=identityFn?identityFn.apply(this,arguments):'';}catch(_){}
      let result;
      try{ result=original.apply(this,arguments); }
      finally{ Promise.resolve().then(()=>record(kind,identity,before)); }
      return result;
    }
    fn.__wsStockAtomic=true; fn.__wsStockAtomicOriginal=original; g[name]=fn; wrapped.add(name);
  }
  function install(){
    wrap('saveCurrentInvoice','create',()=>{const e=document.getElementById('pos-edit-id');return e&&e.value||'new';});
    wrap('confirmDraftInvoice','draft-create',()=>{const d=g.draftData;return d&&d.id?d.id:'draft';});
    wrap('saveEditedInvoice','update',()=>{const e=document.getElementById('modal-inv-id');return e&&e.value||'';});
    wrap('deleteInvoiceToTrash','delete',id=>id);
    wrap('restoreTrashItem','restore',idx=>{const t=g.DB&&Array.isArray(g.DB.trash)?g.DB.trash[idx]:null;return t&&t.payload?t.payload.id:String(idx);});
    g.__wsStockAtomicInstalled=true;
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
  g.StockAtomic=Object.freeze({install});
})(window);
