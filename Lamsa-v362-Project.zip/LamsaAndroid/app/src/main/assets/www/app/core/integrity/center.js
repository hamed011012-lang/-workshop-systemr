/* Workshop Integrity Center v152.
 * Read-only diagnostics across finance, stock, idempotency and sync.
 * It never deletes or auto-corrects data.
 */
(function(g){'use strict'; if(g.AppIntegrityCenter)return;
  const n=v=>Number.isFinite(Number(v))?Number(v):0;
  async function scan(){
    const issues=[]; const checks=[];
    const add=(kind,detail,meta)=>issues.push(Object.assign({kind,detail},meta||{}));
    try{
      if(typeof g.wsFindDuplicatePayments==='function'){
        const groups=g.wsFindDuplicatePayments()||[];
        checks.push({name:'duplicate-payments',count:groups.length});
        groups.forEach(x=>add('دفعات متشابهة تحتاج مراجعة',x.reason||'تكرار محتمل',{count:Array.isArray(x.rows)?x.rows.length:0}));
      }
    }catch(e){add('فحص الدفعات','تعذر إكمال فحص الدفعات: '+String(e&&e.message||e));}
    try{
      if(typeof g.wsFindDuplicateInvoices==='function'){
        const groups=g.wsFindDuplicateInvoices()||[];
        checks.push({name:'duplicate-invoices',count:groups.length});
        groups.forEach(x=>add('فواتير متشابهة تحتاج مراجعة','نفس العميل والمبلغ ضمن نافذة الفحص',{count:x.length}));
      }
    }catch(e){add('فحص الفواتير','تعذر إكمال فحص الفواتير: '+String(e&&e.message||e));}
    try{
      if(g.StockLedger&&typeof g.StockLedger.report==='function'){
        const r=await g.StockLedger.report();
        checks.push({name:'stock-reconciliation',count:(r.mismatches||[]).length+(r.duplicates||[]).length});
        (r.mismatches||[]).forEach(x=>add('اختلاف في المخزون',`${x.name||x.itemId}: الفعلي ${x.actual} والمتوقع ${x.expected}`,{itemId:x.itemId}));
        (r.duplicates||[]).forEach(x=>add('حركة مخزون مكررة','معرّف العملية مكرر: '+x,{operationId:x}));
      }
    }catch(e){add('فحص المخزون','تعذر إكمال فحص المخزون: '+String(e&&e.message||e));}
    try{
      if(g.AppConflictCenter&&typeof g.AppConflictCenter.count==='function'){
        const conflicts=await g.AppConflictCenter.count();
        checks.push({name:'conflicts',count:conflicts});
        if(conflicts>0)add('تعارضات تحتاج مراجعة',`هناك ${conflicts} تعارضات لم تتم تسويتها`,{count:conflicts});
      }
    }catch(e){add('فحص التعارضات','تعذر قراءة التعارضات: '+String(e&&e.message||e));}
    try{
      if(g.AppSyncHealth&&typeof g.AppSyncHealth.snapshot==='function'){
        const s=await g.AppSyncHealth.snapshot();
        checks.push({name:'sync',count:n(s.pending)+n(s.durablePending)});
        const pending=n(s.pending)+n(s.durablePending);
        if(pending>0)add('عمليات تنتظر المزامنة',`هناك ${pending} عملية محلية لم تكتمل مزامنتها`,{count:pending});
      }
    }catch(e){add('فحص المزامنة','تعذر قراءة حالة المزامنة: '+String(e&&e.message||e));}
    const status=issues.some(x=>x.kind==='فحص الدفعات'||x.kind==='فحص الفواتير'||x.kind==='فحص المخزون'||x.kind==='فحص المزامنة')?'error':issues.length?'review':'ok';
    return {status,issues,checks,at:Date.now()};
  }
  function label(r){ if(!r)return 'غير معروف'; if(r.status==='ok')return 'سليم ✓'; if(r.status==='error')return 'خطأ في الفحص'; return `${r.issues.length} تحتاج مراجعة`; }
  async function run(options){const r=await scan(); g.AppIntegrityCenter.last=r; try{g.AppEvents&&g.AppEvents.emit&&g.AppEvents.emit('integrity:scan',r);}catch(_){} if(!(options&&options.silent))show(r); return r;}
  function show(r){
    if(!r)return;
    if(r.status==='ok'){alert('✅ مركز سلامة البيانات\n\nلم يتم العثور على مشكلة تحتاج مراجعة في الفحوص الحالية.');return;}
    let msg=`⚠️ مركز سلامة البيانات\n\nالحالة: ${label(r)}\n`;
    r.issues.slice(0,18).forEach((x,i)=>{msg+=`\n${i+1}) ${x.kind}\n${x.detail}`;});
    if(r.issues.length>18)msg+=`\n\n… وهناك ${r.issues.length-18} حالة أخرى.`;
    msg+='\n\nلم يتم حذف أو تعديل أي بيانات تلقائيًا.';
    alert(msg);
  }
  function bindBadge(){
    const b=document.getElementById('integrity-center-badge'); if(!b)return;
    const r=g.AppIntegrityCenter.last; if(!r||r.status==='ok'){b.classList.add('hidden');b.textContent='⚠️ يحتاج مراجعة';return;}
    b.classList.remove('hidden');b.textContent=r.status==='error'?'⚠️ فشل فحص السلامة':`⚠️ ${r.issues.length} تحتاج مراجعة`;
  }
  g.AppIntegrityCenter=Object.freeze({scan,run,show,label,bindBadge,get last(){return this._last||null;},set last(v){this._last=v;}});
  const schedule=()=>setTimeout(()=>g.AppIntegrityCenter.run({silent:true}).then(()=>g.AppIntegrityCenter.bindBadge()).catch(()=>{}),900);
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',schedule,{once:true}); else schedule();
})(window);
