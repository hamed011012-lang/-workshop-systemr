/* v238 — Financial integrity guard. Pure validation; no DOM/Firebase writes. */
(function(g){'use strict'; if(g.FinancialIntegrity)return;
  const EPS=0.01;
  const n=v=>Number(v);
  const finite=v=>Number.isFinite(n(v));
  const money=(v,min=0)=>finite(v)&&n(v)>=min;
  const r2=v=>Math.round((n(v)+Number.EPSILON)*100)/100;
  function item(i,allowZero){
    if(!i||typeof i!=='object')return {ok:false,reason:'ITEM_INVALID'};
    const q=n(i.qty), p=n(i.price), t=n(i.total);
    if(!money(q,0)||!money(p,0)||!money(t,0))return {ok:false,reason:'ITEM_NUMBER'};
    if(allowZero ? q<0 : q<=0)return {ok:false,reason:'ITEM_QTY'};
    if(Math.abs(r2(q*p)-r2(t))>EPS)return {ok:false,reason:'ITEM_TOTAL_MISMATCH'};
    return {ok:true};
  }
  function invoice(inv){
    if(!inv||!String(inv.id||'').trim())return {ok:false,reason:'INVOICE_ID'};
    if(!Array.isArray(inv.items)||!inv.items.length)return {ok:false,reason:'INVOICE_EMPTY'};
    for(const x of inv.items){const v=item(x,true);if(!v.ok)return v;}
    const itemsTotal=r2(inv.items.reduce((a,x)=>a+n(x.total),0));
    const discount=n(inv.discount||0), subtotal=n(inv.subtotal), paid=n(inv.paid||0), debt=n(inv.netDebt||0), credit=n(inv.creditUsed||0), over=n(inv.overpayCredited||0);
    if(!money(discount)||!money(subtotal)||!money(paid)||!money(debt)||!money(credit)||!money(over))return {ok:false,reason:'INVOICE_NUMBER'};
    if(credit>subtotal+EPS||discount>itemsTotal+EPS||Math.abs(r2(itemsTotal-discount)-r2(subtotal))>EPS)return {ok:false,reason:'SUBTOTAL_MISMATCH'};
    if(paid>subtotal+over+EPS)return {ok:false,reason:'PAID_EXCEEDS_SETTLEMENT'};
    if(Math.abs(r2(Math.max(0,subtotal-paid-credit))-r2(debt))>EPS)return {ok:false,reason:'DEBT_MISMATCH'};
    return {ok:true,itemsTotal,subtotal:r2(subtotal)};
  }
  function payment(p){
    if(!p||!String(p.id||'').trim())return {ok:false,reason:'PAYMENT_ID'};
    if(!money(p.amount,EPS))return {ok:false,reason:'PAYMENT_AMOUNT'};
    if(p.isRefund===true && (!p.originalInvId||!String(p.originalInvId).trim()))return {ok:false,reason:'REFUND_SOURCE'};
    if(Array.isArray(p.debtDistribution)){
      let sum=0;
      for(const d of p.debtDistribution){if(!d||!d.saleId||!money(d.amountApplied))return {ok:false,reason:'PAYMENT_DISTRIBUTION'};sum=r2(sum+n(d.amountApplied));}
      if(sum>n(p.amount)+EPS)return {ok:false,reason:'PAYMENT_DISTRIBUTION_OVER'};
    }
    return {ok:true};
  }
  function returnRecord(r){
    if(!r||!String(r.id||'').trim()||!String(r.originalInvId||'').trim())return {ok:false,reason:'RETURN_ID'};
    if(!money(r.total))return {ok:false,reason:'RETURN_TOTAL'};
    if(!Array.isArray(r.items)||!r.items.length)return {ok:false,reason:'RETURN_EMPTY'};
    let sum=0; for(const x of r.items){const v=item(x);if(!v.ok)return v;sum=r2(sum+n(x.total));}
    if(Math.abs(sum-n(r.total))>EPS)return {ok:false,reason:'RETURN_TOTAL_MISMATCH'};
    return {ok:true};
  }
  function scan(db){
    const issues=[];
    (Array.isArray(db&&db.sales)?db.sales:[]).forEach((x,i)=>{const v=invoice(x);if(!v.ok)issues.push({collection:'sales',index:i,id:x&&x.id||'',reason:v.reason});});
    (Array.isArray(db&&db.payments)?db.payments:[]).forEach((x,i)=>{const v=payment(x);if(!v.ok)issues.push({collection:'payments',index:i,id:x&&x.id||'',reason:v.reason});});
    (Array.isArray(db&&db.returns)?db.returns:[]).forEach((x,i)=>{const v=returnRecord(x);if(!v.ok)issues.push({collection:'returns',index:i,id:x&&x.id||'',reason:v.reason});});
    return {ok:issues.length===0,issues,count:issues.length};
  }
  g.FinancialIntegrity=Object.freeze({EPS,item,invoice,payment,returnRecord,scan});
})(window);
