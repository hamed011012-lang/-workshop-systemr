(function (g) {
  'use strict'; if (g.AppEvents) return;
  const map = new Map();
  function on(name, fn) { if (typeof fn !== 'function') return () => {}; const set = map.get(name) || new Set(); set.add(fn); map.set(name,set); return () => set.delete(fn); }
  function emit(name, detail) { const set = map.get(name); if (!set) return; [...set].forEach(fn => { try { fn(detail); } catch(e) { console.error('[AppEvents]', name, e); } }); }
  g.AppEvents = Object.freeze({ on, emit });
})(window);
