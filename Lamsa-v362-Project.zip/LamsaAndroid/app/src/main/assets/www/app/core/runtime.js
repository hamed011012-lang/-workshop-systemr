/* Workshop Runtime v139 — small, deterministic application kernel. */
(function (global) {
  'use strict';
  if (global.AppRuntime && global.AppRuntime.version === 'v139') return;
  const locks = new Map();
  const PREFIX = 'ws:v139:lock:';
  const now = () => Date.now();
  const keyOf = k => PREFIX + String(k || '').trim();
  function acquire(key, ttl) {
    const k = String(key || '').trim(); if (!k) return true;
    const ms = Math.max(300, Number(ttl) || 2500), t = now();
    if ((locks.get(k) || 0) > t) return false;
    try { if (Number(localStorage.getItem(keyOf(k)) || 0) > t) return false; localStorage.setItem(keyOf(k), String(t + ms)); } catch (_) {}
    locks.set(k, t + ms); return true;
  }
  function release(key) { const k = String(key || '').trim(); if (!k) return; locks.delete(k); try { localStorage.removeItem(keyOf(k)); } catch (_) {} }
  async function once(key, work, ttl) { if (!acquire(key, ttl)) return { skipped: true }; try { return { skipped: false, value: await work() }; } finally { release(key); } }
  function jsonGet(key, fallback) { try { const v = localStorage.getItem(key); return v == null ? fallback : JSON.parse(v); } catch (_) { return fallback; } }
  function jsonSet(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (_) { return false; } }
  function debounce(fn, wait) { let timer = 0; return function () { const a = arguments, c = this; clearTimeout(timer); timer = setTimeout(() => fn.apply(c, a), Number(wait) || 120); }; }
  function ready(fn) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once: true }); else queueMicrotask(fn); }
  const api = Object.freeze({ version: 'v139', now, acquire, release, once, jsonGet, jsonSet, debounce, ready });
  global.AppRuntime = api;
  addEventListener('error', e => { try { console.error('[AppRuntime]', e.error || e.message || e); } catch (_) {} });
  addEventListener('unhandledrejection', e => { try { console.error('[AppRuntime:promise]', e.reason); } catch (_) {} });
})(window);
