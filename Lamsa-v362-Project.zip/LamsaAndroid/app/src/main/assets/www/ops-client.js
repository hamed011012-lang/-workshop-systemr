'use strict';
/* v212 — بوابة العمليات المالية غير المتصلة
   ---------------------------------------------------------------
   هذه الطبقة لا تغيّر المسار القديم تلقائياً. تُستخدم فقط عندما تستدعي
   الصفحة wsSubmitOp(). الكتابة الوحيدة هنا هي ops/{opId} بحالة pending؛
   النتيجة لا يستطيع العميل تعديلها أو حذفها، والدالة هي التي تعتمدها.

   الهدف: إبقاء البيع قابلاً للعمل دون اتصال مع نقل الحساب المالي إلى السيرفر.
*/
(function (global) {
  const ALLOWED = new Set(['createInvoice', 'recordPayment', 'createReturn']);
  const FORBIDDEN_COMPUTED = new Set([
    'itemsTotal','subtotal','paid','netDebt','creditUsed','oldDebtPay',
    'overpayCredited','creditAdded','cashBack','total','timestamp','computedBy'
  ]);

  function dbRef() {
    if (!global.firebase || !firebase.firestore) throw new Error('Firestore غير جاهز');
    return firebase.firestore();
  }
  function actorUid() {
    const u = global.firebase && firebase.auth && firebase.auth().currentUser;
    if (!u || !u.uid) throw new Error('يجب تسجيل الدخول أولاً');
    return String(u.uid);
  }
  function cleanValue(v) {
    if (Array.isArray(v)) return v.map(cleanValue);
    if (v && typeof v === 'object') {
      const o = {};
      Object.keys(v).forEach(k => {
        if (!FORBIDDEN_COMPUTED.has(k)) o[k] = cleanValue(v[k]);
      });
      return o;
    }
    return v;
  }

  async function wsSubmitOp(kind, payload) {
    if (!ALLOWED.has(kind)) throw new Error('نوع عملية غير مسموح: ' + kind);
    const uid = actorUid();
    const safe = cleanValue(payload || {});
    const ref = dbRef().collection('ops').doc();
    const data = {
      uid,
      kind,
      status: 'pending',
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      ...safe
    };
    // لا نرسل أي مبلغ محسوب حتى لو حاول المسار القديم تمريره.
    FORBIDDEN_COMPUTED.forEach(k => delete data[k]);
    await ref.set(data);
    return ref.id;
  }

  function wsWatchOp(opId, onDone, onFailed) {
    if (!opId) throw new Error('معرّف العملية مطلوب');
    return dbRef().collection('ops').doc(String(opId)).onSnapshot(snap => {
      if (!snap.exists) return;
      const d = snap.data() || {};
      if (d.status === 'done') {
        if (typeof onDone === 'function') onDone(d.result || d);
      } else if (d.status === 'failed') {
        const e = new Error((d.error && d.error.message) || 'فشلت العملية');
        e.code = d.error && d.error.code;
        if (typeof onFailed === 'function') onFailed(e, d);
      }
    });
  }

  global.wsSubmitOp = wsSubmitOp;
  global.wsWatchOp = wsWatchOp;
  global.WS_FINANCIAL_GATEWAY_V212 = Object.freeze({
    version: 'v212',
    enabledByDefault: false,
    kinds: Array.from(ALLOWED)
  });
})(window);
