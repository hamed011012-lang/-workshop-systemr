(function(g){'use strict';
const KEY='ws_symbol_formulas_v1';
const bases={w:'العرض',h:'الارتفاع',perimeter:'محيط الفتحة',area:'المساحة الفعلية م²',one:'قيمة ثابتة'};
const expressions={w:'w',h:'h',perimeter:'(2*w+2*h)',area:'(w*h/10000)',one:'0'};
function num(v){return Number(String(v).replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/٫/g,'.'));}
function normalize(d){
 if(!d||!g.WSOpeningSymbols.get(d.symbol)||!/^[-\w]+$/.test(d.material)||['__proto__','constructor','prototype'].includes(d.material)||!String(d.name||'').trim())throw Error('اختر الرمز والنوع واكتب اسم المعادلة');
 if(!Array.isArray(d.rows)||!d.rows.length||d.rows.length>60)throw Error('أضف من 1 إلى 60 بندًا');
 const seen=new Set();const rows=d.rows.map(r=>{
 const label=String(r.label||'').trim();if(!label||label.length>100||seen.has(label))throw Error('اسم كل بند مطلوب ويجب ألا يتكرر');seen.add(label);
 if(!Object.hasOwn(expressions,r.base))throw Error('أساس حساب غير صالح');
 const offset=num(r.offset),divisor=num(r.divisor),quantity=num(r.quantity),rod=num(r.rod);
 if(![offset,divisor,quantity,rod].every(Number.isFinite)||Math.abs(offset)>100000||divisor<=0||quantity<=0||quantity>10000||rod<=0)throw Error('راجع الأرقام: القسمة والعدد وطول العود يجب أن تكون موجبة');
 const unit=['none','عود','قطعة','م²'].includes(r.unit)?r.unit:'none';
 return {label,base:r.base,offset,divisor,quantity,unit,rod};});
 return {symbol:d.symbol,material:d.material,name:String(d.name).trim().slice(0,120),key:'custom_symbol_'+d.material+'_'+d.symbol,rows};
}
function all(){try{return (JSON.parse(localStorage.getItem(KEY)||'[]')||[]).map(d=>{try{return normalize(d);}catch(e){return null;}}).filter(Boolean);}catch(e){return [];}}
function get(material,symbol){return all().find(d=>d.material===material&&d.symbol===symbol)||null;}
function find(key){return all().find(d=>d.key===key)||null;}
function save(d){d=normalize(d);const list=all().filter(x=>x.material!==d.material||x.symbol!==d.symbol);list.push(d);localStorage.setItem(KEY,JSON.stringify(list));return d;}
function remove(key){localStorage.setItem(KEY,JSON.stringify(all().filter(x=>x.key!==key)));}
function label(r){return r.label+(r.quantity!==1?' × '+r.quantity:'');}
function formulas(d){return d.rows.map(r=>({label:label(r),calc:'('+expressions[r.base]+' + ('+r.offset+')) / '+r.divisor,editNum:''}));}
function materials(d,res){return d.rows.filter(r=>r.unit!=='none').map(r=>({name:r.label,amount:Number(res[label(r)])*r.quantity,unit:r.unit,rodLength:r.rod}));}
function install(profiles,registry,names){all().forEach(d=>{registry[d.key]=d.name;names[d.key]=d.name;Object.values(profiles).forEach(p=>p[d.key]=formulas(d));});}
function el(tag,text){const x=document.createElement(tag);if(text!=null)x.textContent=text;return x;}
function field(parent,title,value){const l=el('label',title);l.style.cssText='display:grid;gap:4px;font-size:13px';const input=el('input');input.value=value;l.append(input);parent.append(l);return input;}
function open(material,symbol,onSave){
 const existing=get(material,symbol),sym=g.WSOpeningSymbols.get(symbol);if(!sym)return;
 const dialog=el('dialog');dialog.dir='rtl';dialog.style.cssText='width:min(850px,94vw);max-height:90vh;overflow:auto;border:1px solid #cbd5e1;border-radius:16px;padding:20px;font-family:inherit';
 dialog.append(el('h2','معادلة: '+sym.label),el('p','كل بند = (الأساس + الزيادة أو الخصم) ÷ المقسوم. اكتب الخصم بالسالب. العدد يحسب للمواد الخام؛ طول القص المعروض لكل قطعة. أدخل خصومات نظامك المعتمدة. كافلوتي الضلفتين والثوابت يُضاف حسب الرمز تلقائيًا؛ لتعريفه بنفسك أضف بند كافلوتي بوحدة قطعة.'));
 const name=field(dialog,'اسم المعادلة',existing?.name||sym.label+' — '+(material==='xtype_alum'?'المونيوم':material==='xtype_kitchen_skirt'?'سكارات مطبخ':material==='pvc'?'PVC':g.WSSystems?.get(material)?.name||'نظام مخصص'));
 const list=el('div');dialog.append(list);
 function row(data={label:'',base:'w',offset:0,divisor:1,quantity:1,unit:'none',rod:580}){
  const box=el('fieldset');box.style.cssText='display:flex;flex-wrap:wrap;gap:9px;margin:12px 0';const inputs={};
  inputs.label=field(box,'اسم الناتج',data.label);
  const bl=el('label','الأساس '),base=el('select');Object.entries(bases).forEach(([v,t])=>base.add(new Option(t,v)));base.value=data.base;bl.append(base);box.append(bl);inputs.base=base;
  for(const [k,t] of [['offset','الزيادة / الخصم'],['divisor','القسمة على'],['quantity','عدد القطع'],['rod','طول العود بالسم']]){inputs[k]=field(box,t,data[k]);inputs[k].inputMode='decimal';inputs[k].style.width='95px';}
  const ul=el('label','تجميع المواد '),unit=el('select');[['none','نتيجة قص فقط'],['عود','أعواد من مجموع الأطوال'],['قطعة','عدد قطع'],['م²','متر مربع']].forEach(([v,t])=>unit.add(new Option(t,v)));unit.value=data.unit;ul.append(unit);box.append(ul);inputs.unit=unit;
  const del=el('button','حذف البند');del.type='button';del.onclick=()=>box.remove();box.append(del);box.inputs=inputs;list.append(box);
 }
 (existing?.rows||[{}]).forEach(r=>Object.keys(r).length?row(r):row());
 const add=el('button','+ إضافة نتيجة قص أو مادة');add.type='button';add.onclick=()=>row();dialog.append(add);
 const preview=el('pre');preview.style.cssText='white-space:pre-wrap;line-height:1.8';const test=el('button','تجربة على مقاس');test.type='button';
 const dims=el('div');dims.style.cssText='display:flex;gap:12px;margin:12px 0';const w=field(dims,'العرض (سم)',document.getElementById('pw')?.value||120),h=field(dims,'الارتفاع (سم)',document.getElementById('ph')?.value||150);dialog.append(dims,test,preview);
 function read(){return normalize({material,symbol,name:name.value,rows:Array.from(list.children).map(b=>Object.fromEntries(Object.entries(b.inputs).map(([k,v])=>[k,v.value])))});}
 test.onclick=()=>{try{const d=read(),W=num(w.value),H=num(h.value);if(!(W>0&&H>0))throw Error('أدخل مقاسًا موجبًا');preview.textContent=d.rows.map(r=>{const n=({w:W,h:H,perimeter:2*(W+H),area:W*H/10000,one:0}[r.base]+r.offset)/r.divisor;return label(r)+': '+n.toFixed(2)+(n<=0?' — راجع قيمة غير موجبة':'')+(r.unit!=='none'?' | الخام '+(n*r.quantity).toFixed(2)+' '+(r.unit==='عود'?'سم، أعواد: '+Math.ceil(n*r.quantity/r.rod):r.unit):'');}).join('\n');}catch(e){preview.textContent=e.message;}};
 const ok=el('button','حفظ وربط بالرمز'),cancel=el('button','إلغاء');ok.type=cancel.type='button';ok.style.margin='12px';
 ok.onclick=()=>{try{const d=save(read());dialog.close();dialog.remove();onSave?.(d);}catch(e){preview.textContent='لم يتم الحفظ: '+e.message;}};
 cancel.onclick=()=>{dialog.close();dialog.remove();};dialog.append(ok,cancel);dialog.addEventListener('cancel',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
}
g.WSSymbolFormulas=Object.freeze({all,get,find,save,remove,normalize,formulas,materials,install,open,num});
})(window);
