/* ============================================================
   sw.js — تشغيل النظام بالكامل دون إنترنت   (نسخة 2.0)
   ------------------------------------------------------------
   يخزّن هيكل التطبيق محلياً: الصفحات الأربع وملفات المكتبات الخارجية
   (Tailwind، Firebase، الخطوط، الأيقونات، html2canvas، lucide).
   بعد أول زيارة ناجحة واحدة يفتح النظام ويعمل بلا إنترنت إطلاقاً.

   لا يتدخل إطلاقاً في طلبات Firebase الحيّة (بيانات/تسجيل دخول) —
   تلك تُترك لآلية Firebase الخاصة بالعمل دون اتصال، فتُحفظ التعديلات
   محلياً وتُرفع تلقائياً فور عودة الاتصال (enablePersistence).

   إصلاحات جوهرية في هذه النسخة:
   • مخزنان منفصلان: الصفحات (يُجدَّد مع كل نسخة) والمكتبات الخارجية
     (يبقى كما هو). قبل ذلك كان كل تحديث للنظام يمسح مخزن المكتبات،
     فإن حدث التحديث والجهاز دون اتصال يفتح التطبيق بلا تنسيق ولا خطوط.
   • تجاهل ما بعد ? عند مطابقة الصفحات، فـ index.html?msg=... كان
     يُعتبر صفحة غير مخزَّنة فيفشل فتحها دون اتصال.
   • تثبيت إصدار lucide بدل latest، فالرابط المتغيّر لا يصلح للتخزين.
   • عدم تخزين أي رد فاشل أو جزئي (206) بالخطأ.
   ============================================================ */

/* رقم النسخة. رفعُه هنا يمسح **كل** المخازن القديمة عند التفعيل
   (activate يحذف ما ليس في KEEP) — وهذا مقصود في 8.8 تحديداً: أي جهاز
   خزّن نسخة احتياطية من Drive بالخطأ في النسخة السابقة يتخلّص منها فور
   التحديث، فلا يبقى ملف بيانات خاص في مخزن المتصفح. */
/* v244: auth session recovery and protected-page redirect guard. */
const VERSION='v350';
const SHELL_CACHE = 'workshop-shell-' + VERSION;   // صفحات النظام — تتجدد مع كل نسخة
/* مخزن المكتبات الخارجية.
   كان ثابتاً على 'v1' فلا يتجدّد أبداً مع تحديث التطبيق. ومع رابط
   مكتبة بلا إصدار دقيق (@4)، يبقى جهاز قديم على نسخة مخزَّنة منذ شهور
   بينما بقية التطبيق تحدّثت — فتظهر فروق تنسيق لا يُعرف سببها، ولا
   يُصلحها إلا مسح بيانات المتصفح.

   ربطه بإصدار التطبيق يجعله يتجدّد مع كل نشر: المكتبة تُجلب من جديد
   مرة واحدة ثم تُخزَّن، فلا تُفقد فائدة التخزين ولا يتجمّد الإصدار. */
const CDN_CACHE   = 'workshop-cdn-' + VERSION;
const KEEP        = [SHELL_CACHE, CDN_CACHE];

// ملفات النظام نفسه
const APP_SHELL = [
  './',
  'index.html',
  'measurements.html',
  'invoices.html',
  'cutting.html',
  'data-size.html',
  'firestore-pager.js',
  'app/legacy/shared.js',
  'app/core/runtime.js',
  'app/core/storage.js',
  'app/core/idempotency.js',
  'app/core/events.js',
  'app/core/diagnostics.js',
  'app/core/idb.js',
  'app/core/outbox.js',
  'app/core/audit.js',
  'app/core/command-bus.js',
  'app/core/sync-engine.js',
  'app/core/sync-health.js',
  'app/core/integrity/center.js',
  'app/core/conflicts/center.js','app/core/conflicts/resolver.js','app/core/versioning/engine.js','app/core/versioning/revisions.js',
  'app/core/versioning/restore-center.js',
  'app/core/boot.js',
  'app/data/repository.js',
  'app/pages/home.js',
  'app/pages/measurements.js',
  'app/opening-symbols.js',
  'app/symbol-formulas.js',
'assets/openings/kitchen-oven-right-doors-3.svg','assets/openings/kitchen-oven-right-doors-4.svg','assets/openings/kitchen-oven-right-top-drawer-two.svg','assets/openings/kitchen-oven-right-bottom-drawer-1.svg','assets/openings/kitchen-oven-right-bottom-drawer-2.svg','assets/openings/kitchen-oven-left-doors-3.svg','assets/openings/kitchen-oven-left-doors-4.svg','assets/openings/kitchen-oven-left-top-drawer-two.svg','assets/openings/kitchen-oven-left-bottom-drawer-1.svg','assets/openings/kitchen-oven-left-bottom-drawer-2.svg', 'app/calculation-systems.js', 'app/default-cutting-data.js', 'app/full-system-file.js','app/system-studio.js','app/engineering.js','app/engineering-ui.js',
  'app/materials-easy.js',
  'app/materials-easy-ui.js','app/vendor/qrcodegen.js','app/qr-card.js',
'assets/openings/kitchen-drawers-1.svg','assets/openings/kitchen-1-drawers-right.svg','assets/openings/kitchen-1-drawers-left.svg','assets/openings/kitchen-drawers-2.svg','assets/openings/kitchen-2-drawers-right.svg','assets/openings/kitchen-2-drawers-left.svg','assets/openings/kitchen-drawers-3.svg','assets/openings/kitchen-3-drawers-right.svg','assets/openings/kitchen-3-drawers-left.svg','assets/openings/kitchen-drawers-4.svg','assets/openings/kitchen-4-drawers-right.svg','assets/openings/kitchen-4-drawers-left.svg','assets/openings/kitchen-top-drawer-1.svg','assets/openings/kitchen-top-drawer-2.svg','assets/openings/kitchen-oven.svg','assets/openings/kitchen-oven-top-drawer.svg','assets/openings/kitchen-oven-bottom-drawer.svg','assets/openings/kitchen-oven-right-drawers-1.svg','assets/openings/kitchen-oven-right-drawers-2.svg','assets/openings/kitchen-oven-right-drawers-3.svg','assets/openings/kitchen-oven-right-drawers-4.svg','assets/openings/kitchen-oven-right-doors-1.svg','assets/openings/kitchen-oven-right-doors-2.svg','assets/openings/kitchen-oven-right-door-drawer.svg','assets/openings/kitchen-oven-left-drawers-1.svg','assets/openings/kitchen-oven-left-drawers-2.svg','assets/openings/kitchen-oven-left-drawers-3.svg','assets/openings/kitchen-oven-left-drawers-4.svg','assets/openings/kitchen-oven-left-doors-1.svg','assets/openings/kitchen-oven-left-doors-2.svg','assets/openings/kitchen-oven-left-door-drawer.svg',
'assets/openings/fixed-single.svg','assets/openings/fixed-two.svg','assets/openings/fixed-three.svg','assets/openings/fixed-four.svg','assets/openings/single-fixed-left.svg','assets/openings/single-fixed-right.svg','assets/openings/single-fixed-top.svg','assets/openings/single-fixed-bottom.svg','assets/openings/single-two-sides.svg','assets/openings/single-two-fixed.svg','assets/openings/tilt-two.svg','assets/openings/tilt-three.svg','assets/openings/tilt-fixed-left.svg','assets/openings/tilt-fixed-right.svg','assets/openings/tilt-fixed-top.svg','assets/openings/tilt-two-sides.svg','assets/openings/tilt-over-two.svg','assets/openings/two-tilt-over-two.svg','assets/openings/three-open.svg','assets/openings/four-open.svg','assets/openings/double-fixed-left.svg','assets/openings/double-fixed-right.svg','assets/openings/double-fixed-top.svg','assets/openings/double-four-fixed.svg','assets/openings/slide-two.svg','assets/openings/slide-three.svg','assets/openings/slide-four.svg','assets/openings/door-fixed-left.svg','assets/openings/door-fixed-right.svg','assets/openings/door-fixed-top.svg','assets/openings/door-two-side-fixed.svg','assets/openings/door-double-fixed-top.svg','assets/openings/kitchen-1.svg','assets/openings/kitchen-2.svg','assets/openings/kitchen-3.svg','assets/openings/kitchen-4.svg','assets/openings/kitchen-drawers.svg',
  'assets/openings/leaf-tilt.svg', 'assets/openings/door-fixed.svg', 'assets/openings/door-right.svg',
  'assets/openings/door-left.svg',
  'assets/openings/door-two-large-right.svg',
  'assets/openings/door-two-large-left.svg',
  'assets/openings/door-two-equal.svg',
  'assets/openings/window-right.svg',
  'assets/openings/window-left.svg',
  'assets/openings/tilt-single.svg',
  'assets/openings/tilt-fixed.svg',
  'assets/openings/window-double.svg',
  'assets/openings/two-center-fixed.svg',
  'assets/openings/two-side-fixed.svg',
  'assets/openings/two-three-fixed.svg',
  'assets/openings/two-top-fixed-bottom.svg',
  'assets/openings/fixed-top-two-bottom.svg',
  'assets/openings/leaf-fixed.svg',

  'assets/formulas/door-single.svg',
  'assets/formulas/door-double.svg',
  'assets/formulas/window-single.svg',
  'assets/formulas/window-double.svg',
  'assets/formulas/window-three.svg',
  'assets/formulas/window-tilt.svg',
  'assets/formulas/window-tilt-single.svg',
  'assets/formulas/window-fixed.svg',
  'assets/formulas/window-slide.svg',
  'assets/formulas/shutter-large.svg',
  'assets/formulas/shutter-small.svg',
  'assets/formulas/shutter-normal.svg',

  'app/pages/cutting.js',
  'app/pages/invoices/lucide-fallback.js',
  'app/pages/invoices/admin-access.js',
  'app/pages/invoices/connectivity.js',
  'app/pages/invoices/auth.js',
  'app/pages/invoices/app.js',
  'app/pages/invoices/members.js',
  'app/pages/invoices/receipt-buttons.js',
  'app/features/invoices/application/receipt-command.js',
  'app/features/invoices/application/invoice-command.js',
  'app/features/invoices/infrastructure/receipt-repository.js',
    'app/features/invoices/infrastructure/invoice-repository.js',
  'app/features/customers/infrastructure/customer-repository.js',
  'app/features/invoices/infrastructure/debt-repository.js',
  'app/features/invoices/application/receipt-offline.js',
  'app/features/inventory/domain/stock-policy.js',
  'app/features/inventory/infrastructure/inventory-repository.js',
  'app/features/inventory/application/stock-command.js',
  'app/features/inventory/application/stock-atomic.js',
  'app/features/inventory/application/stock-ledger.js',
  'motion.css',
  'manifest.json',
  /* مانيفست لكل قسم: هو ما يجعل كل واحد يُثبَّت أيقونةً مستقلة.
     تخزينها مسبقاً ضروري — بلا المانيفست لا يعرض المتصفح خيار التثبيت
     أصلاً، ولا تظهر الأيقونة الصحيحة لمن ثبّته وهو دون اتصال. */
  'manifest-measurements.json',
  'manifest-invoices.json',
  'manifest-cutting.json',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/icon-maskable-512.png',
  'icons/measurements-192.png',
  'icons/measurements-512.png',
  'icons/measurements-512-maskable.png',
  'icons/invoices-192.png',
  'icons/invoices-512.png',
  'icons/invoices-512-maskable.png',
  'icons/cutting-192.png',
  'icons/cutting-512.png',
  'icons/cutting-512-maskable.png'
];

/* المكتبات الخارجية التي يعتمد عليها النظام. بدون تخزينها تفتح
   الصفحات دون اتصال بلا أي تنسيق ولا خط عربي. */
const CDN_ASSETS = [
  'https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
  'https://unpkg.com/lucide@0.469.0/dist/umd/lucide.min.js',
  'https://www.gstatic.com/firebasejs/12.16.0/firebase-app-compat.js',
  'https://www.gstatic.com/firebasejs/12.16.0/firebase-auth-compat.js',
  'https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore-compat.js',
  'https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap',
  'https://fonts.googleapis.com/css2?family=Cairo:wght@600;700;800&family=Tajawal:wght@400;500;700&family=JetBrains+Mono:wght@500;600;700&display=swap',
  'https://fonts.googleapis.com/css2?family=El+Messiri:wght@500;600;700&family=Cairo:wght@400;500;600;700;800&display=swap',
  'https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;900&family=Cairo:wght@500;600;700;800&display=swap'
];

/* طلبات Firebase الحيّة (بيانات/تسجيل دخول) — لا نتدخل فيها إطلاقاً.
   لا يشمل ملفات SDK نفسها (gstatic.com/firebasejs) فهي كود ثابت يُخزَّن بأمان.

   ⚠️ إصلاح 8.8 — أخطر بند في هذا الملف:
   كان المُدرَج 'googleapis.com/upload' وحده، فرفعُ النسخة الاحتياطية
   منجّى واسترجاعُها **ليس كذلك**. ورابط الاسترجاع:
       https://www.googleapis.com/drive/v3/files/{id}?alt=media
   طلبُ GET، فيمرّ على معالج fetch أدناه ويُخزَّن، ثم يُقدَّم في المرة
   التالية **من المخزن أولاً** — ويُمرَّر إلى bulkRestoreToFirestore الذي
   يمسح المجموعات ويكتب فوقها. أي: مسح قاعدة البيانات الحيّة واستبدالها
   بنسخة أقدم، بلا رسالة واحدة. وفوق ذلك كان ملف النسخة (القاعدة كاملة
   بأسماء العملاء وأرقامهم وديونهم) يبقى مخزَّناً في CacheStorage.

   الآن: كل نطاقات واجهات جوجل مستثناة، ولا يبقى داخل المخزن إلا الخطوط
   والمكتبات (fonts.* و gstatic.com/firebasejs) وهي مُدرجة صراحةً أدناه. */
/* ⚠️ توسعة 8.8.3 — كانت القائمة تعدّد مضيفات googleapis بالاسم:
   firestore و identitytoolkit و securetoken و firebaseinstallations
   و www. وأي مضيف آخر تحت النطاق نفسه — وهو ما تتغيّر إليه واجهات
   جوجل من إصدار لآخر — كان يمرّ ويُخزَّن. والقاعدة الصحيحة هنا عكس
   ما كان: **النطاق كله ممنوع، والخطوط وحدها استثناء صريح**، فلا
   يفتح رابط جديد الباب من تلقاء نفسه. */
const NEVER_INTERCEPT = [
  'googleapis.com',            // كل واجهات جوجل: Firestore وAuth وDrive وما يستجد
  'firebaseio.com',
  'firebaseapp.com',
  'web.app',                   // عنوان استضافة Firebase الثاني
  'google-analytics.com',
  'googletagmanager.com',
  'accounts.google.com',
  'apis.google.com'
];

/* الاستثناءات الوحيدة داخل النطاقات أعلاه: خطوط جوجل وملفات SDK الثابتة.
   وهي روابط محتوى ساكن لا تحمل بيانات حساب، وتخزينها هو ما يجعل
   الصفحة تفتح بخطها وتنسيقها دون اتصال. */
const ALWAYS_CACHEABLE_HOSTS = ['fonts.googleapis.com', 'fonts.gstatic.com'];

/* نطاقات موثوقة لا ترسل ترويسات CORS، فتصل ردودها بنوع "opaque"
   (لا يمكن قراءة حالتها 200/404). نثق بها لأنها روابط ثابتة لمكتبات
   معروفة، ونخزّنها رغم هذا القيد. */
const TRUSTED_HOSTS = [
  'gstatic.com', 'unpkg.com', 'cdn.jsdelivr.net',
  'cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com'
];

const isTrustedHost = (hostname) =>
  TRUSTED_HOSTS.some(h => hostname === h || hostname.endsWith('.' + h));

const isExternal = (url) => url.origin !== self.location.origin;

function isCacheableResponse(response, url) {
  if (!response) return false;
  if (response.status === 206) return false;            // رد جزئي (فيديو/صوت) لا يصلح للتخزين
  if (response.type === 'basic' || response.type === 'cors') return response.ok;
  if (response.type === 'opaque') return isTrustedHost(url.hostname);
  return false;
}

/* تخزين ملف خارجي: cache.add يرفض الردود المبهمة (opaque) لأن حالتها 0،
   لذلك نجلبها يدوياً بوضع no-cors ثم نضعها في المخزن بـ cache.put. */
function cacheExternal(cache, url) {
  return fetch(url, { mode: 'no-cors', credentials: 'omit' })
    .then(res => {
      // الردود المبهمة حالتها 0 دائماً؛ نرفض فقط ما نعرف يقيناً أنه فاشل
      if (res && res.type !== 'opaque' && !res.ok) return null;
      return res ? cache.put(url, res) : null;
    })
    .catch(() => {});
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    Promise.all([
      // كل ملف على حدة: فشل واحد لا يمنع تخزين البقية
      caches.open(SHELL_CACHE).then(cache =>
        Promise.all(APP_SHELL.map(url => cache.add(new Request(url, { cache: 'reload' })).catch(() => {})))
      ),
      // المكتبات الخارجية تُجلب مرة واحدة فقط ولا يُعاد جلبها مع كل نسخة
      caches.open(CDN_CACHE).then(cache =>
        Promise.all(CDN_ASSETS.map(url =>
          cache.match(url).then(hit => hit ? null : cacheExternal(cache, url))
        ))
      )
    ]).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => !KEEP.includes(k)).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

const OFFLINE_PAGE = new Response(
  '<!doctype html><html dir="rtl" lang="ar"><meta charset="utf-8">' +
  '<meta name="viewport" content="width=device-width,initial-scale=1">' +
  '<body style="font-family:Tahoma,sans-serif;text-align:center;padding:40px;background:#0b1220;color:#fff">' +
  '<h2 style="margin-bottom:8px">لا يوجد اتصال</h2>' +
  '<p style="opacity:.8;line-height:1.9">افتح النظام مرة واحدة وأنت متصل بالإنترنت،<br>ثم سيعمل بعدها دون اتصال بالكامل.</p>' +
  '<button onclick="location.reload()" style="margin-top:18px;padding:12px 26px;border:0;border-radius:12px;background:#2563eb;color:#fff;font-size:15px;font-weight:700">إعادة المحاولة</button>' +
  '</body></html>',
  { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
);

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  /* ⚠️ إصلاح 8.8 — حزام أمان ثانٍ فوق NEVER_INTERCEPT:
     أي طلب يحمل ترويسة اعتماد (Bearer) هو طلب بيانات خاصة بحساب —
     لا يُخزَّن ولا يُقدَّم من مخزن إطلاقاً، مهما تغيّرت الروابط مستقبلاً.
     بدونه يكفي رابط واجهة جديد لم يُدرَج أعلاه ليعود الخلل نفسه. */
  try { if (req.headers && req.headers.has('authorization')) return; } catch (e) {}

  let url;
  try { url = new URL(req.url); } catch (e) { return; }

  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;

  /* ⚠️ إصلاح 8.8.3 — أخطر خلل في هذا الملف، وكان يُعطّل العمل دون
     اتصال تعطيلاً كاملاً وصامتاً على استضافة Firebase الافتراضية.

     كان الفحص: url.href.includes(host) — أي مطابقة نصّية على **الرابط
     كاملاً**، لا على اسم النطاق. والقائمة تحتوي 'firebaseapp.com'.
     ومشروع هذا النظام نفسه (authDomain في shared.js) هو:
         smart-center-7b530.firebaseapp.com
     فإن فُتح التطبيق من عنوان الاستضافة الافتراضي، صار رابط **كل**
     ملف فيه — invoices.html و shared.js والخطوط والأيقونات — يحتوي
     السلسلة 'firebaseapp.com'، فيخرج المعالج فوراً عند أول سطر.

     النتيجة: Service Worker مسجَّل وظاهر في أدوات المطوّر، ولا يخزّن
     ملفاً واحداً ولا يقدّم شيئاً من المخزن. فيفتح التطبيق دون اتصال
     على صفحة خطأ المتصفح — بينما التطبيق كله مبنيّ على أن يعمل في
     مواقع بلا تغطية. ولا رسالة ولا أثر يدلّ على السبب.

     ولها وجه ثانٍ: المطابقة على الرابط كاملاً تشمل المسار والمعاملات،
     فأي رابط يحمل نصاً كـ ...?ref=accounts.google.com كان يُستثنى بلا سبب.

     الآن: (١) طلبات نطاقنا نفسه لا تُستثنى أبداً — هي هيكل التطبيق،
     و(٢) المطابقة على hostname وبحدود النطاق (تطابق تام أو لاحقة
     تسبقها نقطة)، فلا يخدعها مسار ولا معامل. */
  const hostIn = (list) => list.some(h => url.hostname === h || url.hostname.endsWith('.' + h));
  if (isExternal(url) && !hostIn(ALWAYS_CACHEABLE_HOSTS) && hostIn(NEVER_INTERCEPT)) return;

  /* v300: الشبكة أولاً للصفحات والملفات المحلية لتجنب واجهة قديمة
     تعيد بيانات محذوفة أو تشغّل منطقاً قديماً بعد تعديل السجلات.
     عند انقطاع الشبكة فقط نرجع إلى الكاش. بيانات Firebase الحية مستثناة
     أعلاه وتبقى دائماً خارج كاش Service Worker. */
  if (req.mode === 'navigate') {
    event.respondWith(
      caches.open(SHELL_CACHE).then(async cache => {
        try {
          const response = await fetch(req, { cache: 'no-store' });
          if (response && response.ok && response.type === 'basic') {
            cache.put(req.url.split('?')[0], response.clone()).catch(() => {});
          }
          return response;
        } catch (e) {
          const cached = await cache.match(req, { ignoreSearch: true });
          if (cached) return cached;
          return (await cache.match('index.html')) || (await cache.match('./')) || OFFLINE_PAGE.clone();
        }
      })
    );
    return;
  }

  const targetCache = isExternal(url) ? CDN_CACHE : SHELL_CACHE;
  // الملفات المحلية: الشبكة أولاً والكاش احتياط عند عدم الاتصال.
  // المكتبات الخارجية تبقى cache-first لتقليل التنزيلات.
  if (!isExternal(url)) {
    event.respondWith(
      caches.open(targetCache).then(async cache => {
        try {
          const response = await fetch(req, { cache: 'no-store' });
          if (isCacheableResponse(response, url)) cache.put(req, response.clone()).catch(() => {});
          return response;
        } catch (e) {
          return (await cache.match(req)) || Response.error();
        }
      })
    );
    return;
  }
  event.respondWith(
    caches.open(targetCache).then(async cache => {
      const cached = await cache.match(req);
      if (cached) return cached;
      const response = await fetch(req);
      if (isCacheableResponse(response, url)) cache.put(req, response.clone()).catch(() => {});
      return response;
    })
  );
});

// يسمح للصفحة بطلب تفعيل النسخة الجديدة فوراً
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
