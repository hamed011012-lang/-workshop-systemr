
  // بصمة النسخة الفعلية العاملة على هذا الجهاز — للتأكد من أن الملفات الجديدة وصلت
  (function stampBuild(){
    const el = document.getElementById('ws-build-stamp');
    if (el) el.textContent = 'نسخة ' + (window.WS_BUILD || '؟');
  })();

  function showLoading(v){ document.getElementById('loading-screen').classList.toggle('hidden', !v); }
  function showLoginError(msg){
    const el = document.getElementById('login-error');
    if (!msg){ el.style.display='none'; el.textContent=''; return; }
    el.textContent = msg; el.style.display='block';
  }
  function togglePassVisibility(){
    const inp = document.getElementById('login-password');
    inp.type = (inp.type === 'password') ? 'text' : 'password';
  }

  // رسالة قادمة من إعادة توجيه (مثلاً حساب غير مصرَّح له من صفحة أخرى)
  (function checkRedirectMessage(){
    const params = new URLSearchParams(window.location.search);
    const msg = params.get('msg');
    if (msg){
      const el = document.getElementById('login-notice');
      el.textContent = msg;
      el.style.display = 'block';
    }
  })();

  /* إعادة زر الدخول لحالته. كان التعطيل يُرفع في مسار الخطأ وحده،
     فمن يدخل بحساب صحيح لكن **غير مصرّح له** يرى رسالة الرفض والزر
     ما زال معطّلاً مكتوباً عليه «جاري الدخول...» — فلا يستطيع تجربة
     حساب آخر إلا بإعادة تحميل الصفحة كاملة. */
  function resetLoginBtn(){
    const btn = document.getElementById('login-btn');
    if (!btn) return;
    btn.disabled = false;
    btn.textContent = 'تسجيل الدخول';
  }

  async function doLogin(){
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    showLoginError('');
    if (!email || !password){ showLoginError('يرجى إدخال البريد الإلكتروني وكلمة المرور'); return; }
    if (!navigator.onLine){ showLoginError('🔴 لا يوجد اتصال بالإنترنت. أول تسجيل دخول على هذا الجهاز يحتاج شبكة، وبعدها يعمل النظام دون اتصال.'); return; }
    const btn = document.getElementById('login-btn');
    btn.disabled = true; btn.textContent = 'جاري الدخول...';
    try{
      // 8.9.2 — لا ندخل قبل ضبط نمط حفظ الجلسة (انظر wsAuthReady في shared.js)
      await Promise.resolve(window.wsAuthReady).catch(() => {});
      await auth.signInWithEmailAndPassword(email, password);
      // البقية تتولاها onAuthStateChanged أدناه
    }catch(e){
      let msg = 'تعذّر تسجيل الدخول، حاول مجدداً';
      if (e.code === 'auth/invalid-email') msg = 'صيغة البريد الإلكتروني غير صحيحة';
      else if (e.code === 'auth/user-not-found' || e.code === 'auth/invalid-credential') msg = 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
      else if (e.code === 'auth/wrong-password') msg = 'كلمة المرور غير صحيحة';
      else if (e.code === 'auth/too-many-requests') msg = 'محاولات كثيرة، يرجى الانتظار قليلاً والمحاولة مجدداً';
      else if (e.code === 'auth/network-request-failed') msg = 'لا يوجد اتصال بالإنترنت';
      showLoginError(msg);
      resetLoginBtn();
    }
  }
  document.getElementById('login-password').addEventListener('keydown', function(e){
    if (e.key === 'Enter') doLogin();
  });

  function initialsOf(name){
    if (!name) return '؟';
    const parts = name.trim().split(/\s+/);
    return parts[0].charAt(0);
  }

  async function showHub(shopUser){
    document.getElementById('hub-username').textContent = shopUser.name;
    // الاسم وحده فقط — بلا أي كلمة صفة تحته
    document.getElementById('hub-userrole').textContent = '';
    const avatar = document.getElementById('hub-avatar');
    avatar.textContent = initialsOf(shopUser.name);
    avatar.style.background = wsSafeColor(shopUser.color);   // 8.8.5

    // جلب اسم/شعار المحل الحقيقي إن وُجد في الإعدادات المخزّنة
    try{
      const doc = await db.collection('meta').doc('settings').get();
      if (doc.exists){
        const s = doc.data();
        if (s.name) document.getElementById('brand-name').textContent = s.name;
        if (s.tagline) document.getElementById('brand-tagline').textContent = s.tagline;
      }
    }catch(e){ /* تجاهل بصمت، الاسم الافتراضي يبقى معروضاً */ }

    /* ⚠️ 9.5.0 — قسم الفواتير للمدير وحده.
       البطاقة تحمل `hidden` في الوسم ولا تُكشف إلا هنا. والوسم أأمن من
       الإخفاء بالجافاسكربت: لو تعطّل السكربت لأي سبب بقيت مخفية، بدل أن
       تظهر لحظةً ثم تُخفى — وتلك اللحظة تكفي لضغطة. */
    const isMgr = (shopUser.role === 'manager') ||
                  (shopUser.email && shopUser.email === ADMIN_EMAIL);
    window.WSCanManageSystems=isMgr;
    const materialsCard=document.getElementById('module-materials');if(materialsCard)materialsCard.hidden=!isMgr;
    const systemsCard=document.getElementById('module-systems');if(systemsCard)systemsCard.hidden=!isMgr;
    const invCard = document.getElementById('module-invoices');
    if (invCard) { if (isMgr) invCard.removeAttribute('hidden'); else invCard.setAttribute('hidden',''); }
    // إدارة الأعضاء تظهر في اللوحة الرئيسية للمدير فقط.
    const memberAdminCard = document.getElementById('module-member-admin');
    const isPrimaryAdmin = !!(shopUser.email && ADMIN_EMAIL && String(shopUser.email).trim().toLowerCase() === String(ADMIN_EMAIL).trim().toLowerCase());
    if (memberAdminCard) { if (isPrimaryAdmin) memberAdminCard.removeAttribute('hidden'); else memberAdminCard.setAttribute('hidden',''); }
    try { applyModuleAccessUI(shopUser); } catch(e) {}
    const showSetting=(id,allowed)=>{const el=document.getElementById(id);if(el)el.hidden=!allowed;};
    showSetting('ws-settings-materials',isMgr);
    showSetting('ws-settings-systems',isMgr);
    showSetting('ws-settings-members',isPrimaryAdmin);


    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('hub-screen').classList.remove('hidden');
    showLoading(false);
  }

  let homeAuthResolved = false;
  const slowNoticeTimer = setTimeout(() => {
    const p = document.getElementById('loading-screen-text');
    if (p) p.textContent = navigator.onLine ? 'الاتصال بطيء، جارٍ المحاولة...' : '🔴 لا يوجد اتصال بالإنترنت حالياً — سيتم الدخول تلقائياً فور عودته';
  }, 6000);

  // حارس واجهة: إذا لم يُرجع Firebase حالة الجلسة، لا نترك المستخدم
  // أمام شاشة تحميل تغطي نموذج الدخول بلا نهاية. إذا وصلت الحالة لاحقاً
  // فسيحدّث المستمع الشاشة بصورة طبيعية.
  const homeAuthFallback = setTimeout(() => {
    if (homeAuthResolved) return;
    showLoading(false);
    document.getElementById('hub-screen').classList.add('hidden');
    document.getElementById('login-screen').classList.remove('hidden');
    showLoginError(navigator.onLine
      ? 'تعذّر التحقق من الجلسة بعد الانتظار. يمكنك تجربة الدخول مجدداً.'
      : 'لا يوجد اتصال بالإنترنت. اتصل بالشبكة ثم حاول تسجيل الدخول.');
    resetLoginBtn();
  }, 12000);

  auth.onAuthStateChanged(async function(user){
    homeAuthResolved = true;
    clearTimeout(slowNoticeTimer);
    clearTimeout(homeAuthFallback);
    if (!user){
      showLoading(false);
      document.getElementById('hub-screen').classList.add('hidden');
      document.getElementById('login-screen').classList.remove('hidden');
      resetLoginBtn();
      return;
    }
    showLoading(true);
    try {
      const shopUser = await resolveShopUser(user);
      if (!shopUser){
        await auth.signOut().catch(()=>{});
        showLoading(false);
        document.getElementById('login-screen').classList.remove('hidden');
        showLoginError(wsAuthFailureMessage());
        resetLoginBtn();
        return;
      }
      await showHub(shopUser);
    } catch (e) {
      console.error('Home auth/bootstrap failed:', e);
      showLoading(false);
      document.getElementById('hub-screen').classList.add('hidden');
      document.getElementById('login-screen').classList.remove('hidden');
      showLoginError(navigator.onLine
        ? 'حدث خطأ أثناء تجهيز الصفحة. أعد المحاولة أو حدّث الصفحة.'
        : 'انقطع الاتصال أثناء التحقق من الحساب. اتصل بالإنترنت ثم حاول مجدداً.');
      resetLoginBtn();
    }
  }, function(error) {
    homeAuthResolved = true;
    clearTimeout(slowNoticeTimer);
    clearTimeout(homeAuthFallback);
    console.error('Home auth listener failed:', error);
    showLoading(false);
    document.getElementById('hub-screen').classList.add('hidden');
    document.getElementById('login-screen').classList.remove('hidden');
    showLoginError('تعذّر التحقق من تسجيل الدخول. تحقق من الاتصال ثم أعد المحاولة.');
    resetLoginBtn();
  });
