/* Namespaced storage v139 with safe JSON and bounded collections. */
(function (g) {
  'use strict'; if (g.AppStorage) return;
  const NS = 'ws:v138:';
  const key = k => NS + String(k || '');
  const get = (k, fallback) => { try { const v = localStorage.getItem(key(k)); return v == null ? fallback : JSON.parse(v); } catch (_) { return fallback; } };
  const set = (k, v) => { try { localStorage.setItem(key(k), JSON.stringify(v)); return true; } catch (_) { return false; } };
  const remove = k => { try { localStorage.removeItem(key(k)); } catch (_) {} };
  const pushBounded = (k, item, max) => { const a = Array.isArray(get(k, [])) ? get(k, []) : []; a.push(item); set(k, a.slice(-Math.max(1, max || 100))); return a.length; };
  g.AppStorage = Object.freeze({ namespace: NS, key, get, set, remove, pushBounded });
})(window);
