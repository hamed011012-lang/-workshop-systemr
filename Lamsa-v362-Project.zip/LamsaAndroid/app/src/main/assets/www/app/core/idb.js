/* Workshop Core v139 — IndexedDB durable local store.
 * This is an additive foundation: existing Firebase offline behaviour remains intact.
 * No business page depends on this file yet, so rollout is safe and incremental.
 */
(function (g) {
  'use strict';
  if (g.AppDB) return;

  const DB_NAME = 'workshop-system';
  const DB_VERSION = 3;
  const STORES = ['records', 'outbox', 'idempotency', 'audit', 'meta', 'conflicts', 'revisions'];
  let opening = null;
  let db = null;

  function open() {
    if (db) return Promise.resolve(db);
    if (opening) return opening;
    if (!('indexedDB' in g)) return Promise.reject(new Error('IndexedDB غير متاح'));
    opening = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains('records')) {
          const s = d.createObjectStore('records', { keyPath: 'key' });
          s.createIndex('collection', 'collection', { unique: false });
          s.createIndex('updatedAt', 'updatedAt', { unique: false });
        }
        if (!d.objectStoreNames.contains('outbox')) {
          const s = d.createObjectStore('outbox', { keyPath: 'id' });
          s.createIndex('status', 'status', { unique: false });
          s.createIndex('createdAt', 'createdAt', { unique: false });
        }
        if (!d.objectStoreNames.contains('idempotency')) {
          const s = d.createObjectStore('idempotency', { keyPath: 'key' });
          s.createIndex('createdAt', 'createdAt', { unique: false });
        }
        if (!d.objectStoreNames.contains('audit')) {
          const s = d.createObjectStore('audit', { keyPath: 'id' });
          s.createIndex('at', 'at', { unique: false });
          s.createIndex('type', 'type', { unique: false });
        }
        if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta', { keyPath: 'key' });
        if (!d.objectStoreNames.contains('conflicts')) {
          const s = d.createObjectStore('conflicts', { keyPath: 'id' });
          s.createIndex('status', 'status', { unique: false });
          s.createIndex('createdAt', 'createdAt', { unique: false });
          s.createIndex('entity', 'entity', { unique: false });
        }
        if (!d.objectStoreNames.contains('revisions')) {
          const s = d.createObjectStore('revisions', { keyPath: 'key' });
          s.createIndex('entity', 'entity', { unique: false });
          s.createIndex('entityId', 'entityId', { unique: false });
          s.createIndex('createdAt', 'createdAt', { unique: false });
          s.createIndex('operationId', 'operationId', { unique: false });
        }
      };
      req.onsuccess = () => { db = req.result; db.onversionchange = () => { try { db.close(); } catch (_) {} db = null; }; resolve(db); };
      req.onerror = () => reject(req.error || new Error('فشل فتح قاعدة البيانات المحلية'));
      req.onblocked = () => console.warn('[AppDB] فتح قاعدة البيانات محجوب بتبويب قديم');
    }).finally(() => { opening = null; });
    return opening;
  }

  function tx(store, mode, fn) {
    return open().then(d => new Promise((resolve, reject) => {
      let value;
      const t = d.transaction(store, mode);
      try { value = fn(t.objectStore(store)); } catch (e) { reject(e); return; }
      t.oncomplete = () => resolve(value);
      t.onerror = () => reject(t.error || new Error('فشلت العملية المحلية'));
      t.onabort = () => reject(t.error || new Error('أُلغيت العملية المحلية'));
    }));
  }

  function put(store, value) { return tx(store, 'readwrite', s => s.put(value)); }
  function add(store, value) { return tx(store, 'readwrite', s => s.add(value)); }
  function get(store, key) { return open().then(d => new Promise((resolve, reject) => { const r = d.transaction(store, 'readonly').objectStore(store).get(key); r.onsuccess = () => resolve(r.result || null); r.onerror = () => reject(r.error); })); }
  function del(store, key) { return tx(store, 'readwrite', s => s.delete(key)); }
  function clear(store) { return tx(store, 'readwrite', s => s.clear()); }
  function count(store) { return open().then(d => new Promise((resolve, reject) => { const r = d.transaction(store, 'readonly').objectStore(store).count(); r.onsuccess = () => resolve(r.result || 0); r.onerror = () => reject(r.error); })); }
  function list(store, limit) {
    const max = Math.max(1, Number(limit) || 500);
    return open().then(d => new Promise((resolve, reject) => {
      const out = [], r = d.transaction(store, 'readonly').objectStore(store).openCursor(null, 'prev');
      r.onsuccess = () => { const c = r.result; if (!c || out.length >= max) return resolve(out); out.push(c.value); c.continue(); };
      r.onerror = () => reject(r.error);
    }));
  }

  async function health() {
    try { await open(); return { available: true, name: DB_NAME, version: DB_VERSION, stores: STORES.slice() }; }
    catch (error) { return { available: false, name: DB_NAME, version: DB_VERSION, error: String(error && error.message || error) }; }
  }

  g.AppDB = Object.freeze({ name: DB_NAME, version: DB_VERSION, stores: STORES.slice(), open, put, add, get, del, clear, count, list, health });
})(window);
