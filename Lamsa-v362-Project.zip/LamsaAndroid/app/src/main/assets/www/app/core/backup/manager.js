/* Workshop Backup Manager v243
 * Backup integrity hardening: deterministic envelope, dual checksum, optional SHA-256,
 * strict restore validation and bounded input size. No Firebase writes occur here.
 */
(function(g){'use strict'; if(g.AppBackup)return;
  const FORMAT='workshop-backup';
  const SCHEMA=2;
  const MAX_TEXT_BYTES=50*1024*1024;
  const clone=v=>JSON.parse(JSON.stringify(v));
  function stable(v){
    if(v===null||typeof v!=='object') return JSON.stringify(v);
    if(Array.isArray(v)) return '['+v.map(stable).join(',')+']';
    return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}';
  }
  function checksum(value){
    const s=typeof value==='string'?value:stable(value); let h=2166136261;
    for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);} return (h>>>0).toString(16).padStart(8,'0');
  }
  function checksum2(value){
    const s=typeof value==='string'?value:stable(value); let a=0x811c9dc5,b=0x9e3779b9;
    for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);a=Math.imul(a^c,16777619);b=Math.imul((b^((c<<1)|(c>>>15)))>>>0,2246822519);}
    return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0');
  }
  function byteLength(s){try{return new TextEncoder().encode(s).length;}catch(_){return unescape(encodeURIComponent(s)).length;}}
  function create(data,meta){
    const payload=clone(data||{}), canonical=stable(payload);
    return {format:FORMAT,schemaVersion:SCHEMA,appVersion:String(meta&&meta.appVersion||'v243'),createdAt:new Date().toISOString(),checksum:checksum(canonical),checksum2:checksum2(canonical),dataBytes:byteLength(canonical),data:payload};
  }
  async function sha256(s){
    if(g.crypto&&g.crypto.subtle&&g.TextEncoder){const b=await g.crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');}
    return null;
  }
  async function createAsync(data,meta){
    const out=create(data,meta), canonical=stable(out.data), digest=await sha256(canonical);
    if(digest) out.sha256=digest;
    return out;
  }
  function isEnvelope(x){return !!(x&&typeof x==='object'&&x.format===FORMAT&&x.data&&typeof x.data==='object');}
  function normalize(input){
    const x=input&&typeof input==='object'?input:null;
    if(!x) throw new Error('BACKUP_NOT_OBJECT');
    if(isEnvelope(x)){
      if(Number(x.schemaVersion)>SCHEMA) throw new Error('BACKUP_NEWER_THAN_APP');
      const canonical=stable(x.data), actual=checksum(canonical), actual2=checksum2(canonical);
      if(String(x.checksum||'')!==actual || (x.checksum2!==undefined&&String(x.checksum2)!==actual2)) throw new Error('BACKUP_CORRUPTED');
      if(x.dataBytes!==undefined && Number(x.dataBytes)!==byteLength(canonical)) throw new Error('BACKUP_SIZE_MISMATCH');
      return {data:clone(x.data),legacy:false,schemaVersion:Number(x.schemaVersion||1),appVersion:x.appVersion||'unknown',createdAt:x.createdAt||null,sha256:x.sha256||null};
    }
    if(Array.isArray(x.sales)||Array.isArray(x.store)) return {data:clone(x),legacy:true,schemaVersion:1,appVersion:'legacy',createdAt:null,sha256:null};
    throw new Error('BACKUP_UNSUPPORTED');
  }
  async function verifyAsync(input){
    const n=normalize(input); if(n.legacy||!n.sha256)return {ok:true,sha256Checked:false,legacy:n.legacy};
    const actual=await sha256(stable(n.data));
    if(!actual||actual!==String(n.sha256)) throw new Error('BACKUP_SHA256_MISMATCH');
    return {ok:true,sha256Checked:true,legacy:false};
  }
  function validateRestoreData(data,opts){
    const x=data&&typeof data==='object'?data:null;
    if(!x||Array.isArray(x)) throw new Error('RESTORE_DATA_INVALID');
    const collections=Array.isArray(opts&&opts.collections)?opts.collections:[];
    for(const key of collections){
      if(x[key]===undefined) continue;
      if(!Array.isArray(x[key])) throw new Error('RESTORE_COLLECTION_NOT_ARRAY:'+key);
      const ids=new Set();
      for(const item of x[key]){
        if(!item||typeof item!=='object'||Array.isArray(item)) throw new Error('RESTORE_RECORD_INVALID:'+key);
        for(const bad of ['__proto__','constructor','prototype']) if(Object.prototype.hasOwnProperty.call(item,bad)) throw new Error('RESTORE_UNSAFE_KEY:'+key);
        if(item.id!==undefined){const id=String(item.id);if(!id||id.length>512)throw new Error('RESTORE_ID_INVALID:'+key);if(ids.has(id))throw new Error('RESTORE_DUPLICATE_ID:'+key+':'+id);ids.add(id);}
      }
    }
    if(x.creditBalances!==undefined){
      if(!x.creditBalances||typeof x.creditBalances!=='object'||Array.isArray(x.creditBalances))throw new Error('RESTORE_CREDITS_INVALID');
      for(const [name,amount] of Object.entries(x.creditBalances)){if(['__proto__','constructor','prototype'].includes(name))throw new Error('RESTORE_UNSAFE_CREDIT_KEY');const n=Number(amount);if(!Number.isFinite(n)||n<0)throw new Error('RESTORE_CREDIT_AMOUNT_INVALID');}
    }
    if(x.settings!==undefined&&(!x.settings||typeof x.settings!=='object'||Array.isArray(x.settings)))throw new Error('RESTORE_SETTINGS_INVALID');
    return true;
  }
  function preflightRestore(data,opts){
    validateRestoreData(data,opts);
    const issues=[];
    if(g.FinancialIntegrity){const r=g.FinancialIntegrity.scan(data);if(!r.ok)issues.push(...r.issues.map(x=>({type:'financial-integrity',...x})));}
    if(g.FinancialTamper){const r=g.FinancialTamper.scan(data);if(!r.ok)issues.push(...r.issues);}
    if(issues.length) {const e=new Error('RESTORE_FINANCIAL_INTEGRITY_FAILED');e.issues=issues;throw e;}
    return {ok:true};
  }
  function stringify(data,meta){return JSON.stringify(create(data,meta));}
  async function stringifyAsync(data,meta){return JSON.stringify(await createAsync(data,meta));}
  async function parseAsync(text){
    const raw=String(text||'');if(byteLength(raw)>MAX_TEXT_BYTES)throw new Error('BACKUP_TOO_LARGE');
    const input=JSON.parse(raw);const n=normalize(input);await verifyAsync(input);return n;
  }
  function parse(text){const raw=String(text||'');if(byteLength(raw)>MAX_TEXT_BYTES)throw new Error('BACKUP_TOO_LARGE');return normalize(JSON.parse(raw));}
  g.AppBackup=Object.freeze({FORMAT,SCHEMA,MAX_TEXT_BYTES,checksum,checksum2,create,createAsync,stringify,stringifyAsync,parse,parseAsync,normalize,verifyAsync,isEnvelope,validateRestoreData,preflightRestore});
})(window);
