
(function () {
  let localSecondaryAuth = null;
  const getEl = id => document.getElementById(id);
  const showMsg = (text, ok=false) => { const el=getEl('member-msg'); if(el){el.style.color=ok?'#179baa':'#ed4832';el.textContent=text;} };
  function getSecondaryAuth() {
    if (localSecondaryAuth) return localSecondaryAuth;
    try { localSecondaryAuth = firebase.app('secondary').auth(); return localSecondaryAuth; } catch (_) {}
    const app = firebase.initializeApp(firebaseConfig, 'secondary-add-member');
    localSecondaryAuth = app.auth();
    return localSecondaryAuth;
  }
  async function addNewMemberFromNewButton() {
    const btn=getEl('add-member-btn-new');
    const nameEl=getEl('newmember-name'), emailEl=getEl('newmember-email'), passEl=getEl('newmember-password');
    const roleEl=getEl('newmember-role'), accessEl=getEl('newmember-access');
    try {
      if(!btn||!nameEl||!emailEl||!passEl||!roleEl||!accessEl) return showMsg('❌ نموذج إضافة العضو غير مكتمل.');
      const current=(typeof auth!=='undefined')?auth.currentUser:null;
      const adminEmail=(typeof ADMIN_EMAIL!=='undefined')?ADMIN_EMAIL:'hamed011012@gmail.com';
      if(!current || String(current.email||'').toLowerCase()!==adminEmail.toLowerCase()) return showMsg('⛔ يجب أن تكون داخل حساب المشرف الأساسي.');
      if(!navigator.onLine) return showMsg('🔴 إضافة عضو جديد تحتاج إلى الإنترنت.');
      const name=nameEl.value.trim(), email=emailEl.value.trim().toLowerCase(), pass=passEl.value;
      const role=roleEl.value==='manager'?'manager':'employee';
      const choice=accessEl.value||'measurements';
      const access=role==='manager'?{measurements:true,cutting:true}:{measurements:choice==='measurements'||choice==='both',cutting:choice==='cutting'||choice==='both'};
      if(!name) return showMsg('⚠️ أدخل اسم العضو.');
      if(!/^\S+@\S+\.\S+$/.test(email)) return showMsg('⚠️ أدخل بريداً إلكترونياً صحيحاً.');
      if(pass.length<6) return showMsg('⚠️ كلمة المرور يجب أن تكون 6 أحرف على الأقل.');
      if(email===adminEmail.toLowerCase()) return showMsg('⚠️ هذا البريد محجوز للمشرف.');
      btn.disabled=true; btn.style.opacity='.7'; btn.textContent='⏳ جارٍ إنشاء العضو...';
      showMsg('⏳ جارٍ إنشاء الحساب...',true);
      const secondary=getSecondaryAuth();
      try{await secondary.signOut();}catch(_){ }
      const cred=await secondary.createUserWithEmailAndPassword(email,pass);
      const uid=cred.user.uid;
      await db.collection('members').doc(uid).set({name,email,role,access,color:'#199959',addedAt:firebase.firestore.FieldValue.serverTimestamp(),addedBy:current.email||adminEmail});
      try{await secondary.signOut();}catch(_){ }
      showMsg('✅ تم إنشاء العضو وحفظه بنجاح.',true);
      nameEl.value=''; emailEl.value=''; passEl.value=''; roleEl.value='employee'; accessEl.value='measurements';
      if(typeof renderMembersListUI==='function') renderMembersListUI();
    } catch(e) {
      console.error('ADD MEMBER NEW BUTTON ERROR',e);
      const c=e&&e.code||''; let t='❌ تعذّرت إضافة العضو.';
      if(c==='auth/email-already-in-use')t='❌ هذا البريد مستخدم مسبقاً.';
      else if(c==='auth/invalid-email')t='❌ صيغة البريد الإلكتروني غير صحيحة.';
      else if(c==='auth/weak-password')t='❌ كلمة المرور ضعيفة؛ استخدم 6 أحرف على الأقل.';
      else if(c==='auth/network-request-failed')t='📶 تعذر الاتصال بـ Firebase.';
      else if(c==='auth/operation-not-allowed')t='⚠️ فعّل تسجيل الدخول بالبريد وكلمة المرور من Firebase Authentication.';
      else if(c==='permission-denied'||/Missing or insufficient permissions/i.test(e&&e.message||''))t='⛔ Firestore رفض حفظ العضو. تحقق من قواعد members.';
      else if(e&&e.message)t+=' '+e.message;
      showMsg(t);
    } finally {
      if(btn){btn.disabled=false;btn.style.opacity='';btn.textContent='👤 إضافة العضو — زر جديد';}
    }
  }
  const newMemberButton=getEl('add-member-btn-new');
  if(newMemberButton) newMemberButton.addEventListener('click', addNewMemberFromNewButton);

  window.addNewMember = async function () {
    const btn=getEl('add-member-btn'), nameEl=getEl('newmember-name'), emailEl=getEl('newmember-email'), passEl=getEl('newmember-password'), roleEl=getEl('newmember-role'), accessEl=getEl('newmember-access');
    try {
      if(!btn||!nameEl||!emailEl||!passEl||!roleEl||!accessEl) return showMsg('❌ نموذج إضافة العضو غير مكتمل.');
      const current=(typeof auth!=='undefined')?auth.currentUser:null;
      const adminEmail=(typeof ADMIN_EMAIL!=='undefined')?ADMIN_EMAIL:'hamed011012@gmail.com';
      if(!current || String(current.email||'').toLowerCase()!==adminEmail.toLowerCase()) return showMsg('⛔ يجب أن تكون داخل حساب المشرف الأساسي.');
      if(!navigator.onLine) return showMsg('🔴 إضافة عضو جديد تحتاج إلى الإنترنت.');
      const name=nameEl.value.trim(), email=emailEl.value.trim().toLowerCase(), pass=passEl.value;
      const role=roleEl.value==='manager'?'manager':'employee', choice=accessEl.value||'measurements';
      const access=role==='manager'?{measurements:true,cutting:true}:{measurements:choice==='measurements'||choice==='both',cutting:choice==='cutting'||choice==='both'};
      if(!name) return showMsg('⚠️ أدخل اسم العضو.');
      if(!/^\S+@\S+\.\S+$/.test(email)) return showMsg('⚠️ أدخل بريداً إلكترونياً صحيحاً.');
      if(pass.length<6) return showMsg('⚠️ كلمة المرور يجب أن تكون 6 أحرف على الأقل.');
      if(email===adminEmail.toLowerCase()) return showMsg('⚠️ هذا البريد محجوز للمشرف.');
      btn.disabled=true; btn.style.opacity='.7'; btn.textContent='⏳ جارٍ إنشاء العضو...'; showMsg('⏳ جارٍ إنشاء الحساب...',true);
      const secondary=getSecondaryAuth();
      try{await secondary.signOut();}catch(_){ }
      const cred=await secondary.createUserWithEmailAndPassword(email,pass);
      const uid=cred.user.uid;
      await db.collection('members').doc(uid).set({name,email,role,access,color:'#199959',addedAt:firebase.firestore.FieldValue.serverTimestamp(),addedBy:current.email||adminEmail});
      try{await secondary.signOut();}catch(_){ }
      showMsg('✅ تم إنشاء العضو وحفظه بنجاح.',true);
      nameEl.value=''; emailEl.value=''; passEl.value=''; roleEl.value='employee'; accessEl.value='measurements';
      if(typeof renderMembersListUI==='function') renderMembersListUI();
    }catch(e){
      console.error('ADD MEMBER ERROR',e);
      const c=e&&e.code||''; let t='❌ تعذّرت إضافة العضو.';
      if(c==='auth/email-already-in-use')t='❌ هذا البريد مستخدم مسبقاً.';
      else if(c==='auth/invalid-email')t='❌ صيغة البريد الإلكتروني غير صحيحة.';
      else if(c==='auth/weak-password')t='❌ كلمة المرور ضعيفة.';
      else if(c==='auth/network-request-failed')t='📶 تعذر الاتصال بـ Firebase.';
      else if(c==='auth/operation-not-allowed')t='⚠️ فعّل تسجيل الدخول بالبريد وكلمة المرور من Firebase Authentication.';
      else if(c==='permission-denied'||/Missing or insufficient permissions/i.test(e&&e.message||''))t='⛔ Firestore رفض حفظ العضو. تحقق من قواعد members.';
      else if(e&&e.message)t+=' '+e.message;
      showMsg(t);
    }finally{if(btn){btn.disabled=false;btn.style.opacity='';btn.textContent='➕ إضافة العضو الآن';}}
  };
})();
