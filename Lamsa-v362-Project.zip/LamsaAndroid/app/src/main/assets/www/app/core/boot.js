(function (g) {
  'use strict';
  const VERSION='v299';
  function registerSW(){ if(!('serviceWorker' in navigator)) return; navigator.serviceWorker.register('./sw.js?v='+VERSION,{updateViaCache:'none'}).catch(()=>{}); }
  async function init(){
    const p=document.body&&document.body.dataset&&document.body.dataset.page || location.pathname.split('/').pop() || 'index.html';
    document.documentElement.dataset.wsVersion=VERSION;
    document.documentElement.dataset.wsPage=p;
    registerSW();
    if (g.AppDB) {
      try { const h=await g.AppDB.health(); g.AppDiagnostics && g.AppDiagnostics.record && g.AppDiagnostics.record('local-db', h); }
      catch (_) {}
    }
    if(g.AppEvents) g.AppEvents.emit('boot:ready',{page:p,version:VERSION});
  }
  if(g.AppRuntime) g.AppRuntime.ready(init); else if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true}); else init();
})(window);
