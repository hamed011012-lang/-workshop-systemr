from pathlib import Path
import json,xml.etree.ElementTree as ET
root=Path('app/src/main/assets/www');s=(root/'app/opening-symbols.js').read_text();data=json.loads(s.split('const catalog=')[1].split(';\nconst byId')[0]);assert len({x['id'] for x in data})==len(data)
new=[x for x in data if x.get('group') in ['partitions','facades','balconies'] and '-opening-' not in x['id']];assert len(new)==38
for item in data:ET.parse(root/('assets/openings/'+item['id']+'.svg'))
for p in (root/'assets/openings').glob('door*.svg'):
 tree=ET.parse(p);paths=[e for e in tree.iter() if e.tag.endswith('path')];assert any(' V' in e.get('d','') and 'H' in e.get('d','') for e in paths),p
for item in new:assert not item['pvc'] and not item['alum'],'complex symbols must not assume a simple cutting formula'
print('PASS: 38 new symbols; unique catalogue; all SVG resources parse; door frames open; complex symbols need explicit formulas.')
