const fs=require('fs'),vm=require('vm'),assert=require('assert');
const base='app/src/main/assets/www/';
const solve=require('../'+base+'app/cut-optimizer.js').solve;
let p=solve([312,312,312,312,102,102,102,102].map((length,i)=>({length,source:1+i%2})),580);assert.equal(p.rods.length,4);assert(p.optimal);assert.equal(p.rods.reduce((n,r)=>n+580-r.used,0),664);
p=solve([60,50,30,20,20,20].map(length=>({length,source:1})),100);assert.equal(p.rods.length,2);assert(p.optimal);
p=solve([{length:290},{length:290}],580,.3);assert.equal(p.rods.length,2);assert(solve([{length:581}],580).invalid);
let code=fs.readFileSync(base+'app/pages/cutting.js','utf8');code=code.slice(code.indexOf('    function wsStockLength('),code.indexOf('    function wsRefreshRowFormula('));
const store={};const ctx={window:{WSCutOptimizer:{solve}},localStorage:{getItem:k=>store[k]||null},setTimeout(){},document:{},console};vm.createContext(ctx);vm.runInContext(code,ctx);
const row=(index,type='window_double',profileName='A')=>({index,type,profileName,w:300,h:90,res:{'عرض الضلفة':146,'ارتفاع الضلفة':82},materialRows:[{name:'شمبرلي'}]});
let plans=ctx.wsBuildCutPlan([row(1),row(2)],0);assert.equal(plans.get('pvc مفصلي — A|شمبرلي|580').rods.length,4);assert.equal(plans.get('pvc مفصلي — A|ضلفة النافذة|580').pieces.length,16);
plans=ctx.wsBuildCutPlan([row(1,'door_single'),row(2)],0);assert(plans.has('pvc مفصلي — A|ضلفة الباب|580'));assert(plans.has('pvc مفصلي — A|ضلفة النافذة|580'));assert.equal(plans.get('pvc مفصلي — A|ضلفة الباب|580').pieces.length,4);
store.ws_pvc_stock_cm='600';plans=ctx.wsBuildCutPlan([row(1),row(2,'window_double','B')],0);assert(plans.has('pvc مفصلي — A|شمبرلي|600'));assert(plans.has('pvc مفصلي — B|شمبرلي|600'));
plans=ctx.wsBuildCutPlan([row(1,'aluminum_window_double')],0);assert(plans.has('المونيوم مفصلي — A|حلق المونيوم|650'));
const r=row(1);r.rawEdits=[{name:'ضلفة النافذة',unit:'عود',base:'original',factor:1,rod:700}];plans=ctx.wsBuildCutPlan([r],0);assert(plans.has('pvc مفصلي — A|ضلفة النافذة|700'));
function brute(a,cap){a.sort((a,b)=>b-a);let best=a.length;const used=[];function go(i){if(i===a.length){best=Math.min(best,used.length);return;}const seen=new Set();for(let j=0;j<used.length;j++){if(seen.has(used[j])||used[j]+a[i]>cap)continue;seen.add(used[j]);used[j]+=a[i];go(i+1);used[j]-=a[i];}if(used.length+1<best){used.push(a[i]);go(i+1);used.pop();}}go(0);return best;}
let seed=355;for(let t=0;t<100;t++){let a=Array.from({length:8},()=>{seed=(seed*16807)%2147483647;return 10+seed%81;});p=solve(a.map((length,i)=>({length,source:i})),100);assert.equal(p.rods.length,brute(a.slice(),100));assert.equal(p.rods.reduce((n,r)=>n+r.pieces.length,0),a.length);for(const rod of p.rods)assert(rod.used<=100);}
console.log('PASS: example 4 rods, exact search, 100 brute-force comparisons, kerf, oversize, material rows, profile isolation, window/door isolation, PVC/aluminium stock, material stock overrides.');
