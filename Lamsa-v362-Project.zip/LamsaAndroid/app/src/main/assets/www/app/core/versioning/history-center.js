/* Workshop History Center v155 — read-only change history UI. */
(function(g){'use strict'; if(g.AppHistoryCenter)return;
  const esc=s=>String(s==null?'':s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const pretty=v=>{try{return JSON.stringify(v,null,2);}catch(_){return String(v);}};
  function ensure(){
    let el=document.getElementById('ws-history-center'); if(el)return el;
    el=document.createElement('div'); el.id='ws-history-center'; el.className='fixed inset-0 z-[1900] hidden items-center justify-center p-3';
    el.style.cssText='background:rgba(15,23,42,.45);backdrop-filter:blur(3px);';
    el.innerHTML='<div class="bg-white w-full max-w-2xl max-h-[88vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col">'+
      '<div class="px-4 py-3 border-b flex items-center justify-between"><div><div class="font-black text-slate-800">📋 سجل التعديلات</div><div id="ws-history-sub" class="text-[11px] text-slate-500 mt-0.5">قراءة فقط — لا يتم تعديل البيانات</div></div><button type="button" id="ws-history-close" class="w-9 h-9 rounded-xl bg-slate-100 font-black">×</button></div>'+
      '<div id="ws-history-list" class="p-3 overflow-auto space-y-2"></div></div>';
    document.body.appendChild(el); el.querySelector('#ws-history-close').onclick=close; el.addEventListener('click',e=>{if(e.target===el)close();}); return el;
  }
  function close(){const el=document.getElementById('ws-history-center'); if(el){el.classList.add('hidden');el.classList.remove('flex');}}
  function open(){const el=ensure();el.classList.remove('hidden');el.classList.add('flex');}
  async function load(opts){
    const el=ensure(), list=el.querySelector('#ws-history-list'), sub=el.querySelector('#ws-history-sub'); list.innerHTML='<div class="text-center text-sm text-slate-400 py-8">جارٍ تحميل السجل…</div>';
    const entity=opts&&opts.entity, id=opts&&opts.entityId;
    sub.textContent=entity?(id?'سجل '+entity+' رقم '+id:'سجل '+entity):'آخر التعديلات المسجلة محليًا';
    let rows=[];
    try{
      if(g.AppFieldRevisions&&g.AppFieldRevisions.list) rows=await g.AppFieldRevisions.list(entity,id,120);
      if(!rows.length&&g.AppVersioning&&g.AppVersioning.list) rows=await g.AppVersioning.list(entity,id,120);
    }catch(e){ rows=[]; }
    if(!rows.length){list.innerHTML='<div class="text-center text-sm text-slate-500 py-10">لا توجد تعديلات مسجلة لهذا السجل.</div>';return;}
    list.innerHTML=rows.map((r,i)=>{const changes=r.changes||[]; const title=changes.length?('تم تعديل '+changes.length+' حقل'):('إصدار '+(r.version||0)); const when=new Date(r.createdAt||Date.now()).toLocaleString('ar-LY'); const body=changes.slice(0,30).map(c=>'<div class="bg-slate-50 rounded-xl p-2"><div class="font-bold text-xs text-slate-700">'+esc(c.path)+'</div><div class="text-[11px] text-slate-500 mt-1 break-words">'+esc(pretty(c.before))+' <span class="font-black">←</span> '+esc(pretty(c.after))+'</div></div>').join(''); return '<details class="border border-slate-200 rounded-2xl p-3" '+(i===0?'open':'')+'><summary class="cursor-pointer list-none"><div class="flex items-center justify-between gap-2"><div><div class="font-black text-sm text-slate-800">'+esc(title)+'</div><div class="text-[10px] text-slate-400 mt-1">'+esc(when)+' · الإصدار '+esc(r.version||0)+'</div></div><span class="text-[10px] text-slate-400">'+esc(r.operationId||'')+'</span></div></summary><div class="mt-3 space-y-1.5">'+(body||'<div class="text-xs text-slate-400">لا توجد فروقات تفصيلية.</div>')+'</div><div class="pt-2 flex justify-end"><button type="button" data-ws-restore="1" data-entity="'+esc(entity||'')+'" data-entity-id="'+esc(id||'')+'" data-version="'+esc(r.version||0)+'" class="text-[11px] font-black px-3 py-2 rounded-xl bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100">↩️ استعادة هذه النسخة</button></div></details>';}).join('');
    list.querySelectorAll('[data-ws-restore]').forEach(btn=>btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();restoreVersion(btn.dataset.entity,btn.dataset.entityId,btn.dataset.version);}));

  }
  async function restoreVersion(entity,entityId,version){
    if(!g.AppRestoreCenter||!g.AppRestoreCenter.preview) return alert('مركز الاستعادة غير متاح حالياً.');
    try{
      const p=await g.AppRestoreCenter.preview({entity,entityId,version});
      if(!p.adapter){ alert('الاستعادة الآمنة لهذا النوع لم تُفعّل بعد. السجل متاح للمراجعة فقط.'); return; }
      const ok=confirm('سيتم إنشاء عملية جديدة تستعيد الإصدار '+version+' دون حذف سجل التاريخ.\n\nإذا تم تعديل السجل بعد فتح هذه النافذة سيمنع النظام الاستعادة تلقائياً.\n\nهل تريد المتابعة؟');
      if(!ok)return;
      const result=await g.AppRestoreCenter.apply({entity,entityId,version},{expectedCurrentVersion:p.current.version});
      alert(result.status==='already-restored'?'تمت هذه الاستعادة مسبقاً.':'تمت الاستعادة كعملية جديدة، ولم يتم حذف سجل التعديلات.');
      await load({entity,entityId});
    }catch(e){alert('تعذر تنفيذ الاستعادة بأمان: '+String(e&&e.message||e));}
  }
  async function show(opts){open();await load(opts||{});}
  g.AppHistoryCenter=Object.freeze({show,open,close,load,restoreVersion});
})(window);
